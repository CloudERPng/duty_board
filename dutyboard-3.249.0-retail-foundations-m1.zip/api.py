from datetime import datetime, time as dtime

import pytz

import frappe
from frappe import _
from duty_board.permissions import require_staff
from frappe.utils import (
	add_days,
	cint,
	getdate,
	now_datetime,
	time_diff_in_seconds,
	today,
)

END_OF_DAY = "End of day"
AUTO_PREFIX = "Auto clock-out"
EXPECTED_DUTY_HOURS = 8
EXPECTED_BREAK_HOURS = 1
ALLOWED_EMOJIS = ["👍", "❤️", "😂", "🎉", "✅", "👀"]


# ---------------- Timezone helpers ----------------


def _system_tz():
	try:
		from frappe.utils import get_system_timezone

		return pytz.timezone(get_system_timezone())
	except Exception:
		return pytz.timezone(
			frappe.db.get_single_value("System Settings", "time_zone") or "UTC"
		)


def _user_tz(user):
	cache = getattr(frappe.local, "duty_tz_cache", None)
	if cache is None:
		cache = {}
		frappe.local.duty_tz_cache = cache
	if user not in cache:
		tz_name = frappe.db.get_value("User", user, "time_zone")
		try:
			cache[user] = pytz.timezone(tz_name) if tz_name else _system_tz()
		except Exception:
			cache[user] = _system_tz()
	return cache[user]


def user_now(user):
	"""Current time in the user's own timezone (aware)."""
	return _system_tz().localize(now_datetime()).astimezone(_user_tz(user))


def user_today(user):
	"""The user's local calendar date right now."""
	return user_now(user).date()


def user_day_window(user, day=None):
	"""The user's local day expressed as naive system-timezone datetimes,
	for querying log_time / start_time columns."""
	day = day or user_today(user)
	utz = _user_tz(user)
	stz = _system_tz()
	start = utz.localize(datetime.combine(day, dtime.min)).astimezone(stz)
	end = utz.localize(datetime.combine(day, dtime.max)).astimezone(stz)
	return start.replace(tzinfo=None), end.replace(tzinfo=None)


def _is_break(reason):
	reason = reason or ""
	return reason != END_OF_DAY and not reason.startswith(AUTO_PREFIX)


# ---------------- Clock in / out ----------------


@frappe.whitelist()
def clock_in():
	require_staff()
	_make_log("Clock In")
	return get_board()


@frappe.whitelist()
def clock_out(reason=None, summary=None):
	require_staff()
	if not reason:
		frappe.throw(_("Please give a reason for clocking out."))
	_capture_paused_task(frappe.session.user)
	_stop_running_session(frappe.session.user)
	_make_log("Clock Out", reason, summary)
	board = get_board()
	if (reason or "").strip() == END_OF_DAY:
		board["day_summary"] = _day_numbers(frappe.session.user)
	return board


def _day_numbers(user):
	"""The user's day in numbers, computed right after end-of-day clock out."""
	start, end = user_day_window(user)
	logs = frappe.get_all(
		"Duty Log",
		filters={"user": user, "log_time": ["between", [start, end]]},
		fields=["log_type", "reason", "log_time"],
		order_by="log_time asc",
	)

	duty = 0
	brk = 0
	open_in = None
	break_out = None
	for log in logs:
		if log.log_type == "Clock In":
			if break_out:
				brk += time_diff_in_seconds(log.log_time, break_out)
				break_out = None
			open_in = log.log_time
		else:
			if open_in:
				duty += time_diff_in_seconds(log.log_time, open_in)
				open_in = None
			if _is_break(log.reason):
				break_out = log.log_time

	sessions = frappe.get_all(
		"Work Session",
		filters={"user": user, "start_time": ["between", [start, end]]},
		fields=["customer", "duration", "end_time", "start_time"],
	)
	now = now_datetime()
	task = 0
	cust = 0
	for s in sessions:
		secs = s.duration or 0
		if not s.end_time:
			secs = time_diff_in_seconds(now, s.start_time)
		task += secs
		if s.customer:
			cust += secs

	expected_duty = EXPECTED_DUTY_HOURS * 3600
	expected_break = EXPECTED_BREAK_HOURS * 3600

	remarks = []
	if duty < expected_duty:
		remarks.append(
			{
				"kind": "warn",
				"text": _("You were on duty {0} less than the expected {1} hours today.").format(
					_fmt_hm(expected_duty - duty), EXPECTED_DUTY_HOURS
				),
			}
		)
	else:
		remarks.append(
			{
				"kind": "good",
				"text": _("You met the expected {0} hours on duty. Well done.").format(
					EXPECTED_DUTY_HOURS
				),
			}
		)
	if brk > expected_break:
		remarks.append(
			{
				"kind": "warn",
				"text": _("You took {0} more break time than the {1} hour allowance.").format(
					_fmt_hm(brk - expected_break), EXPECTED_BREAK_HOURS
				),
			}
		)
	elif brk:
		remarks.append(
			{"kind": "good", "text": _("Break time stayed within the allowance.")}
		)

	return {
		"expected_duty": expected_duty,
		"expected_break": expected_break,
		"duty": int(duty),
		"task": int(task),
		"breaks": int(brk),
		"customer": int(cust),
		"remarks": remarks,
	}


def _fmt_hm(seconds):
	seconds = int(seconds)
	h, m = seconds // 3600, round((seconds % 3600) / 60)
	return f"{h}h {m}m" if h else f"{m}m"


# ---------------- Team chat ----------------


EDIT_WINDOW_SECONDS = 30 * 60


def _within_edit_window(creation):
	from frappe.utils import time_diff_in_seconds, now_datetime

	return time_diff_in_seconds(now_datetime(), creation) <= EDIT_WINDOW_SECONDS


@frappe.whitelist()
def edit_message(name, message=None, drop_attachment=0):
	"""Edit own Team Message within the window. Optionally clear attachment."""
	require_staff()
	doc = frappe.get_doc("Team Message", name)
	if doc.user != frappe.session.user:
		frappe.throw(_("You can only edit your own messages."))
	if not _within_edit_window(doc.creation):
		frappe.throw(_("The 30-minute edit window has passed."))
	text = (message or "").strip()
	if not text and not doc.attachment:
		frappe.throw(_("A message cannot be empty."))
	doc.message = text
	if cint(drop_attachment):
		doc.attachment = None
		doc.attachment_name = None
		doc.attachment_type = None
	doc.edited_on = frappe.utils.now_datetime()
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	payload = _message_payload(doc.as_dict(), _reactions_for([doc.name]))
	frappe.publish_realtime("duty_board_message_edit", payload)
	return payload


@frappe.whitelist()
def send_message(
	message=None,
	mentions=None,
	reply_to=None,
	reply_snippet=None,
	attachment=None,
	attachment_name=None,
	attachment_type=None,
):
	require_staff()
	mention_list = []
	if mentions:
		try:
			parsed = frappe.parse_json(mentions)
			if isinstance(parsed, list):
				mention_list = [m for m in parsed if isinstance(m, str)][:50]
		except Exception:
			mention_list = []

	doc = frappe.get_doc(
		{
			"doctype": "Team Message",
			"user": frappe.session.user,
			"message": message,
			"mentions": frappe.as_json(mention_list) if mention_list else None,
			"reply_to": reply_to or None,
			"reply_snippet": (reply_snippet or "")[:140] or None,
			"attachment": attachment or None,
			"attachment_name": attachment_name or None,
			"attachment_type": attachment_type or None,
		}
	)
	doc.insert()

	if attachment:
		file_name = frappe.db.get_value(
			"File",
			{
				"file_url": attachment,
				"owner": frappe.session.user,
				"attached_to_name": ["is", "not set"],
			},
		)
		if file_name:
			frappe.db.set_value(
				"File",
				file_name,
				{"attached_to_doctype": "Team Message", "attached_to_name": doc.name},
				update_modified=False,
			)

	frappe.db.commit()
	payload = _message_payload(doc.as_dict(), {})
	frappe.publish_realtime("duty_board_message", payload)

	if mention_list:
		first = frappe.utils.get_fullname(frappe.session.user).split(" ")[0]
		body = (message or attachment_name or "").strip()[:120]
		for m in mention_list:
			if m != frappe.session.user:
				_push_safe(m, _("{0} mentioned you in Duty Room").format(first), body)
	return payload


def _touch_delivered(user):
	"""Advance the user's delivery watermark: their app is open and
	receiving, so everything up to now has reached their client."""
	try:
		name = frappe.db.get_value("Chat Seen", {"user": user}, "name")
		if name:
			frappe.db.set_value("Chat Seen", name, "last_delivered", frappe.utils.now(), update_modified=False)
		else:
			frappe.get_doc({"doctype": "Chat Seen", "user": user, "last_delivered": frappe.utils.now()}).insert(ignore_permissions=True)
	except Exception:
		pass  # receipts must never break a poll


@frappe.whitelist()
def get_messages(limit=50, before=None, after=None):
	require_staff()
	_touch_delivered(frappe.session.user)
	filters = {}
	if before:
		filters["creation"] = ["<", before]
	if after:
		filters["creation"] = [">", after]
	rows = frappe.get_all(
		"Team Message",
		filters=filters,
		fields=[
			"name",
			"user",
			"full_name",
			"message",
			"mentions",
			"reply_to",
			"reply_snippet",
			"attachment",
			"attachment_name",
			"attachment_type",
			"creation",
			"edited_on",
		],
		order_by="creation desc",
		limit=min(cint(limit) or 50, 200),
	)
	has_more = len(rows) >= min(cint(limit) or 50, 200)
	rows.reverse()
	reactions = _reactions_for([r.name for r in rows])
	rows_seen = frappe.get_all("Chat Seen", fields=["user", "last_seen", "last_delivered"])
	alive = set(
		frappe.get_all(
			"User",
			filters={"name": ["in", [s.user for s in rows_seen]], "enabled": 1},
			pluck="name",
		)
	) if rows_seen else set()
	seen = {s.user: str(s.last_seen) for s in rows_seen if s.user in alive and s.last_seen}
	delivered = {s.user: str(s.last_delivered) for s in rows_seen if s.user in alive and s.last_delivered}
	return {
		"messages": [_message_payload(r, reactions) for r in rows],
		"seen": seen,
		"delivered": delivered,
		"has_more": has_more,
	}


@frappe.whitelist()
def search_messages(query):
	require_staff()
	query = (query or "").strip()
	if len(query) < 2:
		frappe.throw(_("Type at least 2 characters to search."))
	rows = frappe.get_all(
		"Team Message",
		filters=[
			["Team Message", "message", "like", f"%{query}%"],
		],
		fields=[
			"name",
			"user",
			"full_name",
			"message",
			"mentions",
			"reply_to",
			"reply_snippet",
			"attachment",
			"attachment_name",
			"attachment_type",
			"creation",
		],
		order_by="creation desc",
		limit=30,
	)
	return [_message_payload(r, {}) for r in rows]


@frappe.whitelist()
def set_chat_seen(upto=None):
	"""Advance the caller's seen watermark. With `upto` (a message creation
	timestamp) this is a WITNESSED mark — the client sends it only after
	the message was actually on screen; the mark is monotonic and clamped
	to now, so it can neither retreat nor time-travel. Without `upto` it
	behaves as before (stamp now) for backward compatibility."""
	require_staff()
	user = frappe.session.user
	now = now_datetime()
	target = now
	if upto:
		try:
			target = min(frappe.utils.get_datetime(str(upto)), now)
		except Exception:
			target = now
	name = frappe.db.exists("Chat Seen", {"user": user})
	if name:
		existing = frappe.db.get_value("Chat Seen", name, "last_seen")
		if existing and frappe.utils.get_datetime(existing) >= target:
			return {"user": user, "last_seen": str(existing)}
		frappe.db.set_value("Chat Seen", name, "last_seen", target, update_modified=False)
	else:
		frappe.get_doc(
			{"doctype": "Chat Seen", "user": user, "last_seen": target}
		).insert(ignore_permissions=True)
	frappe.db.commit()
	frappe.publish_realtime(
		"duty_board_seen", {"user": user, "last_seen": str(target)}
	)
	return {"user": user, "last_seen": str(target)}


@frappe.whitelist()
def toggle_reaction(message, emoji):
	require_staff()
	if emoji not in ALLOWED_EMOJIS:
		frappe.throw(_("That reaction is not available."))
	if not frappe.db.exists("Team Message", message):
		frappe.throw(_("Message not found."))
	user = frappe.session.user
	existing = frappe.db.exists(
		"Message Reaction", {"message": message, "user": user, "emoji": emoji}
	)
	if existing:
		frappe.delete_doc("Message Reaction", existing, ignore_permissions=True)
	else:
		frappe.get_doc(
			{
				"doctype": "Message Reaction",
				"message": message,
				"user": user,
				"emoji": emoji,
			}
		).insert()
	frappe.db.commit()
	reactions = _reactions_for([message]).get(message, {})
	frappe.publish_realtime(
		"duty_board_reaction", {"message": message, "reactions": reactions}
	)
	return reactions


def _reactions_for(names):
	if not names:
		return {}
	rows = frappe.get_all(
		"Message Reaction",
		filters={"message": ["in", names]},
		fields=["message", "user", "emoji"],
	)
	out = {}
	for r in rows:
		out.setdefault(r.message, {}).setdefault(r.emoji, []).append(r.user)
	return out


def _message_payload(r, reactions):
	mentions = []
	if r.get("mentions"):
		try:
			parsed = frappe.parse_json(r.get("mentions"))
			if isinstance(parsed, list):
				mentions = parsed
		except Exception:
			mentions = []
	return {
		"name": r.get("name"),
		"user": r.get("user"),
		"full_name": r.get("full_name") or r.get("user"),
		"message": r.get("message"),
		"mentions": mentions,
		"reply_to": r.get("reply_to"),
		"reply_snippet": r.get("reply_snippet"),
		"attachment": r.get("attachment"),
		"attachment_name": r.get("attachment_name"),
		"attachment_type": r.get("attachment_type"),
		"creation": str(r.get("creation")),
		"edited_on": str(r.get("edited_on")) if r.get("edited_on") else None,
		"reactions": reactions.get(r.get("name"), {}),
	}


# ---------------- To-do list ----------------


@frappe.whitelist()
def plan_sources():
	"""My open issues and my open project tasks — the 'add from existing'
	picker's data."""
	require_staff()
	user = frappe.session.user
	issue_names = frappe.get_all("Duty Issue Assignee", filters={"user": user}, pluck="parent")
	issues = []
	if issue_names:
		issues = frappe.get_all(
			"Duty Issue",
			filters={"name": ["in", issue_names], "status": ["in", ["Open", "In Progress"]]},
			fields=["name", "title", "customer"],
			order_by="modified desc",
			limit=50,
		)
	tasks = frappe.get_all(
		"Duty Project Task",
		filters={"assignee": user, "column": ["not in", ["Completed", "Suspended"]]},
		fields=["name", "title", "project"],
		order_by="modified desc",
		limit=50,
	)
	pnames = {}
	if tasks:
		for p in frappe.get_all(
			"Duty Project",
			filters={"name": ["in", list({t.project for t in tasks})]},
			fields=["name", "project_name", "customer"],
		):
			pnames[p.name] = p
	for t in tasks:
		pr = pnames.get(t.project)
		t.project_name = pr.project_name if pr else t.project
		t.customer = pr.customer if pr else None
	return {"issues": issues, "tasks": tasks}


@frappe.whitelist()
def plan_existing(kind, source, date=None):
	"""Add an existing issue/task to my plan for a day (default today)."""
	require_staff()
	user = frappe.session.user
	d = getdate(date) if date else getdate(today())
	if d < getdate(today()):
		frappe.throw(_("Plan for today or a future day."))
	if kind == "issue":
		row = frappe.db.get_value("Duty Issue", source, ["title", "customer"], as_dict=True)
		if not row:
			frappe.throw(_("Unknown issue."))
		dupe = frappe.get_all(
			"Daily Todo",
			filters={"user": user, "duty_issue": source, "status": ["!=", "Completed"]},
			limit=1,
		)
		if dupe:
			frappe.throw(_("That issue is already on your plan."))
		vals = {"description": row.title, "customer": row.customer, "duty_issue": source}
	elif kind == "task":
		row = frappe.db.get_value("Duty Project Task", source, ["title", "project"], as_dict=True)
		if not row:
			frappe.throw(_("Unknown task."))
		dupe = frappe.get_all(
			"Daily Todo",
			filters={"user": user, "project_task": source, "status": ["!=", "Completed"]},
			limit=1,
		)
		if dupe:
			frappe.throw(_("That task is already on your plan."))
		cust = frappe.db.get_value("Duty Project", row.project, "customer")
		vals = {"description": row.title, "customer": cust, "project_task": source, "project": row.project}
	else:
		frappe.throw(_("Unknown kind."))
	frappe.get_doc(
		dict(
			doctype="Daily Todo",
			user=user,
			full_name=frappe.utils.get_fullname(user),
			date=d,
			status="Open",
			**vals,
		)
	).insert(ignore_permissions=True)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def add_todo(description, customer=None, for_user=None, for_users=None, date=None, due_time=None):
	require_staff()
	session = frappe.session.user
	if not (description or "").strip():
		frappe.throw(_("Please type the to-do first."))

	targets = _parse_targets(for_users) or ([for_user] if for_user else [session])
	for target in targets:
		_create_todo_for(target, description, customer, date, due_time)
	frappe.db.commit()
	return get_board()


def _parse_targets(for_users):
	if not for_users:
		return None
	try:
		parsed = frappe.parse_json(for_users)
	except Exception:
		return None
	if not isinstance(parsed, list):
		return None
	targets = [t for t in parsed if isinstance(t, str)]
	return list(dict.fromkeys(targets)) or None


def _validate_target(target):
	if target == frappe.session.user:
		return
	exists = frappe.db.get_value("User", target, ["enabled", "user_type"], as_dict=True)
	if not exists or not exists.enabled or exists.user_type != "System User":
		frappe.throw(_("Cannot assign to {0}.").format(target))


def _create_todo_for(target, description, customer=None, date=None, due_time=None, notify=True):
	session = frappe.session.user
	_validate_target(target)
	target_today = user_today(target)
	todo_date = getdate(date) if date else target_today
	if todo_date < target_today:
		todo_date = target_today

	frappe.get_doc(
		{
			"doctype": "Daily Todo",
			"user": target,
			"date": todo_date,
			"due_time": due_time or None,
			"description": description.strip(),
			"customer": customer or None,
			"status": "Open",
			"assigned_by": session if target != session else None,
		}
	).insert()
	if notify and target != session:
		first = frappe.utils.get_fullname(session).split(" ")[0]
		_notify_user(target, _("New to-do from {0}").format(first), description.strip())


def _notify_user(user, title, body):
	frappe.publish_realtime(
		"duty_board_notify", {"title": title, "body": body or ""}, user=user
	)
	_push_safe(user, title, body)


def parse_mentions(text):
	"""Find @first-name or @email mentions of enabled staff in free text."""
	if not text or "@" not in text:
		return []
	low = text.lower()
	mentioned = []
	for u in frappe.get_all(
		"User",
		filters={"enabled": 1, "user_type": "System User"},
		fields=["name", "full_name"],
	):
		first = (u.full_name or u.name).split(" ")[0].lower()
		if f"@{first}" in low or f"@{u.name.lower()}" in low:
			mentioned.append(u.name)
	return mentioned


def _push_safe(user, title, body):
	try:
		from duty_board.push import push_to_user

		push_to_user(user, title, body or "")
	except Exception:
		pass


@frappe.whitelist()
def share_todo(name, users, date=None):
	require_staff()
	doc = frappe.get_doc("Daily Todo", name)
	_check_todo_owner(doc)
	share_date = date or doc.date
	targets = _parse_targets(users) or []
	if not targets:
		frappe.throw(_("Pick at least one colleague."))
	for target in targets:
		if target == doc.user:
			continue
		_create_todo_for(target, doc.description, doc.customer, share_date, doc.due_time)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def update_todo(name, description=None, customer=None, due_time=None, date=None):
	require_staff()
	doc = frappe.get_doc("Daily Todo", name)
	_check_todo_owner(doc)
	if description is not None and description.strip():
		doc.description = description.strip()
	doc.customer = customer or None
	doc.due_time = due_time or None
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def invite_to_task(users):
	require_staff()
	user = frappe.session.user
	running = _get_running_session(user)
	if not running:
		frappe.throw(_("You have no task running."))
	targets = _parse_targets(users) or []
	if not targets:
		frappe.throw(_("Pick at least one colleague."))
	first = frappe.utils.get_fullname(user).split(" ")[0]
	for target in targets:
		if target == user:
			continue
		_create_todo_for(target, running.activity, running.customer, None, None, notify=False)
		_notify_user(target, _("{0} invited you to a task").format(first), running.activity)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def set_task_customer(customer=None):
	require_staff()
	user = frappe.session.user
	running = _get_running_session(user)
	if not running:
		frappe.throw(_("You have no task running."))
	doc = frappe.get_doc("Work Session", running.name)
	doc.customer = customer or None
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def add_task_note(session, note):
	require_staff()
	if not (note or "").strip():
		frappe.throw(_("Note is empty."))
	owner = frappe.db.get_value("Work Session", session, "user")
	if not owner:
		frappe.throw(_("Task not found."))
	if owner != frappe.session.user and "System Manager" not in frappe.get_roles():
		frappe.throw(_("You can only add notes to your own tasks."))
	frappe.get_doc(
		{
			"doctype": "Task Note",
			"work_session": session,
			"user": frappe.session.user,
			"note": note.strip(),
		}
	).insert()
	frappe.db.commit()
	return get_task_notes(session)


@frappe.whitelist()
def get_task_history(before=None, limit=60):
	"""The current user's past work sessions (before their local today), newest first."""
	require_staff()
	user = frappe.session.user
	start_today, _end = user_day_window(user)
	cutoff = before or str(start_today)
	cap = min(cint(limit) or 60, 200)
	rows = frappe.get_all(
		"Work Session",
		filters={"user": user, "start_time": ["<", cutoff]},
		fields=["name", "activity", "customer", "start_time", "end_time", "duration"],
		order_by="start_time desc",
		limit=cap,
	)
	has_more = len(rows) >= cap
	next_before = str(rows[-1].start_time) if rows else None

	counts = {}
	names = [r.name for r in rows]
	if names:
		for nc in frappe.get_all(
			"Task Note",
			filters={"work_session": ["in", names]},
			fields=["work_session", "count(name) as cnt"],
			group_by="work_session",
		):
			counts[nc.work_session] = nc.cnt

	for r in rows:
		r.notes = counts.get(r.name, 0)
		r.date = str(getdate(r.start_time))
		r.start_time = str(r.start_time)
		r.end_time = str(r.end_time) if r.end_time else None

	return {"sessions": rows, "has_more": has_more, "next_before": next_before}


@frappe.whitelist()
def get_task_notes(session):
	require_staff()
	rows = frappe.get_all(
		"Task Note",
		filters={"work_session": session},
		fields=["user", "full_name", "note", "creation"],
		order_by="creation asc",
	)
	for r in rows:
		r.creation = str(r.creation)
	return rows


# ---------------- Issues ----------------

SEVERITIES = ["Low", "Medium", "High", "Critical"]
ISSUE_STATUSES = ["Open", "In Progress", "Resolved", "Closed"]


def _issue_member_check(doc):
	session = frappe.session.user
	if "System Manager" in frappe.get_roles():
		return
	members = {a.user for a in (doc.assignees or [])}
	members.add(doc.raised_by)
	if session not in members:
		frappe.throw(_("Only the raiser or an assignee can update this issue."))


# ---------------- knowledge: kb, similar work, team load, on-call ----------------


@frappe.whitelist()
def kb_promote(issue, title=None, problem=None, solution=None, product=None):
	require_staff()
	doc = frappe.get_doc("Duty Issue", issue)
	solution = (solution or doc.resolution or "").strip()
	if not solution:
		frappe.throw(_("Write the solution before promoting to the knowledge base."))
	art = frappe.get_doc(
		{
			"doctype": "Duty KB Article",
			"title": (title or doc.title).strip()[:140],
			"product": (product or "").strip()[:60] or None,
			"problem": (problem or doc.description or "").strip() or None,
			"solution": solution,
			"source_issue": issue,
			"active": 1,
		}
	).insert(ignore_permissions=True)
	frappe.db.commit()
	return {"name": art.name}


@frappe.whitelist()
def kb_search(query):
	require_staff()
	query = (query or "").strip()
	if len(query) < 2:
		return []
	like = f"%{query}%"
	rows = frappe.get_all(
		"Duty KB Article",
		filters={"active": 1},
		or_filters=[
			{"title": ["like", like]},
			{"problem": ["like", like]},
			{"solution": ["like", like]},
			{"product": ["like", like]},
		],
		fields=["name", "title", "product", "problem", "solution", "source_issue"],
		order_by="modified desc",
		limit=12,
	)
	return rows


def _title_tokens(title):
	import re

	stop = {"the", "and", "for", "with", "from", "not", "issue", "error", "problem"}
	return [
		w
		for w in re.findall(r"[a-zA-Z]{4,}", (title or "").lower())
		if w not in stop
	][:6]


@frappe.whitelist()
def similar_issues(name):
	require_staff()
	doc = frappe.get_doc("Duty Issue", name)
	tokens = _title_tokens(doc.title)
	if not tokens:
		return {"issues": [], "kb": []}
	or_issues = [{"title": ["like", f"%{t}%"]} for t in tokens]
	rows = frappe.get_all(
		"Duty Issue",
		filters={"name": ["!=", name], "status": ["in", ["Resolved", "Closed"]]},
		or_filters=or_issues,
		fields=["name", "title", "customer", "resolution", "resolved_at"],
		order_by="resolved_at desc",
		limit=5,
	)
	for r in rows:
		r.resolved_at = str(r.resolved_at)[:10] if r.resolved_at else None
		r.resolution = (r.resolution or "")[:220]
	kb = frappe.get_all(
		"Duty KB Article",
		filters={"active": 1},
		or_filters=[{"title": ["like", f"%{t}%"]} for t in tokens],
		fields=["name", "title", "product", "solution"],
		limit=4,
	)
	for k in kb:
		k.solution = (k.solution or "")[:220]
	return {"issues": rows, "kb": kb}


@frappe.whitelist()
def staff_workload():
	require_staff()
	staff = frappe.get_all(
		"User",
		filters={"enabled": 1, "user_type": "System User"},
		fields=["name", "full_name"],
	)
	skills = {}
	for s in frappe.get_all("Duty Staff Skill", fields=["name", "user", "skill"]):
		skills.setdefault(s.user, []).append({"name": s.name, "skill": s.skill})
	out = []
	for u in staff:
		if u.name in ("Administrator", "Guest"):
			continue
		assigned = frappe.get_all(
			"Duty Issue Assignee",
			filters={"user": u.name},
			pluck="parent",
		)
		open_n = prog_n = 0
		if assigned:
			open_n = frappe.db.count(
				"Duty Issue", {"name": ["in", assigned], "status": "Open"}
			)
			prog_n = frappe.db.count(
				"Duty Issue", {"name": ["in", assigned], "status": "In Progress"}
			)
		out.append(
			{
				"user": u.name,
				"full_name": u.full_name or u.name,
				"open": open_n,
				"in_progress": prog_n,
				"skills": skills.get(u.name, []),
			}
		)
	out.sort(key=lambda r: -(r["open"] + r["in_progress"]))
	return out


@frappe.whitelist()
def skill_add(user, skill):
	require_staff()
	skill = (skill or "").strip()[:60]
	if not skill:
		frappe.throw(_("Name the skill."))
	if user != frappe.session.user and "System Manager" not in frappe.get_roles():
		frappe.throw(_("You can only edit your own skills."))
	if not frappe.db.exists("Duty Staff Skill", {"user": user, "skill": skill}):
		frappe.get_doc(
			{"doctype": "Duty Staff Skill", "user": user, "skill": skill}
		).insert(ignore_permissions=True)
		frappe.db.commit()
	return staff_workload()


@frappe.whitelist()
def skill_remove(name):
	require_staff()
	row = frappe.get_doc("Duty Staff Skill", name)
	if row.user != frappe.session.user and "System Manager" not in frappe.get_roles():
		frappe.throw(_("You can only edit your own skills."))
	frappe.delete_doc("Duty Staff Skill", name, ignore_permissions=True, force=True)
	frappe.db.commit()
	return staff_workload()


@frappe.whitelist()
def set_on_call(user):
	require_staff()
	if "System Manager" not in frappe.get_roles():
		frappe.throw(_("Only a System Manager can set the on-call person."))
	frappe.db.set_value("Duty Settings", "Duty Settings", "on_call_user", user or None)
	frappe.db.commit()
	frappe.get_cached_doc("Duty Settings").reload()
	return {"ok": True}


def on_call_info():
	try:
		u = frappe.get_cached_doc("Duty Settings").get("on_call_user")
		if u:
			return {
				"user": u,
				"first": frappe.utils.get_fullname(u).split(" ")[0],
			}
	except Exception:
		pass
	return None


def notify_on_call(title, body):
	"""Out-of-hours urgent escalation to the named person."""
	info = on_call_info()
	if not info:
		return
	now = now_datetime()
	in_hours = now.weekday() < 5 and BH_START <= now.hour < BH_END
	if in_hours:
		return
	_notify_user(info["user"], _("🌙 OUT-OF-HOURS · {0}").format(title), body)


# ---------------- SLA engine: promises in business hours ----------------
# Business hours: Mon-Fri 09:00-18:00 site time. (ack_hours, resolve_hours)
SLA_DEFAULTS = {
	"Critical": (1, 4),
	"High": (2, 8),
	"Medium": (8, 24),
	"Low": (24, 40),
}


def SLA_MATRIX_get(severity, fallback):
	sev = (severity or "Medium").lower()
	try:
		s = frappe.get_cached_doc("Duty Settings")
		a = s.get(f"sla_{sev}_ack_hours")
		r = s.get(f"sla_{sev}_res_hours")
		if a and r:
			return (a, r)
	except Exception:
		pass
	return SLA_DEFAULTS.get(severity or "Medium", fallback)


class _SLAMatrix:
	def get(self, severity, fallback=None):
		return SLA_MATRIX_get(severity, fallback or SLA_DEFAULTS["Medium"])

	def __getitem__(self, severity):
		return SLA_MATRIX_get(severity, SLA_DEFAULTS["Medium"])


SLA_MATRIX = _SLAMatrix()
BH_START, BH_END = 9, 18


def _bh_snap(dt):
	from datetime import timedelta

	while True:
		if dt.weekday() >= 5:
			dt = (dt + timedelta(days=1)).replace(hour=BH_START, minute=0, second=0, microsecond=0)
			continue
		if dt.hour < BH_START:
			return dt.replace(hour=BH_START, minute=0, second=0, microsecond=0)
		if dt.hour >= BH_END:
			dt = (dt + timedelta(days=1)).replace(hour=BH_START, minute=0, second=0, microsecond=0)
			continue
		return dt


def _bh_add(start, hours):
	from datetime import timedelta

	minutes = int(hours * 60)
	# whole-minute walker: strip seconds or the final partial minute of a day
	# floors to zero available and the loop spins forever
	cur = _bh_snap(start).replace(second=0, microsecond=0)
	while minutes > 0:
		eod = cur.replace(hour=BH_END, minute=0, second=0, microsecond=0)
		avail = int((eod - cur).total_seconds() // 60)
		chunk = min(minutes, avail)
		if chunk <= 0:
			# nothing usable left today — move to the next business morning
			cur = _bh_snap(eod + timedelta(minutes=1))
			continue
		cur += timedelta(minutes=chunk)
		minutes -= chunk
		if minutes > 0:
			cur = _bh_snap(cur)
	return cur


def _bh_between(a, b):
	from datetime import timedelta

	if b <= a:
		return 0
	cur = _bh_snap(a)
	total = 0
	while cur < b:
		eod = cur.replace(hour=BH_END, minute=0, second=0, microsecond=0)
		stop = min(eod, b)
		if stop > cur:
			total += int((stop - cur).total_seconds() // 60)
		cur = _bh_snap(eod + timedelta(minutes=1))
	return total


def _bh_fmt(minutes):
	if minutes < 60:
		return f"{minutes}m"
	h, m = minutes // 60, minutes % 60
	return f"{h}h {m}m" if m else f"{h}h"


def sla_dues(severity, start):
	start = frappe.utils.get_datetime(start)
	ack_h, res_h = SLA_MATRIX.get(severity or "Medium", SLA_MATRIX["Medium"])
	return _bh_add(start, ack_h), _bh_add(start, res_h)


def stamp_sla(doc_name, severity, start):
	try:
		ack_due, res_due = sla_dues(severity, start)
		frappe.db.set_value(
			"Duty Issue",
			doc_name,
			{"sla_ack_due": ack_due, "sla_res_due": res_due},
			update_modified=False,
		)
	except Exception:
		frappe.log_error(frappe.get_traceback(), "duty_board.stamp_sla")


def _sla_state(due, done_at, met_flag):
	if not due:
		return None, None
	due = frappe.utils.get_datetime(due)
	now = now_datetime()
	if done_at:
		return ("met" if cint(met_flag) else "missed"), None
	if now < due:
		return "pending", _bh_fmt(_bh_between(now, due)) + " left"
	return "overdue", _bh_fmt(_bh_between(due, now)) + " over"


def sla_warnings():
	from datetime import timedelta

	now = now_datetime()
	horizon = now + timedelta(hours=2)
	for due_f, warned_f, done_f, label in [
		("sla_ack_due", "sla_ack_warned", "acknowledged_at", "response"),
		("sla_res_due", "sla_res_warned", "resolved_at", "resolution"),
	]:
		rows = frappe.get_all(
			"Duty Issue",
			filters={
				"status": ["in", ["Open", "In Progress"]],
				due_f: ["<=", horizon],
				warned_f: 0,
			},
			fields=["name", "title", "customer", due_f, done_f],
			limit=50,
		)
		for r in rows:
			if r.get(done_f):
				continue
			frappe.db.set_value("Duty Issue", r.name, warned_f, 1, update_modified=False)
			assignees = frappe.get_all(
				"Duty Issue Assignee", filters={"parent": r.name}, pluck="user"
			)
			targets = assignees or [
				u.name
				for u in frappe.get_all(
					"User", filters={"enabled": 1, "user_type": "System User"}, fields=["name"]
				)
				if frappe.db.exists("Duty Push Subscription", {"user": u.name})
			]
			overdue = now > r.get(due_f)
			for t in targets:
				_notify_user(
					t,
					(_("🔴 SLA {0} BREACHED · {1}") if overdue else _("⏳ SLA {0} due soon · {1}")).format(
						label, r.customer
					),
					r.title[:120],
				)
	frappe.db.commit()


def _email_raiser_on_resolution(issue_name):
	"""Email the client who raised it, once resolved/closed. Queued — never blocks."""
	doc = frappe.db.get_value(
		"Duty Issue",
		issue_name,
		["title", "resolution", "raised_by", "client_requested", "status", "customer"],
		as_dict=True,
	)
	if not (doc and cint(doc.client_requested) and doc.raised_by):
		return
	u = frappe.db.get_value(
		"User", doc.raised_by, ["enabled", "user_type", "first_name"], as_dict=True
	)
	if not (u and cint(u.enabled) and u.user_type == "Website User"):
		return
	portal = frappe.utils.get_url("/portal")
	frappe.sendmail(
		recipients=[doc.raised_by],
		subject=_("✅ {0} — your request is {1}").format(doc.title[:80], _(doc.status.lower())),
		message=f"""<p>Hello {frappe.utils.escape_html(u.first_name or "")},</p>
<p>Your request <b>“{frappe.utils.escape_html(doc.title)}”</b> has been marked <b>{frappe.utils.escape_html(doc.status)}</b>.</p>
{f'<p style="background:#f0fdfa;border-radius:10px;padding:12px 16px"><b>How we resolved it:</b><br>{frappe.utils.escape_html(doc.resolution)}</p>' if doc.resolution else ''}
<p>Please open your portal to confirm the resolution and rate our service —
or reopen it if anything still isn't right:</p>
<p><a href="{portal}" style="background:#0F5C55;color:#fff;padding:10px 22px;border-radius:8px;text-decoration:none">Open your portal</a></p>
<p style="color:#6b7280;font-size:12px">Xlevel Retail Systems · CloudERP.One</p>""",
	)


@frappe.whitelist()
def my_dashboard(month=None):
	"""Everything one staff member is doing and has done — theirs alone."""
	from datetime import datetime, timedelta

	from duty_board.permissions import require_staff_or_consultant

	require_staff_or_consultant()
	me = frappe.session.user
	now = now_datetime()
	d30 = now - timedelta(days=30)

	mine = frappe.get_all(
		"Duty Issue Assignee",
		filters={"user": me, "parenttype": "Duty Issue"},
		pluck="parent",
		ignore_permissions=True,
	)
	raised = frappe.get_all(
		"Duty Issue", filters={"raised_by": me}, pluck="name", ignore_permissions=True
	)
	if raised:
		claimed = set(
			frappe.get_all(
				"Duty Issue Assignee",
				filters={"parent": ["in", raised], "parenttype": "Duty Issue"},
				pluck="parent",
				ignore_permissions=True,
			)
		)
		# what I created and nobody owns yet is mine until claimed
		mine = list(set(mine) | (set(raised) - claimed))
	issues = (
		frappe.get_all(
			"Duty Issue",
			filters={"name": ["in", mine]},
			fields=[
				"name", "title", "status", "severity", "issue_type", "customer",
				"creation", "resolved_at", "due_date", "sla_res_met", "sla_ack_met",
				"client_stars",
			],
			ignore_permissions=True,
		)
		if mine
		else []
	)
	open_now = [i for i in issues if i.status in ("Open", "In Progress")]
	resolved = [i for i in issues if i.resolved_at]
	res_30 = [i for i in resolved if i.resolved_at >= d30]

	res_min = [
		(i.resolved_at - i.creation).total_seconds() / 60
		for i in resolved
		if i.resolved_at and i.creation and i.resolved_at >= now - timedelta(days=90)
	]
	avg_res = round(sum(res_min) / len(res_min)) if res_min else None
	rated = [cint(i.client_stars) for i in resolved if cint(i.client_stars) > 0]
	my_stars = round(sum(rated) / len(rated), 1) if rated else 0
	judged = [i for i in resolved if i.sla_res_met in (0, 1)]
	sla_pct = round(sum(1 for i in judged if i.sla_res_met) * 100 / len(judged)) if judged else None

	# weekly resolutions, last 8 weeks
	weeks, wl = [], []
	for k in range(7, -1, -1):
		start = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(weeks=k)
		end = start + timedelta(weeks=1)
		weeks.append(sum(1 for i in resolved if start <= i.resolved_at < end))
		wl.append(start.strftime("%d %b"))

	def top(counter, n=8):
		items = sorted(counter.items(), key=lambda x: -x[1])[:n]
		return {"labels": [k for k, _ in items], "values": [v for _, v in items]}

	by_type = {}
	for i in open_now:
		by_type[i.issue_type or "Support"] = by_type.get(i.issue_type or "Support", 0) + 1

	sessions = frappe.get_all(
		"Work Session",
		filters={"user": me, "start_time": [">", d30]},
		fields=["customer", "duration", "start_time"],
		ignore_permissions=True,
	)
	hrs_cust = {}
	for s in sessions:
		if s.duration:
			hrs_cust[s.customer or "—"] = hrs_cust.get(s.customer or "—", 0) + s.duration / 3600
	hrs_cust = {k: round(v, 1) for k, v in hrs_cust.items()}
	hours_30 = round(sum(s.duration or 0 for s in sessions) / 3600, 1)

	upd_30 = frappe.db.count("Duty Issue Update", {"owner": me, "creation": [">", d30]})
	msg_30 = frappe.db.count("Client Room Message", {"owner": me, "creation": [">", d30]})

	# calendar month
	try:
		mstart = datetime.strptime(month, "%Y-%m") if month else now.replace(day=1)
	except Exception:
		mstart = now.replace(day=1)
	mstart = mstart.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
	nxt = (mstart + timedelta(days=32)).replace(day=1)
	days = {}

	def bump(dt, key, amt=1):
		if dt and mstart <= dt < nxt:
			k = str(dt.date() if hasattr(dt, "date") else dt)
			days.setdefault(k, {"due": 0, "res": 0, "hrs": 0})
			days[k][key] = round(days[k][key] + amt, 1)

	from frappe.utils import get_datetime

	for i in open_now:
		if i.due_date:
			bump(get_datetime(str(i.due_date)), "due")
	for i in resolved:
		bump(i.resolved_at, "res")
	msessions = frappe.get_all(
		"Work Session",
		filters={"user": me, "start_time": ["between", [str(mstart), str(nxt)]]},
		fields=["start_time", "duration"],
		ignore_permissions=True,
	)
	for s in msessions:
		if s.duration:
			bump(s.start_time, "hrs", s.duration / 3600)

	# meetings I'm part of, this month
	my_meets = frappe.db.sql(
		"""select distinct dm.name, dm.topic, dm.customer, dm.meeting_date,
			dm.start_time, dm.status
		from `tabDuty Meeting` dm
		left join `tabDuty Meeting Attendee` a on a.parent = dm.name
		where dm.meeting_date >= %(s)s and dm.meeting_date < %(e)s
			and dm.status in ('Pending', 'Confirmed')
			and (a.user = %(me)s or dm.requested_by = %(me)s or dm.confirmed_by = %(me)s)
		order by dm.meeting_date, dm.start_time""",
		{"s": str(mstart.date()), "e": str(nxt.date()), "me": me},
		as_dict=True,
	)
	my_todos = frappe.get_all(
		"Daily Todo",
		filters={"user": me, "date": ["between", [str(mstart.date()), str(nxt.date())]]},
		fields=["name", "description", "date", "due_time", "status", "customer"],
		order_by="date, due_time",
		ignore_permissions=True,
	)
	day_items = {}
	for td in my_todos:
		k = str(td.date)
		days.setdefault(k, {"due": 0, "res": 0, "hrs": 0})
		days[k]["todo"] = days[k].get("todo", 0) + 1
		day_items.setdefault(k, {"meetings": [], "tasks": [], "todos": []})
		day_items[k]["todos"].append(
			{
				"name": td.name,
				"text": td.description,
				"time": str(td.due_time)[:5] if td.due_time else "",
				"done": 1 if td.status == "Completed" else 0,
				"customer": td.customer,
			}
		)
	for mt in my_meets:
		k = str(mt.meeting_date)
		days.setdefault(k, {"due": 0, "res": 0, "hrs": 0})
		days[k]["meet"] = days[k].get("meet", 0) + 1
		day_items.setdefault(k, {"meetings": [], "tasks": [], "todos": []})
		day_items[k]["meetings"].append(
			{
				"name": mt.name,
				"topic": mt.topic,
				"customer": mt.customer,
				"time": str(mt.start_time)[:5] if mt.start_time else "",
				"status": mt.status,
			}
		)
	for i in open_now:
		if i.due_date and mstart.date() <= get_datetime(str(i.due_date)).date() < nxt.date():
			k = str(i.due_date)
			day_items.setdefault(k, {"meetings": [], "tasks": [], "todos": []})
			day_items[k]["tasks"].append(
				{"name": i.name, "title": i.title, "customer": i.customer, "severity": i.severity}
			)

	logs_today = frappe.get_all(
		"Duty Log",
		filters={"user": me, "log_time": [">=", str(now.date())]},
		fields=["log_type", "log_time"],
		order_by="log_time asc",
		ignore_permissions=True,
	)
	on_secs, open_in = 0, None
	for lg in logs_today:
		if lg.log_type == "Clock In":
			open_in = lg.log_time
		elif lg.log_type == "Clock Out" and open_in:
			on_secs += (lg.log_time - open_in).total_seconds()
			open_in = None
	if open_in:
		on_secs += (now - open_in).total_seconds()
	duty = {
		"on": bool(open_in),
		"today": f"{int(on_secs // 3600)}h {int(on_secs % 3600 // 60)}m" if on_secs else "0h 0m",
	}

	return {
		"full_name": frappe.utils.get_fullname(me),
		"duty": duty,
		"tiles": {
			"open_now": len(open_now),
			"in_progress": sum(1 for i in open_now if i.status == "In Progress"),
			"resolved_30": len(res_30),
			"avg_res": f"{avg_res // 60}h {avg_res % 60}m" if avg_res and avg_res >= 60 else (f"{avg_res}m" if avg_res else None),
			"sla_pct": sla_pct,
			"my_stars": my_stars,
			"my_rated_n": len(rated),
			"hours_30": hours_30 or None,
			"updates_30": upd_30 or None,
			"messages_30": msg_30 or None,
		},
		"weekly": {"labels": wl, "values": weeks},
		"by_type": top(by_type),
		"hours_by_customer": top(hrs_cust),
		"pending_requests": [
			{
				"name": r.name,
				"topic": r.topic,
				"customer": r.customer,
				"date": str(r.meeting_date),
				"time": str(r.start_time)[:5] if r.start_time else "",
				"by": frappe.utils.get_fullname(r.requested_by) if r.requested_by else "",
			}
			for r in frappe.get_all(
				"Duty Meeting",
				filters={"status": "Pending"},
				fields=["name", "topic", "customer", "meeting_date", "start_time", "requested_by"],
				order_by="meeting_date, start_time",
				limit=20,
				ignore_permissions=True,
			)
		],
		"month": mstart.strftime("%Y-%m"),
		"days": days,
		"day_items": day_items,
		"open_list": [
			{"name": i.name, "title": i.title, "customer": i.customer, "severity": i.severity, "due": str(i.due_date) if i.due_date else None}
			for i in sorted(open_now, key=lambda x: str(x.due_date or "9999"))[:12]
		],
	}


@frappe.whitelist()
def create_meeting(topic, meeting_date, start_time=None, duration_mins=30, customer=None, attendees=None):
	from duty_board.client_room import _staff_only

	_staff_only()
	topic = (topic or "").strip()
	if not topic:
		frappe.throw(_("Give the meeting a topic."))
	me = frappe.session.user
	users = []
	if attendees:
		import json as _json

		try:
			users = _json.loads(attendees) if isinstance(attendees, str) else list(attendees)
		except Exception:
			users = []
	if me not in users:
		users.insert(0, me)
	room_name = None
	if customer:
		room_name = frappe.db.get_value(
			"Client Room", {"customer": customer, "status": ["!=", "Archived"]}, "name"
		)
	doc = frappe.get_doc(
		{
			"doctype": "Duty Meeting",
			"topic": topic[:140],
			"room": room_name,
			"customer": customer or None,
			"meeting_date": meeting_date,
			"start_time": start_time or None,
			"duration_mins": cint(duration_mins) or 30,
			"status": "Confirmed",
			"requested_by": me,
			"confirmed_by": me,
			"attendees": [{"user": u} for u in users],
		}
	)
	doc.insert(ignore_permissions=True)
	frappe.db.commit()
	try:
		from duty_board.client_room import _send_meeting_invite

		_send_meeting_invite(doc, "REQUEST")
	except Exception:
		pass
	if customer:
		try:
			from duty_board.client_room import _post

			rn = frappe.get_all(
				"Client Room",
				filters={"customer": customer, "status": ["!=", "Archived"]},
				limit=1,
				pluck="name",
			)
			if rn:
				room = frappe.get_doc("Client Room", rn[0])
				_post(
					room,
					_("📅 Meeting scheduled: “{0}” — {1} {2}").format(
						topic[:80], meeting_date, str(start_time or "")[:5]
					),
				)
		except Exception:
			frappe.log_error(frappe.get_traceback(), "duty_board.meeting_narrate")
	return {"name": doc.name}


@frappe.whitelist()
def reschedule_meeting(name, meeting_date, start_time=None):
	from duty_board.client_room import _staff_only

	_staff_only()
	doc = frappe.get_doc("Duty Meeting", name)
	if doc.status not in ("Pending", "Confirmed"):
		frappe.throw(_("This meeting is settled — schedule a new one instead."))
	old_when = f"{doc.meeting_date} {str(doc.start_time or '')[:5]}".strip()
	doc.meeting_date = meeting_date
	doc.start_time = start_time or None
	doc.reminded_morning = 0
	doc.reminded_hour = 0
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	if doc.room:
		try:
			from duty_board.client_room import _post

			room = frappe.get_doc("Client Room", doc.room)
			_post(
				room,
				_("📅 Meeting moved: “{0}” — now {1} {2} (was {3})").format(
					(doc.topic or "")[:80], meeting_date, str(start_time or "")[:5], old_when
				),
			)
		except Exception:
			frappe.log_error(frappe.get_traceback(), "duty_board.meeting_move_narrate")
	return {"ok": True}


def _issue_updates(issue, limit=20):
	rows = frappe.get_all(
		"Duty Issue Update",
		filters={"issue": issue},
		fields=["name", "note", "owner", "creation"],
		order_by="creation desc",
		limit=limit,
	)
	kmap = {}
	kmine = set()
	if rows:
		names = [r.name for r in rows]
		for k in frappe.get_all(
			"Duty Kudos",
			filters={"ref_name": ["in", names]},
			fields=["ref_name", "from_user"],
		):
			kmap[k.ref_name] = kmap.get(k.ref_name, 0) + 1
			if k.from_user == frappe.session.user:
				kmine.add(k.ref_name)
	return [
		{
			"row": r.name,
			"note": r.note,
			"by": frappe.utils.get_fullname(r.owner).split(" ")[0],
			"owner": r.owner,
			"when": str(r.creation)[:16],
			"kudos": kmap.get(r.name, 0),
			"mine": 1 if r.name in kmine else 0,
			"self": 1 if r.owner == frappe.session.user else 0,
		}
		for r in rows
	]


@frappe.whitelist()
def issue_updates(name):
	from duty_board.permissions import require_staff_or_consultant
	_is_c = require_staff_or_consultant()
	if _is_c:
		_consultant_issue_check(frappe.get_doc("Duty Issue", name))
	return _issue_updates(name)


@frappe.whitelist()
def issue_update_add(name, note):
	from duty_board.permissions import require_staff_or_consultant
	_is_c = require_staff_or_consultant()
	if _is_c:
		_consultant_issue_check(frappe.get_doc("Duty Issue", name))
	note = (note or "").strip()
	if not note:
		frappe.throw(_("Write the update."))
	doc = frappe.get_doc("Duty Issue", name)
	frappe.get_doc(
		{"doctype": "Duty Issue Update", "issue": name, "note": note[:2000]}
	).insert(ignore_permissions=True)
	frappe.db.commit()
	try:
		from duty_board.client_room import _issue_home_room, _post, _push_room_clients

		row = frappe._dict(
			customer=doc.customer, source_type=doc.source_type, source=doc.source
		)
		home = _issue_home_room(row)
		if home and cint(doc.client_visible):
			room = frappe.get_doc("Client Room", home.name)
			_post(room, _("📝 Update on “{0}”: {1}").format(doc.title[:80], note[:400]))
			_push_room_clients(
				room, _("📝 Update · {0}").format(doc.customer), doc.title[:120]
			)
	except Exception:
		frappe.log_error(frappe.get_traceback(), "duty_board.issue_update_narrate")
	return _issue_updates(name)


def _issue_payload(doc):
	files = frappe.get_all(
		"File",
		filters={"attached_to_doctype": "Duty Issue", "attached_to_name": doc.name},
		fields=["file_url", "file_name"],
		order_by="creation asc",
	)
	image_exts = ("png", "jpg", "jpeg", "gif", "webp")
	attachments = [
		{
			"file_url": f.file_url,
			"file_name": f.file_name,
			"is_image": (f.file_name or "").lower().rsplit(".", 1)[-1] in image_exts,
		}
		for f in files
	]
	working = [
		w.user
		for w in frappe.get_all(
			"Work Session",
			filters={"duty_issue": doc.name, "end_time": ["is", "not set"]},
			fields=["user"],
		)
	]
	return {
		"attachments": attachments,
		"working": working,
		"client_visible": cint(doc.client_visible or 0),
		"client_requested": cint(doc.client_requested or 0),
		"client_rating": doc.get("client_rating") or None,
		"sla": {
			"ack": dict(zip(("state", "detail"), _sla_state(doc.get("sla_ack_due"), doc.get("acknowledged_at"), doc.get("sla_ack_met")))),
			"res": dict(zip(("state", "detail"), _sla_state(doc.get("sla_res_due"), doc.get("resolved_at"), doc.get("sla_res_met")))),
		},
		"acknowledged_first": (
			frappe.utils.get_fullname(doc.acknowledged_by).split(" ")[0]
			if doc.get("acknowledged_by")
			else None
		),
		"name": doc.name,
		"title": doc.title,
		"customer": doc.customer,
		"severity": doc.severity,
		"issue_type": doc.get("issue_type"),
		"change_request": _issue_cr(doc),
		"checklist": [
			{
				"row": c.name,
				"item": c.item,
				"done": cint(c.done),
				"done_by": c.done_by,
				"assignee": c.get("assignee"),
				"due_date": str(c.get("due_date")) if c.get("due_date") else None,
			}
			for c in (doc.checklist or [])
		],
		"client_stars": doc.get("client_stars"),
		"client_confirmed_at": str(doc.get("client_confirmed_at")) if doc.get("client_confirmed_at") else None,
		"status": doc.status,
		"due_date": str(doc.due_date) if doc.due_date else None,
		"raised_by": doc.raised_by,
		"description": doc.description,
		"resolution": doc.resolution,
		"resolved_at": str(doc.resolved_at) if doc.resolved_at else None,
		"source_type": doc.source_type,
		"source": doc.source,
		"source_message": doc.get("source_message"),
		"created": str(doc.creation),
		"assignees": [a.user for a in (doc.assignees or [])],
	}


@frappe.whitelist()
def create_issue(
	title,
	customer,
	severity="Medium",
	due_date=None,
	description=None,
	assignees=None,
	source_type=None,
	source=None,
	attachments=None,
	issue_type=None,
):
	from duty_board.permissions import require_staff_or_consultant
	_is_c = require_staff_or_consultant()
	if _is_c and customer:
		from duty_board.permissions import consultant_customers

		if customer not in consultant_customers():
			frappe.throw(_("Not permitted."), frappe.PermissionError)
	if not (title or "").strip():
		frappe.throw(_("Please give the issue a title."))
	if not customer:
		frappe.throw(_("An issue must be tracked against a customer."))
	if severity not in SEVERITIES:
		severity = "Medium"

	targets = _parse_targets(assignees) or []
	for t in targets:
		_validate_target(t)

	doc = frappe.get_doc(
		{
			"doctype": "Duty Issue",
			"title": title.strip(),
			"customer": customer,
			"severity": severity,
			"issue_type": issue_type or "Support",
			"status": "Open",
			"due_date": due_date or None,
			"description": (description or "").strip() or None,
			"raised_by": frappe.session.user,
			"source_type": source_type or "Manual",
			"source": source or None,
			"assignees": [{"user": t} for t in targets],
		}
	)
	doc.insert(ignore_permissions=True)
	stamp_sla(doc.name, severity, doc.creation)

	attach_urls = []
	if attachments:
		try:
			parsed = frappe.parse_json(attachments)
			if isinstance(parsed, list):
				attach_urls = [u for u in parsed if isinstance(u, str)][:10]
		except Exception:
			attach_urls = []
	for u in attach_urls:
		_link_upload_to_issue(u, doc.name)

	frappe.db.commit()

	first = frappe.utils.get_fullname(frappe.session.user).split(" ")[0]
	for t in targets:
		if t != frappe.session.user:
			_notify_user(
				t,
				_("{0} issue from {1}").format(severity, first),
				f"{doc.name}: {doc.title}",
			)
	return _issue_payload(doc)


@frappe.whitelist()
def get_issue(name):
	from duty_board.permissions import require_staff_or_consultant
	_is_c = require_staff_or_consultant()
	doc = frappe.get_doc("Duty Issue", name)
	if _is_c:
		_consultant_issue_check(doc)
	return _issue_payload(doc)


def _link_upload_to_issue(file_url, issue_name):
	fname = frappe.db.get_value(
		"File",
		{
			"file_url": file_url,
			"owner": frappe.session.user,
			"attached_to_name": ["is", "not set"],
		},
	)
	if fname:
		frappe.db.set_value(
			"File",
			fname,
			{"attached_to_doctype": "Duty Issue", "attached_to_name": issue_name},
			update_modified=False,
		)
	return fname


@frappe.whitelist()
def attach_to_issue(name, file_url):
	require_staff()
	doc = frappe.get_doc("Duty Issue", name)
	_issue_member_check(doc)
	if not _link_upload_to_issue(file_url, doc.name):
		frappe.throw(_("Upload not found — try attaching again."))
	frappe.db.commit()
	return _issue_payload(frappe.get_doc("Duty Issue", name))


@frappe.whitelist()
def set_issue_visibility(name, visible):
	require_staff()
	doc = frappe.get_doc("Duty Issue", name)
	_issue_member_check(doc)
	frappe.db.set_value("Duty Issue", name, "client_visible", cint(visible), update_modified=False)
	frappe.db.commit()
	return _issue_payload(frappe.get_doc("Duty Issue", name))


@frappe.whitelist()
def acknowledge_issue(name):
	require_staff()
	doc = frappe.get_doc("Duty Issue", name)
	_issue_member_check(doc)
	if not doc.acknowledged_by:
		now = now_datetime()
		vals = {"acknowledged_by": frappe.session.user, "acknowledged_at": now}
		if doc.get("sla_ack_due"):
			vals["sla_ack_met"] = 1 if now <= frappe.utils.get_datetime(doc.sla_ack_due) else 0
		frappe.db.set_value("Duty Issue", name, vals, update_modified=False)
		frappe.db.commit()
		try:
			_email_raiser_on_resolution(name)
		except Exception:
			frappe.log_error(frappe.get_traceback(), "duty_board.resolution_email")
		try:
			from duty_board.client_room import narrate_issue

			narrate_issue(name, "seen")
		except Exception:
			pass
	return _issue_payload(frappe.get_doc("Duty Issue", name))


@frappe.whitelist()
def duty_typing():
	require_staff()
	first = frappe.utils.get_fullname(frappe.session.user).split(" ")[0]
	frappe.publish_realtime("duty_board_typing", {"who": first, "user": frappe.session.user})
	return {"ok": True}


@frappe.whitelist()
def start_issue_work(name):
	from duty_board.permissions import require_staff_or_consultant
	_is_c = require_staff_or_consultant()
	user = frappe.session.user
	doc = frappe.get_doc("Duty Issue", name)
	if _is_c:
		_consultant_issue_check(doc)
	if doc.status not in ("Open", "In Progress"):
		frappe.throw(_("This issue is already {0}.").format(_(doc.status)))
	if not _is_c and not _is_clocked_in(user):
		frappe.throw(_("Clock in first before starting work on an issue."))

	# picking up an issue assigns you to it
	if user not in {a.user for a in (doc.assignees or [])}:
		doc.append("assignees", {"user": user})
	doc.status = "In Progress"
	if not doc.get("work_started_at"):
		doc.work_started_at = now_datetime()
	if not doc.get("acknowledged_by"):
		doc.acknowledged_by = user
		doc.acknowledged_at = now_datetime()
		if doc.get("sla_ack_due"):
			doc.sla_ack_met = (
				1
				if frappe.utils.get_datetime(doc.acknowledged_at)
				<= frappe.utils.get_datetime(doc.sla_ack_due)
				else 0
			)
	doc.save(ignore_permissions=True)
	try:
		from duty_board.client_room import narrate_issue

		narrate_issue(name, "started")
	except Exception:
		pass

	_stop_running_session(user)
	frappe.get_doc(
		{
			"doctype": "Work Session",
			"user": user,
			"activity": doc.title,
			"customer": doc.customer,
			"duty_issue": doc.name,
			"start_time": now_datetime(),
		}
	).insert()
	frappe.db.commit()
	return _issue_payload(frappe.get_doc("Duty Issue", name))


@frappe.whitelist()
def stop_issue_work(name):
	from duty_board.permissions import require_staff_or_consultant
	_is_c = require_staff_or_consultant()
	user = frappe.session.user
	doc = frappe.get_doc("Duty Issue", name)

	running = _get_running_session(user)
	if running and running.get("duty_issue") == name:
		s = frappe.get_doc("Work Session", running.name)
		s.end_time = now_datetime()
		s.save(ignore_permissions=True)

	# revert to Open only when nobody is actively working it anymore
	still_working = frappe.db.exists(
		"Work Session", {"duty_issue": name, "end_time": ["is", "not set"]}
	)
	if doc.status == "In Progress" and not still_working:
		doc.status = "Open"
		doc.save(ignore_permissions=True)
	frappe.db.commit()
	return _issue_payload(frappe.get_doc("Duty Issue", name))


@frappe.whitelist()
def update_issue_status(name, status, resolution=None, hours=None):
	from duty_board.permissions import require_staff_or_consultant
	from frappe.utils import flt
	_is_c = require_staff_or_consultant()
	if status not in ISSUE_STATUSES:
		frappe.throw(_("Unknown status."))
	doc = frappe.get_doc("Duty Issue", name)
	if status in ("Resolved", "Closed") and (doc.checklist or []):
		open_items = [c.item for c in doc.checklist if not cint(c.done)]
		if open_items:
			frappe.throw(
				_("The checklist is not complete — {0} item(s) remain: {1}").format(
					len(open_items), "; ".join(open_items[:5])
				)
			)
	if _is_c:
		_consultant_issue_check(doc)
		if status in ("Resolved", "Closed"):
			if not flt(hours) > 0:
				frappe.throw(_("Enter the hours spent before closing this issue."))
			_retro_session(hours, doc.title, doc.customer, duty_issue=name)
			try:
				from duty_board.notify import closure_email

				closure_email(doc, hours)
			except Exception:
				frappe.log_error(frappe.get_traceback()[-1200:], "closure email")
	_issue_member_check(doc)
	if status in ("Resolved", "Closed"):
		running = _get_running_session(frappe.session.user)
		if running and running.get("duty_issue") == name:
			s = frappe.get_doc("Work Session", running.name)
			s.end_time = now_datetime()
			s.save(ignore_permissions=True)
	doc.status = status
	if resolution:
		doc.resolution = resolution.strip()
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	if status in ("Resolved", "Closed"):
		try:
			from duty_board.uat import on_issue_resolved

			on_issue_resolved(name)
		except Exception:
			pass
		fresh = frappe.db.get_value(
			"Duty Issue", name, ["resolved_at", "sla_res_due"], as_dict=True
		)
		if fresh and fresh.resolved_at and fresh.sla_res_due:
			frappe.db.set_value(
				"Duty Issue",
				name,
				"sla_res_met",
				1
				if frappe.utils.get_datetime(fresh.resolved_at)
				<= frappe.utils.get_datetime(fresh.sla_res_due)
				else 0,
				update_modified=False,
			)
			frappe.db.commit()
		try:
			from duty_board.client_room import narrate_issue

			narrate_issue(name, "done")
		except Exception:
			pass

	if status in ("Resolved", "Closed"):
		actor = frappe.session.user
		first = frappe.utils.get_fullname(actor).split(" ")[0]
		recipients = {a.user for a in (doc.assignees or [])}
		recipients.add(doc.raised_by)
		recipients.discard(actor)
		for r in recipients:
			_notify_user(
				r,
				_("Issue {0} by {1}").format(status.lower(), first),
				f"{doc.name}: {doc.title}",
			)
	return _issue_payload(doc)


@frappe.whitelist()
def update_issue(name, severity=None, due_date=None, add_assignees=None, issue_type=None):
	from duty_board.permissions import require_staff_or_consultant
	_is_c = require_staff_or_consultant()
	doc = frappe.get_doc("Duty Issue", name)
	if _is_c:
		_consultant_issue_check(doc)
	_issue_member_check(doc)
	if issue_type and issue_type in (
		"Support", "Bug", "Feature Request", "Configuration", "Training", "Enablement",
		"Data Correction", "Integration", "Billing", "Implementation",
	):
		doc.issue_type = issue_type
	if severity and severity in SEVERITIES:
		doc.severity = severity
	doc.due_date = due_date or None
	new_targets = _parse_targets(add_assignees) or []
	existing = {a.user for a in (doc.assignees or [])}
	first = frappe.utils.get_fullname(frappe.session.user).split(" ")[0]
	for t in new_targets:
		if t in existing:
			continue
		_validate_target(t)
		doc.append("assignees", {"user": t})
		if t != frappe.session.user:
			_notify_user(
				t,
				_("Issue assigned by {0}").format(first),
				f"{doc.name}: {doc.title}",
			)
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	added = [t for t in new_targets if t not in existing]
	if added:
		try:
			from duty_board.notify import assignment_email

			assignment_email(doc, added)
		except Exception:
			frappe.log_error(frappe.get_traceback()[-1200:], "assign email")
	return _issue_payload(doc)


def _fetch_issues(statuses, order_by):
	issues = frappe.get_all(
		"Duty Issue",
		filters={"status": ["in", statuses]},
		fields=[
			"name",
			"title",
			"customer",
			"severity",
			"issue_type",
			"from_change_request",
			"status",
			"due_date",
			"raised_by",
			"creation",
		],
		order_by=order_by,
		limit=200,
	)
	if issues:
		wk = {
			r.parent: r
			for r in frappe.get_all(
				"Duty Issue Checklist Item",
				filters={"parenttype": "Duty Issue", "parent": ["in", [i.name for i in issues]]},
				fields=["parent", "count(name) as total", "sum(done) as done"],
				group_by="parent",
			)
		}
		for i in issues:
			w = wk.get(i.name)
			i.wk_total = cint(w.total) if w else 0
			i.wk_done = cint(w.done) if w else 0
		rows = frappe.get_all(
			"Duty Issue Assignee",
			filters={"parenttype": "Duty Issue", "parent": ["in", [i.name for i in issues]]},
			fields=["parent", "user"],
		)
		by_issue = {}
		for r in rows:
			by_issue.setdefault(r.parent, []).append(r.user)
		for i in issues:
			i.assignees = by_issue.get(i.name, [])
			i.due_date = str(i.due_date) if i.due_date else None
			i.creation = str(i.creation)
		_attach_cr_tags(issues)
	return issues


def _open_issues():
	issues = _fetch_issues(["Open", "In Progress"], "creation asc")
	issues.sort(key=lambda i: str(i.creation), reverse=True)
	return issues


@frappe.whitelist()
def get_issues(status="open", scope=None):
	from duty_board.permissions import require_staff_or_consultant
	_is_c = require_staff_or_consultant()
	if scope:
		status = scope  # the staff page sends scope=; both names welcome
	status_map = {
		"open": None,
		"resolved": ["Resolved"],
		"closed": ["Closed"],
		"all": ISSUE_STATUSES,
	}
	if status not in status_map:
		status = "open"
	rows = _open_issues() if status == "open" else _fetch_issues(status_map[status], "creation desc")
	if _is_c:
		me = frappe.session.user
		rows = [r for r in rows if me in (r.get("assignees") or [])]
	return rows


@frappe.whitelist()
def toggle_todo(name, done):
	require_staff()
	doc = frappe.get_doc("Daily Todo", name)
	_check_todo_owner(doc)
	doc.status = "Done" if cint(done) else "Open"
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def remove_todo(name):
	require_staff()
	doc = frappe.get_doc("Daily Todo", name)
	_check_todo_owner(doc)
	frappe.delete_doc("Daily Todo", name, ignore_permissions=True)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def carry_todo(name):
	require_staff()
	doc = frappe.get_doc("Daily Todo", name)
	_check_todo_owner(doc)
	if doc.status == "Done":
		frappe.throw(_("This to-do is already done."))
	doc.date = add_days(getdate(doc.date), 1)
	doc.carry_count = cint(doc.carry_count) + 1
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def carry_all():
	require_staff()
	user = frappe.session.user
	names = frappe.get_all(
		"Daily Todo",
		filters={"user": user, "date": user_today(user), "status": "Open"},
		pluck="name",
	)
	tomorrow = add_days(user_today(user), 1)
	for name in names:
		doc = frappe.get_doc("Daily Todo", name)
		doc.date = tomorrow
		doc.carry_count = cint(doc.carry_count) + 1
		doc.save(ignore_permissions=True)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def bring_old_todos():
	require_staff()
	user = frappe.session.user
	names = frappe.get_all(
		"Daily Todo",
		filters={"user": user, "date": ["<", user_today(user)], "status": "Open"},
		pluck="name",
	)
	for name in names:
		doc = frappe.get_doc("Daily Todo", name)
		doc.date = user_today(user)
		doc.carry_count = cint(doc.carry_count) + 1
		doc.save(ignore_permissions=True)
	frappe.db.commit()
	return get_board()


def _check_todo_owner(doc):
	if doc.user != frappe.session.user and "System Manager" not in frappe.get_roles():
		frappe.throw(_("You can only manage your own to-do list."))


def _complete_todo(name):
	if not name or not frappe.db.exists("Daily Todo", name):
		return
	doc = frappe.get_doc("Daily Todo", name)
	if doc.status != "Done":
		doc.status = "Done"
		doc.save(ignore_permissions=True)


def _sorted_todos(rows):
	return sorted(rows, key=lambda x: (str(x.due_time or "99:99:99"), str(x.name)))


# ---------------- Tasks ----------------


def _capture_paused_task(user):
	"""Remember the running session so clock-in can offer it back. One per
	user; a new pause overwrites the last (you resume the most recent thing)."""
	running = _get_running_session(user)
	if not running:
		return
	# Additive: this joins the stack rather than replacing it. Dedupe on
	# activity so pausing the same task twice keeps one entry (the fresh one).
	frappe.db.delete(
		"Duty Paused Task", {"user": user, "activity": (running.activity or "").strip()}
	)
	frappe.get_doc(
		{
			"doctype": "Duty Paused Task",
			"user": user,
			"activity": running.activity,
			"customer": running.customer,
			"daily_todo": running.daily_todo,
			"duty_issue": running.duty_issue,
			"project_task": running.project_task,
			"paused_at": now_datetime(),
		}
	).insert(ignore_permissions=True)
	# Cap the stack: keep the newest 5, drop the oldest overflow.
	extras = frappe.get_all(
		"Duty Paused Task",
		filters={"user": user},
		order_by="paused_at desc",
		pluck="name",
	)[5:]
	for name in extras:
		frappe.delete_doc("Duty Paused Task", name, ignore_permissions=True, force=True)
	frappe.db.commit()


def _my_paused(user):
	rows = frappe.get_all(
		"Duty Paused Task",
		filters={"user": user},
		fields=["name", "activity", "customer", "daily_todo", "paused_at"],
		order_by="paused_at desc",
		limit=5,
	)
	for r in rows:
		r.paused_at = str(r.paused_at) if r.paused_at else None
	return rows


@frappe.whitelist()
def resume_paused_task(name=None):
	"""Reopen ONE paused task as a fresh Work Session, pausing whatever is
	running now. No name = the most recently paused."""
	require_staff()
	user = frappe.session.user
	if not _is_clocked_in(user):
		frappe.throw(_("Clock in first before resuming."))
	filters = {"user": user}
	if name:
		filters["name"] = name
	rows = frappe.get_all(
		"Duty Paused Task",
		filters=filters,
		fields=["name", "activity", "customer", "daily_todo", "duty_issue", "project_task"],
		order_by="paused_at desc",
		limit=1,
	)
	if not rows:
		frappe.throw(_("Nothing paused to resume."))
	row = rows[0]
	# The task you are leaving joins the stack; the one you resume leaves it.
	_capture_paused_task(user)
	_stop_running_session(user)
	frappe.get_doc(
		{
			"doctype": "Work Session",
			"user": user,
			"activity": row.activity or _("Resumed task"),
			"customer": row.customer or None,
			"daily_todo": row.daily_todo or None,
			"duty_issue": row.duty_issue or None,
			"project_task": row.project_task or None,
			"start_time": now_datetime(),
		}
	).insert()
	frappe.delete_doc("Duty Paused Task", row.name, ignore_permissions=True, force=True)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def dismiss_paused_task(name=None):
	"""Drop one paused task (or all of them, with no name) without resuming."""
	require_staff()
	filters = {"user": frappe.session.user}
	if name:
		filters["name"] = name
	frappe.db.delete("Duty Paused Task", filters)
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def start_task(activity, customer=None, todo=None, complete_previous=0):
	require_staff()
	user = frappe.session.user
	if not (activity or "").strip():
		frappe.throw(_("Please describe what you are working on."))
	if not _is_clocked_in(user):
		frappe.throw(_("Clock in first before starting a task."))

	# Switching pauses the running task instead of discarding it — unless
	# you marked it completed, in which case it is done, not paused.
	if not cint(complete_previous):
		_capture_paused_task(user)
	previous = _stop_running_session(user)
	if cint(complete_previous) and previous and previous.daily_todo:
		_complete_todo(previous.daily_todo)
	# Typing a task that matches a paused entry IS resuming it by hand.
	frappe.db.delete("Duty Paused Task", {"user": user, "activity": activity.strip()})

	_t_task, _t_issue = None, None
	if todo:
		_tv = frappe.db.get_value("Daily Todo", todo, ["project_task", "duty_issue"], as_dict=True)
		if _tv:
			_t_task, _t_issue = _tv.project_task or None, _tv.duty_issue or None
	frappe.get_doc(
		{
			"doctype": "Work Session",
			"user": user,
			"activity": activity.strip(),
			"customer": customer or None,
			"daily_todo": todo or None,
			"project_task": _t_task,
			"duty_issue": _t_issue,
			"start_time": now_datetime(),
		}
	).insert()
	frappe.db.commit()
	return get_board()


@frappe.whitelist()
def stop_task(completed=0):
	require_staff()
	user = frappe.session.user
	stopped = _stop_running_session(user)
	if cint(completed) and stopped and stopped.daily_todo:
		_complete_todo(stopped.daily_todo)
	frappe.db.commit()
	return get_board()


def _make_log(log_type, reason=None, summary=None):
	frappe.get_doc(
		{
			"doctype": "Duty Log",
			"user": frappe.session.user,
			"log_type": log_type,
			"log_time": now_datetime(),
			"reason": reason,
			"day_summary": summary,
		}
	).insert()
	frappe.db.commit()


def _is_clocked_in(user):
	start, end = user_day_window(user)
	last = frappe.get_all(
		"Duty Log",
		filters={"user": user, "log_time": ["between", [start, end]]},
		fields=["log_type"],
		order_by="log_time desc",
		limit=1,
	)
	return bool(last) and last[0].log_type == "Clock In"


def _get_running_session(user):
	rows = frappe.get_all(
		"Work Session",
		filters={"user": user, "end_time": ["is", "not set"]},
		fields=["name", "activity", "customer", "daily_todo", "duty_issue", "project_task", "start_time"],
		order_by="start_time desc",
		limit=1,
	)
	return rows[0] if rows else None


def _stop_running_session(user):
	running = _get_running_session(user)
	if running:
		doc = frappe.get_doc("Work Session", running.name)
		doc.end_time = now_datetime()
		doc.save()
	return running


# ---------------- Leave awareness ----------------


def _users_on_leave(user_ids):
	"""Users on approved Duty Board leave covering their local today.
	(Source-swapped from ERPNext Leave Application — leave now lives here.)"""
	rows = frappe.get_all(
		"Duty Leave Request",
		filters={
			"user": ["in", list(user_ids)],
			"status": "Approved",
			"start_date": ["<=", add_days(getdate(today()), 1)],
			"end_date": [">=", add_days(getdate(today()), -1)],
		},
		fields=["user", "start_date", "end_date"],
	)
	on_leave = set()
	for lv in rows:
		local_today = user_today(lv.user)
		if getdate(lv.start_date) <= local_today <= getdate(lv.end_date):
			on_leave.add(lv.user)
	return on_leave


# ---------------- The board ----------------


@frappe.whitelist()
def delete_message(name):
	"""System Managers only: remove a Duty Room message everywhere.
	Cascades attached files and reactions, then tells every open client."""
	require_staff()
	if "System Manager" not in frappe.get_roles():
		frappe.throw(_("Only System Managers can delete messages."))
	if not frappe.db.exists("Team Message", name):
		frappe.throw(_("Message not found — perhaps already deleted."))
	frappe.db.delete("Message Reaction", {"message": name})
	frappe.delete_doc("Team Message", name, ignore_permissions=True, force=True)
	frappe.db.commit()
	frappe.publish_realtime("duty_board_message_deleted", {"name": name})
	return {"ok": True}


def _rooms_joins_board_safe():
	try:
		from duty_board.client_room import _pending_joins_safe

		return _pending_joins_safe()
	except Exception:
		return 0


def _rooms_unread_board_safe(user):
	try:
		from duty_board.client_room import _rooms_unread_safe

		return _rooms_unread_safe(user)
	except Exception:
		return 0


def _dm_unread_safe(user):
	try:
		from duty_board.dm import get_unread_map

		return get_unread_map(user)
	except Exception:
		return {}


@frappe.whitelist()
def get_board():
	"""Current status of every enabled System User, each in their own local day."""
	from duty_board.permissions import require_staff_or_consultant

	if require_staff_or_consultant():
		return _consultant_board()
	now = now_datetime()
	session = frappe.session.user
	_touch_delivered(session)

	users = frappe.get_all(
		"User",
		filters={
			"enabled": 1,
			"user_type": "System User",
			"name": ["not in", ["Guest", "Administrator"]],
		},
		fields=["name", "full_name", "user_image"],
		order_by="full_name asc",
	)
	user_ids = [u.name for u in users]

	windows = {u.name: user_day_window(u.name) for u in users}
	global_start = min(w[0] for w in windows.values()) if windows else now
	global_end = max(w[1] for w in windows.values()) if windows else now

	logs = frappe.get_all(
		"Duty Log",
		filters={"log_time": ["between", [global_start, global_end]]},
		fields=["user", "log_type", "reason", "log_time", "day_summary"],
		order_by="log_time asc",
	)
	logs_by_user = {}
	for log in logs:
		win = windows.get(log.user)
		if win and win[0] <= log.log_time <= win[1]:
			logs_by_user.setdefault(log.user, []).append(log)

	running = frappe.get_all(
		"Work Session",
		filters={"end_time": ["is", "not set"]},
		fields=["name", "user", "activity", "customer", "daily_todo", "duty_issue", "project_task", "start_time"],
		order_by="start_time desc",
	)
	running_by_user = {}
	for s in running:
		running_by_user.setdefault(s.user, s)

	all_sessions = frappe.get_all(
		"Work Session",
		filters={"start_time": ["between", [global_start, global_end]]},
		fields=["name", "user", "activity", "customer", "start_time", "end_time", "duration"],
		order_by="start_time asc",
	)
	sessions_by_user = {}
	for s in all_sessions:
		win = windows.get(s.user)
		if not (win and win[0] <= s.start_time <= win[1]):
			continue
		if not s.end_time:
			s.duration = int(time_diff_in_seconds(now, s.start_time))
		sessions_by_user.setdefault(s.user, []).append(s)

	note_names = list({s.name for s in all_sessions} | {s.name for s in running})
	note_counts = {}
	if note_names:
		for nc in frappe.get_all(
			"Task Note",
			filters={"work_session": ["in", note_names]},
			fields=["work_session", "count(name) as cnt"],
			group_by="work_session",
		):
			note_counts[nc.work_session] = nc.cnt
	for s in all_sessions:
		s.notes = note_counts.get(s.name, 0)

	todo_fields = [
		"name",
		"user",
		"date",
		"description",
		"customer",
		"status",
		"due_time",
		"assigned_by",
		"carry_count",
		"project_task",
		"project",
		"lead",
		"lead_title",
	]
	local_dates = {u.name: user_today(u.name) for u in users}
	todos = frappe.get_all(
		"Daily Todo",
		filters={"date": ["in", list(set(local_dates.values()))]},
		fields=todo_fields,
		order_by="creation asc",
	)
	todos_by_user = {}
	for t in todos:
		if getdate(t.date) != local_dates.get(t.user):
			continue
		t.due_time = str(t.due_time)[:5] if t.due_time else None
		todos_by_user.setdefault(t.user, []).append(t)
	for key in todos_by_user:
		todos_by_user[key] = _sorted_todos(todos_by_user[key])

	on_leave = _users_on_leave(user_ids)

	board = []
	for u in users:
		ulogs = logs_by_user.get(u.name, [])
		status, reason, since, summary = "Off Duty", None, None, None
		on_duty_seconds, open_in, breaks = 0, None, 0

		for log in ulogs:
			if log.log_type == "Clock In":
				open_in = log.log_time
			elif open_in:
				on_duty_seconds += time_diff_in_seconds(log.log_time, open_in)
				open_in = None
				if _is_break(log.reason):
					breaks += 1

		if ulogs:
			last = ulogs[-1]
			since = last.log_time
			if last.log_type == "Clock In":
				status = "On Duty"
				if open_in:
					on_duty_seconds += time_diff_in_seconds(now, open_in)
			elif (last.reason or "") == END_OF_DAY:
				status = "Done for the Day"
				reason = last.reason
				summary = last.day_summary
			else:
				status = "Away"
				reason = last.reason

		if status == "Off Duty" and u.name in on_leave:
			status = "On Leave"

		task = None
		sess = running_by_user.get(u.name)
		if sess and status == "On Duty":
			task = {
				"name": sess.name,
				"notes": note_counts.get(sess.name, 0),
				"issue": sess.duty_issue,
				"card": sess.project_task,
				"activity": sess.activity,
				"customer": sess.customer,
				"todo": sess.daily_todo,
				"start_time": str(sess.start_time),
				"seconds": int(time_diff_in_seconds(now, sess.start_time)),
			}

		utodos = todos_by_user.get(u.name, [])
		todos_done = sum(1 for t in utodos if t.status == "Done")

		board.append(
			{
				"user": u.name,
				"full_name": u.full_name or u.name,
				"user_image": u.user_image,
				"status": status,
				"reason": reason,
				"since": since,
				"on_duty_seconds": int(on_duty_seconds),
				"breaks": breaks,
				"task": task,
				"summary": summary,
				"todos_done": todos_done,
				"todos_total": len(utodos),
				"todos": utodos,
				"sessions": sessions_by_user.get(u.name, []),
			}
		)

	order = {
		"On Duty": 0,
		"Away": 1,
		"Done for the Day": 2,
		"On Leave": 3,
		"Off Duty": 4,
	}
	board.sort(key=lambda r: (order.get(r["status"], 9), r["full_name"].lower()))

	me = next((r for r in board if r["user"] == session), None)
	my_paused = _my_paused(session)

	my_start, my_end = user_day_window(session)
	my_sessions = frappe.get_all(
		"Work Session",
		filters={"user": session, "start_time": ["between", [my_start, my_end]]},
		fields=["name", "activity", "customer", "start_time", "end_time", "duration"],
		order_by="start_time desc",
		limit=10,
	)
	for s in my_sessions:
		if not s.end_time:
			s.duration = int(time_diff_in_seconds(now, s.start_time))
		s.notes = note_counts.get(s.name, 0)

	my_today = user_today(session)
	my_upcoming = frappe.get_all(
		"Daily Todo",
		filters={"user": session, "date": [">", my_today], "status": "Open"},
		fields=todo_fields,
		order_by="date asc, creation asc",
		limit=30,
	)
	for t in my_upcoming:
		t.due_time = str(t.due_time)[:5] if t.due_time else None
		t.date = str(t.date)

	overdue_count = frappe.db.count(
		"Daily Todo",
		{"user": session, "date": ["<", my_today], "status": "Open"},
	)

	issues = _open_issues()

	return {
		"me": me,
		"my_paused": my_paused,
		"board": board,
		"my_sessions": my_sessions,
		"my_todos": todos_by_user.get(session, []),
		"my_upcoming": my_upcoming,
		"overdue_count": overdue_count,
		"issues": issues,
		"dm_unread": _dm_unread_safe(session),
		"rooms_unread": _rooms_unread_board_safe(session),
		"rooms_joins": _rooms_joins_board_safe(),
		"on_call": on_call_info(),
		"server_time": str(now),
	}


@frappe.whitelist()
def consultant_gate():
	"""The one endpoint a consultant may always call: identifies the
	principal so the client can render the right shell instead of frappe's
	generic permission modal. Returns consultant=False for staff."""
	from duty_board.permissions import require_staff_or_consultant

	is_c = require_staff_or_consultant()
	return {
		"consultant": bool(is_c),
		"full_name": frappe.utils.get_fullname(frappe.session.user),
	}


def _consultant_issue_check(doc):
	"""A consultant may touch only issues they are assigned to."""
	if frappe.session.user not in [a.user for a in (doc.assignees or [])]:
		frappe.throw(_("Not permitted."), frappe.PermissionError)


def _consultant_board():
	"""Minimal board payload for external consultants: their assigned open
	issues plus the people directory (name visibility approved). No team
	presence, plans, chat, or attendance."""
	user = frappe.session.user
	rows = [r for r in _open_issues() if user in (r.get("assignees") or [])]
	today = frappe.utils.today()
	overdue = len([r for r in rows if r.get("due_date") and str(r["due_date"]) < today])
	mine_all = frappe.get_all(
		"Duty Issue Assignee", filters={"user": user}, pluck="parent"
	)
	resolved30 = frappe.db.count(
		"Duty Issue",
		{
			"name": ["in", mine_all or [""]],
			"status": ["in", ["Resolved", "Closed"]],
			"modified": [">", frappe.utils.add_days(today, -30)],
		},
	)
	week_secs = 0
	for s in frappe.get_all(
		"Work Session",
		filters={"user": user, "start_time": [">", frappe.utils.add_days(today, -7)]},
		fields=["start_time", "end_time"],
	):
		if s.end_time:
			week_secs += (s.end_time - s.start_time).total_seconds()
	people = frappe.get_all(
		"User",
		filters={
			"enabled": 1,
			"user_type": "System User",
			"name": ["not in", ["Guest", "Administrator"]],
		},
		fields=["name as user", "full_name"],
	)
	return {
		"consultant": 1,
		"stats": {
			"open": len(rows),
			"overdue": overdue,
			"resolved30": resolved30,
			"week_hours": round(week_secs / 3600, 1),
		},
		"me": {"user": user, "full_name": frappe.utils.get_fullname(user)},
		"issues": rows,
		"people": people,
		"board": [],
		"my_todos": [],
		"my_upcoming": [],
		"overdue_count": 0,
	}


@frappe.whitelist()
def remove_assignee(name, user):
	"""Take one user off an issue's assignee list. Consultants may reshape
	the roster only on issues they are themselves assigned to."""
	from duty_board.permissions import require_staff_or_consultant

	_is_c = require_staff_or_consultant()
	doc = frappe.get_doc("Duty Issue", name)
	if _is_c:
		_consultant_issue_check(doc)
	before = len(doc.assignees or [])
	doc.assignees = [a for a in (doc.assignees or []) if a.user != user]
	if len(doc.assignees) == before:
		frappe.throw(_("Not an assignee."))
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	return _issue_payload(doc)


def _retro_session(hours, activity, customer=None, duty_issue=None, project_task=None):
	"""Backdated Work Session for a consultant's retrospective time entry:
	ends now, starts hours ago. Duration feeds cost-to-serve like any
	live-timed session."""
	from frappe.utils import flt, now_datetime
	from datetime import timedelta

	hours = flt(hours)
	end = now_datetime()
	frappe.get_doc({
		"doctype": "Work Session",
		"user": frappe.session.user,
		"full_name": frappe.utils.get_fullname(frappe.session.user),
		"activity": (activity or "")[:140],
		"customer": customer,
		"duty_issue": duty_issue,
		"project_task": project_task,
		"start_time": end - timedelta(hours=hours),
		"end_time": end,
		"duration": int(hours * 3600),
	}).insert(ignore_permissions=True)


def _issue_cr(doc):
	"""The linked change request from either direction, with its chip."""
	from duty_board.commercial import cr_chip

	fields = ["name", "title", "status", "pricing_status", "approved_at"]
	cr = None
	if doc.get("from_change_request"):
		cr = frappe.db.get_value(
			"Duty Change Request", doc.from_change_request, fields, as_dict=True
		)
	if not cr:
		cr = frappe.db.get_value(
			"Duty Change Request", {"source_issue": doc.name}, fields, as_dict=True
		)
	if not cr:
		return None
	chip = cr_chip(cr)
	cr["chip"] = chip["label"]
	cr["go"] = chip["go"]
	cr["approved_at"] = str(cr["approved_at"]) if cr.get("approved_at") else None
	return cr


def _attach_cr_tags(issues):
	"""Batch chip attachment for list rows: CRs linked by either direction."""
	from duty_board.commercial import cr_chip

	names = [i.name for i in issues]
	rev = [i.from_change_request for i in issues if i.get("from_change_request")]
	crs = frappe.get_all(
		"Duty Change Request",
		filters={"source_issue": ["in", names or [""]]},
		fields=["name", "source_issue", "status", "pricing_status", "approved_at"],
	)
	by_issue = {c.source_issue: c for c in crs}
	by_name = {}
	if rev:
		for c in frappe.get_all(
			"Duty Change Request",
			filters={"name": ["in", rev]},
			fields=["name", "status", "pricing_status", "approved_at"],
		):
			by_name[c.name] = c
	for i in issues:
		cr = by_name.get(i.get("from_change_request")) or by_issue.get(i.name)
		if cr:
			chip = cr_chip(cr)
			i.cr_chip = chip["label"]
			i.cr_go = chip["go"]


@frappe.whitelist()
def cr_accept(name):
	"""The consultant's (or staff's) explicit 'I have seen the approval and
	I am starting': moves an Open issue to In Progress and records the
	acceptance in the updates thread. Only when the linked CR says work
	may proceed."""
	from duty_board.permissions import require_staff_or_consultant

	_is_c = require_staff_or_consultant()
	doc = frappe.get_doc("Duty Issue", name)
	if _is_c:
		_consultant_issue_check(doc)
	cr = _issue_cr(doc)
	if not (cr and cr.get("go")):
		frappe.throw(_("The change request is not yet approved for work."))
	if doc.status == "Open":
		doc.status = "In Progress"
		doc.save(ignore_permissions=True)
	frappe.get_doc({
		"doctype": "Duty Issue Update",
		"issue": name,
		"note": _("✅ Change request accepted — work starting."),
	}).insert(ignore_permissions=True)
	frappe.db.commit()
	return _issue_payload(doc)


@frappe.whitelist()
def my_customer_options():
	"""Customer picker source for the new-issue dialog. Staff get every
	non-disabled customer; consultants get exactly their rooms' customers —
	the same fence create_issue enforces on the way in."""
	from duty_board.permissions import require_staff_or_consultant, consultant_customers

	if require_staff_or_consultant():
		return sorted(consultant_customers())
	return frappe.get_all(
		"Customer", filters={"disabled": 0}, pluck="name", order_by="name asc"
	)


def _checklist_door(name):
	from duty_board.permissions import require_staff_or_consultant

	# the wall answers BEFORE the document is touched — a stranger probing
	# with a junk name must meet PermissionError, never DoesNotExist
	_is_c = require_staff_or_consultant()
	doc = frappe.get_doc("Duty Issue", name)
	if _is_c:
		_consultant_issue_check(doc)
	_issue_member_check(doc)
	return doc


@frappe.whitelist()
def checklist_add(name, item, assignee=None, due_date=None):
	"""Append a checklist item to an issue."""
	doc = _checklist_door(name)
	item = (item or "").strip()
	if not item:
		frappe.throw(_("Say what needs doing."))
	doc.append("checklist", {"item": item[:140], "done": 0, "assignee": assignee or None, "due_date": due_date or None})
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	return _issue_payload(doc)


@frappe.whitelist()
def checklist_toggle(name, row, done):
	"""Tick or untick one checklist item; stamps who and when."""
	doc = _checklist_door(name)
	for c in doc.checklist or []:
		if c.name == row:
			c.done = cint(done)
			c.done_by = frappe.session.user if cint(done) else None
			c.done_at = now_datetime() if cint(done) else None
			break
	else:
		frappe.throw(_("Checklist item not found."))
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	return _issue_payload(doc)


@frappe.whitelist()
def checklist_remove(name, row):
	"""Delete one checklist item."""
	doc = _checklist_door(name)
	before = len(doc.checklist or [])
	doc.checklist = [c for c in (doc.checklist or []) if c.name != row]
	if len(doc.checklist) == before:
		frappe.throw(_("Checklist item not found."))
	doc.save(ignore_permissions=True)
	frappe.db.commit()
	return _issue_payload(doc)


# ─────────────── Enablements: more than a task, less than a project ───────────────

@frappe.whitelist()
def checklist_assign(name, row, assignee=None, due_date=None):
	"""Give a workplan step an owner and a date — staff only; the
	workplan's shape is a delivery decision."""
	require_staff()
	doc = frappe.get_doc("Duty Issue", name)
	for c in doc.checklist or []:
		if c.name == row:
			c.assignee = assignee or None
			c.due_date = due_date or None
			doc.save(ignore_permissions=True)
			frappe.db.commit()
			return _issue_payload(doc)
	frappe.throw(_("Step not found."))


def _parse_enablement_templates():
	raw = frappe.db.get_single_value("Duty Settings", "enablement_templates") or ""
	out = []
	cur = None
	for line in raw.splitlines():
		line = line.strip()
		if line.startswith("[") and line.endswith("]"):
			cur = {"name": line[1:-1].strip(), "steps": []}
			out.append(cur)
		elif line and cur is not None:
			cur["steps"].append(line[:140])
	return [t for t in out if t["name"] and t["steps"]]


@frappe.whitelist()
def enablement_templates():
	require_staff()
	return _parse_enablement_templates()


@frappe.whitelist()
def enablement_create(customer, title, template=None, description=None, assignees=None, due_date=None):
	"""One call: an Enablement ticket with its workplan pre-loaded."""
	require_staff()
	name = create_issue(
		title=title,
		customer=customer,
		severity="Medium",
		due_date=due_date,
		description=description,
		assignees=assignees,
		issue_type="Enablement",
	)["name"]
	doc = frappe.get_doc("Duty Issue", name)
	if template:
		for t in _parse_enablement_templates():
			if t["name"] == template:
				for step in t["steps"]:
					doc.append("checklist", {"item": step, "done": 0})
				doc.save(ignore_permissions=True)
				frappe.db.commit()
				break
	return _issue_payload(doc)


@frappe.whitelist()
def promote_to_project(name):
	"""The judgment call made real: an Enablement that grew milestones
	becomes a Duty Project. Open workplan steps become project tasks
	(assignee and due carried); the ticket closes with a paper trail."""
	require_staff()
	doc = frappe.get_doc("Duty Issue", name)
	if doc.get("issue_type") != "Enablement":
		frappe.throw(_("Only Enablements promote to projects."))
	if doc.status in ("Resolved", "Closed"):
		frappe.throw(_("This enablement is already {0}.").format(doc.status.lower()))
	from duty_board.projects import create_project, create_task

	proj = create_project(project_name=doc.title[:120], customer=doc.customer)
	proj_name = proj["name"] if isinstance(proj, dict) else proj
	carried = 0
	for c in doc.checklist or []:
		if not cint(c.done):
			create_task(
				project=proj_name,
				title=c.item,
				column="To Do",
				assignee=c.get("assignee") or None,
				due_date=str(c.get("due_date")) if c.get("due_date") else None,
			)
			carried += 1
	first = frappe.utils.get_fullname(frappe.session.user).split(" ")[0]
	frappe.get_doc({
		"doctype": "Duty Issue Update",
		"issue": doc.name,
		"note": _("⤴ Promoted to project by {0} — {1} open step(s) carried to {2}.").format(first, carried, proj_name),
	}).insert(ignore_permissions=True)
	doc.db_set("status", "Closed", update_modified=True)
	doc.db_set("resolution", _("Promoted to project {0}").format(proj_name), update_modified=False)
	frappe.db.commit()
	return {"project": proj_name, "carried": carried}


@frappe.whitelist()
def enablement_apply(name, template):
	"""Pre-load a workplan template onto an existing Enablement ticket."""
	require_staff()
	doc = frappe.get_doc("Duty Issue", name)
	for t in _parse_enablement_templates():
		if t["name"] == template:
			for step in t["steps"]:
				doc.append("checklist", {"item": step, "done": 0})
			doc.save(ignore_permissions=True)
			frappe.db.commit()
			return _issue_payload(doc)
	frappe.throw(_("Template not found — check Duty Settings."))


@frappe.whitelist()
def merge_issue(source, target):
	"""Fold a duplicate into the real ticket: updates, assignees,
	checklist steps, work sessions and attachments all move; the
	duplicate closes with a paper trail on both sides."""
	require_staff()
	if source == target:
		frappe.throw(_("A ticket cannot merge into itself."))
	src = frappe.get_doc("Duty Issue", source)
	tgt = frappe.get_doc("Duty Issue", target)
	if tgt.status in ("Closed",):
		frappe.throw(_("Target {0} is closed — merge into a living ticket.").format(target))
	frappe.db.sql("update `tabDuty Issue Update` set issue=%s where issue=%s", (target, source))
	frappe.db.sql("update `tabWork Session` set duty_issue=%s where duty_issue=%s", (target, source))
	frappe.db.sql(
		"update `tabFile` set attached_to_name=%s where attached_to_doctype='Duty Issue' and attached_to_name=%s",
		(target, source),
	)
	have = {a.user for a in (tgt.assignees or [])}
	for a in src.assignees or []:
		if a.user not in have:
			tgt.append("assignees", {"user": a.user})
	for c in src.checklist or []:
		tgt.append("checklist", {
			"item": c.item, "done": c.done, "done_by": c.done_by,
			"assignee": c.get("assignee"), "due_date": c.get("due_date"),
		})
	if src.description and src.description not in (tgt.description or ""):
		tgt.description = ((tgt.description or "") + "\n\n— " + _("From merged {0}").format(source) + " —\n" + src.description).strip()
	tgt.save(ignore_permissions=True)
	first = frappe.utils.get_fullname(frappe.session.user).split(" ")[0]
	frappe.get_doc({"doctype": "Duty Issue Update", "issue": target,
		"note": _("⇄ {0} merged {1} into this ticket.").format(first, source)}).insert(ignore_permissions=True)
	src.db_set("status", "Closed", update_modified=True)
	src.db_set("resolution", _("Merged into {0}").format(target), update_modified=False)
	frappe.db.commit()
	return _issue_payload(tgt)
