"""ZhiftPOS Professional track seed — the counter curriculum:
the till certified from constitution to daily proof.

Content lives in academy_pos_pro_data.json. Modules are PROCTORED:
timed 60s/question, 10 served from each 35-question bank. Modules
are added pass by pass; re-running the seed appends new modules to
the existing track (idempotent per module and for the track).

Run:  bench --site xlevel.clouderp.one execute duty_board.academy_seed_pos_pro.seed_pos_pro_track
"""

import json
import os

import frappe

ORDER = ["counter_system", "pos_profile", "terminal_estate", "shift_sale", "concessions_returns", "extended_counters", "voucher_programme", "honest_counter"]

TRACK = {
	"title": "ZhiftPOS Professional",
	"serial_prefix": "ZPOS-PRO",
	"description": "The complete counter certification: the system and its roles, the Point of Sale Profile at full depth, commissioning and the terminal estate, shift operations and sales processing, concessions, returns and overrides, the extended counters, the voucher programme, and daily verification — offline operation, the queue, reconciliation and supervision — with proctored examinations per module.",
}


def _data():
	path = os.path.join(os.path.dirname(__file__), "academy_pos_pro_data.json")
	with open(path) as f:
		return json.load(f)


def seed_pos_pro_track():
	data = _data()
	if not frappe.db.exists("Duty Product", "ZhiftPOS"):
		frappe.get_doc(
			{"doctype": "Duty Product", "title": "ZhiftPOS", "active": 1, "sort_order": 12}
		).insert(ignore_permissions=True)
		print("created Duty Product: ZhiftPOS")

	module_names = {}
	for i, key in enumerate(ORDER):
		m = data[key]
		existing = frappe.db.get_value("Duty Training Module", {"title": m["title"]}, "name")
		if existing:
			module_names[key] = existing
			print(f"module exists: {m['title']}")
			continue
		mod = frappe.get_doc(
			{
				"doctype": "Duty Training Module",
				"title": m["title"],
				"product": "ZhiftPOS",
				"description": m["desc"],
				"active": 1,
				"audience": "Both",
				"sort_order": 130 + i,
				"pass_mark": 70,
				"timed_mode": 1,
				"seconds_per_question": 60,
				"questions_served": 10,
			}
		).insert(ignore_permissions=True)
		module_names[key] = mod.name
		for j, l in enumerate(m["lessons"]):
			frappe.get_doc(
				{
					"doctype": "Duty Lesson",
					"module": mod.name,
					"title": l["title"],
					"sort_order": j,
					"est_minutes": l["est"],
					"content": l["html"],
				}
			).insert(ignore_permissions=True)
		for q in m["questions"]:
			frappe.get_doc(
				{
					"doctype": "Duty Quiz Question",
					"module": mod.name,
					"question": q["q"],
					"opt_a": q["opts"][0],
					"opt_b": q["opts"][1],
					"opt_c": q["opts"][2],
					"opt_d": q["opts"][3],
					"correct": "ABCD"[q["ans"]],
					"rationale": q["why"],
					"source": q["src"],
					"active": 1,
				}
			).insert(ignore_permissions=True)
		print(f"seeded module: {m['title']} ({len(m['lessons'])} lessons, {len(m['questions'])} questions, proctored)")

	existing_track = frappe.db.get_value("Duty Certification Track", {"title": TRACK["title"]}, "name")
	if existing_track:
		tr = frappe.get_doc("Duty Certification Track", existing_track)
		have = {r.module for r in tr.get("modules") or []}
		added = 0
		for k in ORDER:
			if module_names[k] not in have:
				tr.append("modules", {"module": module_names[k]})
				added += 1
		if added:
			tr.save(ignore_permissions=True)
			print(f"track exists: {TRACK['title']} — appended {added} new module(s)")
		else:
			print(f"track exists: {TRACK['title']} — complete")
	else:
		frappe.get_doc(
			{
				"doctype": "Duty Certification Track",
				"title": TRACK["title"],
				"product": "ZhiftPOS",
				"audience": "Consultant",
				"serial_prefix": TRACK["serial_prefix"],
				"description": TRACK["description"],
				"active": 1,
				"modules": [{"module": module_names[k]} for k in ORDER],
			}
		).insert(ignore_permissions=True)
		print(f"created track: {TRACK['title']} ({TRACK['serial_prefix']}, {len(ORDER)} modules)")

	frappe.db.commit()
	print("ZhiftPOS Professional track ready.")


def refresh_lessons(only=None):
	"""Replace lesson content on ALREADY-SEEDED modules from the data
	file (matched by title). Clears lesson read-progress for refreshed
	modules. Questions untouched. Pass only=<module_key> for a single
	module."""
	data = _data()
	refreshed = 0
	keys = [only] if only else ORDER
	for key in keys:
		if key not in data:
			print(f"unknown module key: {key}")
			continue
		m = data[key]
		mod = frappe.db.get_value("Duty Training Module", {"title": m["title"]}, "name")
		if not mod:
			print(f"module not seeded yet (skipped): {m['title']}")
			continue
		for row in frappe.get_all("Duty Lesson", filters={"module": mod}, pluck="name"):
			frappe.delete_doc("Duty Lesson", row, ignore_permissions=True, force=True)
		for row in frappe.get_all("Duty Lesson Progress", filters={"module": mod}, pluck="name"):
			frappe.delete_doc("Duty Lesson Progress", row, ignore_permissions=True, force=True)
		for j, l in enumerate(m["lessons"]):
			frappe.get_doc(
				{
					"doctype": "Duty Lesson",
					"module": mod,
					"title": l["title"],
					"sort_order": j,
					"est_minutes": l["est"],
					"content": l["html"],
				}
			).insert(ignore_permissions=True)
		refreshed += 1
		print(f"refreshed: {m['title']} ({len(m['lessons'])} lessons)")
	frappe.db.commit()
	print(f"{refreshed} module(s) refreshed. Read-progress reset for refreshed modules.")


def refresh_questions(only=None):
	"""Replace a seeded module's question bank from the data file
	(matched by title). Past attempts keep stored results. Pass
	only=<module_key> for one module, else all in ORDER."""
	data = _data()
	keys = [only] if only else ORDER
	for key in keys:
		if key not in data:
			print(f"unknown module key: {key}")
			continue
		m = data[key]
		mod = frappe.db.get_value("Duty Training Module", {"title": m["title"]}, "name")
		if not mod:
			print(f"module not seeded yet (skipped): {m['title']}")
			continue
		for row in frappe.get_all("Duty Quiz Question", filters={"module": mod}, pluck="name"):
			frappe.delete_doc("Duty Quiz Question", row, ignore_permissions=True, force=True)
		for q in m["questions"]:
			frappe.get_doc(
				{
					"doctype": "Duty Quiz Question",
					"module": mod,
					"question": q["q"],
					"opt_a": q["opts"][0],
					"opt_b": q["opts"][1],
					"opt_c": q["opts"][2],
					"opt_d": q["opts"][3],
					"correct": "ABCD"[q["ans"]],
					"rationale": q["why"],
					"source": q["src"],
					"active": 1,
				}
			).insert(ignore_permissions=True)
		print(f"bank refreshed: {m['title']} ({len(m['questions'])} questions)")
	frappe.db.commit()
	print("Question banks refreshed.")


def rename_pos_modules():
	"""One-off (v3.178.0): flatten POS module titles to the strict manual
	register and update the track description. MUST run BEFORE
	refresh_lessons/refresh_questions after v3.178.0, because refresh
	matches modules by title."""
	renames = {
		"POS 1 — The Counter & the System": "POS 1 — The Counter System: Concepts & Architecture",
		"POS 4 — The Shift & the Sale": "POS 4 — Shift Operations & Sales Processing",
		"POS 6 — The Extended Counters": "POS 6 — Extended Counter Operations",
		"POS 8 — The Honest Counter": "POS 8 — Daily Verification & Offline Operations",
	}
	for old, new in renames.items():
		name = frappe.db.get_value("Duty Training Module", {"title": old}, "name")
		if name:
			frappe.db.set_value("Duty Training Module", name, "title", new)
			print(f"renamed: {old} -> {new}")
		else:
			already = frappe.db.get_value("Duty Training Module", {"title": new}, "name")
			print(f"skipped: {old} ({'already renamed' if already else 'NOT FOUND'})")
	tr = frappe.db.get_value("Duty Certification Track", {"title": TRACK["title"]}, "name")
	if tr:
		frappe.db.set_value("Duty Certification Track", tr, "description", TRACK["description"])
		print("track description updated")
	frappe.db.commit()
