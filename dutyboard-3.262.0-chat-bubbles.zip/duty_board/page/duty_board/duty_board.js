frappe.pages["duty-board"].on_page_load = function (wrapper) {
	const page = frappe.ui.make_app_page({
		parent: wrapper,
		title: __("Duty Board"),
		single_column: true,
	});

	page.set_secondary_action(__("Refresh"), () => board.refresh(), "refresh");
	page.add_menu_item(__("Plan Calendar"), () =>
		frappe.set_route("List", "Daily Todo", "Calendar")
	);
	page.add_menu_item(__("Time Report"), () =>
		frappe.set_route("query-report", "Daily Duty Summary")
	);
	page.add_menu_item(__("Work Sessions Report"), () =>
		frappe.set_route("query-report", "Work Sessions")
	);
	page.add_menu_item(__("Duty Log List"), () => frappe.set_route("List", "Duty Log"));

	// Frappe's fixed-width .container ignores the expanded workspace
	// sidebar and overflows small viewports (measured: 106px at 1315px).
	// Fluid containers on THIS page only — head and body stay aligned.
	$(wrapper).find(".container").addClass("duty-fluid");
	const board = new DutyBoard(page);
	board.refresh();

	board.face_btn = null;
	board.sales_btn = null;
	const RSVG = {
		pulse: '<path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/>',
		ask: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>',
		day: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
		proj: '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
		sales: '<path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
		rooms: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
		me: '<circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/>',
		lib: '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
		books: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
		coin: '<circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 18V6"/>',
		cap: '<path d="M21.42 10.92a2 2 0 0 0 0-3.84L12.83 3.5a2 2 0 0 0-1.66 0L2.58 7.08a2 2 0 0 0 0 3.84l8.59 3.58a2 2 0 0 0 1.66 0z"/><path d="M22 10v6"/><path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5"/>',
		tag: '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
	};
	RSVG.warn = '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 20h16a2 2 0 0 0 1.73-2Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>';
	board.rail = [
		{ id: "board", ic: RSVG.day, label: __("My Day"), go: () => board.show_face("board") },
		{ id: "issues", ic: RSVG.warn, label: __("Issues"), go: () => board.show_face("issues") },
		{ id: "projects", ic: RSVG.proj, label: __("Projects"), go: () => board.show_face("projects") },
		{ id: "sales", ic: RSVG.sales, label: __("Sales"), go: () => board.show_face("sales") },
		{ id: "chat", ic: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>', label: __("Chat"), go: () => board.show_face("chat") },
		{ id: "clients", ic: RSVG.rooms, label: __("Client Rooms"), go: () => board.show_face("clients") },
		{ id: "me", ic: RSVG.me, label: __("My Dashboard"), go: () => board.show_face("me") },
		{ id: "news", ic: '<path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"/><path d="M18 14h-8"/><path d="M15 18h-5"/><path d="M10 6h8v4h-8V6Z"/>', label: __("News"), go: () => board.show_face("news") },
	];
	board._rsvg = RSVG;
	board._is_consultant = localStorage.getItem("duty_cons") === "1";
	// Desktop staff reach the dashboard as a tab inside My Day now.
	// Consultants keep the standalone face; mobile keeps its \ud83d\udc64 chip.
	if (!board._is_consultant && !board.is_mobile()) {
		board.rail = board.rail.filter((r) => r.id !== "me");
	}
	// show_face only runs on clicks; fire it once so the day tabs (and
	// every other face-state toggle) are correct on first paint.
	// Desktop only: this exists so the day tabs paint on first load.
	// On mobile it fired AFTER the tab bar restored the saved tab, hiding
	// the dashboard host mid-fetch and triggering the old overlay fallback.
	if (!board._is_consultant && !window.matchMedia("(max-width: 991px)").matches) {
		board.show_face("board");
	}
	if (board._is_consultant) {
		$("body").addClass("duty-consultant");
		if (!window._duty_msg_wrap) {
			window._duty_msg_wrap = 1;
			const _mp = frappe.msgprint;
			frappe.msgprint = function (msg, ...rest) {
				const txt = typeof msg === "string" ? msg : (msg && (msg.message || "")) || "";
				if (board._is_consultant && /not permitted/i.test(String(txt))) return;
				return _mp.call(this, msg, ...rest);
			};
		}
	}
	board.build_rail();
	if (!board._is_consultant) frappe.call({
		method: "duty_board.accounting.books_access",
		error: () => {},
		callback: (r) => {
			board.books_acc = (r.message && r.message.allowed && r.message) || null;
			if (board.books_acc) {
				board.rail.push({ id: "books", ic: board._rsvg.books, label: __("Books"), go: () => board.show_face("books") });
				if (board.books_acc.manager) board.rail.push({ id: "cost", ic: board._rsvg.coin, label: __("Cost to serve"), go: () => board.cost_dialog() });
				board.build_rail();
				board._more_extra = board._more_extra || [];
				board._more_extra.push({ icon: "📒", label: __("Books"), go: () => board.set_mtab("books") });
				if (board.books_acc.manager) {
					board._more_extra = board._more_extra || [];
					board._more_extra.push({ icon: "💰", label: __("Cost to serve"), go: () => board.cost_dialog() });
				}
			}
		},
	});
	if (!board._is_consultant) frappe.call({
		method: "duty_board.commercial.pricing_queue",
		error: () => {},
		callback: (r) => {
			const q = r.message || {};
			board.is_pricer = !!q.pricer;
			board.rail.splice(5, 0, { id: "library", ic: board._rsvg.lib, label: __("Library"), go: () => board.show_face("library") });
			board.rail.push({ id: "training", ic: board._rsvg.cap, label: __("Team training"), go: () => board.team_training_dialog() });
			board.rail.push({ id: "academyhealth", ic: board._rsvg.pulse, label: __("Academy health"), go: () => board.academy_health_dialog() });
			board.rail.push({ id: "lessonq", ic: board._rsvg.ask, label: __("Lesson questions"), go: () => board.lesson_questions_dialog() });
			/* An unanswered question is only useful if somebody knows it is there.
			   The count rides on the rail label so it is visible without opening. */
			frappe.call({
				method: "duty_board.academy.question_counts",
				error: () => {},
				callback: (qc) => {
					const n = (qc.message || {}).open || 0;
					if (!n) return;
					const item = board.rail.find((x) => x.id === "lessonq");
					if (item) { item.label = __("Lesson questions ({0})", [n]); board.build_rail(); }
				},
			});
			if (q.pricer) board.rail.push({ id: "pricing", ic: board._rsvg.tag, label: __("CR pricing"), go: () => board.pricing_dialog() });
			board.build_rail();
			page.add_menu_item(__("🎓 Team training"), () => board.team_training_dialog());
			page.add_menu_item(__("\u{1F4C8} Academy health"), () => board.academy_health_dialog());
			board._more_extra = board._more_extra || [];
			board._more_extra.push({ icon: "🎓", label: __("Team training"), go: () => board.team_training_dialog() });
			board._more_extra.push({ icon: "\u{1F4C8}", label: __("Academy health"), go: () => board.academy_health_dialog() });
			if (q.pricer) {
				page.add_menu_item(__("💼 CR pricing ({0})", [(q.queue || []).length]), () => board.pricing_dialog());
				board._more_extra = board._more_extra || [];
				board._more_extra.push({ icon: "💼", label: __("CR pricing"), go: () => board.pricing_dialog() });
			}
		},
	});
	page.add_inner_button(__("📄 Document Hub"), () => frappe.set_route("List", "Client Document"));

	board.timer = setInterval(() => {
		if (board._halted) return;
		if (frappe.get_route_str() !== "duty-board") return;
		if (board.face === "projects") board.refresh_projects(true);
		else if (board.face === "sales") board.refresh_sales(true);
		else if (board.face === "clients") board.refresh_clients(true);
		else board.refresh(true);
	}, 60 * 1000);
	board.main_timer = board.timer;
};

class DutyBoard {
	constructor(page) {
		this.page = page;
		this.body = $(`
			<div class="duty-board duty-layout">
				<div class="duty-main">
					<div class="duty-me"></div>
					<div class="duty-task"></div>
					<div class="duty-plan"></div>
					<div class="duty-my-sessions"></div>
					<div class="duty-team-title">${__("Team — Today")}</div>
					<div class="duty-team"></div>
					<div class="duty-updated text-muted"></div>
				</div>
				<div class="duty-side">
					<div class="duty-chat"></div>
					<div class="duty-chat-rail" style="display:none" title="${__("Open Duty Room")}">
						<span class="duty-rail-badge" style="display:none"></span>
						<span class="duty-rail-label">💬 ${__("Duty Room")}</span>
					</div>
				</div>
			</div>
		`).appendTo(page.body);
		this.face = "board";
		this._day_tab = "today";
		this.$daytabs = $(`
			<div class="duty-daytabs" style="display:none">
				<a data-dt="today" class="on">\ud83d\udcc6 ${__("My Day")}</a>
				<a data-dt="dash">\ud83d\udcca ${__("Dashboard")}</a>
			</div>`).insertBefore(this.body);
		this.$daytabs.find("a").on("click", (e) => {
			this._day_tab = $(e.currentTarget).attr("data-dt") === "dash" ? "dash" : "today";
			this.show_face("board");
		});
		this.$issues = $(`
			<div class="duty-issues-face" style="display:none">
				<div class="duty-issues"></div>
				<div class="duty-issues-rail" style="display:none"></div>
			</div>`).appendTo(page.body);
		this.$projects = $(`
			<div class="duty-projects" style="display:none">
				<div class="duty-pj-side">
					<div class="duty-pj-sidehead">
						<input type="text" class="form-control input-sm duty-pj-filter" placeholder="${__("Filter projects…")}">
						<button class="btn btn-sm btn-default duty-proj-portfolio" title="${__("Portfolio — all projects at a glance")}">📊</button>
						<button class="btn btn-sm btn-default duty-proj-team" title="${__("Team load — who's carrying what")}">👥</button>
						<button class="btn btn-sm btn-default duty-proj-new" title="${__("New Project")}">＋</button>
					</div>
					<div class="duty-proj-tabs"></div>
				</div>
				<div class="duty-pj-main">
					<div class="duty-pj-title"></div>
					<div class="duty-kanban-wrap"></div>
				</div>
			</div>
		`).appendTo(page.body);
		this.$projects.find(".duty-proj-new").on("click", () => this.new_project_dialog());
		this.$projects.find(".duty-proj-portfolio").on("click", () => this.render_portfolio());
		this.$projects.find(".duty-proj-team").on("click", () => this.render_team_load());
		this.$library = $(`<div class="duty-library" style="display:none"></div>`).appendTo(page.body);
		this.$news = $(`<div class="duty-news" style="display:none"></div>`).appendTo(page.body);
		this.$projects.find(".duty-pj-filter").on("input", (e) => {
			this._pj_filter = e.target.value;
			this.render_project_tabs();
		});
		this.$sales = $(`
			<div class="duty-sales" style="display:none">
				<div class="duty-sales-head">
					<div class="duty-sales-total"></div>
					<div class="duty-sales-actions">
						<a class="duty-sales-arch" data-outcome="Won">🏆 ${__("Won")}</a>
						<a class="duty-sales-arch" data-outcome="Lost">✖ ${__("Lost")}</a>
						<button class="btn btn-sm btn-primary duty-lead-new">＋ ${__("New Lead")}</button>
					</div>
				</div>
				<div class="duty-sales-wrap"></div>
			</div>
		`).appendTo(page.body);
		this.$sales.find(".duty-lead-new").on("click", () => this.new_lead_dialog());
		this.$sales.find(".duty-sales-arch").on("click", (e) =>
			this.closed_leads_dialog($(e.currentTarget).data("outcome"))
		);
		this.$clients = $(`
			<div class="duty-clients" style="display:none">
				<div class="duty-cr-list"></div>
				<div class="duty-cr-room" style="display:none"></div>
			</div>
		`).appendTo(page.body);
		this.$chatface = $(`
			<div class="duty-chatface" style="display:none">
				<div class="duty-ch-rail">
					<div class="duty-ch-railhead"><b>\ud83d\udcac ${__("Chats")}</b><span class="duty-ch-total"></span><a class="duty-ch-new" title="${__("New direct message")}">\u270f</a></div>
					<div class="duty-ch-search"><input type="text" class="form-control input-sm" placeholder="${__("Search chats\u2026")}"></div>
					<div class="duty-ch-list"></div>
				</div>
				<div class="duty-ch-center">
					<a class="duty-ch-sidetoggle" style="display:none" title="${__("Show or hide the task column")}">\ud83d\udccb</a>
					<div class="duty-ch-room duty-cr-room" style="display:none"></div>
					<div class="duty-ch-team" style="display:none"></div>
					<div class="duty-ch-dm" style="display:none"></div>
					<div class="duty-ch-blank">${__("Pick a conversation on the left.")}</div>
				</div>
			</div>
		`).appendTo(page.body);
		if (localStorage.getItem("duty_ch_side") === "0") this.$chatface.addClass("ch-side-hidden");
		this.$chatface.find(".duty-ch-sidetoggle").on("click", () => this.toggle_ch_side());
		this.$chatface.find(".duty-ch-new").on("click", () => this.new_dm_dialog());
		this.$chatface.find(".duty-ch-search input").on("input", frappe.utils.debounce((e) => {
			this._ch_q = e.target.value;
			this.render_chat_rail();
		}, 200));
		this.$me = $(`<div class="duty-me" style="display:none"></div>`).appendTo(page.body);
		this.$books = $(`<div class="duty-books" style="display:none"></div>`).appendTo(page.body);
		this.name_map = {};
		this.inject_style();
		this.setup_pwa();
		this.init_chat();
		this.setup_mobile_tabs();
		document.addEventListener(
			"click",
			(e) => {
				const btn = e.target.closest && e.target.closest(".duty-dm-btn");
				if (!btn) return;
				e.preventDefault();
				e.stopPropagation();
				this.open_dm($(btn).data("user"), $(btn).data("name"));
			},
			true
		);
	}

	// ---------------- Team chat ----------------

	init_chat() {
		this.unread = 0;
		this.base_title = document.title;
		this._mentions = [];
		this._reply = null;
		this._file = null;
		const $c = this.body.find(".duty-chat");
		$c.html(`
			<div class="duty-chat-card">
				<div class="duty-chat-head">
					<span>💬 ${__("Duty Room")} <span class="duty-chat-badge" style="display:none"></span></span>
					<span class="duty-chat-tools">
						<a class="duty-chat-notif" style="display:none">${__("Enable notifications")}</a>
						<a class="duty-chat-search-toggle" title="${__("Search messages")}">🔍</a>
						<a class="duty-chat-collapse" title="${__("Collapse")}">»</a>
					</span>
				</div>
				<div class="duty-search-bar" style="display:none">
					<input type="text" class="form-control input-sm duty-search-input" placeholder="${__("Search messages...")}">
					<a class="duty-search-close">×</a>
				</div>
				<div class="duty-search-notice" style="display:none"></div>
				<div class="duty-chat-list"></div>
				<div class="duty-reply-bar" style="display:none"></div>
				<div class="duty-attach-bar" style="display:none"></div>
				<div class="duty-chat-typing" style="display:none"></div>
				<div class="duty-tc-emojis" style="display:none"></div>
				<div class="duty-chat-send" style="display:block">
					<div class="duty-chat-input-wrap">
						<textarea rows="2" class="form-control duty-chat-input" maxlength="1000"
							placeholder="${__("Message the team — @ to mention, Shift+Enter for a new line...")}"></textarea>
						<div class="duty-mention-menu" style="display:none"></div>
					</div>
					<div class="duty-chat-toolbar" style="display:flex;align-items:center;gap:8px;margin-top:6px">
						<label class="btn btn-default btn-sm duty-attach-btn" style="margin:0" title="${__("Attach file, image or video (max 25 MB)")}">📎<input type="file" class="duty-file-input" hidden></label>
						<a class="duty-tc-emojibtn" title="${__("Emoji")}">😊</a>
						<a class="duty-tc-mic" title="${__("Hold to record a voice note")}">🎙</a>
						<button class="btn btn-primary btn-sm duty-chat-btn" style="margin-left:auto">${__("Send")}</button>
					</div>
				</div>
			</div>
		`);

		this.$chat = $c.find(".duty-chat-card");
		this.$rail = this.body.find(".duty-chat-rail");
		this.chat_open = localStorage.getItem("duty_chat_open") !== "0";
		if (this.is_mobile()) this.chat_open = true;
		this.last_seen = localStorage.getItem("duty_chat_seen") || "";
		this.apply_chat_state();
		$c.find(".duty-chat-collapse").on("click", () => this.toggle_chat(false));
		this.$rail.on("click", () => this.toggle_chat(true));
		this.$list = $c.find(".duty-chat-list");
		this.$badge = $c.find(".duty-chat-badge");
		this.$input = $c.find(".duty-chat-input");
		this.$input.on("input", function () {
			if (!window.matchMedia("(max-width: 991px)").matches) return;
			this.style.height = "42px";
			this.style.height = Math.min(this.scrollHeight, 120) + "px";
		});
		this._last_typing = 0;
		this.$input.on("input", () => {
			const now = Date.now();
			if (now - this._last_typing < 2500) return;
			this._last_typing = now;
			frappe.call({ method: "duty_board.api.duty_typing", freeze: false });
		});
		this.$mmenu = $c.find(".duty-mention-menu");
		this.$replybar = $c.find(".duty-reply-bar");
		this.$attachbar = $c.find(".duty-attach-bar");

		this.seen_map = {};
		this.load_messages();

		frappe.realtime.on("duty_board_seen", (d) => {
			if (d && d.user) {
				this.seen_map[d.user] = d.last_seen;
				this.update_receipts();
			}
		});
		frappe.realtime.on("duty_board_reaction", (d) => {
			if (!d || !d.message) return;
			const $row = this.$list.find(`.duty-msg[data-name="${d.message}"]`);
			if ($row.length) this.render_reactions($row, d.reactions || {}, d.message);
		});

		$c.find(".duty-chat-search-toggle").on("click", () => {
			$c.find(".duty-search-bar").toggle();
			$c.find(".duty-search-input").focus();
		});
		$c.find(".duty-search-close").on("click", () => {
			$c.find(".duty-search-bar").hide();
			$c.find(".duty-search-input").val("");
			this.exit_search();
		});
		$c.find(".duty-search-input").on("keydown", (e) => {
			if (e.key === "Enter") this.run_search($c.find(".duty-search-input").val());
			if (e.key === "Escape") $c.find(".duty-search-close").click();
		});

		frappe.realtime.on("duty_board_message", (m) => {
			this.handle_incoming(m);
			this.ch_ping();
		});
		frappe.realtime.on("duty_board_message_edit", (m) => {
			const $row = this.$list && this.$list.find(`.duty-msg[data-name="${m.name}"]`);
			if ($row && $row.length) {
				$row.find(".duty-msg-text").html(this.format_message_text(m));
				if (!$row.find(".duty-msg-edited").length) {
					$row.find(".duty-msg-time").append(
						` <span class="duty-msg-edited">${__("edited")}</span>`
					);
				}
			}
		});
		this._sync_timer = setInterval(() => this.sync_messages(), 25 * 1000);
		frappe.realtime.on("duty_board_notify", (d) => this.notify_event(d));
		frappe.realtime.on("duty_board_dm", (m) => {
			this.handle_dm(m);
			this.ch_ping();
		});
		frappe.realtime.on("duty_board_typing", (n) => {
			if (!n || n.user === frappe.session.user) return;
			const $t = $(".duty-chat-typing");
			if (!$t.length) return;
			$t.text(`${n.who} ${__("is typing…")}`).show();
			clearTimeout(this._typing_hide);
			this._typing_hide = setTimeout(() => $t.hide(), 4000);
		});
		frappe.realtime.on("duty_client_typing", (n) => {
			if (!n || !n.room || n.room !== this._open_room) return;
			const me_first = (this.name_map[frappe.session.user] || "").split(" ")[0];
			if (n.staff && n.who === me_first) return;
			const $t = this.$clients.find(".duty-cr-typing");
			if (!$t.length) return;
			$t.text(
				n.client
					? `${n.who} (${__("client")}) ${__("is typing…")}`
					: `${n.who} ${__("is typing…")}`
			).show();
			clearTimeout(this._cr_typing_hide);
			this._cr_typing_hide = setTimeout(() => $t.hide(), 4000);
		});
		frappe.realtime.on("duty_client_room", (n) => {
			if (n && n.room && this._open_room === n.room) this.load_client_room(n.room);
			else if (this.face === "clients") this.refresh_clients(true);
			this.ch_ping();
		});
		frappe.realtime.on("duty_board_note", (n) => {
			if (!n || !n.id) return;
			if (n.kind === "card" && this._open_card_ctx && this._open_card_ctx.id === n.id) {
				frappe.call({
					method: "duty_board.projects.get_card",
					args: { name: n.id },
					callback: (r) => {
						const ctx = this._open_card_ctx;
						if (r.message && ctx && ctx.id === n.id) this.update_notes(ctx.$x, r.message.notes);
					},
				});
			}
			if (n.kind === "lead" && this._open_lead_ctx && this._open_lead_ctx.id === n.id) {
				frappe.call({
					method: "duty_board.sales.get_lead",
					args: { name: n.id },
					callback: (r) => {
						const ctx = this._open_lead_ctx;
						if (r.message && ctx && ctx.id === n.id) this.update_notes(ctx.$x, r.message.notes);
					},
				});
			}
		});
		frappe.realtime.on("duty_board_message_deleted", (d) => {
			if (d && d.name) {
				this.$list.find(`.duty-msg[data-name="${d.name}"]`).fadeOut(200, function () {
					$(this).remove();
				});
			}
		});
		this._due_timer = setInterval(() => this.check_due_todos(), 30 * 1000);

		$c.find(".duty-chat-btn").on("click", () => this.send_chat());
		this.$input.on("keydown", (e) => {
			if (this.$mmenu.is(":visible")) {
				if (e.key === "Enter" || e.key === "Tab") {
					e.preventDefault();
					const $a = this.$mmenu.find(".active");
					this.pick_mention(($a.length ? $a : this.$mmenu.children().first()).data("user"));
					return;
				}
				if (e.key === "ArrowDown" || e.key === "ArrowUp") {
					e.preventDefault();
					this.move_mention(e.key === "ArrowDown" ? 1 : -1);
					return;
				}
				if (e.key === "Escape") {
					this.$mmenu.hide();
					return;
				}
			}
			if (e.key === "Enter" && !e.shiftKey) {
				e.preventDefault();
				this.send_chat();
			}
		});
		this.$input.on("input click", () => this.update_mention_menu());
		this.$input.on("input", () => this.autosize_input());
		this.$input.on("paste", (e) => {
			const items = (e.originalEvent.clipboardData || {}).items || [];
			for (const it of items) {
				if (it.kind === "file") {
					const f = it.getAsFile();
					if (f) {
						e.preventDefault();
						this.set_file(f);
						break;
					}
				}
			}
		});
		$c.find(".duty-file-input").on("change", (e) => {
			if (e.target.files[0]) this.set_file(e.target.files[0]);
			e.target.value = "";
		});
		const TC_EMOJIS = ["😀","😂","🙏","👍","👌","🙌","🎉","❤️","🔥","💯","😅","😢","😡","🤔","👀","✅","❌","⏳","📌","💡","📞","🤝","🚀","🙈"];
		const $tce = $c.find(".duty-tc-emojis");
		$c.find(".duty-tc-emojibtn").on("click", () => {
			if ($tce.is(":visible")) return $tce.hide();
			if (!$tce.children().length)
				TC_EMOJIS.forEach((em) =>
					$(`<a style="font-size:19px;padding:2px 5px;cursor:pointer;text-decoration:none">${em}</a>`)
						.appendTo($tce)
						.on("click", () => { this.$input.val(this.$input.val() + em).focus(); })
				);
			$tce.css({ display: "flex", "flex-wrap": "wrap", gap: "2px", padding: "4px 6px" }).show();
		});
		this.bind_recorder($c.find(".duty-tc-mic"), (file) => {
			this.set_file(file);
			this.send_chat();
		});

		document.addEventListener("visibilitychange", () => {
			if (!document.hidden && this.chat_open && (!this.is_mobile() || this.mtab === "chat")) {
				this.mark_caught_up();
			}
		});

		const $notif = $c.find(".duty-chat-notif");
		if (window.Notification && Notification.permission === "default") {
			$notif.show().on("click", (e) => {
				e.preventDefault();
				e.stopPropagation();
				Notification.requestPermission().then(() => {
					$notif.hide();
					if (this._sw) this.maybe_subscribe_push(this._sw);
				});
			});
		}
	}

	notify_event(d) {
		if (!d || !d.title) return;
		frappe.show_alert(
			{
				message: `<b>${frappe.utils.escape_html(d.title)}</b><br>${frappe.utils.escape_html(d.body || "")}`,
				indicator: "blue",
			},
			8
		);
		this.ping();
		if (window.Notification && Notification.permission === "granted") {
			try {
				new Notification(d.title, {
					body: d.body || "",
					tag: "duty-notify",
					renotify: true,
				});
			} catch (e) {
				/* ignore */
			}
		}
		this.refresh(true);
	}

	check_due_todos() {
		if (this._halted) return;
		if (frappe.get_route_str() !== "duty-board") return;
		this._due_alerted = this._due_alerted || {};
		const now = new Date();
		(this.my_todos || []).forEach((t) => {
			if (t.status !== "Open" || !t.due_time || this._due_alerted[t.name]) return;
			const parts = t.due_time.split(":");
			const due = new Date();
			due.setHours(Number(parts[0]), Number(parts[1]), 0, 0);
			const mins = (due - now) / 60000;
			if (mins > 0 && mins <= 5) {
				this._due_alerted[t.name] = true;
				this.notify_event({
					title: __("Starting in {0} min", [Math.ceil(mins)]),
					body: t.description,
				});
			}
		});
	}

	touch_issues() {
		this._issues_alt = null;
		this._issues_alt_scope = null;
		this.refresh(true);
	}

	check_overdue_issues(issues) {
		const today = frappe.datetime.get_today();
		if (localStorage.getItem("duty_overdue_day") === today) return;
		const mine = (issues || []).filter(
			(x) => this.issue_is_mine(x) && x.due_date && x.due_date < today
		);
		if (!mine.length) return;
		localStorage.setItem("duty_overdue_day", today);
		const titles = mine
			.slice(0, 3)
			.map((x) => x.title)
			.join(" · ");
		this.notify_event({
			title: __("{0} of your issue(s) are overdue", [mine.length]),
			body: titles + (mine.length > 3 ? " …" : ""),
		});
	}

	user_color(user) {
		const palette = [
			"#0E7490", "#B45309", "#6D28D9", "#BE185D", "#15803D", "#B91C1C",
			"#1D4ED8", "#0F766E", "#A16207", "#7C2D12", "#4D7C0F", "#86198F",
		];
		let h = 0;
		for (let i = 0; i < (user || "").length; i++) h = (h * 31 + user.charCodeAt(i)) >>> 0;
		return palette[h % palette.length];
	}

	handle_incoming(m) {
		if (!m || !m.name) return;
		if (this.search_mode) return;
		if (this.$list.find(`.duty-msg[data-name="${m.name}"]`).length) return;
		const mine = m.user === frappe.session.user;
		const seen_live =
			mine ||
			(this.chat_open && !document.hidden && (!this.is_mobile() || this.mtab === "chat"));
		try {
			this.append_message(m, !seen_live);
		} catch (e) {
			console.error("Duty Room: failed to render message", m && m.name, e);
		}
		this.scroll_chat();
		if (seen_live) {
			this.mark_caught_up(m.creation);
		} else {
			this.bump_unread();
		}
		if (!mine) {
			const mentioned = (m.mentions || []).includes(frappe.session.user);
			this.ping();
			if (mentioned) setTimeout(() => this.ping(), 450);
			this.desktop_notify(m, mentioned);
		}
	}

	sync_messages() {
		if (this._halted || this.search_mode) return;
		if (frappe.get_route_str() !== "duty-board") return;
		const latest = this.latest_creation();
		if (!latest) return;
		frappe.call({
			method: "duty_board.api.get_messages",
			args: { after: latest },
			error: (x) => this._poll_failed(x),
			callback: (r) => {
				this._fail_count = 0;
				const msgs = (r.message && r.message.messages) || [];
				msgs.forEach((m) => this.handle_incoming(m));
			},
		});
	}

	_badge_more() {
		const total = this._issues_open || 0;
		$(".duty-tabbar .duty-tab-more").text(total).toggle(total > 0);
	}

	refresh_sheet_badges() {
		$(".duty-sheet .duty-tab-issues").text(this._issues_open || 0).toggle((this._issues_open || 0) > 0);
	}

	is_mobile() {
		return window.matchMedia("(max-width: 767px)").matches;
	}

	setup_mobile_tabs() {
		if (!window.matchMedia("(max-width: 991px)").matches) return;
		$("body").addClass("duty-mobile");
		this._more_extra = this._more_extra || [];
		const $bar = $(`
			<div class="duty-tabbar">
				<a data-tab="me"><span>🏠</span>${__("Today")}</a>
				<a data-tab="chat"><span>💬</span>${__("Chat")}<b class="duty-tab-badge duty-tab-chat" style="display:none"></b></a>
				<a data-tab="projects"><span>📁</span>${__("Projects")}</a>
				<a data-tab="library"><span>📚</span>${__("Library")}</a>
				<a data-tab="more"><span>⋯</span>${__("More")}<b class="duty-tab-badge duty-tab-more" style="display:none"></b></a>
			</div>
		`).appendTo("body");
		$bar.find("a").on("click", (e) => {
			const tab = $(e.currentTarget).data("tab");
			const go = () => (tab === "more" ? this.more_sheet() : this.set_mtab(tab));
			if (frappe.get_route_str() !== "duty-board") {
				if (tab !== "more") localStorage.setItem("duty_mtab", tab);
				frappe.set_route("duty-board").then(go);
				return;
			}
			go();
		});
		this.set_mtab(localStorage.getItem("duty_mtab") || "me");
		const sync_bar = () => {
			const here = frappe.get_route_str() === "duty-board";
			$bar.toggleClass("duty-tabbar-away", !here);
			$("body").toggleClass("duty-immersive", here);
		};
		frappe.router.on("change", sync_bar);
		sync_bar();
	}

	more_sheet() {
		const items = [
			{ icon: "📋", label: __("Team board"), go: () => this.set_mtab("board") },
			{ icon: "✓", label: __("My plan"), go: () => this.set_mtab("plan") },
			{ icon: "🤝", label: __("Client Rooms"), badge: "duty-tab-clients", go: () => this.set_mtab("clients") },
			{ icon: "⚠", label: __("Issues"), badge: "duty-tab-issues", go: () => this.set_mtab("issues") },
			{ icon: "💼", label: __("Sales"), go: () => this.set_mtab("sales") },
		].concat(this._more_extra || []);
		this.sheet(__("More"), items);
	}

	sheet(title, items) {
		$(".duty-sheet-wrap").remove();
		const $w = $(`
			<div class="duty-sheet-wrap">
				<div class="duty-sheet-ovl"></div>
				<div class="duty-sheet">
					<div class="duty-sheet-grip"></div>
					<div class="duty-sheet-title">${frappe.utils.escape_html(title)}</div>
					<div class="duty-sheet-items"></div>
				</div>
			</div>`).appendTo("body");
		const close = () => $w.remove();
		$w.find(".duty-sheet-ovl").on("click", close);
		const $it = $w.find(".duty-sheet-items");
		items.forEach((i) => {
			const $row = $(`<a class="duty-sheet-item"><span class="i">${i.icon}</span><span class="l">${frappe.utils.escape_html(i.label)}</span>${i.badge ? `<b class="duty-tab-badge ${i.badge}" style="position:static;display:none;margin-left:auto"></b>` : ""}</a>`)
				.appendTo($it)
				.on("click", () => { close(); i.go(); });
		});
		this.refresh_sheet_badges && this.refresh_sheet_badges();
		requestAnimationFrame(() => $w.addClass("open"));
	}

	set_mtab(tab) {
		this.mtab = tab;
		localStorage.setItem("duty_mtab", tab);
		if (tab === "projects") {
			this.show_face("projects");
		} else if (tab === "sales") {
			this.show_face("sales");
		} else if (tab === "chat") {
			this.show_face("chat");
		} else if (tab === "clients") {
			this.show_face("clients");
		} else if (tab === "me") {
			this.show_face("me");
		} else if (tab === "books") {
			this.show_face("books");
		} else if (tab === "library") {
			this.show_face("library");
		} else if (tab === "issues") {
			this.show_face("issues");
		} else {
			this.show_face("board");
			this.body.attr("data-mtab", tab);
		}
		const primary = ["me", "chat", "projects", "library"];
		$(".duty-tabbar a")
			.removeClass("active")
			.filter(`[data-tab="${primary.indexOf(tab) >= 0 ? tab : "more"}"]`)
			.addClass("active");
		if (tab === "chat") {
			this.mark_caught_up();
			this.scroll_chat();
		}
	}

	setup_pwa() {
		if (!("serviceWorker" in navigator)) return;
		if (!document.querySelector('link[rel="manifest"]')) {
			$('<link rel="manifest" href="/assets/duty_board/mobile/manifest.webmanifest">').appendTo("head");
		}
		navigator.serviceWorker
			.register("/duty_sw.js", { scope: "/" })
			.then((reg) => {
				this._sw = reg;
				this.maybe_subscribe_push(reg);
			})
			.catch(() => {
				/* SW route not configured yet — PWA features stay off */
			});
	}

	async maybe_subscribe_push(reg) {
		try {
			if (!window.Notification || Notification.permission !== "granted") return;
			if (!reg.pushManager) return;
			const r = await frappe.call({ method: "duty_board.push.get_push_config" });
			const key = r.message && r.message.public_key;
			if (!key) return;
			let sub = await reg.pushManager.getSubscription();
			if (!sub) {
				sub = await reg.pushManager.subscribe({
					userVisibleOnly: true,
					applicationServerKey: this.urlb64_to_uint8(key),
				});
			}
			frappe.call({
				method: "duty_board.push.save_push_subscription",
				args: { subscription: JSON.stringify(sub.toJSON()) },
			});
		} catch (e) {
			/* push unsupported or denied on this device — realtime still works */
		}
	}

	urlb64_to_uint8(s) {
		const pad = "=".repeat((4 - (s.length % 4)) % 4);
		const b = (s + pad).replace(/-/g, "+").replace(/_/g, "/");
		const raw = atob(b);
		return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
	}

	_poll_failed(x) {
		if (this._halted) return;
		const status = (x && (x.status || (x.xhr && x.xhr.status) || (x.responseJSON && x.responseJSON.http_status_code))) || 0;
		if (!navigator.onLine || status === 0 || status >= 500 || status === 417) {
			this._note_reconnecting();
			return;
		}
		if (status === 401 || status === 403) {
			this._verify_session();
			return;
		}
		// other 4xx: endpoint-specific problem, not connectivity — ignore here
	}

	_note_reconnecting() {
		const now = Date.now();
		this._reconn_count = (this._reconn_count || 0) + 1;
		if (this._reconn_count >= 5) {
			this._reconn_count = 0;
			this._verify_session();
			return;
		}
		if (this._reconn_toast_at && now - this._reconn_toast_at < 60000) return;
		this._reconn_toast_at = now;
		frappe.show_alert({ message: __("Reconnecting to Duty Board…"), indicator: "orange" }, 4);
	}

	_verify_session() {
		const now = Date.now();
		if (this._auth_checking) return;
		if (this._auth_checked_at && now - this._auth_checked_at < 10000) return;
		this._auth_checking = true;
		$.ajax({ url: "/api/method/frappe.auth.get_logged_user", timeout: 8000 })
			.done(() => {
				this._reconn_count = 0; // session alive — it was transient
			})
			.fail((xhr) => {
				if (xhr && (xhr.status === 401 || xhr.status === 403)) this.halt_polling();
				else this._note_reconnecting();
			})
			.always(() => {
				this._auth_checking = false;
				this._auth_checked_at = Date.now();
			});
	}

	halt_polling() {
		if (this._halted) return;
		this._halted = true;
		clearInterval(this.main_timer);
		clearInterval(this._sync_timer);
		clearInterval(this._due_timer);
		this.stop_title_flash();
		frappe.msgprint({
			title: __("Connection lost"),
			message: __(
				"Duty Board can no longer reach the server — your session has probably expired. Please log in again, then reopen the board."
			),
			primary_action: {
				label: __("Log in again"),
				action: () => (window.location.href = "/login?redirect-to=/app/duty-board"),
			},
		});
	}

	toggle_chat(open) {
		this.chat_open = open;
		localStorage.setItem("duty_chat_open", open ? "1" : "0");
		this.apply_chat_state();
		if (open) {
			this.mark_caught_up();
			this.scroll_chat();
			this.$input.focus();
		}
	}

	apply_chat_state() {
		this.body.toggleClass("duty-chat-collapsed", !this.chat_open);
		this.body.find(".duty-chat").toggle(this.chat_open);
		this.$rail.toggle(!this.chat_open);
	}

	autosize_input() {
		const el = this.$input[0];
		el.style.height = "auto";
		el.style.height = Math.min(el.scrollHeight, 120) + "px";
	}

	team_members() {
		return Object.keys(this.name_map || {})
			.map((u) => ({ user: u, full_name: this.name_map[u] }))
			.filter((x) => x.user !== frappe.session.user);
	}

	update_mention_menu() {
		const val = this.$input.val() || "";
		const caret = this.$input[0].selectionStart;
		const match = val.slice(0, caret).match(/@([\w .-]*)$/);
		if (!match) {
			this.$mmenu.hide();
			return;
		}
		const q = match[1].toLowerCase();
		const opts = this.team_members()
			.filter((x) => x.full_name.toLowerCase().includes(q) || x.user.toLowerCase().includes(q))
			.slice(0, 6);
		if ("all".startsWith(q)) {
			opts.unshift({ user: "__all__", full_name: __("all — notify everyone") });
		}
		if (!opts.length) {
			this.$mmenu.hide();
			return;
		}
		this.$mmenu.empty();
		opts.forEach((o, ix) => {
			$(`<div class="duty-mention-opt ${ix === 0 ? "active" : ""}" data-user="${o.user}">${frappe.utils.escape_html(o.full_name)}</div>`)
				.appendTo(this.$mmenu)
				.on("mousedown", (e) => {
					e.preventDefault();
					this.pick_mention(o.user);
				});
		});
		this.$mmenu.show();
	}

	move_mention(dir) {
		const $opts = this.$mmenu.children();
		let ix = $opts.index(this.$mmenu.find(".active"));
		ix = (ix + dir + $opts.length) % $opts.length;
		$opts.removeClass("active").eq(ix).addClass("active");
	}

	pick_mention(user) {
		if (!user) return;
		const handle = user === "__all__" ? "@all" : "@" + (this.name_map[user] || user).split(" ")[0];
		const val = this.$input.val();
		const caret = this.$input[0].selectionStart;
		const before = val.slice(0, caret).replace(/@([\w .-]*)$/, handle + " ");
		this.$input.val(before + val.slice(caret)).focus();
		if (user !== "__all__" && !this._mentions.includes(user)) this._mentions.push(user);
		this.$mmenu.hide();
		this.autosize_input();
	}

	set_reply(m) {
		this._reply = m;
		const who = (m.full_name || m.user).split(" ")[0];
		const snip = (m.message || m.attachment_name || "").slice(0, 60);
		this.$replybar
			.html(`↩ ${__("Replying to")} <b>${frappe.utils.escape_html(who)}</b>: ${frappe.utils.escape_html(snip)} <a class="duty-reply-x">×</a>`)
			.show();
		this.$replybar.find(".duty-reply-x").on("click", () => {
			this._reply = null;
			this.$replybar.hide();
		});
		if (!this.chat_open) this.toggle_chat(true);
		this.$input.focus();
	}

	bind_recorder($btn, on_done) {
		let rec = null, chunks = [], stream = null, started = 0;
		const stop = () => {
			if (rec && rec.state !== "inactive") rec.stop();
			$btn.removeClass("rec").css("animation", "");
		};
		const start = async (e) => {
			e.preventDefault();
			if (rec && rec.state === "recording") return;
			try {
				stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			} catch {
				frappe.show_alert({ message: __("Microphone permission denied."), indicator: "red" });
				return;
			}
			chunks = [];
			started = Date.now();
			rec = new MediaRecorder(stream);
			rec.ondataavailable = (ev) => ev.data.size && chunks.push(ev.data);
			rec.onstop = () => {
				stream.getTracks().forEach((t) => t.stop());
				const dur = Date.now() - started;
				if (dur < 600 || !chunks.length) return;
				const blob = new Blob(chunks, { type: "audio/webm" });
				if (blob.size > 25 * 1024 * 1024) {
					frappe.show_alert({ message: __("Voice note too large."), indicator: "red" });
					return;
				}
				on_done(new File([blob], `voice-note-${Date.now()}.webm`, { type: "audio/webm" }));
			};
			rec.start();
			$btn.addClass("rec").css("animation", "duty-pulse 1s infinite");
		};
		$btn.on("pointerdown", start);
		$btn.on("pointerup pointerleave", stop);
	}

	set_file(f) {
		const MAX = 25 * 1024 * 1024;
		if (f.size > MAX) {
			frappe.msgprint(__("File too large (max 25 MB). For big videos, share a link instead."));
			return;
		}
		this._file = f;
		this.$attachbar
			.html(`📎 ${frappe.utils.escape_html(f.name)} <span class="text-muted">(${(f.size / 1048576).toFixed(1)} MB)</span> <a class="duty-attach-x">×</a>`)
			.show();
		this.$attachbar.find(".duty-attach-x").on("click", () => {
			this._file = null;
			this.$attachbar.hide();
		});
	}

	async send_chat() {
		const text = (this.$input.val() || "").trim();
		if (!text && !this._file) return;

		let kept = this._mentions.filter((u) => {
			const h = "@" + (this.name_map[u] || u).split(" ")[0];
			return text.includes(h);
		});
		if (/@all\b/i.test(text)) {
			kept = this.team_members().map((x) => x.user);
		}
		const args = { message: text, mentions: JSON.stringify(kept) };
		if (this._reply) {
			args.reply_to = this._reply.name;
			args.reply_snippet = (
				(this._reply.full_name || this._reply.user).split(" ")[0] +
				": " +
				(this._reply.message || this._reply.attachment_name || "")
			).slice(0, 120);
		}
		const file = this._file;

		this.$input.val("");
		this.autosize_input();
		this._mentions = [];
		this._reply = null;
		this._file = null;
		this.$replybar.hide();
		this.$attachbar.hide();
		this.$mmenu.hide();

		if (file) {
			try {
				const fd = new FormData();
				fd.append("file", file, file.name);
				fd.append("is_private", "1");
				const res = await fetch("/api/method/upload_file", {
					method: "POST",
					headers: { "X-Frappe-CSRF-Token": frappe.csrf_token },
					body: fd,
				});
				const out = await res.json();
				const fu = out.message && out.message.file_url;
				if (!res.ok || !fu) {
					throw new Error(
						(out._server_messages && JSON.parse(JSON.parse(out._server_messages)[0]).message) ||
							out.exception ||
							`HTTP ${res.status}`
					);
				}
				args.attachment = fu;
				args.attachment_name = file.name;
				args.attachment_type = file.type.startsWith("image/")
					? "image"
					: file.type.startsWith("video/")
					? "video"
					: "file";
			} catch (e) {
				frappe.msgprint(__("Upload failed: {0}", [frappe.utils.escape_html(e.message || "unknown error")]));
				return;
			}
		}
		frappe.call({ method: "duty_board.api.send_message", args: args });
	}

	linkify(escaped) {
		return (escaped || "").replace(/(https?:\/\/[^\s<]+)/g, (u) => {
			const trail = (u.match(/[).,;!?]+$/) || [""])[0];
			const core = trail ? u.slice(0, -trail.length) : u;
			return `<a href="${core}" target="_blank" rel="noopener noreferrer">${core}</a>${trail}`;
		});
	}

	edited_tag(m) {
		return m.edited_on ? ` <span class="duty-msg-edited" title="${__("edited")}">${__("edited")}</span>` : "";
	}

	can_edit(creation) {
		if (!creation) return false;
		const t = frappe.datetime.str_to_obj(creation).getTime();
		return Date.now() - t <= 30 * 60 * 1000;
	}

	edit_prompt(kind, name, current, hasAttach, onDone) {
		const d = new frappe.ui.Dialog({
			title: __("Edit message"),
			fields: [
				{ fieldname: "text", fieldtype: "Small Text", label: __("Message"), default: current || "" },
				hasAttach
					? { fieldname: "drop", fieldtype: "Check", label: __("Remove the attachment"), default: 0 }
					: null,
			].filter(Boolean),
			primary_action_label: __("Save"),
			primary_action: (v) => {
				const method =
					kind === "team"
						? "duty_board.api.edit_message"
						: kind === "room"
						? "duty_board.client_room.edit_room_message"
						: "duty_board.dm.edit_dm";
				frappe.call({
					method: method,
					args: { name: name, message: v.text || "", drop_attachment: v.drop ? 1 : 0 },
					callback: (r) => { d.hide(); if (onDone) onDone(r.message); },
				});
			},
		});
		d.show();
	}

	format_message_text(m) {
		let html = this.linkify(frappe.utils.escape_html(m.message || ""));
		return html.replace(/@([\w-]+)(?![^<]*<\/a>)/g, '<span class="duty-mention">@$1</span>');
	}

	append_message(m, is_new, in_search, $insert_after) {
		const mine = m.user === frappe.session.user;
		const mentioned = !mine && (m.mentions || []).includes(frappe.session.user);
		const when = this.smart_time(m.creation);
		let attach = "";
		if (m.attachment) {
			const url = frappe.utils.escape_html(m.attachment);
			if (m.attachment_type === "image") {
				attach = `<div class="duty-msg-attach"><a href="${url}" target="_blank"><img src="${url}"></a></div>`;
			} else if (m.attachment_type === "video") {
				attach = `<div class="duty-msg-attach"><video src="${url}" controls preload="metadata"></video></div>`;
			} else if (m.attachment_type === "audio" || /\.(webm|ogg|mp3|m4a|wav)$/i.test(m.attachment_name || "")) {
				attach = `<div class="duty-msg-attach"><audio controls preload="none" src="${url}" style="max-width:240px"></audio></div>`;
			} else {
				attach = `<div class="duty-msg-attach"><a href="${url}" target="_blank">📎 ${frappe.utils.escape_html(m.attachment_name || "file")}</a></div>`;
			}
		}
		const $row = $(`
			<div class="duty-msg ${mine ? "duty-msg-mine" : ""} ${mentioned ? "duty-msg-mentioned" : ""} ${is_new ? "duty-msg-new" : ""}" data-creation="${frappe.utils.escape_html(m.creation || "")}" data-name="${frappe.utils.escape_html(m.name || "")}">
				${m.reply_snippet ? `<div class="duty-msg-quote ${m.reply_to ? "duty-msg-quote-link" : ""}" ${m.reply_to ? `data-target="${m.reply_to}"` : ""}>${frappe.utils.escape_html(m.reply_snippet)}</div>` : ""}
				<span class="duty-msg-who" style="color:${this.user_color(m.user)}">${frappe.utils.escape_html(mine ? __("You") : (m.full_name || m.user).split(" ")[0])}</span>
				<span class="duty-msg-text">${this.format_message_text(m)}</span>
				<span class="duty-msg-time">${when}${this.edited_tag(m)}</span>
				${mine && this.can_edit(m.creation) ? `<a class="duty-msg-edit" title="${__("Edit")}">✏</a>` : ""}
				<a class="duty-msg-reply" title="${__("Reply")}">↩</a>
				<a class="duty-msg-react" title="${__("React")}">🙂</a>
				<a class="duty-msg-issue" title="${__("Raise issue from this message")}">⚠</a>
				${frappe.user.has_role("System Manager") ? `<a class="duty-msg-del" title="${__("Delete for everyone")}">🗑</a>` : ""}
				${attach}
			</div>
		`);
		if ($insert_after && $insert_after.length) {
			$row.insertAfter($insert_after);
		} else {
			$row.appendTo(this.$list);
		}
		if (is_new && !in_search) this.ensure_divider($row);
		if (in_search) {
			$row.find(".duty-msg-time").text(when);
			$row.find(".duty-msg-reply, .duty-msg-react, .duty-msg-issue, .duty-msg-del").remove();
		} else {
			$row.find(".duty-msg-reply").on("click", () => this.set_reply(m));
			$row.find(".duty-msg-edit").on("click", () =>
				this.edit_prompt("team", m.name, m.message, !!m.attachment, () => this.load_messages())
			);
			$row.find(".duty-msg-quote-link").on("click", (e) => {
				e.stopPropagation();
				const target = $(e.currentTarget).data("target");
				const $t = this.$list.find(`.duty-msg[data-name="${target}"]`);
				if (!$t.length) {
					frappe.show_alert({ message: __("That message is further up — use Load earlier."), indicator: "orange" }, 3);
					return;
				}
				$t[0].scrollIntoView({ behavior: "smooth", block: "center" });
				$t.addClass("duty-msg-flash");
				setTimeout(() => $t.removeClass("duty-msg-flash"), 1600);
			});
			$row.find(".duty-msg-react").on("click", (e) => {
				e.stopPropagation();
				this.react_picker($row, m.name);
			});
			$row.find(".duty-msg-del").on("click", (e) => {
				e.stopPropagation();
				frappe.confirm(
					__("Delete this message for everyone? Attachments go with it. This cannot be undone."),
					() =>
						frappe.call({
							method: "duty_board.api.delete_message",
							args: { name: m.name },
						})
				);
			});
			$row.find(".duty-msg-issue").on("click", (e) => {
				e.stopPropagation();
				this.create_issue_dialog({
					description: m.message || "",
					source_type: "Chat",
					source: m.name,
				});
			});
			if (m.reactions && Object.keys(m.reactions).length) {
				this.render_reactions($row, m.reactions, m.name);
			}
		}
		if (!$insert_after) {
			const $rows = this.$list.find(".duty-msg");
			if ($rows.length > 400) $rows.slice(0, $rows.length - 400).remove();
		}
		this.witness_observe($row, m);
		return $row;
	}

	load_messages() {
		frappe.call({
			method: "duty_board.api.get_messages",
			callback: (r) => {
				const data = r.message || {};
				const msgs = data.messages || [];
				this.seen_map = data.seen || {};
				this.delivered_map = data.delivered || {};
				this.$list.empty();
				this.$list.append(
					`<div class="duty-load-earlier"><a>${__("Load earlier messages")}</a></div>`
				);
				this.$list.find(".duty-load-earlier a").on("click", () => this.load_earlier());
				this.oldest = msgs.length ? msgs[0].creation : null;
				if (!data.has_more) this.$list.find(".duty-load-earlier").hide();
				let new_count = 0;
				msgs.forEach((m) => {
					try {
						const is_new =
							m.user !== frappe.session.user &&
							!!this.last_seen &&
							m.creation > this.last_seen;
						if (is_new) new_count += 1;
						this.append_message(m, is_new);
					} catch (e) {
						console.error("Duty Room: failed to render message", m && m.name, e);
					}
				});
				if (!this.last_seen && msgs.length) {
					this.set_seen(msgs[msgs.length - 1].creation);
				}
				this.update_receipts();
				this.scroll_chat();
				if (new_count) {
					if (this.chat_open && !document.hidden && (!this.is_mobile() || this.mtab === "chat")) {
						this.mark_caught_up();
					} else {
						this.unread = new_count - 1;
						this.bump_unread();
					}
				}
			},
		});
	}

	load_earlier() {
		if (!this.oldest) return;
		frappe.call({
			method: "duty_board.api.get_messages",
			args: { before: this.oldest },
			callback: (r) => {
				const data = r.message || {};
				const msgs = data.messages || [];
				if (msgs.length) {
					const old_h = this.$list[0].scrollHeight;
					let $anchor = this.$list.find(".duty-load-earlier");
					msgs.forEach((m) => {
						try {
							$anchor = this.append_message(m, false, false, $anchor) || $anchor;
						} catch (e) {
							console.error("Duty Room: failed to render message", m && m.name, e);
						}
					});
					this.oldest = msgs[0].creation;
					this.update_receipts();
					this.$list.scrollTop(this.$list[0].scrollHeight - old_h);
				}
				if (!data.has_more) this.$list.find(".duty-load-earlier").hide();
			},
		});
	}

	run_search(query) {
		query = (query || "").trim();
		if (query.length < 2) return;
		frappe.call({
			method: "duty_board.api.search_messages",
			args: { query: query },
			callback: (r) => {
				this.search_mode = true;
				this.$list.empty();
				const results = r.message || [];
				this.$chat
					.find(".duty-search-notice")
					.text(
						results.length
							? __("{0} result(s) for “{1}” — press × to return to chat", [results.length, query])
							: __("No messages match “{0}”", [query])
					)
					.show();
				results.forEach((m) => {
					try {
						this.append_message(m, false, true);
					} catch (e) {
						console.error("Duty Room: failed to render message", m && m.name, e);
					}
				});
				this.$list.scrollTop(0);
			},
		});
	}

	exit_search() {
		if (!this.search_mode) return;
		this.search_mode = false;
		this.$chat.find(".duty-search-notice").hide();
		this.load_messages();
	}

	update_receipts() {
		const me = frappe.session.user;
		const first = (u) => (((this.name_map || {})[u] || u).split(" ")[0]);
		const audience = [...new Set([...Object.keys(this.seen_map || {}), ...Object.keys(this.delivered_map || {})])].filter((u) => u !== me);
		this.$list.find(".duty-msg-mine").each((_, el) => {
			const $row = $(el);
			const creation = $row.data("creation");
			if (!creation) return;
			const readers = audience.filter((u) => (this.seen_map || {})[u] >= creation);
			const dlv = audience.filter((u) => readers.indexOf(u) < 0 && ((this.delivered_map || {})[u] >= creation || (this.seen_map || {})[u] >= creation));
			const pending = audience.filter((u) => readers.indexOf(u) < 0 && dlv.indexOf(u) < 0);
			let $seen = $row.find(".duty-msg-seen");
			if (!$seen.length) {
				$seen = $(`<span class="duty-msg-seen"></span>`).insertAfter($row.find(".duty-msg-time"));
			}
			const allRead = audience.length && readers.length === audience.length;
			const allDlv = audience.length && !pending.length;
			const tick = allRead || allDlv || readers.length || dlv.length ? "✓✓" : "✓";
			const cls = allRead ? "tick-read" : "tick-dlv";
			const parts = [];
			if (readers.length) parts.push(`${__("Read")}: ${readers.map(first).join(", ")}`);
			if (dlv.length) parts.push(`${__("Delivered")}: ${dlv.map(first).join(", ")}`);
			if (pending.length) parts.push(`${__("Pending")}: ${pending.map(first).join(", ")}`);
			$seen.removeClass("tick-read tick-dlv").addClass(cls)
				.text(`${tick}${readers.length ? " " + readers.length : ""}`)
				.attr("title", parts.join(" · "));
		});
	}

	render_reactions($row, map, name) {
		let $box = $row.find(".duty-msg-reactions");
		if (!$box.length) $box = $(`<div class="duty-msg-reactions"></div>`).appendTo($row);
		$box.empty();
		const me = frappe.session.user;
		Object.keys(map || {}).forEach((emoji) => {
			const users = map[emoji] || [];
			if (!users.length) return;
			const mine = users.includes(me);
			const names = users.map((u) => ((this.name_map || {})[u] || u).split(" ")[0]).join(", ");
			$(`<span class="duty-react-chip ${mine ? "duty-react-mine" : ""}" title="${frappe.utils.escape_html(names)}">${emoji} ${users.length}</span>`)
				.appendTo($box)
				.on("click", () =>
					frappe.call({
						method: "duty_board.api.toggle_reaction",
						args: { message: name, emoji: emoji },
					})
				);
		});
	}

	react_picker($row, name) {
		$(".duty-react-picker").remove();
		const emojis = ["👍", "❤️", "😂", "🎉", "✅", "👀"];
		const $p = $(`<div class="duty-react-picker"></div>`);
		emojis.forEach((e) => {
			$(`<span>${e}</span>`)
				.appendTo($p)
				.on("click", (ev) => {
					ev.stopPropagation();
					$p.remove();
					frappe.call({
						method: "duty_board.api.toggle_reaction",
						args: { message: name, emoji: e },
					});
				});
		});
		$row.append($p);
		setTimeout(() => $(document).one("click", () => $p.remove()), 0);
	}

	ensure_divider($row) {
		if (this.$list.find(".duty-new-divider").length) return;
		$(`<div class="duty-new-divider"><span>${__("New")}</span></div>`).insertBefore($row);
	}

	set_seen(creation) {
		if (creation && creation > (this.last_seen || "")) {
			this.last_seen = creation;
			localStorage.setItem("duty_chat_seen", creation);
		}
	}

	latest_creation() {
		const $last = this.$list.find(".duty-msg").last();
		return $last.data("creation") || "";
	}

	witness_ok() {
		return this.chat_open && !document.hidden && (!this.is_mobile() || this.mtab === "chat");
	}

	witness_observe($row, m) {
		if (!window.IntersectionObserver || !$row || !$row.length) return;
		if (m.user === frappe.session.user) return; // your own words need no witness
		if (!this._witness_io) {
			this._witness_pending = {}; // name → timer
			this._witness_visible = {}; // name → creation (currently ≥50% on screen)
			this._witness_hwm = "";
			this._witness_synced = "";
			this._witness_io = new IntersectionObserver(
				(entries) => {
					entries.forEach((en) => {
						const name = en.target.getAttribute("data-name");
						const creation = $(en.target).data("creation");
						if (!name) return;
						if (en.isIntersecting && en.intersectionRatio >= 0.5) {
							this._witness_visible[name] = creation;
							this.witness_arm(name, creation, en.target);
						} else {
							delete this._witness_visible[name];
							clearTimeout(this._witness_pending[name]);
							delete this._witness_pending[name];
						}
					});
				},
				{ threshold: [0.5] }
			);
			document.addEventListener("visibilitychange", () => {
				if (document.hidden) {
					Object.keys(this._witness_pending || {}).forEach((n) => clearTimeout(this._witness_pending[n]));
					this._witness_pending = {};
				} else {
					Object.keys(this._witness_visible || {}).forEach((n) => this.witness_arm(n, this._witness_visible[n]));
				}
			});
		}
		this._witness_io.observe($row[0]);
	}

	witness_arm(name, creation, el) {
		if (!this.witness_ok() || this._witness_pending[name]) return;
		if (creation && this._witness_hwm && creation <= this._witness_hwm) return; // already witnessed past it
		this._witness_pending[name] = setTimeout(() => {
			delete this._witness_pending[name];
			if (!this.witness_ok() || !this._witness_visible[name]) return;
			if (creation > (this._witness_hwm || "")) {
				this._witness_hwm = creation;
				clearTimeout(this._witness_sync_t);
				this._witness_sync_t = setTimeout(() => {
					if (this._witness_hwm && this._witness_hwm !== this._witness_synced) {
						this._witness_synced = this._witness_hwm;
						frappe.call({ method: "duty_board.api.set_chat_seen", args: { upto: this._witness_hwm } });
					}
				}, 1200);
			}
		}, 1000);
	}

	mark_caught_up(creation) {
		this.set_seen(creation || this.latest_creation());
		this.clear_unread();
		// server receipts now come ONLY from witnessing — re-arm what's on screen
		Object.keys(this._witness_visible || {}).forEach((n) => this.witness_arm(n, this._witness_visible[n]));
		clearTimeout(this._divider_t);
		this._divider_t = setTimeout(() => {
			this.$list.find(".duty-new-divider").remove();
			this.$list.find(".duty-msg-new").removeClass("duty-msg-new");
		}, 5000);
	}

	scroll_chat() {
		this.$list.scrollTop(this.$list[0].scrollHeight);
	}

	bump_unread() {
		this.unread += 1;
		this.$badge.text(this.unread).show();
		this.$rail.find(".duty-rail-badge").text(this.unread).show();
		$(".duty-tab-chat").text(this.unread).show();
		this._badge_more();
		document.title = `(${this.unread}) ${this.base_title}`;
		this.start_title_flash();
	}

	start_title_flash() {
		if (this._flash_t) return;
		this._flash_t = setInterval(() => {
			document.title = document.title.startsWith("🔴")
				? `(${this.unread}) ${this.base_title}`
				: `🔴 ${this.unread} — ${this.base_title}`;
		}, 1400);
	}

	stop_title_flash() {
		clearInterval(this._flash_t);
		this._flash_t = null;
	}

	clear_unread() {
		this.unread = 0;
		this.$badge.hide();
		this.$rail.find(".duty-rail-badge").hide();
		$(".duty-tab-chat").hide();
		this._badge_more();
		this.stop_title_flash();
		document.title = this.base_title;
	}

	ping() {
		try {
			const Ctx = window.AudioContext || window.webkitAudioContext;
			this._actx = this._actx || new Ctx();
			const ctx = this._actx;
			const tone = (freq, at, dur) => {
				const o = ctx.createOscillator();
				const g = ctx.createGain();
				o.type = "sine";
				o.frequency.value = freq;
				g.gain.setValueAtTime(0.4, ctx.currentTime + at);
				o.connect(g);
				g.connect(ctx.destination);
				o.start(ctx.currentTime + at);
				g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + at + dur);
				o.stop(ctx.currentTime + at + dur + 0.05);
			};
			tone(880, 0, 0.15);
			tone(1174.66, 0.13, 0.15);
			tone(1567.98, 0.26, 0.3);
		} catch (e) {
			/* sound blocked until first interaction — fine */
		}
	}

	desktop_notify(m, mentioned) {
		if (!window.Notification || Notification.permission !== "granted") return;
		if (!document.hidden && !mentioned) return;
		try {
			const who = (m.full_name || m.user).split(" ")[0];
			new Notification(`${who} — Duty Room${mentioned ? " (mention)" : ""}`, {
				body: m.message || m.attachment_name || "",
				tag: "duty-room",
				renotify: true,
				requireInteraction: mentioned,
			});
		} catch (e) {
			/* ignore */
		}
	}

	refresh(silent) {
		if (this._halted) return;
		frappe.call({
			method: "duty_board.api.get_board",
			freeze: !silent,
			error: (x) => {
				if (!this._cc_done) {
					this._cc_done = 1;
					this.consultant_check();
				}
				this._poll_failed(x);
			},
			callback: (r) => {
				this._fail_count = 0;
				if (r.message) this.render(r.message);
			},
		});
	}

	consultant_cr_edit(cr, vals) {
		vals = vals || {};
		if (vals.locked) {
			frappe.msgprint(__("💱 {0} — {1}. This change request is with Xlevel now and can no longer be edited.", [frappe.utils.escape_html(vals.title || cr), __(vals.pricing_status || vals.status || "")]));
			return;
		}
		const pd = new frappe.ui.Dialog({
			title: __("💱 Change request — detail it for pricing"),
			fields: [
				{ fieldname: "title", fieldtype: "Data", label: __("Title"), default: vals.title || "", reqd: 1 },
				{ fieldname: "reason", fieldtype: "Small Text", label: __("Why this is new scope"), default: vals.reason || "" },
				{ fieldname: "scope_impact", fieldtype: "Small Text", label: __("Scope impact"), default: vals.scope_impact || "" },
				{ fieldname: "timeline_impact", fieldtype: "Data", label: __("Timeline impact"), default: vals.timeline_impact || "" },
				{ fieldname: "resource_impact", fieldtype: "Data", label: __("Resource impact"), default: vals.resource_impact || "" },
				{ fieldname: "risks", fieldtype: "Small Text", label: __("Risks"), default: vals.risks || "" },
			],
			primary_action_label: __("Send for pricing"),
			primary_action: (v) => {
				pd.hide();
				frappe.call({
					method: "duty_board.client_room.chreq_update",
					args: Object.assign({ id: cr }, v),
					callback: () => frappe.show_alert({ message: __("💱 Sent — Xlevel will price it and release it to the client."), indicator: "green" }),
				});
			},
		});
		pd.show();
	}

	open_cr_editor(cr) {
		frappe.call({
			method: "duty_board.client_room.chreq_get",
			args: { id: cr },
			callback: (r) => r.message && this.consultant_cr_edit(cr, r.message),
		});
	}

	consultant_shell() {
		this.rail = (this.rail || []).filter((r) => ["issues", "chat", "projects", "me", "news"].includes(r.id));
		if (!this.rail.some((r) => r.id === "library")) {
			this.rail.splice(this.rail.length - 1, 0, { id: "library", ic: this._rsvg.lib, label: __("Library"), go: () => this.show_face("library") });
		}
		this.build_rail();
		$(".duty-strip").remove();
		this.show_face("issues");
	}

	consultant_check() {
		frappe.call({
			method: "duty_board.api.consultant_gate",
			error: () => {},
			callback: (r) => {
				if (!(r.message && r.message.consultant)) return;
				this._is_consultant = true;
				$("body").addClass("duty-consultant");
				$(".modal:visible .btn-modal-close, .modal:visible .close").click();
				this._fail_count = 0;
				this.consultant_shell();
				this.refresh();
			},
		});
	}

	action(method, args) {
		frappe.call({
			method: `duty_board.api.${method}`,
			args: args || {},
			freeze: true,
			freeze_message: __("Saving..."),
			callback: (r) => r.message && this.render(r.message),
		});
	}

	clock_out_dialog() {
		const d = new frappe.ui.Dialog({
			title: __("Clock Out"),
			fields: [
				{
					fieldname: "reason",
					fieldtype: "Select",
					label: __("Reason"),
					reqd: 1,
					options: [
						"Lunch",
						"Gone for prayers",
						"Short break",
						"Errand",
						"Power outage",
						"Internet outage",
						"Offline meeting",
						"Personal",
						"End of day",
					].join("\n"),
				},
				{
					fieldname: "details",
					fieldtype: "Data",
					label: __("Details (optional)"),
					depends_on: "eval:doc.reason && doc.reason!=='End of day'",
				},
				{
					fieldname: "summary",
					fieldtype: "Small Text",
					label: __("What did you get done today?"),
					depends_on: "eval:doc.reason==='End of day'",
				},
			],
			primary_action_label: __("Clock Out"),
			primary_action: (values) => {
				d.hide();
				let reason = values.reason;
				if (values.details && values.reason !== "End of day") {
					reason = `${values.reason} — ${values.details}`;
				}
				this.action("clock_out", {
					reason: reason,
					summary: values.reason === "End of day" ? values.summary || null : null,
				});
			},
		});
		d.show();
	}

	start_task_dialog(switching) {
		const NEW_TASK = __("✍️ Something else (type below)");
		const open_todos = (this.my_todos || []).filter((t) => t.status === "Open");
		const todo_map = {};
		const options = [NEW_TASK];
		open_todos.forEach((t) => {
			const label = t.customer ? `${t.description} [${t.customer}]` : t.description;
			if (!todo_map[label]) {
				todo_map[label] = t;
				options.push(label);
			}
		});

		const fields = [];
		if (open_todos.length) {
			fields.push({
				fieldname: "todo_pick",
				fieldtype: "Select",
				label: __("Pick from today's plan"),
				options: options.join("\n"),
				default: options.length > 1 ? options[1] : NEW_TASK,
			});
		}
		fields.push(
			{
				fieldname: "activity",
				fieldtype: "Data",
				label: __("What are you working on?"),
				depends_on: open_todos.length
					? `eval:doc.todo_pick==='${NEW_TASK}'`
					: undefined,
				mandatory_depends_on: open_todos.length
					? `eval:doc.todo_pick==='${NEW_TASK}'`
					: undefined,
				reqd: open_todos.length ? 0 : 1,
			},
			{
				fieldname: "customer",
				fieldtype: "Link",
				label: __("Customer (optional)"),
				options: "Customer",
			}
		);

		const current = this.current_task;
		if (switching && current) {
			const note = current.todo
				? __("⏸ “{0}” will pause into your tray unless you mark it completed below.", [frappe.utils.escape_html(current.activity)])
				: __("⏸ “{0}” will pause into your tray — resume it anytime.", [frappe.utils.escape_html(current.activity)]);
			fields.unshift({
				fieldname: "pause_note",
				fieldtype: "HTML",
				options: `<div class="duty-pause-note">${frappe.utils.escape_html(note || "")}</div>`,
			});
		}
		if (switching && current && current.todo) {
			fields.push({
				fieldname: "complete_previous",
				fieldtype: "Check",
				label: __("I completed: {0}", [frappe.utils.escape_html(current.activity)]),
				// Unticked by default: switching PAUSES. Completing is the deliberate act.
				default: 0,
			});
		}

		const d = new frappe.ui.Dialog({
			title: switching ? __("Switch Task") : __("Start Task"),
			fields: fields,
			primary_action_label: __("Start Timer"),
			primary_action: (values) => {
				let activity = values.activity;
				let todo = null;
				let customer = values.customer || null;

				if (values.todo_pick && values.todo_pick !== NEW_TASK) {
					const picked = todo_map[values.todo_pick];
					if (picked) {
						activity = picked.description;
						todo = picked.name;
						customer = customer || picked.customer || null;
					}
				}
				if (!activity || !activity.trim()) {
					frappe.msgprint(__("Please describe what you are working on."));
					return;
				}
				d.hide();
				this.action("start_task", {
					activity: activity,
					customer: customer,
					todo: todo,
					complete_previous: values.complete_previous ? 1 : 0,
				});
			},
		});
		d.show();
	}

	stop_task_flow() {
		const current = this.current_task;
		if (current && current.todo) {
			const d = new frappe.ui.Dialog({
				title: __("Stop Task"),
				fields: [
					{
						fieldname: "completed",
						fieldtype: "Check",
						label: __("I completed: {0}", [
							frappe.utils.escape_html(current.activity),
						]),
						default: 1,
					},
				],
				primary_action_label: __("Stop Timer"),
				primary_action: (values) => {
					d.hide();
					this.action("stop_task", { completed: values.completed ? 1 : 0 });
				},
			});
			d.show();
		} else {
			this.action("stop_task", { completed: 0 });
		}
	}

	render(data) {
		if (data && data.consultant) {
			this._is_consultant = true;
			localStorage.setItem("duty_cons", "1");
			$("body").addClass("duty-consultant");
			this._cons_people = data.people || [];
			this.name_map = {};
			this._cons_people.forEach((r) => (this.name_map[r.user] = r.full_name));
			const st = data.stats || {};
			let $cs = this.$issues.find(".duty-cons-stats");
			if (!$cs.length) $cs = $('<div class="duty-cons-stats"></div>').prependTo(this.$issues);
			$cs.html(`
				<div class="duty-cs-tile"><b>${st.open || 0}</b><span>${__("Assigned open")}</span></div>
				<div class="duty-cs-tile ${st.overdue ? "duty-cs-warn" : ""}"><b>${st.overdue || 0}</b><span>${__("Overdue")}</span></div>
				<div class="duty-cs-tile"><b>${st.resolved30 || 0}</b><span>${__("Resolved · 30d")}</span></div>
				<div class="duty-cs-tile"><b>${st.week_hours || 0}h</b><span>${__("Logged · 7d")}</span></div>`);
			this.render_issues(data.issues || [], data.me || {});
			if (!this._cons_boot) {
				this._cons_boot = 1;
				this.consultant_shell();
			}
			return;
		}
		if (localStorage.getItem("duty_cons")) {
			localStorage.removeItem("duty_cons");
			this._is_consultant = false;
			$("body").removeClass("duty-consultant");
		}
		if (data.day_summary) {
			this.show_day_summary(data.day_summary);
		}
		if (!this._pulse_at || Date.now() - this._pulse_at > 120000) {
			this._pulse_at = Date.now();
			frappe.call({
				method: "duty_board.gamify.team_pulse",
				error: () => {},
				callback: (r) => {
					const p = r.message;
					if (!p) return;
					$(".duty-pulse").remove();
					const pct = Math.min(100, Math.round((p.resolved / (p.target || 1)) * 100));
					const hit = p.resolved >= p.target;
					$(`
					<div class="duty-pulse ${hit ? "duty-pulse-hit" : ""}">
						<span class="duty-pl-label">⚡ ${__("Team pulse")}</span>
						<div class="duty-pl-bar"><i style="width:${pct}%"></i></div>
						<span class="duty-pl-num">${p.resolved} / ${p.target} ${__("resolved this week")}</span>
						<span class="duty-pl-breach ${p.breaches ? "duty-pl-bad" : ""}">${p.breaches ? `⚠ ${p.breaches} ${__("SLA breach(es)")}` : `🛡 ${__("zero breaches")}`}</span>
						${(p.applauded || []).length ? `<span class="duty-pl-app">👏 ${p.applauded.map((a) => `${frappe.utils.escape_html(a.name)} ${a.n}`).join(" · ")}</span>` : ""}
					</div>`).insertBefore(this.body);
					$(".duty-pulse").toggle(this.face === "board");
				},
			});
		}
		this.dm_unread = data.dm_unread || this.dm_unread || {};
		this._on_call = data.on_call || null;
		const cr_attn = (data.rooms_unread || 0) + (data.rooms_joins || 0);
		$(".duty-tab-clients").text(cr_attn).toggle(cr_attn > 0);
		this._rooms_joins = data.rooms_joins || 0;
		$(".duty-cr-barjoins").html(
			this._rooms_joins
				? ` <span class="duty-cr-joinpill">🙋 ${this._rooms_joins} ${__("waiting")}</span>`
				: ""
		);
		this.my_todos = data.my_todos || [];
		this.my_upcoming = data.my_upcoming || [];
		this.overdue_count = data.overdue_count || 0;
		this.current_task = data.me && data.me.task;
		this.name_map = {};
		(data.board || []).forEach((r) => (this.name_map[r.user] = r.full_name));
		this._me = data.me;
		this.render_strip();
		this.render_me(data.me);
		this.render_paused_strip(data);
		this.render_task(data.me);
		this.render_plan(data.me);
		this.render_my_sessions(data.my_sessions, data.me);
		this.render_issues(data.issues, data.me);
		this.render_team(data.board);
		this.body
			.find(".duty-updated")
			.text(__("Last updated {0}", [frappe.datetime.now_time()]));
	}

	show_day_summary(d) {
		const row = (label, secs, cls) =>
			`<tr class="${cls || ""}">
				<td>${label}</td>
				<td style="text-align:right"><b>${this.fmt_duration(secs)}</b></td>
			</tr>`;
		const remarks = (d.remarks || [])
			.map(
				(r) =>
					`<div class="duty-daynum-remark duty-daynum-${r.kind}">${frappe.utils.escape_html(r.text)}</div>`
			)
			.join("");
		const dlg = new frappe.ui.Dialog({
			title: __("Your Day in Numbers"),
			primary_action_label: __("Close"),
			primary_action: () => dlg.hide(),
		});
		$(dlg.body).html(`
			<table class="duty-daynum-table">
				<tr class="duty-daynum-head"><td>${__("Expected on duty")}</td>
					<td style="text-align:right">${this.fmt_duration(d.expected_duty)}</td></tr>
				${row(__("Actual hours on duty"), d.duty, d.duty < d.expected_duty ? "duty-daynum-short" : "duty-daynum-ok")}
				<tr class="duty-daynum-head"><td>${__("Expected break")}</td>
					<td style="text-align:right">${this.fmt_duration(d.expected_break)}</td></tr>
				${row(__("Actual break time"), d.breaks, d.breaks > d.expected_break ? "duty-daynum-short" : "duty-daynum-ok")}
				${row(__("Hours booked to tasks"), d.task)}
				${row(__("Hours attached to a customer"), d.customer)}
			</table>
			${remarks}
		`);
		dlg.show();
	}

	task_history_dialog() {
		const d = new frappe.ui.Dialog({ title: __("My Task History"), size: "large" });
		$(d.body).html(`
			<div class="duty-history-list"><div class="text-muted">${__("Loading...")}</div></div>
			<div class="duty-history-more" style="display:none; text-align:center; margin-top:8px">
				<button class="btn btn-default btn-sm">${__("Load older")}</button>
			</div>
		`);
		const $list = $(d.body).find(".duty-history-list");
		let before = null;
		let last_date = null;
		let first_load = true;
		const load = () => {
			frappe.call({
				method: "duty_board.api.get_task_history",
				args: { before: before },
				callback: (r) => {
					const data = r.message || {};
					if (first_load) {
						$list.empty();
						first_load = false;
					}
					(data.sessions || []).forEach((x) => {
						if (x.date !== last_date) {
							last_date = x.date;
							$list.append(
								`<div class="duty-history-day">${frappe.datetime.str_to_user(x.date)}</div>`
							);
						}
						const $row = $(`
							<div class="duty-session-row">
								<span class="duty-session-activity">${frappe.utils.escape_html(x.activity)}</span>
								${x.customer ? `<span class="duty-task-customer">${frappe.utils.escape_html(x.customer)}${x.unit && x.unit !== "General" ? ` <span class="duty-cr-unitchip">${frappe.utils.escape_html(x.unit)}</span>` : ""}${x.renewal ? (x.renewal.frozen ? ` <span class="duty-renew duty-renew-frozen">⏸ ${__("FROZEN — renewal overdue")}</span>` : x.renewal.days_left < 0 ? ` <span class="duty-renew duty-renew-over">🔴 ${__("expired")} ${-x.renewal.days_left}d</span>` : x.renewal.days_left <= 14 ? ` <span class="duty-renew duty-renew-warn">⏳ ${__("renews in")} ${x.renewal.days_left}d</span>` : ` <span class="duty-renew duty-renew-calm" title="${frappe.utils.escape_html(x.renewal.date)}">🔄 ${__("renews in")} ${x.renewal.days_left}d</span>`) : ""}</span>` : ""}
								<span class="duty-session-time text-muted">
									${this.fmt_time(x.start_time)} – ${x.end_time ? this.fmt_time(x.end_time) : __("open")}
									· ${this.fmt_duration(x.duration)}
								</span>
								<a class="duty-session-notes" title="${__("Notes")}">📝${x.notes ? " " + frappe.utils.escape_html(x.notes) : ""}</a>
							</div>`).appendTo($list);
						$row.find(".duty-session-notes").on("click", (e) => {
							e.preventDefault();
							this.note_dialog(x.name, x.activity, true);
						});
					});
					before = data.next_before;
					$(d.body).find(".duty-history-more").toggle(!!data.has_more);
					if (!$list.children().length) {
						$list.html(`<div class="text-muted">${__("No earlier tasks yet.")}</div>`);
					}
				},
			});
		};
		$(d.body).find(".duty-history-more button").on("click", load);
		load();
		d.show();
	}

	dm_row(m) {
		const mine = m.sender === frappe.session.user;
		const when = this.smart_time(m.creation);
		return `
			<div class="duty-msg ${mine ? "duty-msg-mine" : ""}" data-name="${m.name}">
				<span class="duty-msg-who" style="color:${this.user_color(m.sender)}">${mine ? __("You") : frappe.utils.escape_html((m.sender_name || m.sender).split(" ")[0])}</span>
				<span class="duty-msg-text">${this.linkify(frappe.utils.escape_html(m.message || ""))}</span>${this.dm_att_html(m)}
				<span class="duty-msg-time">${when}${this.edited_tag(m)}</span>${mine ? (m.seen ? ` <span class="duty-msg-seen tick-read" title="${__("Read")}">✓✓</span>` : this._dm_peer_delivered && m.creation <= this._dm_peer_delivered ? ` <span class="duty-msg-seen tick-dlv" title="${__("Delivered")}">✓✓</span>` : ` <span class="duty-msg-seen tick-dlv" title="${__("Sent")}">✓</span>`) : ""}${mine && this.can_edit(m.creation) ? ` <a class="duty-dm-edit" data-name="${m.name}" data-text="${frappe.utils.escape_html(m.message || "")}" data-att="${m.attachment_url ? 1 : 0}" title="${__("Edit")}">✏</a>` : ""}
			</div>`;
	}

	set_dm_badge(user, n) {
		const $b = this.body.find(`.duty-dm-btn[data-user="${user}"] .duty-dm-badge`);
		if (n) $b.text(n).show();
		else $b.hide();
	}

	mark_dm_seen(user) {
		frappe.call({ method: "duty_board.dm.mark_dm_seen", args: { with_user: user } });
		if (this.dm_unread) delete this.dm_unread[user];
		this.set_dm_badge(user, 0);
	}

	open_dm(user, full_name) {
		if (!user || user === frappe.session.user) return;
		full_name = full_name || this.name_map[user] || user;
		if (this._dm_dialog && this._dm_with === user) {
			this._dm_dialog.show();
			return;
		}
		if (this._dm_dialog) this._dm_dialog.hide();
		const d = (this._dm_dialog = new frappe.ui.Dialog({
			title: `✉ ${full_name.split(" ")[0]}`,
		}));
		this._dm_with = user;
		d.onhide = () => {
			if (this._dm_with === user) this._dm_with = null;
		};
		$(d.body).html(`
			<div class="duty-dm-list"><div class="text-muted">${__("Loading...")}</div></div>
			<div class="duty-dm-send">
				<textarea rows="1" class="form-control duty-dm-input" maxlength="1000"
					placeholder="${__("Message {0}... Enter to send, Shift+Enter for a new line", [frappe.utils.escape_html(full_name.split(" ")[0])])}"></textarea>
				<button class="btn btn-primary btn-sm duty-dm-btn-send">${__("Send")}</button>
			</div>
		`);
		const $list = $(d.body).find(".duty-dm-list");
		const $input = $(d.body).find(".duty-dm-input");
		const att = this.wire_dm_attach($(d.body).find(".duty-dm-send"), $input);
		let oldest = null;
		const load = (before) => {
			frappe.call({
				method: "duty_board.dm.get_dm_thread",
				args: { with_user: user, before: before },
				callback: (r) => {
					const data = r.message || {};
					this._dm_peer_delivered = data.peer_delivered || null;
					const msgs = data.messages || [];
					if (msgs.length) oldest = msgs[0].creation;
					if (!before) {
						$list.empty();
						if (data.has_more) {
							$list.append(
								`<div class="duty-load-earlier"><a>${__("Load earlier")}</a></div>`
							);
							$list.find(".duty-load-earlier a").on("click", () => load(oldest));
						}
						$list.append(msgs.map((m) => this.dm_row(m)).join(""));
						if (!msgs.length) {
							$list.append(
								`<div class="text-muted duty-plan-empty">${__("No messages yet — say hello.")}</div>`
							);
						}
						$list.scrollTop($list[0].scrollHeight);
					} else {
						const old_h = $list[0].scrollHeight;
						const $anchor = $list.find(".duty-load-earlier");
						$anchor.after(msgs.map((m) => this.dm_row(m)).join(""));
						if (!data.has_more) $anchor.hide();
						$list.scrollTop($list[0].scrollHeight - old_h);
					}
					this.mark_dm_seen(user);
				},
			});
		};
		const send = async () => {
			const text = ($input.val() || "").trim();
			if (!text && !att.has()) return;
			$input.val("");
			let up = null;
			try {
				up = await att.consume();
			} catch (err) {
				$input.val(text);
				frappe.show_alert(
					{
						message: __("Upload failed: {0}", [frappe.utils.escape_html(err.message || String(err))]),
						indicator: "red",
					},
					8
				);
				console.error("DM upload failed", err);
				return;
			}
			frappe.call({
				method: "duty_board.dm.send_dm",
				args: {
					to: user,
					message: text,
					attachment_url: up ? up.file_url : null,
					attachment_name: up ? up.file_name : null,
				},
				callback: (r) => {
					const m = r.message;
					if (m && !$list.find(`[data-name="${m.name}"]`).length) {
						$list.find(".duty-plan-empty").remove();
						$list.append(this.dm_row(m));
						$list.scrollTop($list[0].scrollHeight);
					}
				},
			});
		};
		$(d.body).find(".duty-dm-btn-send").on("click", send);
		$input.on("keydown", (e) => {
			if (e.key === "Enter" && !e.shiftKey) {
				e.preventDefault();
				send();
			}
		});
		d.show();
		load(null);
		this.set_dm_badge(user, 0);
	}

	handle_dm(m) {
		if (!m || !m.name) return;
		const me = frappe.session.user;
		const other = m.sender === me ? m.recipient : m.sender;
		if (m.edit) {
			// An edit, not a new message: rewrite the row wherever it is shown.
			[
				this._dm_dialog && $(this._dm_dialog.body),
				this.$chatface && this.$chatface.find(".duty-ch-dm"),
			].forEach(($scope) => {
				if (!$scope || !$scope.length) return;
				const $row = $scope.find(`[data-name="${m.name}"]`);
				if ($row.length) $row.replaceWith(this.dm_row(m));
			});
			return;
		}
		const dialog_open =
			this._dm_with === other && this._dm_dialog && this._dm_dialog.$wrapper.is(":visible");
		if (dialog_open) {
			const $list = $(this._dm_dialog.body).find(".duty-dm-list");
			if (!$list.find(`[data-name="${m.name}"]`).length) {
				$list.find(".duty-plan-empty").remove();
				$list.append(this.dm_row(m));
				$list.scrollTop($list[0].scrollHeight);
			}
			if (m.sender !== me) this.mark_dm_seen(other);
			return;
		}
		if (m.sender !== me) {
			this.dm_unread = this.dm_unread || {};
			this.dm_unread[m.sender] = (this.dm_unread[m.sender] || 0) + 1;
			this.set_dm_badge(m.sender, this.dm_unread[m.sender]);
			this.ping();
			const first = (m.sender_name || m.sender).split(" ")[0];
			frappe.show_alert(
				{
					message: `<b>✉ ${frappe.utils.escape_html(first)}</b><br>${frappe.utils.escape_html((m.message || "").slice(0, 80))}`,
					indicator: "blue",
				},
				6
			);
			if (window.Notification && Notification.permission === "granted" && document.hidden) {
				try {
					new Notification(`✉ ${first} — DM`, {
						body: (m.message || "").slice(0, 120),
						tag: "duty-dm",
						renotify: true,
					});
				} catch (e) {
					/* ignore */
				}
			}
		}
	}

	// ---------------- Projects face ----------------

	proj_color(name) {
		return this.user_color("proj:" + name);
	}

	show_face(face) {
		const merged = !this._is_consultant && !this.is_mobile();
		if (face === "me" && merged) {
			// Every existing show_face("me") caller lands on the Dashboard tab.
			face = "board";
			this._day_tab = "dash";
		}
		if (this._idshim) this._idshim.hide();
		if (this._$tdrawer) this._$tdrawer.hide();
		if (this._$ndrawer) this._$ndrawer.hide();
		if (face !== "library" && this._rd_stop) this._rd_stop();
		if (this._$ldrawer) this._$ldrawer.hide();
		$("body").removeClass("duty-idrawer-open");
		const prev_face = this.face;
		if (face === "chat" && prev_face !== "chat") {
			this.$clients.find(".duty-cr-room").empty().hide();
			this.$clients.removeClass("cr-room-open");
			this._open_room = null;
			this._ch_open = null;
		}
		if (face !== "chat" && prev_face === "chat") {
			this.$chatface.find(".duty-ch-room").empty().hide();
			this._open_room = null;
		}
		setTimeout(() => { this.render_strip(); this.rail_sync(face); }, 0);
		if (face === "projects" && prev_face !== "projects") {
			this._pj_open = {};
			if (this.is_mobile()) this.$projects.removeClass("pj-detail");
		}
		if (face === "clients" && prev_face !== "clients") {
			this._cr_open = {};
			Object.keys(localStorage)
				.filter((k) => k.indexOf("duty_cr_fold_") === 0)
				.forEach((k) => localStorage.removeItem(k));
		}
		this.face = face;
		const dtab = merged ? (this._day_tab || "today") : "today";
		this.body.toggle(face === "board" && dtab === "today");
		$(".duty-pulse").toggle(face === "board" && dtab === "today");
		if (this.$daytabs) {
			this.$daytabs.toggle(merged && face === "board");
			this.$daytabs.find("a").removeClass("on").filter(`[data-dt="${dtab}"]`).addClass("on");
		}
		this.$issues.toggle(face === "issues");
		this.$projects.toggle(face === "projects");
		this.$sales.toggle(face === "sales");
		if (this.$chatface) this.$chatface.toggle(face === "chat");
		if (face !== "chat") this._ch_return_team();
		this.$clients.toggle(face === "clients");
		this.$me.toggle(merged ? face === "board" && dtab === "dash" : face === "me");
		this.$books.toggle(face === "books");
		if (this.$library) this.$library.toggle(face === "library");
		if (this.$news) this.$news.toggle(face === "news");
		if (face === "news") this.refresh_news(this._news_cat);
		if (face === "library") this.refresh_library();
		if (face === "books") this.refresh_books();
		if (face === "projects") this.refresh_projects();
		if (face === "sales") this.refresh_sales();
		if (face === "chat") this.refresh_chat();
		if (face === "clients") this.refresh_clients();
		if (face === "me" || (face === "board" && merged && dtab === "dash")) this.refresh_me();
	}

	_me_host() {
		// DOM truth: exactly one .duty-me, attached, bound to this instance
		const $all = $(".duty-me");
		console.log("[duty-me] host nodes found:", $all.length, "| instance node attached:", !!(this.$me && this.$me[0] && document.body.contains(this.$me[0])));
		let $host = $all.filter((i, el) => document.body.contains(el)).last();
		if (!$host.length) {
			$host = $('<div class="duty-me"></div>').appendTo(this.page && this.page.body ? this.page.body : document.body);
			console.log("[duty-me] host rebuilt");
		}
		$(".duty-me").not($host[0]).remove();
		this.$me = $host;
		return $host;
	}

	refresh_news(cat) {
		this._news_cat = cat || "All";
		if (!this.$news.find(".duty-nw-grid").length) {
			this.$news.html(`<div class="duty-nw-load">📰 ${__("Opening the newsstand…")}</div>`);
		}
		frappe.call({
			method: "duty_board.news.get_news",
			args: { category: this._news_cat === "All" ? null : this._news_cat },
			error: () => this.$news.html(`<div class="duty-nw-load">${__("The newsstand is unreachable right now.")}</div>`),
			callback: (r) => {
				const data = r.message || { items: [], categories: [] };
				const items = data.items || [];
				const esc = frappe.utils.escape_html;
				const chip = (c) => `<a class="duty-nw-chip ${this._news_cat === c ? "on" : ""}" data-cat="${esc(c)}">${esc(__(c))}</a>`;
				const card = (x) => `
					<a class="duty-nw-card" data-name="${x.name}">
						${x.image ? `<span class="duty-nw-img" style="background-image:url('${esc(x.image)}')"></span>` : `<span class="duty-nw-img duty-nw-noimg">${esc((x.source || "N")[0])}</span>`}
						<span class="duty-nw-body">
							<span class="duty-nw-src">${esc(x.source || "")} <i class="duty-nw-cat">${esc(x.category || "")}</i></span>
							<span class="duty-nw-title">${esc(x.title)}</span>
							<span class="duty-nw-when">${esc((x.published || "").slice(0, 10))}${(x.published || "").slice(0, 10) === frappe.datetime.get_today() ? ` <b class="duty-nw-new">${__("today")}</b>` : ""}</span>
						</span>
					</a>`;
				const hero = items[0];
				this.$news.html(`
					<div class="duty-nw-head">
						<h3>📰 ${__("The Stand")}</h3>
						<div class="duty-nw-chips">${chip("All")}${(data.categories || []).map(chip).join("")}</div>
						<a class="duty-nw-refresh" title="${__("Harvest the next feeds now")}">↻</a>
					</div>
					${hero ? `
					<a class="duty-nw-hero" data-name="${hero.name}" style="background-image:url('${esc(hero.image || "")}')">
						<span class="duty-nw-hgrad"></span>
						<span class="duty-nw-htxt">
							<i>${esc(hero.source || "")} · ${esc(hero.category || "")}</i>
							<b>${esc(hero.title)}</b>
						</span>
					</a>` : `<div class="duty-nw-load">${__("Nothing on the stand yet — feeds refresh every half hour.")}</div>`}
					<div class="duty-nw-grid">${items.slice(1).map(card).join("")}</div>
				`);
				this._news_items = {};
				items.forEach((x) => (this._news_items[x.name] = x));
				this.$news.find(".duty-nw-chip").on("click", (e) => this.refresh_news($(e.currentTarget).data("cat")));
				this.$news.find(".duty-nw-refresh").on("click", () => {
					frappe.call({
						method: "duty_board.news.get_news",
						args: { force: 1, category: this._news_cat === "All" ? null : this._news_cat },
						callback: () => {
							frappe.show_alert({ message: __("📰 Harvest running — fresh stories in a minute."), indicator: "green" });
							setTimeout(() => this.refresh_news(this._news_cat), 45000);
						},
					});
				});
				this.$news.find(".duty-nw-card, .duty-nw-hero").on("click", (e) => {
					e.preventDefault();
					const x = this._news_items[$(e.currentTarget).data("name")];
					if (x) this.news_reader(x);
				});
			},
		});
	}

	news_reader(x) {
		const esc = frappe.utils.escape_html;
		if (!this._$ndrawer) {
			this._$ndrawer = $(`
				<div class="duty-idrawer duty-ndrawer" style="display:none">
					<div class="duty-id-head"><b>📰 ${__("Reading")}</b><a class="duty-nd-x">✕</a></div>
					<div class="duty-id-body duty-nd-body"></div>
				</div>`).appendTo(document.body);
			this._$ndrawer.find(".duty-nd-x").on("click", () => {
				this._$ndrawer.hide();
				$("body").removeClass("duty-idrawer-open");
			});
		}
		const paras = (x.summary || "").split(/(?<=[.!?])\s+(?=[A-Z0-9"'])/).reduce((acc, s) => {
			if (!acc.length || acc[acc.length - 1].length > 260) acc.push(s);
			else acc[acc.length - 1] += " " + s;
			return acc;
		}, []);
		this._$ndrawer.find(".duty-nd-body").html(`
			${x.image ? `<div class="duty-nd-hero" style="background-image:url('${esc(x.image)}')"></div>` : ""}
			<h3 class="duty-nd-title">${esc(x.title)}</h3>
			<div class="duty-nd-meta">${esc(x.source || "")} · ${esc(x.category || "")} · ${esc((x.published || "").slice(0, 16))}</div>
			${paras.map((s) => `<p class="duty-nd-p">${esc(s)}</p>`).join("")}
			${(x.extra_images || []).map((u) => `<div class="duty-nd-extra" style="background-image:url('${esc(u)}')"></div>`).join("")}
			<a class="btn btn-sm btn-primary duty-nd-src" href="${esc(x.link)}" target="_blank" rel="noopener noreferrer">${__("Read full article at source")} ↗</a>
		`);
		this._$ndrawer.show();
		$("body").addClass("duty-idrawer-open");
	}

	confetti() {
		const COLORS = ["#0E8A63", "#123C35", "#FFC53D", "#E2620E", "#7BE3B0", "#B27409", "#fff"];
		const $sky = $('<div class="duty-confetti"></div>').appendTo(document.body);
		for (let i = 0; i < 140; i++) {
			const size = 6 + Math.random() * 7;
			const $p = $('<i></i>').css({
				left: Math.random() * 100 + "vw",
				width: size + "px",
				height: size * (0.4 + Math.random() * 0.9) + "px",
				background: COLORS[(Math.random() * COLORS.length) | 0],
				"animation-duration": 3 + Math.random() * 2.5 + "s",
				"animation-delay": Math.random() * 0.9 + "s",
				"border-radius": Math.random() < 0.3 ? "50%" : "2px",
				"--sway": (Math.random() * 120 - 60).toFixed(0) + "px",
				"--spin": ((Math.random() * 720 - 360) | 0) + "deg",
			});
			$sky.append($p);
		}
		frappe.show_alert({ message: __("🎉 Resolved — take the applause."), indicator: "green" });
		setTimeout(() => $sky.remove(), 6600);
	}

	render_gamify() {
		frappe.call({
			method: "duty_board.gamify.my_gamify",
			error: () => {},
			callback: (r) => {
				const g = r.message;
				if (!g || !this.$me || !this.$me.length) return;
				this.$me.find(".duty-gamify").remove();
				const t = g.streak.today;
				const chk = (on, label) => `<span class="duty-gm-chk ${on ? "duty-gm-on" : ""}">${on ? "✔" : "○"} ${label}</span>`;
				const earned = g.badges.filter((b) => b.earned);
				const locked = g.badges.filter((b) => !b.earned);
				$(`
				<div class="duty-gamify">
					<div class="duty-gm-card duty-gm-streak">
						<div class="duty-gm-flame">🔥</div>
						<div class="duty-gm-nums"><b>${g.streak.current}</b><span>${__("day streak")}</span><i>${__("best")} · ${g.streak.best}</i></div>
						<div class="duty-gm-today">${chk(t.clock, __("Clocked in"))}${chk(t.plan, __("Plan set"))}${chk(t.update, __("Update posted"))}</div>
					</div>
					<div class="duty-gm-card duty-gm-week">
						<b>${__("This week")}</b>
						<div class="duty-gm-wrow"><span>${g.week.resolved}</span> ${__("resolved")}</div>
						<div class="duty-gm-wrow"><span>${g.week.hours}h</span> ${__("logged")}</div>
						${g.week.avg_rating ? `<div class="duty-gm-wrow"><span>★ ${g.week.avg_rating}</span> ${__("avg rating")}</div>` : ""}
						${g.week.kudos ? `<div class="duty-gm-wrow"><span>👏 ${g.week.kudos}</span> ${__("kudos")}</div>` : ""}
					</div>
					${g.memory ? `<div class="duty-gm-card duty-gm-memory"><b>📜 ${__("From your margins")}</b><q>“${frappe.utils.escape_html(g.memory.text.slice(0, 150))}${g.memory.text.length > 150 ? "…" : ""}”</q><i>— ${frappe.utils.escape_html(g.memory.book_title)}</i></div>` : ""}
					<div class="duty-gm-card duty-gm-badges">
						<b>${__("Badges")} · ${earned.length}</b>
						<div class="duty-gm-brow">
							${earned.map((b) => `<span class="duty-gm-badge" title="${frappe.utils.escape_html(b.label)} — ${frappe.utils.escape_html(b.desc)}">${b.icon}</span>`).join("")}
							${locked.map((b) => `<span class="duty-gm-badge duty-gm-locked" title="${frappe.utils.escape_html(b.label)} — ${frappe.utils.escape_html(b.desc)}">${b.icon}</span>`).join("")}
						</div>
					</div>
				</div>`).prependTo(this.$me);
				this.render_radar_today();
			},
		});
	}

	_load_reminders_card() {
		const $host = this.$me.find(".duty-me-remind");
		if (!$host.length) return;
		frappe.call({
			method: "duty_board.reminders.my_reminders",
			callback: (r) => this._render_reminders_card(r.message || []),
		});
	}

	_render_reminders_card(rows) {
		const esc = frappe.utils.escape_html;
		const $host = this.$me.find(".duty-me-remind");
		if (!$host.length) return;
		const list = rows.map((x) => `
			<div class="duty-lv-row">
				<b>${esc(x.text)}</b>
				<span class="text-muted">${frappe.datetime.str_to_user(x.remind_at)}</span>
				${x.repeat && x.repeat !== "None" ? `<span class="duty-rm-rep">↻ ${__(x.repeat)}</span>` : ""}
				<a class="duty-lv-cancel duty-rm-cancel" data-id="${x.name}" title="${__("Cancel")}">✕</a>
			</div>`).join("");
		$host.html(`
			<div class="duty-me-reqs">
				<h4>⏰ ${__("Reminders")}</h4>
				${list || `<div class="text-muted" style="font-size:12.5px">${__("No reminders set.")}</div>`}
				<div class="duty-lv-ask">
					<input type="text" class="form-control input-sm duty-rm-text" placeholder="${__("Remind me to…")}" maxlength="200">
					<input type="date" class="form-control input-sm duty-rm-date" min="${frappe.datetime.now_date()}">
					<input type="time" class="form-control input-sm duty-rm-time">
					<select class="form-control input-sm duty-rm-rep-sel"><option value="None">${__("Once")}</option><option value="Daily">${__("Daily")}</option><option value="Weekly">${__("Weekly")}</option><option value="Monthly">${__("Monthly")}</option></select>
					<button class="btn btn-xs btn-primary duty-rm-go">⏰ ${__("Set")}</button>
				</div>
			</div>`);
		const redo = (r) => this._render_reminders_card(r.message || []);
		$host.find(".duty-rm-go").on("click", () => {
			const t = $host.find(".duty-rm-text").val();
			const dd = $host.find(".duty-rm-date").val();
			const tt = $host.find(".duty-rm-time").val();
			if (!t || !dd || !tt) return frappe.show_alert({ message: __("Text, date and time, please."), indicator: "orange" });
			frappe.call({
				method: "duty_board.reminders.add_reminder",
				args: { text: t, remind_at: `${dd} ${tt}:00`, repeat: $host.find(".duty-rm-rep-sel").val() },
				callback: (r) => { frappe.show_alert({ message: __("Reminder set."), indicator: "green" }); redo(r); },
			});
		});
		$host.find(".duty-rm-cancel").on("click", (e) =>
			frappe.call({ method: "duty_board.reminders.cancel_reminder", args: { name: $(e.currentTarget).data("id") }, callback: redo })
		);
	}

	_load_earnings_card() {
		const $host = this.$me.find(".duty-me-earn");
		if (!$host.length) return;
		frappe.call({
			method: "duty_board.earnings.my_earnings",
			callback: (r) => r.message && this._render_earnings_card(r.message),
		});
	}

	_render_earnings_card(E) {
		const esc = frappe.utils.escape_html;
		const $host = this.$me.find(".duty-me-earn");
		if (!$host.length) return;
		const naira = (n) => "₦" + (n || 0).toLocaleString();
		const tm = E.this_month, lm = E.last_month;
		if (!tm.totals.grand && !lm.totals.grand) { $host.empty(); return; }
		const block = (c, open) => {
			const eq = [];
			if (c.totals.hours) eq.push(naira(c.totals.hours));
			if (c.totals.resolutions) eq.push(naira(c.totals.resolutions));
			if (c.totals.sla) eq.push(naira(c.totals.sla));
			if (c.totals.phases) eq.push(naira(c.totals.phases));
			return `
			<details ${open ? "open" : ""} class="duty-earn-m">
				<summary><b>${esc(c.label)}</b>${c.closed ? `<span class="duty-earn-lock">🔒 ${__("closed")}</span>` : ""}<span class="duty-earn-grand">${naira(c.totals.grand)}</span></summary>
				<div class="duty-earn-rows">
					<div class="duty-earn-r"><span class="duty-earn-lbl">⏱ ${__("Customer hours")}</span><span class="duty-earn-calc"><b>${c.hours.paid_hours}h</b><span class="text-muted"> / ${c.hours.cap || 120}h</span> × ${naira(c.rates.hourly)}${c.hours.capped ? ` <i class="duty-earn-cap">(${__("capped from")} ${c.hours.hours}h)</i>` : ""} <span class="text-muted">· ${c.hours.linked_hours}h ${__("linked")} / ${c.hours.unlinked_hours}h ${__("unlinked")}</span></span><b>${naira(c.totals.hours)}</b></div>
					${c.resolutions.length ? `<div class="duty-earn-r"><span class="duty-earn-lbl">✅ ${__("Resolutions")}</span><span class="duty-earn-calc"><b>${c.resolutions.length}</b> × ${naira(c.rates.resolution)} ${__("base")} <span class="text-muted">· ${__("stars & splits applied per item below")}</span></span><b>${naira(c.totals.resolutions)}</b></div>` : ""}
					${c.totals.sla ? `<div class="duty-earn-r"><span class="duty-earn-lbl">⚡ ${__("SLA bonus")}</span><span class="duty-earn-calc"><b>${c.sla_count}</b> × ${naira(c.rates.sla)}</span><b>${naira(c.totals.sla)}</b></div>` : ""}
					${c.phases.length ? `<div class="duty-earn-r"><span class="duty-earn-lbl">🚩 ${__("Phase sign-offs")}</span><span class="duty-earn-calc"><b>${c.phases.length}</b> ${__("on baseline")}</span><b>${naira(c.totals.phases)}</b></div>` : ""}
					<div class="duty-earn-r duty-earn-total"><span class="duty-earn-lbl">${__("Total")}</span><span class="duty-earn-calc">${eq.length > 1 ? eq.join(" + ") : ""}</span><b>${naira(c.totals.grand)}</b></div>
				</div>
				${c.resolutions.length ? `<div class="duty-earn-items">${c.resolutions.map((x) => `<div class="duty-earn-it"><span class="duty-earn-t" title="${esc(x.title)}">${esc(x.title)}</span><span class="duty-earn-meta">${esc(x.customer || "")} · ${x.mode === "confirmed" ? (x.stars ? "★".repeat(x.stars) : __("confirmed")) : x.mode === "upgrade" ? `${x.stars ? "★".repeat(x.stars) + " " : ""}${__("upgrade")}` : __("auto (7d)")}${x.split > 1 ? ` · ÷${x.split}` : ""}</span><b>${naira(x.amount + x.sla_amount)}</b></div>`).join("")}</div>` : ""}
				${c.phases.length ? `<div class="duty-earn-items">${c.phases.map((p) => `<div class="duty-earn-it"><span class="duty-earn-t" title="${esc(p.phase)}">${esc(p.phase)}</span><span class="duty-earn-meta">${esc(p.project)} · ${esc(p.approved)}${p.split > 1 ? ` · ÷${p.split}` : ""}</span><b>${naira(p.amount)}</b></div>`).join("")}</div>` : ""}
			</details>`;
		};
		$host.html(`
			<div class="duty-me-reqs duty-earn-card">
				<h4>💵 ${__("Earnings")}</h4>
				${block(tm, true)}
				${block(lm, false)}
			</div>`);
	}

	_load_leave_card() {
		const $host = this.$me.find(".duty-me-leave");
		if (!$host.length) return;
		frappe.call({
			method: "duty_board.leave.my_leave",
			callback: (r) => r.message && this._render_leave_card(r.message),
		});
	}

	_render_leave_card(L) {
		const esc = frappe.utils.escape_html;
		const $host = this.$me.find(".duty-me-leave");
		if (!$host.length) return;
		const PILL = { Pending: "⏳", Approved: "✅", Declined: "✖", Cancelled: "◌" };
		const reqs = (L.requests || []).map((q) => `
			<div class="duty-lv-row">
				<span class="duty-lv-st duty-lv-${q.status.toLowerCase()}">${PILL[q.status] || ""} ${__(q.status)}</span>
				<b>${esc(q.start_date)} → ${esc(q.end_date)}</b>
				<span class="text-muted">${q.work_days} ${__("day(s)")}${q.note ? " · " + esc(q.note) : ""}</span>
				${q.cancellable ? `<a class="duty-lv-cancel" data-id="${q.name}" title="${__("Cancel")}">✕</a>` : ""}
			</div>`).join("");
		const pend = (L.pending || []).map((p) => `
			<div class="duty-lv-row">
				<b>${esc(p.full_name)}</b>
				<span>${esc(p.start_date)} → ${esc(p.end_date)} · ${p.work_days} ${__("day(s)")}</span>
				<span class="text-muted">${p.remaining} ${__("left")}${p.note ? " · " + esc(p.note) : ""}</span>
				${(p.also_away || []).length ? `<span class="duty-lv-clash">⚠ ${__("also away then")}: ${p.also_away.map((a) => `${esc(a.name)}${a.status === "Pending" ? ` <i>(${__("pending")})</i>` : ""}`).join(", ")}</span>` : ""}
				<span class="duty-req-btns">
					<button class="btn btn-xs btn-primary duty-lv-ok" data-id="${p.name}">✓ ${__("Approve")}</button>
					<button class="btn btn-xs btn-default duty-lv-no" data-id="${p.name}">✗ ${__("Decline")}</button>
				</span>
			</div>`).join("");
		$host.html(`
			<div class="duty-me-reqs duty-lv-card">
				<h4>🌴 ${__("Leave")} <span class="duty-lv-bal">${L.remaining} ${__("of")} ${L.entitlement} ${__("days left")} · ${L.taken} ${__("taken in")} ${L.year}</span></h4>
				${reqs || `<div class="text-muted" style="font-size:12.5px">${__("No leave requested this year.")}</div>`}
				<div class="duty-lv-ask">
					<input type="date" class="form-control input-sm duty-lv-s">
					<span>→</span>
					<input type="date" class="form-control input-sm duty-lv-e">
					<input type="text" class="form-control input-sm duty-lv-note" placeholder="${__("Note (optional)")}">
					<button class="btn btn-xs btn-primary duty-lv-go">🌴 ${__("Request leave")}</button>
				</div>
				${L.is_admin && (L.pending || []).length ? `<h4 style="margin-top:14px">🗂 ${__("Awaiting your approval")}</h4>${pend}` : ""}
			</div>`);
		const redo = (r) => r.message && this._render_leave_card(r.message);
		$host.find(".duty-lv-go").on("click", () => {
			const s = $host.find(".duty-lv-s").val();
			const e = $host.find(".duty-lv-e").val();
			if (!s || !e) return frappe.show_alert({ message: __("Pick both dates."), indicator: "orange" });
			frappe.call({
				method: "duty_board.leave.request_leave",
				args: { start_date: s, end_date: e, note: $host.find(".duty-lv-note").val() || null },
				callback: (r) => { frappe.show_alert({ message: __("Leave requested."), indicator: "green" }); redo(r); },
			});
		});
		$host.find(".duty-lv-cancel").on("click", (e) =>
			frappe.confirm(__("Cancel this leave?"), () =>
				frappe.call({ method: "duty_board.leave.cancel_leave", args: { name: $(e.currentTarget).data("id") }, callback: redo }))
		);
		$host.find(".duty-lv-ok").on("click", (e) =>
			frappe.call({ method: "duty_board.leave.decide_leave", args: { name: $(e.currentTarget).data("id"), approve: 1 }, callback: (r) => { frappe.show_alert({ message: __("Approved."), indicator: "green" }); redo(r); } })
		);
		$host.find(".duty-lv-no").on("click", (e) => {
			const id = $(e.currentTarget).data("id");
			frappe.prompt(
				[{ fieldname: "note", fieldtype: "Small Text", label: __("Reason (optional)") }],
				(v) => frappe.call({ method: "duty_board.leave.decide_leave", args: { name: id, approve: 0, note: v.note || null }, callback: redo }),
				__("Decline leave"), __("Decline")
			);
		});
	}

	refresh_me(month) {
		const V = "js v2.59.3";
		console.log("[duty-me]", V, "refresh_me start, month:", month || "(current)");
		this._me_host().show();
		this.$me.html(`<div class="text-muted" style="padding:30px">${__("Loading your dashboard…")} <span style="opacity:.5">(${V})</span></div>`);
		const url = "/api/method/duty_board.api.my_dashboard" + (month ? `?month=${encodeURIComponent(month)}` : "");
		console.log("[duty-me] fetching", url);
		fetch(url, { credentials: "same-origin" })
			.then((res) => {
				console.log("[duty-me] response status", res.status);
				if (!res.ok) throw new Error(`HTTP ${res.status}`);
				return res.json();
			})
			.then((j) => {
				console.log("[duty-me] payload keys:", j && j.message ? Object.keys(j.message).join(",") : "NONE");
				if (!j || !j.message) throw new Error("empty payload");
				console.log("[duty-me] render begin");
				this._me_host();
				this.render_my_dashboard(j.message);
				if (!this._is_consultant) this.render_gamify();
				const node = this.$me[0];
				const rect = node.getBoundingClientRect();
				console.log("[duty-me] painted:", this.$me.find(".duty-mtile").length, "tiles | innerHTML:", node.innerHTML.length, "chars | visible height:", Math.round(rect.height), "| offsetParent:", !!node.offsetParent);
				// v2.59.3 "escalate to overlay" fallback removed (v3.59.5): it
				// answered a hidden host by double-rendering the dashboard into an
				// unstyled fixed panel, masking face-state bugs. If the host is
				// hidden, the render simply waits for the face to show.
				$(".duty-me-overlay").remove();
			})
			.catch((err) => {
				console.error("[duty-me] FAILED:", err);
				this.$me.html(`<div style="color:#b91c1c;padding:30px;white-space:pre-wrap">Dashboard failed: ${frappe.utils.escape_html(err.message)}\n${frappe.utils.escape_html((err.stack || "").split("\n").slice(0, 4).join("\n"))}</div>`);
			});
	}

	render_my_dashboard(m) {
		const esc = frappe.utils.escape_html;
		const t = m.tiles || {};
		const tile = (v, l, act) => (v === null || v === undefined) ? "" : `<div class="duty-mtile ${act ? "duty-mtile-act" : ""}" ${act ? `data-act="${act}"` : ""}><b>${esc(String(v))}</b><span>${esc(l)}</span></div>`;
		this.$me.html(`
			<div class="duty-me-head">
				<div>
					<h2>👤 ${esc(m.full_name)}</h2>
					<span class="text-muted">${__("Your work, your numbers — visible to you alone on this view.")}</span>
				</div>
				<div class="duty-me-clock">
					<span class="duty-me-dot ${m.duty && m.duty.on ? "on" : "off"}">●</span>
					<span>${m.duty && m.duty.on ? __("On duty") : __("Off duty")} · ${esc((m.duty || {}).today || "0h 0m")} ${__("today")}</span>
					${m.duty && m.duty.on
						? `<button class="btn btn-sm btn-default duty-me-clockout">${__("Clock Out")}</button>`
						: `<button class="btn btn-sm btn-primary duty-me-clockin">${__("Clock In")}</button>`}
				</div>
			</div>
			<div class="duty-mtiles">
				${tile(t.open_now, __("open now"), "open")}
				${tile(t.in_progress, __("in progress"), "open")}
				${tile(t.resolved_30, __("resolved · 30 days"), "resolved")}
				${tile(t.avg_res, __("avg resolution"))}
				${tile(t.sla_pct !== null && t.sla_pct !== undefined ? t.sla_pct + "%" : null, __("within SLA"))}
				${tile(t.my_stars !== null && t.my_stars !== undefined ? "★ " + t.my_stars : null, __("client rating") + ` (${t.my_rated_n || 0})`)}
				${tile(t.hours_30, __("hours logged · 30d"))}
				${tile(t.updates_30, __("updates posted · 30d"))}
				${tile(t.messages_30, __("messages · 30d"))}
			</div>
			<div class="duty-me-charts">
				<div class="duty-me-chart"><h4>${__("Resolved per week")}</h4><div class="duty-ch-weekly"></div></div>
				<div class="duty-me-chart"><h4>${__("Open workload by type")}</h4><div class="duty-ch-type"></div></div>
				<div class="duty-me-chart"><h4>${__("Hours by customer · 30d")}</h4><div class="duty-ch-hours"></div></div>
			</div>
			${(m.pending_requests || []).length ? `
			<div class="duty-me-reqs">
				<h4>📨 ${__("Meeting requests awaiting approval")}</h4>
				${m.pending_requests.map((r) => `
					<div class="duty-req-row">
						<b>${esc(r.date)}${r.time ? " · " + esc(r.time) : ""}</b> ${esc(r.topic)}
						<span class="text-muted">· ${esc(r.customer || "")}${r.by ? " — " + esc(r.by) : ""}</span>
						<span class="duty-req-btns">
							<button class="btn btn-xs btn-primary duty-req-ok" data-id="${esc(r.name)}">✓ ${__("Confirm")}</button>
							<button class="btn btn-xs btn-default duty-req-sg" data-id="${esc(r.name)}" data-topic="${esc(r.topic)}">↷ ${__("Suggest time")}</button>
							<button class="btn btn-xs btn-default duty-req-no" data-id="${esc(r.name)}">✗ ${__("Decline")}</button>
						</span>
					</div>`).join("")}
			</div>` : ""}
			<div class="duty-me-leave"></div>
			<div class="duty-me-earn"></div>
			<div class="duty-me-remind"></div>
			<div class="duty-me-cal">
				<div class="duty-me-calhead">
					<button class="btn btn-xs duty-cal-prev">◀</button>
					<h4 class="duty-cal-title"></h4>
					<button class="btn btn-xs duty-cal-next">▶</button>
				</div>
				<div class="duty-cal-grid"></div>
				<div class="duty-cal-legend">
					<span><i class="cdot cmeet"></i> ${__("meetings")}</span>
					<span><i class="cdot ctodo"></i> ${__("plan items")}</span>
					<span><i class="cdot cdue"></i> ${__("due")}</span>
					<span><i class="cdot cres"></i> ${__("resolved")}</span>
					<span><i class="cdot chrs"></i> ${__("hours on duty")}</span>
				</div>
			</div>
			<div class="duty-me-open">
				<h4>${__("Your open queue")}</h4>
				${(m.open_list || []).map((i) => {
					const today = frappe.datetime.get_today();
					const dueCls = !i.due ? "" : i.due < today ? " overdue" : i.due === today ? " duetoday" : "";
					return `
					<div class="duty-me-row" data-name="${esc(i.name)}">
						<span class="duty-sev duty-sev-${(i.severity || "medium").toLowerCase()}">${__(i.severity || "Medium")}</span>
						<span class="duty-me-title">${esc(i.title)}</span>
						<span class="duty-me-cust">${esc(i.customer || "—")}</span>
						<span class="duty-me-due${dueCls}">${i.due ? esc(i.due) : ""}</span>
					</div>`;
				}).join("") || `<div class="text-muted">${__("Nothing assigned — enjoy it while it lasts.")}</div>`}
			</div>
		`);
		const mk = (sel, type, data, height = 190) => {
			const $el = this.$me.find(sel);
			if (!data || !data.labels || !data.labels.length) {
				$el.html(`<div class="text-muted" style="padding:24px 0">${__("No data yet")}</div>`);
				return;
			}
			try {
				new frappe.Chart($el[0], {
					data: { labels: data.labels, datasets: [{ values: data.values }] },
					type, height, colors: ["#0F5C55", "#2563eb", "#d97706", "#7c3aed", "#dc2626", "#0e7490", "#65a30d", "#db2777"],
				});
			} catch (err) {
				console.error("chart", sel, err);
				$el.html(data.labels.map((l, i) => `<div style="display:flex;gap:8px;font-size:12px;padding:2px 0"><span style="flex:1">${frappe.utils.escape_html(String(l))}</span><b>${frappe.utils.escape_html(String(data.values[i]))}</b></div>`).join(""));
			}
		};
		mk(".duty-ch-weekly", "bar", m.weekly);
		mk(".duty-ch-type", "donut", m.by_type);
		mk(".duty-ch-hours", "donut", m.hours_by_customer);
		try {
			this.render_my_dashboard_cal(m);
		} catch (err) {
			console.error("calendar:", err);
			this.$me.find(".duty-cal-grid").html(`<div style="color:#b91c1c">calendar failed: ${frappe.utils.escape_html(err.message)}</div>`);
		}
		this.load_my_training();
		this.$me.find(".duty-me-row").on("click", (e) => this.issue_detail_dialog($(e.currentTarget).data("name")));
		this.$me.find(".duty-me-clockin").on("click", () =>
			frappe.call({
				method: "duty_board.api.clock_in",
				callback: () => this.refresh_me((this._me_data || {}).month),
			})
		);
		this.$me.find(".duty-mtile-act").on("click", (e) => {
			const act = $(e.currentTarget).data("act");
			this.issue_user_filter = "__me__";
			this._iss_overdue = false;
			this.issue_status_filter = act === "resolved" ? "resolved" : "open";
			localStorage.setItem("duty_iv", "mine");
			this.issues_open = true;
			this.show_face("issues");
		});
		this.$me.find(".duty-me-clockout").on("click", () =>
			frappe.prompt(
				{ fieldname: "reason", fieldtype: "Small Text", label: __("Reason"), reqd: 1 },
				(v) =>
					frappe.call({
						method: "duty_board.api.clock_out",
						args: { reason: v.reason },
						callback: () => this.refresh_me((this._me_data || {}).month),
					}),
				__("Clock Out")
			)
		);
		this._load_leave_card();
		this._load_earnings_card();
		this._load_reminders_card();
		this.$me.find(".duty-req-sg").on("click", (e) =>
			this.suggest_meeting_dialog($(e.currentTarget).data("id"), $(e.currentTarget).data("topic"), () => this.show_face("me"))
		);
this.$me.find(".duty-req-ok").on("click", (e) => {
			const $row = $(e.currentTarget).closest(".duty-req-row");
			frappe.call({
				method: "duty_board.client_room.confirm_meeting",
				args: { id: $(e.currentTarget).data("id") },
				callback: () => {
					// Optimistic: show the result at the click, before any refresh.
					$row.find(".duty-req-btns").html(`<span style="color:#0E8A63;font-weight:700">✅ ${__("Confirmed")}</span>`);
					frappe.show_alert({ message: __("Meeting confirmed"), indicator: "green" });
					this.refresh_me((this._me_data || {}).month);
				},
			});
		});
		this.$me.find(".duty-req-no").on("click", (e) => {
			const id = $(e.currentTarget).data("id");
			frappe.prompt(
				{ fieldname: "reason", fieldtype: "Small Text", label: __("Why not? (client sees this)") },
				(v) =>
					frappe.call({
						method: "duty_board.client_room.decline_meeting",
						args: { id, reason: v.reason || null },
						callback: () => {
							frappe.show_alert({ message: __("Declined"), indicator: "orange" });
							this.refresh_me((this._me_data || {}).month);
						},
					}),
				__("Decline meeting")
			);
		});
	}

	load_my_training() {
		if (!this.$me.find(".duty-me-training").length)
			this.$me.append(`<div class="duty-me-training" style="margin-top:18px"></div>`);
		frappe.call({
			method: "duty_board.client_room.my_training",
			callback: (r) => this.render_my_training(r.message || []),
		});
		if (!this.$me.find(".duty-me-certs").length)
			this.$me.append(`<div class="duty-me-certs" style="margin-top:14px"></div>`);
		frappe.call({
			method: "duty_board.client_room.my_certificates",
			callback: (r) => {
				const certs = r.message || [];
				const $c = this.$me.find(".duty-me-certs");
				if (!certs.length) return $c.empty();
				$c.html(`
					<div class="duty-lead-section">🎖 ${__("My certificates")}</div>
					${certs
						.map(
							(x) => `
					<div class="duty-cr-msrow">
						<span>🏅 <b>${frappe.utils.escape_html(x.product)} — ${frappe.utils.escape_html(x.track_title)}</b>
						${x.status !== "Valid" ? `<span class="duty-lead-chip" style="color:#b45309">${__(x.status)}</span>` : ""}</span>
						<span class="text-muted" style="font-size:var(--text-sm)">${x.serial} · ${x.issued_on}
							· <a href="/api/method/duty_board.client_room.my_certificate_file?serial=${encodeURIComponent(x.serial)}" target="_blank">⬇ ${__("PDF")}</a>
							· <a href="/verify?serial=${encodeURIComponent(x.serial)}" target="_blank">✓ ${__("verify")}</a></span>
					</div>`
						)
						.join("")}
				`);
			},
		});
	}

	render_my_training(rows) {
		const $t = this.$me.find(".duty-me-training");
		if (!$t.length) return;
		$t.html(`
			<div class="duty-lead-section">🎓 ${__("My training")} <a class="duty-me-trassign">＋ ${__("Assign to a colleague")}</a></div>
			${rows.length
				? (() => {
						const esc = frappe.utils.escape_html;
						let out = "", last = null;
						rows.forEach((r) => {
							const g = r.product || __("General");
							if (g !== last) {
								const gr = rows.filter((x) => (x.product || __("General")) === g);
								const cert = gr.filter((x) => x.status === "Completed").length;
								out += `<div class="duty-tr-group"><b>${esc(g)}</b><span class="${cert === gr.length ? "duty-tr-done" : ""}">${cert}/${gr.length} ${__("certified")}</span></div>`;
								last = g;
							}
							out += `
				<div class="duty-cr-msrow duty-tr-row" style="cursor:pointer" data-record="${r.name}">
					<span>${r.status === "Completed" ? "🏅" : "📖"} <b>${esc(r.module_title)}</b></span>
					<span class="text-muted" style="font-size:var(--text-sm)">
						${r.status === "Completed"
							? `✓ ${__("certified")} ${r.completed_on || ""}`
							: `📚 ${r.lessons_done}/${r.lessons_total} ${__("lessons")}${r.lessons_total && r.lessons_done === r.lessons_total ? " · ✓ " + __("all read") : ""}`}
					</span>
				</div>`;
						});
						return out;
				  })()
				: `<div class="text-muted" style="font-size:var(--text-sm)">${__("No training assigned to you yet.")}</div>`}
		`);
		$t.find("[data-record]").on("click", (e) => this.my_course_dialog($(e.currentTarget).data("record")));
		$t.find(".duty-me-trassign").on("click", () =>
			frappe.call({
				method: "duty_board.client_room.training_modules_for_staff",
				callback: (r) => {
					const mods = r.message || [];
					if (!mods.length)
						return frappe.msgprint(
							__("No consultant-facing courses yet. Create a Duty Training Module with audience Consultant or Both, and add its Duty Lessons in the desk.")
						);
					frappe.call({
						method: "duty_board.client_room.staff_tracks",
						callback: (tr) => {
							const tracks = tr.message || [];
							frappe.prompt(
								[
									{
										fieldname: "track",
										fieldtype: "Select",
										label: __("Whole track (assigns every course in it)"),
										options: [{ value: "", label: __("— single course instead —") }].concat(
											tracks.map((t) => ({
												value: t.name,
												label: `🎓 ${t.title} (${t.module_count} ${__("courses")})${t.product ? " · " + t.product : ""}${t.audience === "Client" ? " · " + __("client track — product knowledge") : ""}`,
											}))
										),
									},
									{
										fieldname: "module",
										fieldtype: "Select",
										label: __("Single course"),
										options: [{ value: "", label: "" }].concat(
											mods.map((m) => ({ value: m.name, label: `${m.title}${m.product ? " · " + m.product : ""}` }))
										),
									},
									{
										fieldname: "user",
										fieldtype: "Autocomplete",
										label: __("Consultant"),
										options: this.staff_options(),
										reqd: 1,
									},
								],
								(v) => {
									if (!v.track && !v.module)
										return frappe.msgprint(__("Pick a whole track or a single course."));
									if (v.track) {
										frappe.call({
											method: "duty_board.client_room.training_assign_track",
											args: { track: v.track, user: v.user },
											callback: (rr) => {
												const m = rr.message || {};
												frappe.show_alert({
													message: __("🎓 Track assigned: {0} new, {1} already had.", [m.created || 0, m.existing || 0]),
													indicator: "green",
												});
												if (v.user === frappe.session.user && m.records) this.render_my_training(m.records);
											},
										});
									} else {
										frappe.call({
											method: "duty_board.client_room.training_assign_staff",
											args: { module: v.module, user: v.user },
											callback: (rr) => {
												frappe.show_alert({ message: __("🎓 Assigned."), indicator: "green" });
												if (v.user === frappe.session.user && rr.message) this.render_my_training(rr.message);
											},
										});
									}
								},
								__("Assign consultant training"),
								__("Assign")
							);
						},
					});
				},
			})
		);
	}

	my_course_dialog(record) {
		frappe.call({
			method: "duty_board.client_room.my_course",
			args: { record: record },
			callback: (r) => {
				const c = r.message;
				if (!c) return;
				const d = new frappe.ui.Dialog({ title: `📖 ${frappe.utils.escape_html(c.title || "")}`, size: "large" });
				const render = (cc) => {
					const allRead = cc.lessons.length && cc.lessons.every((l) => l.done);
					const qz = cc.quiz || {};
					$(d.body).html(`
						${cc.description ? `<div class="text-muted" style="margin-bottom:10px">${frappe.utils.escape_html(cc.description)}</div>` : ""}
						${cc.status === "Completed" || qz.passed
							? `<div style="background:#EDF7F5;border:1px solid #B7DFD6;border-radius:10px;padding:9px 13px;margin-bottom:10px;font-weight:700;color:#0C4A43">🏅 ${__("Certified")} · ${__("best score")} ${qz.best}%${qz.attempts > 1 ? ` · ${qz.attempts} ${__("attempts")}` : ""}</div>`
							: qz.bank >= 10
								? allRead
									? `<div style="display:flex;gap:10px;align-items:center;margin-bottom:10px"><button type="button" class="btn btn-sm btn-primary duty-me-quiz">📝 ${__("Take the test")}</button><span class="text-muted" style="font-size:var(--text-sm)">${qz.attempts ? `${__("best so far")} ${qz.best}% · ` : ""}10 ${__("questions, pass at 70%")}</span></div>`
									: `<div class="text-muted" style="font-size:var(--text-sm);margin-bottom:10px">📝 ${__("The test unlocks when every lesson is read.")}</div>`
								: ""}
						${cc.lessons.length
							? cc.lessons
									.map(
										(l, i) => `
							<div class="duty-cr-msrow" style="cursor:pointer" data-lesson="${l.name}">
								<span>${l.done ? "✅" : "⚪"} <b>${i + 1}. ${frappe.utils.escape_html(l.title)}</b></span>
								<span class="text-muted" style="font-size:var(--text-sm)">~${l.est_minutes} ${__("min")}</span>
							</div>`
									)
									.join("")
							: `<div class="text-muted">${__("Lessons are being prepared for this course.")}</div>`}
					`);
					$(d.body).find("[data-lesson]").on("click", (e) => {
						d.hide();
						this.my_lesson_dialog($(e.currentTarget).data("lesson"), record, cc);
					});
					$(d.body).find(".duty-me-quiz").on("click", () => {
						d.hide();
						this.my_quiz_dialog(record);
					});
				};
				render(c);
				d.show();
			},
		});
	}

	my_lesson_dialog(lesson, record, course) {
		frappe.call({
			method: "duty_board.client_room.my_lesson",
			args: { lesson: lesson },
			callback: (r) => {
				const l = r.message;
				if (!l) return;
				const lessons = (course && course.lessons) || [];
				const idx = lessons.findIndex((x) => x.name === lesson);
				const next = idx >= 0 ? lessons[idx + 1] : null;
				const d = new frappe.ui.Dialog({ title: (course && course.title) || __("Lesson"), size: "extra-large" });
				let secs = l.seconds || 0;
				let beat = null;
				$(d.body).html(`
					<style>
						.duty-lw { max-width: 74ch; margin: 0 auto; }
						.duty-lw-head { background: linear-gradient(120deg,#0A473F,#0F5C55 60%,#146B62); color: #fff;
							border-radius: 12px; padding: 16px 22px; margin-bottom: 20px; }
						.duty-lw-head .k { font-size: 11px; letter-spacing: 2px; text-transform: uppercase; opacity: .75; }
						.duty-lw-head h2 { margin: 4px 0 0; font-size: 22px; color: #fff; }
						.duty-lw-head .m { font-size: 12px; opacity: .85; margin-top: 6px; }
						.duty-lw-body { font-family: Georgia, "Times New Roman", serif; font-size: 17px; line-height: 1.85; color: #1F2A28; }
						.duty-lw-body p { margin: 0 0 14px; }
						.duty-lw-body b { color: #0C4A43; }
						.duty-lw-body ol { counter-reset: n; list-style: none; padding-left: 6px; }
						.duty-lw-body ol li { counter-increment: n; position: relative; padding-left: 40px; margin: 10px 0; }
						.duty-lw-body ol li:before { content: counter(n); position: absolute; left: 0; top: 2px;
							width: 26px; height: 26px; border-radius: 50%; background: #0F5C55; color: #fff;
							font-family: Inter, sans-serif; font-size: 13px; font-weight: 700;
							display: flex; align-items: center; justify-content: center; }
						.duty-lw-body ul { padding-left: 20px; }
						.duty-lw-body ul li { margin: 8px 0; }
						.duty-lw-body ul li::marker { color: #0F5C55; }
						.duty-lw-body blockquote { margin: 18px 0; padding: 13px 16px 13px 46px; border-radius: 12px;
							font-family: Inter, sans-serif; font-size: 14px; line-height: 1.6; position: relative; }
						.duty-lw-body blockquote:before { position: absolute; left: 14px; top: 12px; font-size: 18px; }
						.duty-lw-body blockquote.bq-note { background: #EEF7F4; border: 1px solid #CBE7DE; }
						.duty-lw-body blockquote.bq-note:before { content: "📌"; }
						.duty-lw-body blockquote.bq-tip { background: #FFF7E6; border: 1px solid #F3E0B5; }
						.duty-lw-body blockquote.bq-tip:before { content: "💡"; }
						.duty-lw-body blockquote.bq-warn { background: #FDECEA; border: 1px solid #F4C7C0; }
						.duty-lw-body blockquote.bq-warn:before { content: "⚠️"; }
						.duty-lw-foot { display: flex; gap: 12px; align-items: center; margin-top: 22px;
							border-top: 1px solid var(--border-color,#E7ECEA); padding-top: 14px; }
						.duty-lw-dots { display: flex; gap: 5px; margin-right: auto; }
						.duty-lw-dots i { width: 9px; height: 9px; border-radius: 50%; background: #D9E4E0; }
						.duty-lw-dots i.done { background: #0F5C55; }
						.duty-lw-dots i.cur { outline: 2px solid #0F5C55; outline-offset: 2px; }
					</style>
					<div class="duty-lw">
						<div class="duty-lw-head">
							<div class="k">${frappe.utils.escape_html((course && course.product) || "")} · ${__("Lesson")} ${idx + 1} ${__("of")} ${lessons.length}</div>
							<h2>${frappe.utils.escape_html(l.title)}</h2>
							<div class="m">⏱ ~${l.est_minutes} ${__("min read")}</div>
						</div>
						<div class="duty-lw-body"></div>
						<div class="duty-lw-foot">
							<span class="duty-lw-dots">${lessons.map((x, k) => `<i class="${x.done || x.name === lesson && l.done ? "done" : ""} ${k === idx ? "cur" : ""}"></i>`).join("")}</span>
							${l.done
								? `<span style="color:#15803d;font-weight:700;font-family:Inter,sans-serif">✓ ${__("Read")}</span>`
								: `<button type="button" class="btn btn-sm btn-primary duty-me-lread">✓ ${__("Mark as read")}${next ? " · " + __("next lesson") + " →" : ""}</button>`}
							${l.done && next ? `<button type="button" class="btn btn-sm btn-primary" data-next>${__("Next lesson")} →</button>` : ""}
							<button type="button" class="btn btn-sm btn-default" data-back>← ${__("Lessons")}</button>
						</div>
					</div>
				`);
				const $b = $(d.body).find(".duty-lw-body");
				$b.html(l.html);
				$b.find("blockquote").each(function () {
					const t = $(this).text();
					$(this).addClass(t.indexOf("WATCH-OUT") === 0 ? "bq-warn" : t.indexOf("IMPLEMENTATION TIP") === 0 ? "bq-tip" : "bq-note");
				});
				if (!l.done) {
					beat = setInterval(() => {
						if (document.visibilityState !== "visible" || !$(d.body).is(":visible")) return;
						secs += 20;
						frappe.call({ method: "duty_board.client_room.my_lesson_beat", args: { lesson: lesson, secs: 20 } });
					}, 20000);
				}
				d.onhide = () => {
					if (beat) clearInterval(beat);
				};
				const go_next = () => {
					d.hide();
					if (next) this.my_lesson_dialog(next.name, record, course);
					else {
						this.load_my_training();
						this.my_course_dialog(record);
					}
				};
				$(d.body).find(".duty-me-lread").on("click", () =>
					frappe.call({
						method: "duty_board.client_room.my_lesson_done",
						args: { lesson: lesson },
						callback: (rr) => {
							if (rr.message) {
								course = rr.message;
								go_next();
							}
						},
					})
				);
				$(d.body).find("[data-next]").on("click", go_next);
				$(d.body).find("[data-back]").on("click", () => {
					d.hide();
					this.my_course_dialog(record);
				});
				d.show();
			},
		});
	}

	books_dialog() {
		// legacy entry point — Books is a face now
		this.show_face("books");
	}

	refresh_books() {
		if (!this.books_period) this.books_period = frappe.datetime.now_date().slice(0, 7);
		if (!this.books_tab) this.books_tab = (this.books_acc && this.books_acc.tab) || "matrix";
		this.render_books_shell();
	}

	_books_shift_period(delta) {
		const [y, mo] = this.books_period.split("-").map(Number);
		const d = new Date(y, mo - 1 + delta, 1);
		this.books_period = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
		this.render_books_shell();
	}

	render_books_shell() {
		const mgr = this.books_acc && this.books_acc.manager;
		const tabs = [
			["matrix", "📊 " + __("Matrix")],
			["round", "📅 " + __("My round")],
			["register", "🗓 " + __("Register")],
			["followups", "📨 " + __("Follow-ups")],
			["onboarding", "🚀 " + __("Onboarding")],
		];
		if (mgr) tabs.push(["profit", "₦ " + __("Profitability")], ["billing", "💰 " + __("Billing")], ["kpi", "📈 " + __("KPIs")]);
		this.$books.html(`
			<style>
				.duty-books-head { display: flex; gap: 12px; align-items: center; flex-wrap: wrap;
					background: linear-gradient(120deg,#0A473F,#0F5C55 60%,#146B62); color: #fff;
					border-radius: 12px; padding: 12px 16px; margin-bottom: 10px; }
				.duty-books-head b.per { font-size: 16px; }
				.duty-books-pulse { display: flex; gap: 14px; margin-left: auto; flex-wrap: wrap; font-size: 12px; }
				.duty-books-pulse span { opacity: .92; white-space: nowrap; }
				.duty-books-tabs { display: flex; gap: 6px; overflow-x: auto; margin-bottom: 12px; padding-bottom: 2px; }
				.duty-books-tabs a { padding: 7px 14px; border-radius: 999px; font-size: 13px; font-weight: 700;
					background: var(--bg-light-gray,#F4F7F6); color: #334; cursor: pointer; white-space: nowrap; }
				.duty-books-tabs a.on { background: #0F5C55; color: #fff; }
				.duty-books-panel { padding-bottom: 90px; }
				.duty-books-panel table { background: #fff; }
			</style>
			<div class="duty-books-head">
				<button class="btn btn-xs btn-default" data-bprev>‹</button>
				<b class="per">${this.books_period}</b>
				<button class="btn btn-xs btn-default" data-bnext>›</button>
				<span class="duty-books-pulse" data-pulse></span>
			</div>
			<div class="duty-books-tabs">
				${tabs.map(([k, l]) => `<a data-btab="${k}" class="${this.books_tab === k ? "on" : ""}">${l}</a>`).join("")}
			</div>
			<div class="duty-books-panel"><div class="text-muted">${__("Loading…")}</div></div>
		`);
		this.$books.find("[data-bprev]").on("click", () => this._books_shift_period(-1));
		this.$books.find("[data-bnext]").on("click", () => this._books_shift_period(1));
		this.$books.find("[data-btab]").on("click", (e) => {
			this.books_tab = $(e.currentTarget).data("btab");
			this.render_books_shell();
		});
		frappe.call({
			method: "duty_board.accounting.books_pulse",
			args: { period: this.books_period },
			callback: (r) => {
				const p = r.message;
				if (!p) return;
				this.$books.find("[data-pulse]").html(`
					<span>🤝 ${p.clients} ${__("clients")}</span>
					<span>✅ ${p.done}/${p.total} ${__("done")}</span>
					${p.late ? `<span style="color:#FCA5A5">⏰ ${p.late} ${__("late")}</span>` : ""}
					${p.neglect ? `<span style="color:#FCA5A5">⚠ ${p.neglect} ${__("neglected")}</span>` : ""}
					${p.open_q || p.open_r ? `<span>📨 ${p.open_q}❓ ${p.open_r}📎</span>` : ""}
					${p.fee_total ? `<span>₦${Number(p.fee_total).toLocaleString()}/mo</span>` : ""}
					${p.unpaid_count ? `<span style="color:#FCD34D">💰 ${p.unpaid_count} ${__("unpaid")} · ₦${Number(p.unpaid_total).toLocaleString()}</span>` : ""}
				`);
			},
		});
		this.render_books_panel();
	}

	render_books_panel() {
		const $p = this.$books.find(".duty-books-panel");
		const fn = {
			matrix: "_bpanel_matrix",
			round: "_bpanel_round",
			register: "_bpanel_register",
			followups: "_bpanel_followups",
			onboarding: "_bpanel_onboarding",
			profit: "_bpanel_profit",
			billing: "_bpanel_billing",
			kpi: "_bpanel_kpi",
		}[this.books_tab];
		if (fn) this[fn]($p);
	}

	_bpanel_matrix($p) {
		frappe.call({
			method: "duty_board.accounting.books_matrix",
			args: { period: this.books_period },
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				const STAT = { Pending: ["·", "#94a3b8"], "In Progress": ["◐", "#b45309"], "In Review": ["👁", "#7c3aed"], Delivered: ["✓", "#0F5C55"], Acknowledged: ["✓✓", "#15803d"] };
				$p.html(`
					<div style="display:flex;gap:8px;justify-content:flex-end;margin-bottom:8px">
						<button class="btn btn-xs btn-default" data-sync>⟳ ${__("Sync clients")}</button>
						<button class="btn btn-xs btn-primary" data-open>📂 ${__("Open period")}</button>
					</div>
					${m.rooms.length
						? `<div style="overflow-x:auto"><table class="table table-bordered" style="font-size:var(--text-sm);margin:0">
							<thead><tr><th style="min-width:170px">${__("Client")}</th><th>${__("Bookkeeper")}</th>${m.types.map((t) => `<th style="min-width:110px">${frappe.utils.escape_html(t.title)}${t.optional ? " *" : ""}</th>`).join("")}</tr></thead>
							<tbody>${m.rooms
								.map(
									(row) => `<tr>
								<td><b>${frappe.utils.escape_html(row.customer)}</b>
									${row.scope ? `<br><span style="font-size:10px;font-weight:700;color:#0e7490">◳ ${frappe.utils.escape_html(row.scope)}</span>` : ""}
									${(!row.scope || row.scope.includes("Bookkeeping")) && row.posted_through ? `<br><span style="font-size:10px;font-weight:700;color:${row.lag <= 1 ? "#15803d" : row.lag <= 3 ? "#b45309" : "#b91c1c"}">📮 ${__("posted thru")} ${row.posted_through.slice(5)} · ${__("lag")} ${row.lag}wd</span>` : (!row.scope || row.scope.includes("Bookkeeping") ? `<br><span style="font-size:10px;color:#94a3b8">📮 ${__("no attestation")}</span>` : "")}
									${row.fee ? `<br><span class="text-muted" style="font-size:11px">₦${Number(row.fee).toLocaleString()}/mo</span>` : ""}</td>
								<td><a class="duty-bk-room" data-room="${row.room}" data-bk="${row.bookkeeper || ""}" data-opt="${frappe.utils.escape_html(row.optionals)}" data-scope="${frappe.utils.escape_html(row.scope || "")}" data-fye="${row.fye_month || ""}" style="cursor:pointer">${row.bookkeeper_name ? frappe.utils.escape_html(row.bookkeeper_name.split(" ")[0]) : "— " + __("set")}</a>
									<a class="duty-bk-pb" data-room="${row.room}" title="${__("Client playbook")}" style="cursor:pointer;margin-left:6px">📖</a></td>
								${m.types
									.map((t) => {
										const c = row.cells[t.name];
										if (!c) {
											const lines = (row.scope || "").split(",").map((s) => s.trim()).filter(Boolean);
											if (lines.length && t.service_line && !lines.includes(t.service_line)) {
												return `<td class="text-muted" style="text-align:center;opacity:.35" title="${__("Outside this client's service scope")}">·</td>`;
											}
											const enabled = !t.optional || (row.optionals || "").split(",").map((s) => s.trim()).some((s) => s === t.title || s === t.name);
											if (enabled && t.frequency === "Quarterly") {
												const mo = Number(m.period.slice(5, 7));
												const qm = mo <= 3 ? 3 : mo <= 6 ? 6 : mo <= 9 ? 9 : 12;
												const qname = ["", "", "", "Mar", "", "", "Jun", "", "", "Sep", "", "", "Dec"][qm];
												return `<td class="text-muted" style="text-align:center;font-size:10px" title="${__("Quarterly — next occurrence opens with the {0} period", [qname])}">↻ ${qname}</td>`;
											}
											return `<td class="text-muted" style="text-align:center">—</td>`;
										}
										const [ic, col] = STAT[c.status] || ["·", "#94a3b8"];
										return `<td style="text-align:center;cursor:pointer;${c.late ? "background:#FDECEA;" : ""}" class="duty-bk-cell" data-name="${c.name}" title="${frappe.utils.escape_html((c.notes || "") + (c.assigned_to ? " · " + c.assigned_to : ""))}">
											<span style="color:${col};font-weight:800">${ic}</span>
											<div style="font-size:10px;color:${c.late ? "#b91c1c" : "#94a3b8"}">${c.due_date ? c.due_date.slice(5) : ""}${c.late ? " ⚠" : ""}</div>
											${c.assigned_to ? `<div style="font-size:10px;color:#64748b">${frappe.utils.escape_html((c.assigned_to || "").split("@")[0])}</div>` : ""}
										</td>`;
									})
									.join("")}
							</tr>`
								)
								.join("")}</tbody>
						</table></div>
						<div class="text-muted" style="font-size:11px;margin-top:8px">· ${__("Pending")} &nbsp; ◐ ${__("In progress")} &nbsp; 👁 ${__("In review")} &nbsp; ✓ ${__("Delivered")} &nbsp; ✓✓ ${__("Acknowledged by client")} &nbsp; * ${__("optional per room")} &nbsp; ${__("red = past due")}</div>`
						: `<div class="text-muted">${__("No accounting clients found — set accounting_services to 'On Board' on the Customer, then Sync.")}</div>`}
				`);
				$p.find("[data-sync]").on("click", () =>
					frappe.call({ method: "duty_board.accounting.sync_accounting_clients", callback: (rr) => { frappe.show_alert({ message: __("Synced: {0} clients, {1} rooms created", [rr.message.customers, rr.message.rooms_created]), indicator: "green" }); this.render_books_shell(); } })
				);
				$p.find("[data-open]").on("click", () =>
					frappe.call({ method: "duty_board.accounting.books_open_period", args: { period: this.books_period }, callback: (rr) => { frappe.show_alert({ message: __("{0} deliverables, {1} document requests opened", [rr.message.spawned, rr.message.requests || 0]), indicator: "green" }); this.render_books_shell(); } })
				);
				$p.find(".duty-bk-cell").on("click", (e) => this.books_cell_dialog($(e.currentTarget).data("name")));
				$p.find(".duty-bk-pb").on("click", (e) => this.books_playbook_dialog($(e.currentTarget).data("room")));
				$p.find(".duty-bk-room").on("click", (e) => {
					const room = $(e.currentTarget).data("room");
					const current = ($(e.currentTarget).data("opt") || "").split(",").map((s) => s.trim()).filter(Boolean);
					const opts = m.types.filter((t) => t.optional);
					const LINES = ["Bookkeeping", "Payroll & HR", "Tax"];
					const curScope = ($(e.currentTarget).data("scope") || "").split(",").map((s) => s.trim()).filter(Boolean);
					const scopeSel = curScope.length ? curScope : LINES;
					frappe.prompt(
						[
							{ fieldname: "bookkeeper", fieldtype: "Autocomplete", label: __("Bookkeeper (default owner)"), options: this.staff_options(), default: $(e.currentTarget).data("bk") || "" },
							{
								fieldname: "scope",
								fieldtype: "MultiCheck",
								label: __("Service scope — all three checked = Full Books"),
								columns: 3,
								options: LINES.map((l) => ({ label: l, value: l, checked: scopeSel.includes(l) })),
							},
							{
								fieldname: "fye_month",
								fieldtype: "Select",
								label: __("Financial year end month (annual tax deliverables)"),
								options: ["", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
								default: String($(e.currentTarget).data("fye") || ""),
								description: __("CIT / annual returns spawn 6 months after this month; blank = skipped"),
							},
							{
								fieldname: "optionals",
								fieldtype: "MultiCheck",
								label: __("Service tier — optional deliverables this client pays for"),
								columns: 1,
								options: opts.map((t) => ({ label: t.title + (t.service_line && t.service_line !== "Bookkeeping" ? " · " + t.service_line : ""), value: t.title, checked: current.includes(t.title) || current.includes(t.name) })),
							},
						],
						(v) =>
							frappe.call({
								method: "duty_board.accounting.books_set_room",
								args: { name: room, bookkeeper: v.bookkeeper || null, optionals: (v.optionals || []).join(", "), scope: (v.scope || []).join(", "), fye_month: v.fye_month || 0 },
								callback: () => this.render_books_shell(),
							}),
						__("Client setup"),
						__("Save")
					);
				});
			},
		});
	}

	_bpanel_round($p) {
		frappe.call({
			method: "duty_board.accounting.books_daily_round",
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				$p.html(`
					<div class="text-muted" style="font-size:12px;margin-bottom:10px">📅 ${m.date} — ${__("two taps per client: where are the books posted through, and anything worth noting. Sessions you've clocked already show as ●.")}</div>
					${m.rows
						.map(
							(x, i) => `
					<div style="border:1px solid var(--border-color,#E7ECEA);border-radius:10px;padding:10px 12px;margin-bottom:8px;background:#fff" data-row="${i}">
						<div style="display:flex;gap:8px;align-items:center;margin-bottom:7px">
							<b>${frappe.utils.escape_html(x.customer)}</b>
							<span title="${__("worked today (session tagged)")}">${x.worked_today ? "●" : "○"}</span>
							${x.logged_today ? `<span style="color:#15803d;font-size:11px;font-weight:700">✓ ${__("attested")}</span>` : ""}
							<span style="margin-left:auto;font-size:11px;color:${x.lag === null ? "#94a3b8" : x.lag <= 1 ? "#15803d" : x.lag <= 3 ? "#b45309" : "#b91c1c"}">${x.posted_through ? __("posted thru {0} · lag {1}wd", [x.posted_through, x.lag]) : __("no attestation yet")}</span>
						</div>
						<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
							<input type="date" class="form-control input-sm bk-pt" style="width:150px" value="${x.posted_through || ""}" max="${m.date}">
							<input type="number" class="form-control input-sm bk-tx" style="width:90px" placeholder="${__("tx posted")}" value="${x.tx_posted ?? ""}">
							<input type="number" class="form-control input-sm bk-q" style="width:90px" placeholder="${__("queries")}" value="${x.queries_raised ?? ""}">
							<input type="text" class="form-control input-sm bk-note" style="flex:1;min-width:140px" placeholder="${__("note (optional)")}" value="${frappe.utils.escape_html(x.note || "")}">
							<button class="btn btn-xs btn-primary bk-save" data-room="${x.room}">💾</button>
						</div>
					</div>`
						)
						.join("") || `<div class="text-muted">${__("No accounting clients assigned to you.")}</div>`}
				`);
				$p.find(".bk-save").on("click", (e) => {
					const $row = $(e.currentTarget).closest("[data-row]");
					frappe.call({
						method: "duty_board.accounting.books_log_day",
						args: {
							room: $(e.currentTarget).data("room"),
							posted_through: $row.find(".bk-pt").val() || null,
							tx_posted: $row.find(".bk-tx").val() || 0,
							queries_raised: $row.find(".bk-q").val() || 0,
							note: $row.find(".bk-note").val() || null,
						},
						callback: () => {
							frappe.show_alert({ message: __("Attested"), indicator: "green" });
							this.render_books_shell();
						},
					});
				});
			},
		});
	}

	_bpanel_register($p) {
		frappe.call({
			method: "duty_board.accounting.books_register",
			args: { period: this.books_period },
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				const CELL = { both: ["●", "#0F5C55"], worked: ["◐", "#b45309"], logged: ["◔", "#7c3aed"], none: ["·", "#cbd5e1"], future: ["", "#fff"] };
				$p.html(`
					<div style="overflow-x:auto"><table class="table table-bordered" style="font-size:11px;margin:0">
						<thead><tr><th style="min-width:150px">${__("Client")}</th>${m.days.map((ds) => `<th style="text-align:center;padding:4px 5px">${ds.slice(8)}</th>`).join("")}<th>${__("Lag")}</th></tr></thead>
						<tbody>${m.rooms
							.map(
								(row) => `<tr ${row.neglected ? 'style="background:#FDECEA"' : ""}>
							<td><b>${frappe.utils.escape_html(row.customer)}</b>${row.neglected ? ` <span style="color:#b91c1c;font-weight:800">⚠ ${row.streak}${__("wd")}</span>` : ""}</td>
							${m.days.map((ds) => { const [ic, col] = CELL[row.cells[ds]] || CELL.none; return `<td style="text-align:center;color:${col};font-weight:800;padding:4px 5px">${ic}</td>`; }).join("")}
							<td style="font-size:10px;font-weight:700;color:${row.lag === null ? "#94a3b8" : row.lag <= 1 ? "#15803d" : row.lag <= 3 ? "#b45309" : "#b91c1c"}">${row.posted_through ? row.lag + "wd" : "—"}</td>
						</tr>`
							)
							.join("")}</tbody>
					</table></div>
					<div class="text-muted" style="font-size:11px;margin-top:8px">● ${__("worked + attested")} &nbsp; ◐ ${__("worked, no attestation")} &nbsp; ◔ ${__("attested, no session")} &nbsp; · ${__("untouched")} &nbsp; ${__("red row = {0}+ working days untouched", [m.neglect_days])}</div>
				`);
			},
		});
	}

	_bpanel_followups($p, room_filter) {
		frappe.call({
			method: "duty_board.accounting.books_followups",
			args: { room: room_filter || null },
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				const roomName = (rm) => { const x = m.rooms.find((y) => y.room === rm); return x ? x.customer : rm; };
				$p.html(`
					<div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap">
						<select class="form-control input-sm" data-roomsel style="width:220px">
							<option value="">${__("All clients")}</option>
							${m.rooms.map((x) => `<option value="${x.room}" ${room_filter === x.room ? "selected" : ""}>${frappe.utils.escape_html(x.customer)}</option>`).join("")}
						</select>
						<span style="margin-left:auto;display:flex;gap:8px">
							<button class="btn btn-xs btn-primary" data-addq>❓ ${__("New question")}</button>
							<button class="btn btn-xs btn-default" data-addr>📎 ${__("New request")}</button>
						</span>
					</div>
					<div style="font-size:12px;font-weight:800;margin-bottom:6px">❓ ${__("Questions")} (${m.queries.length})</div>
					${m.queries
						.map(
							(q) => `
					<div style="border:1px solid var(--border-color,#E7ECEA);border-radius:10px;padding:9px 12px;margin-bottom:7px;background:${q.status === "Answered" ? "#F4FBF8" : "#fff"}">
						<div style="display:flex;gap:8px;align-items:baseline;flex-wrap:wrap">
							<b style="font-size:13px">${frappe.utils.escape_html(roomName(q.room))}</b>
							<span class="text-muted" style="font-size:11px">${[q.ref_date, q.amount ? "₦" + Number(q.amount).toLocaleString() : null, q.reference].filter(Boolean).map(frappe.utils.escape_html).join(" · ")}</span>
							${q.recipients ? `<span style="font-size:11px;color:#0e7490;font-weight:700">👤 ${frappe.utils.escape_html(q.recipients.split(",").map((s) => s.trim().split("@")[0]).join(", "))}</span>` : ""}
							<span style="margin-left:auto;font-size:11px;font-weight:700;color:${q.status === "Answered" ? "#15803d" : "#b45309"}">${q.status === "Answered" ? "💬 " + __("answered") : __("open") + " · " + q.age_wd + "wd"}</span>
						</div>
						<div style="font-size:13px;margin-top:3px">${frappe.utils.escape_html(q.question)}</div>
						${q.answer ? `<div style="font-size:13px;margin-top:5px;padding:7px 10px;background:#fff;border:1px solid #CBE7DE;border-radius:8px">💬 <b>${frappe.utils.escape_html(q.answered_by || "")}</b>: ${frappe.utils.escape_html(q.answer)} <button class="btn btn-xs btn-primary" data-resolve="${q.name}" style="margin-left:8px">✓ ${__("Resolve")}</button></div>` : ""}
					</div>`
						)
						.join("") || `<div class="text-muted" style="margin-bottom:8px">${__("No open questions.")}</div>`}
					<div style="font-size:12px;font-weight:800;margin:10px 0 6px">📎 ${__("Document requests")} (${m.requests.length})</div>
					${m.requests
						.map(
							(x) => `
					<div style="border:1px solid var(--border-color,#E7ECEA);border-radius:10px;padding:8px 12px;margin-bottom:6px;display:flex;gap:8px;align-items:center;background:${x.overdue ? "#FDECEA" : "#fff"}">
						<b style="font-size:13px">${frappe.utils.escape_html(roomName(x.room))}</b>
						<span style="font-size:13px">${frappe.utils.escape_html(x.title)}</span>
						${x.recipients ? `<span style="font-size:11px;color:#0e7490;font-weight:700">👤 ${frappe.utils.escape_html(x.recipients.split(",").map((s) => s.trim().split("@")[0]).join(", "))}</span>` : ""}
						<span class="text-muted" style="font-size:11px;margin-left:auto">${x.due_date ? __("due") + " " + x.due_date + (x.overdue ? " ⚠" : "") : ""}</span>
						<button class="btn btn-xs btn-default" data-waive="${x.name}">${__("Waive")}</button>
					</div>`
						)
						.join("") || `<div class="text-muted">${__("Nothing outstanding.")}</div>`}
					${m.received && m.received.length
						? `<div style="font-size:12px;font-weight:800;margin:10px 0 6px">📥 ${__("Recently received")}</div>` +
							m.received
								.map(
									(x) => `
					<div style="border:1px solid #CBE7DE;background:#F4FBF8;border-radius:10px;padding:8px 12px;margin-bottom:6px;display:flex;gap:8px;align-items:center">
						<b style="font-size:13px">${frappe.utils.escape_html(roomName(x.room))}</b>
						<span style="font-size:13px">${frappe.utils.escape_html(x.title)}</span>
						<span class="text-muted" style="font-size:11px;margin-left:auto">${frappe.utils.escape_html(x.fulfilled_by || "")} · ${x.fulfilled_on || ""}</span>
						${x.attachment_url ? `<a class="btn btn-xs btn-default" href="/api/method/duty_board.accounting.books_request_file?name=${encodeURIComponent(x.name)}" target="_blank">📎 ${__("Open")}</a>` : ""}
					</div>`
								)
								.join("")
						: ""}
				`);
				const reload = (rm) => this._bpanel_followups($p, rm !== undefined ? rm : room_filter);
				$p.find("[data-roomsel]").on("change", (e) => reload($(e.currentTarget).val() || null));
				$p.find("[data-resolve]").on("click", (e) =>
					frappe.call({ method: "duty_board.accounting.books_resolve_query", args: { name: $(e.currentTarget).data("resolve") }, callback: () => reload() })
				);
				$p.find("[data-waive]").on("click", (e) =>
					frappe.call({ method: "duty_board.accounting.books_waive_request", args: { name: $(e.currentTarget).data("waive") }, callback: () => reload() })
				);
				const memOpts = (rm, sel) => ((m.members || {})[rm] || []).map((u) => ({ label: u.full_name || u.user, value: u.user, checked: (sel || []).includes(u.user) }));
				const bindMembers = (dlg) => {
					const refresh = () => {
						const mc = dlg.fields_dict.recipients;
						if (!mc) return;
						mc.df.options = memOpts(dlg.get_value("room"));
						mc.refresh();
					};
					dlg.fields_dict.room.df.onchange = refresh;
					refresh();
				};
				$p.find("[data-addq]").on("click", () => {
					const dlg = frappe.prompt(
						[
							{ fieldname: "room", fieldtype: "Select", label: __("Client"), options: m.rooms.map((x) => ({ label: x.customer, value: x.room })), reqd: 1, default: room_filter || (m.rooms[0] && m.rooms[0].room) },
							{ fieldname: "recipients", fieldtype: "MultiCheck", label: __("Send to (none checked = everyone in the room)"), columns: 2, options: [] },
							{ fieldname: "question", fieldtype: "Small Text", label: __("Question"), reqd: 1 },
							{ fieldname: "ref_date", fieldtype: "Date", label: __("Transaction date") },
							{ fieldname: "amount", fieldtype: "Currency", label: __("Amount") },
							{ fieldname: "reference", fieldtype: "Data", label: __("Reference (narration, counterparty…)") },
						],
						(v) =>
							frappe.call({
								method: "duty_board.accounting.books_add_query",
								args: { room: v.room, question: v.question, ref_date: v.ref_date || null, amount: v.amount || null, reference: v.reference || null, recipients: (v.recipients || []).join(", ") },
								callback: () => reload(),
							}),
						__("Ask the client"),
						__("Send")
					);
					bindMembers(dlg);
				});
				$p.find("[data-addr]").on("click", () => {
					const dlg = frappe.prompt(
						[
							{ fieldname: "room", fieldtype: "Select", label: __("Client"), options: m.rooms.map((x) => ({ label: x.customer, value: x.room })), reqd: 1, default: room_filter || (m.rooms[0] && m.rooms[0].room) },
							{ fieldname: "recipients", fieldtype: "MultiCheck", label: __("Send to (none checked = everyone in the room)"), columns: 2, options: [] },
							{ fieldname: "title", fieldtype: "Data", label: __("Document"), reqd: 1 },
							{ fieldname: "detail", fieldtype: "Small Text", label: __("Detail") },
							{ fieldname: "due_date", fieldtype: "Date", label: __("Due") },
						],
						(v) =>
							frappe.call({
								method: "duty_board.accounting.books_add_request",
								args: { room: v.room, title: v.title, detail: v.detail || null, due_date: v.due_date || null, recipients: (v.recipients || []).join(", ") },
								callback: () => reload(),
							}),
						__("Request a document"),
						__("Send")
					);
					bindMembers(dlg);
				});
			},
		});
	}

	books_playbook_dialog(room) {
		frappe.call({
			method: "duty_board.accounting.books_playbook_get",
			args: { room: room },
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				const d = new frappe.ui.Dialog({
					title: `📖 ${frappe.utils.escape_html(m.customer)} — ${__("playbook")}`,
					size: "large",
					fields: [
						{
							fieldname: "playbook",
							fieldtype: "Text",
							label: __("Everything a covering bookkeeper must know"),
							default: m.playbook,
						},
					],
					primary_action_label: __("Save"),
					primary_action: (v) =>
						frappe.call({
							method: "duty_board.accounting.books_playbook_set",
							args: { room: room, playbook: v.playbook || "" },
							callback: () => {
								frappe.show_alert({ message: __("Playbook saved"), indicator: "green" });
								d.hide();
							},
						}),
				});
				d.$body.find("textarea").css({ "min-height": "320px", "font-family": "ui-monospace, monospace", "font-size": "13px" });
				d.show();
			},
		});
	}

	books_cell_dialog(name) {
		frappe.call({
			method: "duty_board.accounting.books_cell",
			args: { name: name },
			callback: (r) => {
				const c = r.message;
				if (!c) return;
				const d = new frappe.ui.Dialog({
					title: `${frappe.utils.escape_html(c.customer)} — ${frappe.utils.escape_html(c.type_title)} · ${c.period}`,
					size: "large",
					fields: [
						{ fieldname: "status", fieldtype: "Select", label: __("Status"), options: "Pending\nIn Progress\nIn Review\nDelivered", default: c.status === "Acknowledged" ? "Delivered" : c.status },
						{ fieldname: "assigned_to", fieldtype: "Autocomplete", label: __("Assigned to"), options: this.staff_options(), default: c.assigned_to || "" },
						{ fieldname: "reviewer", fieldtype: "Autocomplete", label: __("Reviewer (split clients)"), options: this.staff_options(), default: c.reviewer || "" },
						{ fieldname: "notes", fieldtype: "Small Text", label: __("Notes"), default: c.notes || "" },
					],
					primary_action_label: __("Save"),
					primary_action: (v) => {
						const save = () =>
							frappe.call({
								method: "duty_board.accounting.books_set",
								args: { name: name, status: v.status || null, assigned_to: v.assigned_to || null, reviewer: v.reviewer || null, notes: v.notes || null },
								callback: () => {
									d.hide();
									this.render_books_shell();
								},
							});
						if (v.status === "Delivered" && c.open_items > 0 && c.status !== "Delivered") {
							frappe.confirm(
								__("{0} checklist item(s) are still open — deliver anyway?", [c.open_items]),
								save
							);
						} else save();
					},
				});
				const done = c.items.filter((i) => i.status === "Done").length;
				const $chk = $(`
					<div style="margin-bottom:14px">
						${c.due_date ? `<div class="text-muted" style="font-size:12px;margin-bottom:8px">📅 ${__("due")} ${c.due_date}${c.status === "Acknowledged" ? ` · <b style="color:#15803d">✓✓ ${__("acknowledged by client")}</b>` : ""}</div>` : ""}
						${c.items.length
							? `<div style="display:flex;gap:8px;align-items:center;margin-bottom:6px">
									<b style="font-size:13px">${__("Close checklist")}</b>
									<span style="font-size:12px;font-weight:700;color:${done === c.items.length ? "#15803d" : "#0F5C55"}">${done}/${c.items.length}</span>
									<span style="flex:1;height:5px;background:#E7ECEA;border-radius:99px;overflow:hidden"><i style="display:block;height:100%;width:${c.items.length ? Math.round((done / c.items.length) * 100) : 0}%;background:#0F5C55"></i></span>
								</div>` +
								c.items
									.map(
										(i) => `
							<div style="display:flex;gap:9px;align-items:baseline;padding:4px 0;border-top:1px dashed #EEF2F0">
								<a class="duty-chk" data-name="${i.name}" data-done="${i.status === "Done" ? 0 : 1}" style="cursor:pointer;font-size:15px">${i.status === "Done" ? "☑" : "☐"}</a>
								<span style="font-size:13px;${i.status === "Done" ? "color:#94a3b8;text-decoration:line-through" : ""}">${frappe.utils.escape_html(i.item)}</span>
								<span class="text-muted" style="font-size:10px;margin-left:auto;white-space:nowrap">${i.status === "Done" ? frappe.utils.escape_html((i.done_by || "").split(" ")[0]) + " · " + (i.done_on || "") : ""}</span>
							</div>`
									)
									.join("")
							: `<div class="text-muted" style="font-size:12px">${__("No checklist for this deliverable type — add one on the type in the desk.")}</div>`}
					</div>`);
				$(d.body).prepend($chk);
				$chk.find(".duty-chk").on("click", (e) =>
					frappe.call({
						method: "duty_board.accounting.books_tick_check",
						args: { name: $(e.currentTarget).data("name"), done: $(e.currentTarget).data("done") },
						callback: () => {
							d.hide();
							this.books_cell_dialog(name);
						},
					})
				);
				d.show();
			},
		});
	}

	_bpanel_onboarding($p) {
		frappe.call({
			method: "duty_board.accounting.books_onboarding",
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				const card = (v) => `
					<div style="border:1px solid var(--border-color,#E7ECEA);border-radius:12px;padding:12px 14px;margin-bottom:10px;background:#fff">
						<div style="display:flex;gap:10px;align-items:center;margin-bottom:8px">
							<b style="font-size:14px">${frappe.utils.escape_html(v.customer)}</b>
							<span style="font-size:12px;font-weight:700;color:${v.done === v.total ? "#15803d" : "#0F5C55"}">${v.done}/${v.total}</span>
							<span style="flex:1;height:6px;background:#E7ECEA;border-radius:99px;overflow:hidden"><i style="display:block;height:100%;width:${v.total ? Math.round((v.done / v.total) * 100) : 0}%;background:#0F5C55"></i></span>
						</div>
						${v.steps
							.map(
								(s) => `
						<div style="display:flex;gap:9px;align-items:baseline;padding:4px 0;border-top:1px dashed #EEF2F0">
							<a class="duty-ob-tick" data-name="${s.name}" data-done="${s.status === "Done" ? 0 : 1}" style="cursor:pointer;font-size:15px">${s.status === "Done" ? "☑" : "☐"}</a>
							<span style="font-size:13px;${s.status === "Done" ? "color:#94a3b8;text-decoration:line-through" : ""}">${frappe.utils.escape_html(s.step)}</span>
							<span class="text-muted" style="font-size:10px;margin-left:auto;white-space:nowrap">${s.status === "Done" ? frappe.utils.escape_html((s.done_by || "").split(" ")[0]) + " · " + (s.done_on || "") : ""}</span>
						</div>`
							)
							.join("")}
					</div>`;
				$p.html(`
					${m.active.length ? m.active.map(card).join("") : `<div class="text-muted" style="margin-bottom:10px">${__("No clients mid-onboarding.")}</div>`}
					${m.not_started.length
						? `<div style="font-size:12px;font-weight:800;margin:6px 0">${__("Not started")}</div>` +
							m.not_started
								.map(
									(x) => `<div style="display:flex;gap:8px;align-items:center;padding:6px 0"><span style="font-size:13px">${frappe.utils.escape_html(x.customer)}</span><button class="btn btn-xs btn-default duty-ob-start" data-room="${x.room}" style="margin-left:auto">🚀 ${__("Start onboarding")}</button></div>`
								)
								.join("")
						: ""}
					${m.complete.length
						? `<details style="margin-top:10px"><summary class="text-muted" style="font-size:12px;cursor:pointer">✅ ${__("Completed")} (${m.complete.length})</summary>${m.complete.map(card).join("")}</details>`
						: ""}
				`);
				$p.find(".duty-ob-tick").on("click", (e) =>
					frappe.call({
						method: "duty_board.accounting.books_tick_onboarding",
						args: { name: $(e.currentTarget).data("name"), done: $(e.currentTarget).data("done") },
						callback: () => this._bpanel_onboarding($p),
					})
				);
				$p.find(".duty-ob-start").on("click", (e) =>
					frappe.call({
						method: "duty_board.accounting.books_start_onboarding",
						args: { room: $(e.currentTarget).data("room") },
						callback: () => this._bpanel_onboarding($p),
					})
				);
			},
		});
	}

	_bpanel_kpi($p) {
		frappe.call({
			method: "duty_board.accounting.books_kpi",
			args: { period: this.books_period },
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				const pct = (v) => (v === null ? "—" : `<span style="font-weight:700;color:${v >= 90 ? "#15803d" : v >= 70 ? "#b45309" : "#b91c1c"}">${v}%</span>`);
				const num = (v, unit) => (v === null ? "—" : `${v}${unit || ""}`);
				$p.html(`
					<div style="font-size:12px;font-weight:800;margin-bottom:6px">📈 ${__("Trend — last 6 periods")}</div>
					<div style="overflow-x:auto"><table class="table table-bordered" style="font-size:var(--text-sm);margin:0;background:#fff">
						<thead><tr><th></th>${m.trend.map((t) => `<th style="text-align:center">${t.period.slice(2)}</th>`).join("")}</tr></thead>
						<tbody>
							<tr><td>${__("Deliverables done")}</td>${m.trend.map((t) => `<td style="text-align:center">${t.done}/${t.total}</td>`).join("")}</tr>
							<tr><td>${__("On-time rate")}</td>${m.trend.map((t) => `<td style="text-align:center">${pct(t.on_time_pct)}</td>`).join("")}</tr>
							<tr><td>${__("FS close cycle (days after month end)")}</td>${m.trend.map((t) => `<td style="text-align:center">${num(t.fs_cycle, "d")}</td>`).join("")}</tr>
							<tr><td>${__("Avg posting lag (wd, attested)")}</td>${m.trend.map((t) => `<td style="text-align:center">${num(t.avg_lag, "")}</td>`).join("")}</tr>
						</tbody>
					</table></div>
					<div style="font-size:12px;font-weight:800;margin:14px 0 6px">🤝 ${__("Per client — 6-period window")}</div>
					<div style="overflow-x:auto"><table class="table table-bordered" style="font-size:var(--text-sm);margin:0;background:#fff">
						<thead><tr><th>${__("Client")}</th><th style="text-align:center">${__("Done")}</th><th style="text-align:center">${__("On-time")}</th><th style="text-align:center">${__("FS cycle")}</th><th style="text-align:center">${__("Posting lag")}</th><th style="text-align:center">${__("Client ack (days)")}</th></tr></thead>
						<tbody>${m.by_client
							.map(
								(c) => `<tr>
							<td><b>${frappe.utils.escape_html(c.customer)}</b></td>
							<td style="text-align:center">${c.done}/${c.total}</td>
							<td style="text-align:center">${pct(c.on_time_pct)}</td>
							<td style="text-align:center">${num(c.fs_cycle, "d")}</td>
							<td style="text-align:center">${num(c.avg_lag, "wd")}</td>
							<td style="text-align:center">${num(c.ack_days, "d")}</td>
						</tr>`
							)
							.join("")}</tbody>
					</table></div>
					<div style="font-size:12px;font-weight:800;margin:14px 0 6px">👥 ${__("Per bookkeeper — 6-period window")}</div>
					<table class="table table-bordered" style="font-size:var(--text-sm);margin:0;background:#fff">
						<thead><tr><th>${__("Bookkeeper")}</th><th style="text-align:center">${__("Delivered")}</th><th style="text-align:center">${__("On-time")}</th><th style="text-align:center">${__("Open this period")}</th></tr></thead>
						<tbody>${m.staff
							.map(
								(s) => `<tr>
							<td><b>${frappe.utils.escape_html(s.first)}</b> <span class="text-muted" style="font-size:11px">${frappe.utils.escape_html(s.user)}</span></td>
							<td style="text-align:center">${s.done}/${s.total}</td>
							<td style="text-align:center">${pct(s.on_time_pct)}</td>
							<td style="text-align:center">${s.open_now || ""}</td>
						</tr>`
							)
							.join("") || `<tr><td colspan="4" class="text-muted">${__("No assigned deliverables in the window.")}</td></tr>`}</tbody>
					</table>
					<div style="font-size:12px;font-weight:800;margin:14px 0 6px">🚩 ${__("Fee review — below ₦{0}/hr for 3 consecutive months", [Number(m.floor).toLocaleString()])}</div>
					${m.fee_review.length
						? m.fee_review
								.map(
									(f) => `
					<div style="border:1px solid #F4C7C0;background:#FDECEA;border-radius:10px;padding:9px 12px;margin-bottom:6px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
						<b>${frappe.utils.escape_html(f.customer)}</b>
						<span style="font-size:12px">₦${Number(f.fee).toLocaleString()}/mo</span>
						<span style="font-size:12px;margin-left:auto">${m.last3.map((p, i) => `${p.slice(5)}: <b style="color:#b91c1c">₦${Number(f.rates[i]).toLocaleString()}/hr</b>`).join(" · ")}</span>
					</div>`
								)
								.join("")
						: `<div class="text-muted" style="font-size:12px">${__("No clients flagged — every engagement is above the floor (or lacks 3 months of tagged hours).")}</div>`}
					<div style="font-size:12px;font-weight:800;margin:14px 0 6px">👜 ${__("Capacity — who takes the next client?")}</div>
					<table class="table table-bordered" style="font-size:var(--text-sm);margin:0;background:#fff">
						<thead><tr><th>${__("Bookkeeper")}</th><th style="text-align:center">${__("Clients owned")}</th><th style="text-align:center">${__("Open this period")}</th><th style="text-align:center">${__("Avg hrs/mo (3mo)")}</th></tr></thead>
						<tbody>${(m.capacity || [])
							.map(
								(c, i) => `<tr ${i === 0 ? 'style="background:#F4FBF8"' : ""}>
							<td><b>${frappe.utils.escape_html(c.first)}</b>${i === 0 ? ` <span style="font-size:11px;font-weight:700;color:#15803d">← ${__("lightest load")}</span>` : ""}</td>
							<td style="text-align:center">${c.clients}</td>
							<td style="text-align:center">${c.open_now || ""}</td>
							<td style="text-align:center">${c.hours3 || "—"}</td>
						</tr>`
							)
							.join("") || `<tr><td colspan="4" class="text-muted">${__("No bookkeepers assigned yet.")}</td></tr>`}</tbody>
					</table>
					<div class="text-muted" style="font-size:11px;margin-top:8px">${__("Floor is configurable in Duty Settings. Lag and rates depend on attestations and customer-tagged sessions — the disciplines feed the numbers.")}</div>
				`);
			},
		});
	}

	_bpanel_billing($p) {
		frappe.call({
			method: "duty_board.accounting.books_billing",
			args: { period: this.books_period },
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				const badge = (row) => {
					if (!row.invoice) return `<span style="color:${row.fee ? "#b45309" : "#94a3b8"};font-weight:700">${frappe.utils.escape_html(row.status)}</span>`;
					const col = row.docstatus === 0 ? "#7c3aed" : row.outstanding > 0 ? "#b91c1c" : "#15803d";
					const label = row.docstatus === 0 ? __("Draft — review & submit") : row.outstanding > 0 ? __("Unpaid") : __("Paid");
					return `<a href="/app/sales-invoice/${encodeURIComponent(row.invoice)}" style="color:${col};font-weight:700">${label} · ${frappe.utils.escape_html(row.invoice)}</a>`;
				};
				$p.html(`
					<div style="display:flex;gap:8px;justify-content:flex-end;margin-bottom:8px">
						<button class="btn btn-xs btn-primary" data-gen>🧾 ${__("Generate {0} invoices now", [m.period])}</button>
					</div>
					<table class="table table-bordered" style="font-size:var(--text-sm);margin:0;background:#fff">
						<thead><tr><th>${__("Client")}</th><th style="text-align:right">${__("Fee/mo")}</th><th>${__("This period")} (${m.period})</th></tr></thead>
						<tbody>${m.rows
							.map(
								(row) => `<tr>
							<td><b>${frappe.utils.escape_html(row.customer)}</b></td>
							<td style="text-align:right">${row.fee ? "₦" + Number(row.fee).toLocaleString() : `<span style="color:#b91c1c;font-weight:700">${__("no fee set")}</span>`}</td>
							<td>${badge(row)}</td>
						</tr>`
							)
							.join("")}</tbody>
					</table>
					<div style="font-size:12px;font-weight:800;margin:14px 0 6px">💰 ${__("Awaiting payment")} (${m.unpaid.length}) — ₦${Number(m.unpaid_total).toLocaleString()}</div>
					${m.unpaid.length
						? `<table class="table table-bordered" style="font-size:var(--text-sm);margin:0;background:#fff">
							<thead><tr><th>${__("Client")}</th><th>${__("Invoice")}</th><th style="text-align:right">${__("Outstanding")}</th><th>${__("Due")}</th></tr></thead>
							<tbody>${m.unpaid
								.map(
									(u) => `<tr ${u.days_overdue ? 'style="background:#FDECEA"' : ""}>
								<td><b>${frappe.utils.escape_html(u.customer)}</b></td>
								<td><a href="/app/sales-invoice/${encodeURIComponent(u.name)}">${frappe.utils.escape_html(u.name)}</a></td>
								<td style="text-align:right;font-weight:700">₦${Number(u.outstanding_amount).toLocaleString()}</td>
								<td style="font-size:12px;${u.days_overdue ? "color:#b91c1c;font-weight:700" : ""}">${u.due_date || "—"}${u.days_overdue ? ` · ${u.days_overdue}${__("d overdue")}` : ""}</td>
							</tr>`
								)
								.join("")}</tbody>
						</table>`
						: `<div class="text-muted">${__("Nothing outstanding — everyone has paid.")}</div>`}
					<div class="text-muted" style="font-size:11px;margin-top:8px">${__("Invoices auto-generate on the 28th as drafts; submit them in the desk. Payment status reads the ERP's outstanding amounts.")}</div>
				`);
				$p.find("[data-gen]").on("click", () =>
					frappe.call({
						method: "duty_board.accounting.books_generate_invoices",
						args: { period: this.books_period },
						callback: (rr) => {
							const o = rr.message;
							frappe.show_alert({ message: __("{0} created, {1} already existed{2}", [o.created, o.existing, o.no_fee.length ? ", no fee: " + o.no_fee.join(", ") : ""]), indicator: o.no_fee.length ? "orange" : "green" });
							this.render_books_shell();
						},
					})
				);
			},
		});
	}

	_bpanel_profit($p) {
		frappe.call({
			method: "duty_board.accounting.books_profitability",
			args: { period: this.books_period },
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				const totF = m.rows.reduce((a, x) => a + (x.fee || 0), 0);
				const totH = m.rows.reduce((a, x) => a + (x.hours || 0), 0);
				$p.html(`
					${m.rows.length
						? `<table class="table table-bordered" style="font-size:var(--text-sm);margin:0">
							<thead><tr><th>${__("Client")}</th><th style="text-align:right">${__("Fee/mo")}</th><th style="text-align:right">${__("Hours")}</th><th style="text-align:right">₦/${__("hr")}</th><th>${__("Who worked it")}</th></tr></thead>
							<tbody>
								${m.rows
									.map(
										(x) => `<tr>
									<td><b>${frappe.utils.escape_html(x.customer)}</b></td>
									<td style="text-align:right">₦${Number(x.fee || 0).toLocaleString()}</td>
									<td style="text-align:right">${x.hours}</td>
									<td style="text-align:right;font-weight:800;${x.rate !== null && x.fee && x.rate < (m.floor || 5000) ? "color:#b91c1c" : "color:#0F5C55"}">${x.rate !== null ? "₦" + Number(x.rate).toLocaleString() : "—"}</td>
									<td class="text-muted" style="font-size:11px">${x.team.map((t) => `${frappe.utils.escape_html(t.first)} ${t.hours}h`).join(" · ") || "—"}</td>
								</tr>`
									)
									.join("")}
								<tr style="background:var(--bg-light-gray,#F4F7F6)"><td><b>${__("Total")}</b></td><td style="text-align:right"><b>₦${Number(totF).toLocaleString()}</b></td><td style="text-align:right"><b>${Math.round(totH * 10) / 10}</b></td><td style="text-align:right"><b>${totH ? "₦" + Number(Math.round(totF / totH)).toLocaleString() : "—"}</b></td><td></td></tr>
							</tbody>
						</table>
						<div class="text-muted" style="font-size:11px;margin-top:8px">${__("Sorted worst rate first. Hours from Work Sessions tagged to the customer; sessions without a customer are invisible here — tagging discipline is the price of this number.")}</div>`
						: `<div class="text-muted">${__("No accounting clients for this period.")}</div>`}
				`);
			},
		});
	}

	proctored_runner(t) {
		const esc = frappe.utils.escape_html;
		const d = new frappe.ui.Dialog({ title: `⏱ ${__("Timed assessment")} — ${t.size} ${__("questions")}`, size: "large", static: true });
		let blurs = 0, timer = null, deadline = 0;
		const onBlur = () => { blurs += 1; };
		$(window).on("blur.duty_exam", onBlur);
		const cleanup = () => { clearInterval(timer); $(window).off("blur.duty_exam"); };
		d.$wrapper.on("hidden.bs.modal", cleanup);
		const finish = (R) => {
			cleanup();
			$(d.body).html(`
				<div style="text-align:center;padding:14px 6px">
					<div style="font-size:40px">${R.passed ? "🎉" : "😞"}</div>
					<h4>${R.passed ? __("Passed") : __("Not this time")} — ${R.score}% <span class="text-muted" style="font-size:13px">(${__("pass mark")} ${R.pass_mark}%)</span></h4>
					${R.timeouts ? `<p style="color:#B45309;font-weight:700">⏱ ${R.timeouts} ${__("question(s) timed out")}</p>` : ""}
					${(R.wrong || []).length ? `<div style="text-align:left;margin-top:10px"><b>${__("Review these topics")}:</b><ul>${R.wrong.map((w) => `<li>${esc(w)}</li>`).join("")}</ul></div>` : ""}
					${R.newly_certified ? `<p style="color:#0E8A63;font-weight:700">🎓 ${__("Certified!")}</p>` : ""}
				</div>`);
			d.set_primary_action(__("Close"), () => d.hide());
		};
		const show = (Q) => {
			if (Q.done) return finish(Q);
			deadline = Date.now() + Q.seconds * 1000;
			$(d.body).html(`
				<div class="duty-ex-top"><b>${__("Question")} ${Q.idx + 1} / ${Q.size}</b><span class="duty-ex-clock">${Q.seconds}s</span></div>
				<div class="duty-ex-bar"><span style="width:100%"></span></div>
				<div class="duty-ex-q">${esc(Q.question)}</div>
				${Q.options.map((o, j) => `<label class="duty-ex-opt"><input type="radio" name="duty-ex" value="${j}"><span>${esc(o)}</span></label>`).join("")}
				<p class="text-muted" style="font-size:11.5px;margin-top:8px">${__("One question at a time. No going back. Unanswered when the clock hits zero counts as wrong.")}</p>
			`);
			clearInterval(timer);
			timer = setInterval(() => {
				const left = Math.max(0, deadline - Date.now());
				const pct = (left / (Q.seconds * 1000)) * 100;
				$(d.body).find(".duty-ex-clock").text(`${Math.ceil(left / 1000)}s`);
				$(d.body).find(".duty-ex-bar span").css("width", pct + "%").toggleClass("low", pct < 25);
				if (left <= 0) submit(null);
			}, 250);
			d.set_primary_action(__("Submit answer"), () => {
				const v = $(d.body).find("input[name=duty-ex]:checked").val();
				submit(v === undefined ? null : v);
			});
		};
		const submit = (choice) => {
			clearInterval(timer);
			const b = blurs; blurs = 0;
			frappe.call({
				method: "duty_board.client_room.proctored_answer",
				args: { attempt: t.attempt, choice: choice, blurs: b },
				callback: (r) => r.message && show(r.message),
			});
		};
		// rules screen first — the announcement is part of the deterrent
		$(d.body).html(`
			<div style="padding:6px 2px">
				<h4>⏱ ${__("This is a timed assessment")}</h4>
				<ul style="font-size:13.5px;line-height:1.7">
					<li>${__("Questions appear one at a time — {0} seconds each.", [t.seconds])}</li>
					<li>${__("Once you answer (or time runs out) you move on. There is no going back.")}</li>
					<li>${__("Your time per question and any switching away from this tab are recorded.")}</li>
				</ul>
			</div>`);
		d.set_primary_action(`▶ ${__("Start")}`, () => {
			frappe.call({
				method: "duty_board.client_room.proctored_next",
				args: { attempt: t.attempt },
				callback: (r) => r.message && show(r.message),
			});
		});
		d.show();
	}

	my_quiz_dialog(record) {
		frappe.call({
			method: "duty_board.client_room.my_quiz_start",
			args: { record: record },
			callback: (r) => {
				const t = r.message;
				if (!t) return;
				if (t.timed) return this.proctored_runner(t);
				const d = new frappe.ui.Dialog({ title: `📝 ${__("Assessment")} — 10 ${__("questions")}`, size: "large" });
				$(d.body).html(
					t.questions
						.map(
							(q, i) => `
					<div style="margin-bottom:16px" data-q="${q.name}">
						<div style="font-weight:700;margin-bottom:6px">${i + 1}. ${frappe.utils.escape_html(q.question)}</div>
						${q.options
							.map(
								(o, j) => `
							<label style="display:flex;gap:8px;align-items:flex-start;padding:5px 8px;border-radius:8px;cursor:pointer">
								<input type="radio" name="qz_${i}" value="${j}" style="margin-top:3px">
								<span>${frappe.utils.escape_html(o)}</span>
							</label>`
							)
							.join("")}
					</div>`
						)
						.join("") + `<div class="text-muted" style="font-size:var(--text-sm)">${__("Unanswered questions count as wrong. Unlimited retakes — your best score stands.")}</div>`
				);
				d.set_primary_action(__("Submit answers"), () => {
					const answers = {};
					$(d.body).find("[data-q]").each(function () {
						const chosen = $(this).find("input:checked").val();
						if (chosen !== undefined) answers[$(this).data("q")] = parseInt(chosen, 10);
					});
					d.get_primary_btn().prop("disabled", true);
					frappe.call({
						method: "duty_board.client_room.my_quiz_submit",
						args: { attempt: t.attempt, answers: JSON.stringify(answers) },
						callback: (rr) => {
							d.hide();
							this.my_quiz_result_dialog(rr.message, record);
						},
					});
				});
				d.show();
			},
		});
	}

	my_quiz_result_dialog(res, record) {
		if (!res) return;
		const d = new frappe.ui.Dialog({ title: res.passed ? `🏅 ${__("Passed")}` : `📝 ${__("Not this time")}` });
		$(d.body).html(`
			<div style="text-align:center;padding:8px 0 4px">
				<div style="font-size:44px;font-weight:800;color:${res.passed ? "#15803d" : "#b45309"}">${res.score}%</div>
				<div class="text-muted">${__("pass mark")} ${res.pass_mark}% · ${__("attempt")} ${res.attempts}${res.attempts > 1 ? ` · ${__("best")} ${res.best}%` : ""}</div>
				${res.newly_certified ? `<div style="margin-top:8px;font-weight:700;color:#0C4A43">🎓 ${__("Course completed — certified.")}</div>` : ""}
			</div>
			${!res.passed && (res.wrong || []).length
				? `<div style="margin-top:10px"><b>${__("Review these areas, then retake:")}</b>${res.wrong.map((w) => `<div class="text-muted" style="font-size:var(--text-sm);margin:4px 0">• ${frappe.utils.escape_html(w)}</div>`).join("")}</div>`
				: ""}
			<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:12px">
				${!res.passed ? `<button type="button" class="btn btn-sm btn-primary" data-retake>↻ ${__("Retake now")}</button>` : ""}
				<button type="button" class="btn btn-sm btn-default" data-close>${__("Close")}</button>
			</div>
		`);
		$(d.body).find("[data-retake]").on("click", () => { d.hide(); this.my_quiz_dialog(record); });
		$(d.body).find("[data-close]").on("click", () => { d.hide(); this.load_my_training(); this.my_course_dialog(record); });
		d.show();
	}

	render_my_dashboard_cal(m) {
		const [Y, M] = m.month.split("-").map(Number);
		this.$me.find(".duty-cal-title").text(frappe.datetime.month_name ? m.month : new Date(Y, M - 1, 1).toLocaleString("default", { month: "long", year: "numeric" }));
		const first = new Date(Y, M - 1, 1);
		const startPad = (first.getDay() + 6) % 7; // Monday-first
		const dim = new Date(Y, M, 0).getDate();
		const today = frappe.datetime.get_today();
		let cells = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((d) => `<div class="duty-cal-dow">${d}</div>`).join("");
		for (let i = 0; i < startPad; i++) cells += `<div class="duty-cal-cell empty"></div>`;
		for (let d = 1; d <= dim; d++) {
			const key = `${Y}-${String(M).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
			const info = (m.days || {})[key] || {};
			cells += `<div class="duty-cal-cell${key === today ? " today" : ""}" data-day="${key}">
				<span class="dnum">${d}</span>
				${info.meet ? `<span class="cbadge cmeet">📅${info.meet}</span>` : ""}
				${info.todo ? `<span class="cbadge ctodo">📋${info.todo}</span>` : ""}
				${info.due ? `<span class="cbadge cdue">${info.due}</span>` : ""}
				${info.res ? `<span class="cbadge cres">${info.res}</span>` : ""}
				${info.hrs ? `<span class="cbadge chrs">${info.hrs}h</span>` : ""}
			</div>`;
		}
		this.$me.find(".duty-cal-grid").html(cells);
		const shift = (delta) => {
			const nd = new Date(Y, M - 1 + delta, 1);
			this.refresh_me(`${nd.getFullYear()}-${String(nd.getMonth() + 1).padStart(2, "0")}`);
		};
		this.$me.find(".duty-cal-prev").off("click").on("click", () => shift(-1));
		this.$me.find(".duty-cal-next").off("click").on("click", () => shift(1));
		this._me_data = m;
		this.$me.find(".duty-cal-cell:not(.empty)").on("click", (e) => this.me_day_dialog($(e.currentTarget).data("day")));
	}

	toggle_face() {
		this.show_face(this.face === "projects" ? "board" : "projects");
	}

	toggle_sales() {
		this.show_face(this.face === "sales" ? "board" : "sales");
	}

	render_team_load() {
		this.current_project = null;
		if (this.is_mobile()) this.$projects.addClass("pj-detail");
		const $wrap = this.$projects.find(".duty-kanban-wrap").empty();
		const esc = frappe.utils.escape_html;
		$wrap.html(`<div class="text-muted duty-plan-empty">${__("Loading team load…")}</div>`);
		frappe.call({
			method: "duty_board.projects.get_team_load",
			callback: (r) => {
				const rows = r.message || [];
				if (!rows.length) { $wrap.html(`<div class="text-muted duty-plan-empty">${__("No open work.")}</div>`); return; }
				const body = rows.map((p) => `
					<tr>
						<td><b style="color:${p.user ? this.user_color(p.user) : "#8a958f"}">${esc(p.full_name)}</b>${p.on_leave ? " 🌴" : ""}</td>
						<td>${p.open}</td>
						<td>${p.overdue ? `<span class="duty-proj-over">⚠ ${p.overdue}</span>` : `<span class="text-muted">0</span>`}</td>
						<td>${p.est_hours ? `${p.est_hours}h` : `<span class="text-muted">—</span>`}</td>
						<td>${p.blocked ? `🔒 ${p.blocked}` : `<span class="text-muted">0</span>`}</td>
						<td class="duty-tl-projects">${p.projects.map((n) => `<span class="duty-tl-chip">${esc(n)}</span>`).join(" ")}</td>
						<td>${p.followups ? `📞 ${p.followups}` : `<span class="text-muted">0</span>`}</td>
					</tr>`).join("");
				$wrap.html(`
					<div class="duty-pf">
						<div class="duty-pf-head"><b>👥 ${__("Team load")}</b><span class="text-muted">${rows.length} ${__("people")} · ${__("heaviest first")}</span></div>
						<table class="duty-pf-table">
							<thead><tr><th>${__("Person")}</th><th>${__("Open")}</th><th>${__("Overdue")}</th><th>${__("Est. remaining")}</th><th>${__("Blocked")}</th><th>${__("Projects")}</th><th>📞 ${__("Follow-ups")}</th></tr></thead>
							<tbody>${body}</tbody>
						</table>
						<p class="text-muted" style="font-size:12px;margin-top:10px">${__("Est. remaining sums estimate hours on open tasks — tasks without estimates count as 0, so fill estimates for a truthful picture.")}</p>
					</div>`);
			},
		});
	}

	render_portfolio() {
		this.current_project = null;
		if (this.is_mobile()) this.$projects.addClass("pj-detail");
		const $wrap = this.$projects.find(".duty-kanban-wrap").empty();
		const esc = frappe.utils.escape_html;
		const ps = (this._projects || []).slice().sort((a, b) => (b.at_risk || 0) - (a.at_risk || 0) || (b.overdue || 0) - (a.overdue || 0) || (b.worst_slip || 0) - (a.worst_slip || 0));
		if (!ps.length) { $wrap.html(`<div class="text-muted duty-plan-empty">${__("No active projects.")}</div>`); return; }
		const atRisk = ps.filter((p) => p.at_risk).length;
		const rows = ps.map((p) => {
			const pc = this.proj_color(p.name);
			const slip = p.worst_slip != null && p.worst_slip > 0 ? `<span class="duty-pf-slip late">+${p.worst_slip}d</span>` : (p.phases_total ? `<span class="duty-pf-slip ok">on plan</span>` : `<span class="text-muted">—</span>`);
			const phase = p.phase_current ? esc(p.phase_current) : `<span class="text-muted">${__("no phases")}</span>`;
			const due = p.days_left == null ? `<span class="text-muted">—</span>` : p.days_left < 0 ? `<span class="duty-pf-slip late">${Math.abs(p.days_left)}d over</span>` : `${p.days_left}d left`;
			return `
				<tr class="duty-pf-row" data-name="${p.name}">
					<td><span class="duty-pf-dot" style="background:${pc}"></span><b>${esc(p.project_name)}</b><div class="duty-pf-cust">${esc(p.customer || "")}</div></td>
					<td>🚩 ${phase}${p.phases_total ? ` <span class="text-muted">${p.phases_done}/${p.phases_total}</span>` : ""}</td>
					<td><div class="duty-pf-bar"><span style="width:${p.pct || 0}%;background:${pc}"></span></div><span class="duty-pf-pct">${p.pct || 0}%</span></td>
					<td>${slip}</td>
					<td>${p.overdue ? `<span class="duty-proj-over">⚠ ${p.overdue}</span>` : `<span class="text-muted">0</span>`}</td>
					<td>${due}</td>
					<td>${p.at_risk ? `<span class="duty-pf-badge risk">At risk</span>` : `<span class="duty-pf-badge ok">On track</span>`}${p.open_risks ? `<div class="duty-pf-risks">⚠ ${p.open_risks} ${__("risks")}</div>` : ""}</td>
				</tr>`;
		}).join("");
		$wrap.html(`
			<div class="duty-pf">
				<div class="duty-pf-head"><b>📊 ${__("Portfolio")}</b><span class="text-muted">${ps.length} ${__("active")}${atRisk ? ` · <b class="duty-proj-over">${atRisk} ${__("at risk")}</b>` : ""}</span></div>
				<table class="duty-pf-table">
					<thead><tr><th>${__("Project")}</th><th>${__("Phase")}</th><th>${__("Progress")}</th><th>${__("Slip")}</th><th>${__("Overdue")}</th><th>${__("Target")}</th><th>${__("Status")}</th></tr></thead>
					<tbody>${rows}</tbody>
				</table>
			</div>`);
		$wrap.find(".duty-pf-row").on("click", (e) => {
			const name = $(e.currentTarget).data("name");
			this.current_project = name;
			localStorage.setItem("duty_proj", name);
			this.render_project_tabs();
			this.load_kanban(name);
		});
	}

	refresh_projects(silent) {
		frappe.call({
			method: "duty_board.projects.get_projects",
			freeze: false,
			error: (x) => this._poll_failed(x),
			callback: (r) => {
				this._fail_count = 0;
				this._projects = r.message || [];
				this.render_project_tabs();
				const remembered = localStorage.getItem("duty_proj");
				if (!this.current_project && remembered && this._projects.find((p) => p.name === remembered)) {
					this.current_project = remembered;
				}
				if (this.current_project && !this._projects.find((p) => p.name === this.current_project)) {
					this.current_project = null;
				}
				if (!this.current_project && this._projects.length) {
					this.current_project = this._projects[0].name;
				}
				if (this.current_project) this.load_kanban(this.current_project);
				else this.$projects.find(".duty-kanban-wrap").html(
					`<div class="text-muted duty-plan-empty">${__("No projects yet — create the first one.")}</div>`
				);
			},
		});
	}

	render_project_tabs() {
		const $tabs = this.$projects.find(".duty-proj-tabs").empty();
		const q = ((this._pj_filter || "") + "").toLowerCase();
		const list = (this._projects || []).filter(
			(p) => !q || (p.project_name + " " + (p.customer || "")).toLowerCase().indexOf(q) >= 0
		);
		const groups = {};
		list.forEach((p) => (groups[p.customer || __("Internal")] = groups[p.customer || __("Internal")] || []).push(p));
		this._pj_open = this._pj_open || {};
		const active = this.current_project;
		Object.keys(groups)
			.sort()
			.forEach((cust) => {
				const ps = groups[cust];
				const has_active = ps.some((p) => p.name === active);
				const open = q ? true : has_active || this._pj_open[cust];
				const over = ps.reduce((a, p) => a + (p.overdue || 0), 0);
				$(`<div class="duty-pj-cust"><span class="duty-cr-caret">${open ? "▾" : "▸"}</span> ${frappe.utils.escape_html(cust)} <span class="duty-pj-count">${ps.length}</span>${!open && over ? ` <span class="duty-proj-over">⚠ ${over}</span>` : ""}</div>`)
					.appendTo($tabs)
					.on("click", () => {
						if (open) delete this._pj_open[cust];
						else this._pj_open[cust] = 1;
						this.render_project_tabs();
					});
				if (!open) return;
				ps.forEach((p) => {
					const pc = this.proj_color(p.name);
					$(`
					<a class="duty-pj-item ${p.name === active ? "active" : ""}" data-name="${p.name}" style="border-left:3px solid ${pc}">
						<span class="t">${frappe.utils.escape_html(p.project_name)}</span>
						<span class="s">✓ ${p.done}/${p.total}${p.overdue ? ` <span class="duty-proj-over">⚠ ${p.overdue}</span>` : ""}${p.suspended ? " ⏸" : ""}</span>
						<span class="duty-proj-bar"><span style="width:${p.pct || 0}%;background:${pc}"></span></span>
					</a>`)
						.appendTo($tabs)
						.on("click", () => {
							this.current_project = p.name;
							localStorage.setItem("duty_proj", p.name);
							if (this.is_mobile()) this.$projects.addClass("pj-detail");
							this.render_project_tabs();
							this.load_kanban(p.name);
						});
				});
			});
		if (!list.length)
			$tabs.append(`<div class="text-muted" style="padding:10px;font-size:12.5px">${q ? __("No projects match.") : __("No projects yet.")}</div>`);
		const cur = (this._projects || []).find((p) => p.name === active);
		const $t = this.$projects.find(".duty-pj-title");
		if (cur) {
			const target = cur.target_date
				? ` <span class="duty-proj-target ${cur.days_left != null && cur.days_left < 0 ? "duty-lead-over" : ""}">🎯 ${frappe.datetime.str_to_user(cur.target_date)}${cur.days_left != null ? ` (${cur.days_left}d)` : ""}</span>`
				: "";
			$t.html(target ? `<span class="text-muted" style="font-size:12.5px">${target}</span>` : "");
		} else $t.empty();
	}

	render_agenda(project, data, $wrap) {
		const tasks = [];
		Object.keys(data.tasks || {}).forEach((col) =>
			(data.tasks[col] || []).forEach((t) => tasks.push(Object.assign({ column: col }, t)))
		);
		const open = tasks.filter((t) => t.column !== "Completed");
		const doneN = tasks.length - open.length;
		const today = frappe.datetime.get_today();
		const URG = { Critical: "#B0443C", High: "#A96F1A", Medium: "#0E5A4A", Low: "#6B7772" };
		const groups = {};
		const overdue = [];
		const undated = [];
		open.forEach((t) => {
			if (!t.due_date) undated.push(t);
			else if (t.due_date < today) overdue.push(t);
			else (groups[t.due_date] = groups[t.due_date] || []).push(t);
		});
		const row = (t) => `
			<div class="duty-ag-row" data-name="${t.name}" style="display:flex;gap:10px;align-items:center;background:#fff;border-radius:12px;padding:11px 12px;margin-bottom:7px;border-left:3px solid ${URG[t.urgency] || "#6B7772"};box-shadow:0 1px 2px rgba(16,24,40,.05)">
				<div style="flex:1;min-width:0">
					<div style="font-size:13.5px;font-weight:600;color:#101828;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${frappe.utils.escape_html(t.title)}</div>
					${t.assignee ? `<div style="font-size:11.5px;color:#6B7772">${frappe.utils.escape_html((this.name_map[t.assignee] || t.assignee).split(" ")[0])}</div>` : ""}
				</div>
				<span style="font-size:11px;color:#96A09B;white-space:nowrap">${t.column === "In Progress" ? "▶" : ""}</span>
			</div>`;
		const section = (label, list, color) =>
			list.length
				? `<div style="font-size:11px;font-weight:800;letter-spacing:.07em;text-transform:uppercase;color:${color || "#6B7772"};margin:14px 0 7px">${label} · ${list.length}</div>` + list.map(row).join("")
				: "";
		let daysHtml = "";
		Object.keys(groups).sort().forEach((d) => {
			const dt = frappe.datetime.str_to_obj(d);
			const label = d === today ? __("Today") : dt.toLocaleDateString("default", { weekday: "short", day: "numeric", month: "short" });
			daysHtml += section(label, groups[d], d === today ? "#0E5A4A" : null);
		});
		$wrap.append(`
			<div class="duty-agenda">
				<button class="btn btn-sm btn-primary duty-ag-add" style="width:100%;border-radius:12px;margin:4px 0 6px">＋ ${__("Add a task")}</button>
				${section(__("Overdue"), overdue, "#B0443C")}
				${daysHtml}
				${section(__("No date"), undated)}
				${doneN ? `<div class="text-muted" style="font-size:12px;margin-top:12px;text-align:center">✅ ${doneN} ${__("completed — see the board")}</div>` : ""}
				${!open.length ? `<div class="text-muted" style="padding:20px;text-align:center">${__("Nothing open — clean slate.")}</div>` : ""}
			</div>`);
		$wrap.find(".duty-ag-row").on("click", (e) =>
			frappe.call({
				method: "duty_board.projects.get_card",
				args: { name: $(e.currentTarget).data("name") },
				callback: (r) => r.message && this.task_dialog(project, r.message),
			})
		);
		$wrap.find(".duty-ag-add").on("click", () =>
			frappe.prompt(
				[
					{ fieldname: "title", fieldtype: "Data", label: __("Task"), reqd: 1 },
					{ fieldname: "due", fieldtype: "Date", label: __("Due"), default: today },
					{ fieldname: "assignee", fieldtype: "Autocomplete", label: __("Assignee"), options: this.staff_options() },
					{ fieldname: "urgency", fieldtype: "Select", label: __("Urgency"), options: ["Low", "Medium", "High", "Critical"], default: "Medium" },
				],
				(v) =>
					frappe.call({
						method: "duty_board.projects.create_task",
						args: { project: project, title: v.title, column: "To Do", assignee: v.assignee || null, due_date: v.due || null, urgency: v.urgency },
						callback: (r) => r.message && this.render_kanban(project, r.message),
					}),
				__("New task"), __("Add")
			)
		);
	}

	render_calendar(project, data, $wrap) {
		if (this.is_mobile()) return this.render_agenda(project, data, $wrap);
		const tasks = [];
		Object.keys(data.tasks || {}).forEach((col) =>
			(data.tasks[col] || []).forEach((t) => tasks.push(Object.assign({ column: col }, t)))
		);
		const base = this._cal_base ? new Date(this._cal_base) : new Date();
		base.setDate(1);
		const y = base.getFullYear();
		const mo = base.getMonth();
		const monthName = base.toLocaleString("default", { month: "long", year: "numeric" });
		const first = (base.getDay() + 6) % 7; // Monday-first
		const dim = new Date(y, mo + 1, 0).getDate();
		const byday = {};
		let undated = 0;
		tasks.forEach((t) => {
			if (!t.due_date) { undated++; return; }
			(byday[t.due_date] = byday[t.due_date] || []).push(t);
		});
		const URG = { Critical: "#B0443C", High: "#A96F1A", Medium: "#0E5A4A", Low: "#6B7772" };
		const today = frappe.datetime.get_today();
		let cells = "";
		for (let i = 0; i < first; i++) cells += `<div class="duty-cal-cell duty-cal-pad"></div>`;
		for (let d = 1; d <= dim; d++) {
			const iso = `${y}-${String(mo + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
			const items = (byday[iso] || [])
				.map(
					(t) => `<div class="duty-cal-task ${t.column === "Completed" ? "done" : ""}" draggable="true" data-name="${t.name}" style="border-left:3px solid ${URG[t.urgency] || "#6B7772"}" title="${frappe.utils.escape_html(t.title)}${t.assignee ? " · " + frappe.utils.escape_html((this.name_map[t.assignee] || t.assignee).split(" ")[0]) : ""}">${frappe.utils.escape_html(t.title)}</div>`
				)
				.join("");
			cells += `<div class="duty-cal-cell ${iso === today ? "today" : ""}" data-day="${iso}"><span class="d"><a class="duty-cal-add" title="${__("Add a task on this day")}">＋</a>${d}</span>${items}</div>`;
		}
		$wrap.append(`
			<div class="duty-cal-head">
				<a class="duty-cal-nav" data-n="-1">‹</a>
				<b>${monthName}</b>
				<a class="duty-cal-nav" data-n="1">›</a>
				<a class="duty-cal-today">${__("Today")}</a>
				${undated ? `<span class="text-muted" style="margin-left:auto;font-size:12px">${undated} ${__("task(s) without a date — visible on the board")}</span>` : ""}
			</div>
			<div class="duty-cal-grid">
				${["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((w) => `<div class="duty-cal-dow">${__(w)}</div>`).join("")}
				${cells}
			</div>`);
		$wrap.find(".duty-cal-nav").on("click", (e) => {
			const b = new Date(y, mo + parseInt($(e.currentTarget).data("n"), 10), 1);
			this._cal_base = b.toISOString();
			this.render_kanban(project, data);
		});
		$wrap.find(".duty-cal-today").on("click", () => {
			this._cal_base = null;
			this.render_kanban(project, data);
		});
		$wrap.find(".duty-cal-task").each((_, el) => {
			el.addEventListener("dragstart", (e) => e.dataTransfer.setData("text", $(el).data("name")));
			$(el).on("click", () =>
				frappe.call({
					method: "duty_board.projects.get_card",
					args: { name: $(el).data("name") },
					callback: (r) => r.message && this.task_dialog(project, r.message),
				})
			);
		});
		$wrap.find(".duty-cal-cell:not(.duty-cal-pad)").each((_, el) => {
			$(el).on("click", (e) => {
				if ($(e.target).closest(".duty-cal-task").length) return;
				const day = $(el).data("day");
				frappe.prompt(
					[
						{ fieldname: "title", fieldtype: "Data", label: __("Task"), reqd: 1 },
						{ fieldname: "assignee", fieldtype: "Autocomplete", label: __("Assignee"), options: this.staff_options() },
						{ fieldname: "urgency", fieldtype: "Select", label: __("Urgency"), options: ["Low", "Medium", "High", "Critical"], default: "Medium" },
					],
					(v) =>
						frappe.call({
							method: "duty_board.projects.create_task",
							args: { project: project, title: v.title, column: "To Do", assignee: v.assignee || null, due_date: day, urgency: v.urgency },
							callback: (r) => r.message && this.render_kanban(project, r.message),
						}),
					__("New task · {0}", [frappe.datetime.str_to_user(day)]),
					__("Add")
				);
			});
			el.addEventListener("dragover", (e) => { e.preventDefault(); el.classList.add("over"); });
			el.addEventListener("dragleave", () => el.classList.remove("over"));
			el.addEventListener("drop", (e) => {
				e.preventDefault();
				el.classList.remove("over");
				const name = e.dataTransfer.getData("text");
				if (!name) return;
				frappe.call({
					method: "duty_board.projects.reschedule_task",
					args: { name: name, due_date: $(el).data("day") },
					callback: (r) => r.message && this.render_kanban(project, r.message),
				});
			});
		});
	}

	load_kanban(project) {
		frappe.call({
			method: "duty_board.projects.get_project_board",
			args: { project: project },
			callback: (r) => r.message && this.render_kanban(project, r.message),
		});
	}

	render_risks(project, $wrap) {
		const esc = frappe.utils.escape_html;
		$wrap.html(`<div class="text-muted duty-plan-empty">${__("Loading risks…")}</div>`);
		const SEVC = (s) => s >= 6 ? "#C2410C" : s >= 3 ? "#B45309" : "#65736F";
		const reload = () => frappe.call({ method: "duty_board.projects.project_risks", args: { project: project }, callback: (r) => draw(r.message || []) });
		const draw = (rows) => {
			const open = rows.filter((x) => x.status !== "Closed").length;
			const body = rows.map((x) => `
				<tr class="${x.status === "Closed" ? "duty-risk-closed" : ""}" data-name="${x.name}">
					<td><b style="color:${SEVC(x.severity)}">${x.severity}</b></td>
					<td><b>${esc(x.title)}</b>${x.mitigation ? `<div class="duty-risk-mit">${esc(x.mitigation)}</div>` : ""}</td>
					<td>${esc(x.likelihood)}</td>
					<td>${esc(x.impact)}</td>
					<td>${x.owner_name ? esc(x.owner_name) : `<span class="text-muted">—</span>`}</td>
					<td>${esc(x.status)}</td>
					<td class="duty-risk-acts"><a data-a="edit">✎</a> ${x.status !== "Closed" ? `<a data-a="close">✅</a>` : ""} <a data-a="del">🗑</a></td>
				</tr>`).join("");
			$wrap.html(`
				<div class="duty-pf">
					<div class="duty-pf-head"><b>⚠ ${__("Risk register")}</b><span class="text-muted">${open} ${__("open")}</span><button class="btn btn-xs btn-primary duty-risk-add" style="margin-left:auto">＋ ${__("Log a risk")}</button></div>
					${rows.length ? `<table class="duty-pf-table"><thead><tr><th>${__("Sev")}</th><th>${__("Risk & mitigation")}</th><th>${__("Likelihood")}</th><th>${__("Impact")}</th><th>${__("Owner")}</th><th>${__("Status")}</th><th></th></tr></thead><tbody>${body}</tbody></table>` : `<div class="text-muted duty-plan-empty">${__("No risks logged. A major project with an empty register usually means nobody looked.")}</div>`}
				</div>`);
			const dlg = (x) => frappe.prompt(
				[
					{ fieldname: "title", fieldtype: "Data", label: __("Risk"), reqd: 1, default: x ? x.title : "" },
					{ fieldname: "likelihood", fieldtype: "Select", label: __("Likelihood"), options: ["Low", "Medium", "High"], default: x ? x.likelihood : "Medium" },
					{ fieldname: "impact", fieldtype: "Select", label: __("Impact"), options: ["Low", "Medium", "High"], default: x ? x.impact : "Medium" },
					{ fieldname: "mitigation", fieldtype: "Small Text", label: __("Mitigation"), default: x ? x.mitigation || "" : "" },
					{ fieldname: "owner_user", fieldtype: "Link", options: "User", label: __("Owner"), default: x ? x.owner_user || "" : "" },
					{ fieldname: "status", fieldtype: "Select", label: __("Status"), options: ["Open", "Mitigating", "Closed"], default: x ? x.status : "Open" },
				],
				(v) => frappe.call({
					method: "duty_board.projects.risk_save",
					args: { project: project, name: x ? x.name : null, ...v },
					callback: (r) => draw(r.message || []),
				}),
				x ? __("Edit risk") : __("Log a risk"), __("Save")
			);
			$wrap.find(".duty-risk-add").on("click", () => dlg(null));
			$wrap.find(".duty-risk-acts a").on("click", (e) => {
				const a = $(e.currentTarget).data("a");
				const nm = $(e.currentTarget).closest("tr").data("name");
				const x = rows.find((z) => z.name === nm);
				if (a === "edit") return dlg(x);
				if (a === "close") return frappe.call({ method: "duty_board.projects.risk_save", args: { project: project, name: nm, title: x.title, likelihood: x.likelihood, impact: x.impact, mitigation: x.mitigation, owner_user: x.owner_user, status: "Closed" }, callback: (r) => draw(r.message || []) });
				if (a === "del") return frappe.confirm(__("Delete this risk entry?"), () => frappe.call({ method: "duty_board.projects.risk_delete", args: { name: nm }, callback: (r) => draw(r.message || []) }));
			});
		};
		reload();
	}

	render_phases(project, data, $wrap) {
		const ms = data.milestones || [];
		const esc = frappe.utils.escape_html;
		const $p = $(`<div class="duty-phases"></div>`).appendTo($wrap);

		if (!ms.length) {
			$p.html(`
				<div class="duty-phases-empty">
					<p class="text-muted">${__("No phases yet. Seed the Xlevel delivery method, or add phases one at a time below.")}</p>
					<div class="duty-phase-seed">
						<select class="form-control duty-seed-plan" style="max-width:320px;display:inline-block">
							${(data.plan_types || [{ key: "standard", label: "Standard plan" }])
								.map((p) => `<option value="${esc(p.key)}">${esc(p.label)}</option>`)
								.join("")}
							<option value="">${__("Phases only (no tasks)")}</option>
						</select>
						<button class="btn btn-primary btn-sm duty-seed-go">🚩 ${__("Seed the Xlevel method")}</button>
					</div>
				</div>`);
			$p.find(".duty-seed-go").on("click", () => {
				const plan = $p.find(".duty-seed-plan").val();
				frappe.call({
					method: "duty_board.client_room.project_seed_milestones",
					args: { project: project, plan_type: plan || null },
					freeze: true,
					callback: () => { frappe.show_alert({ message: __("Phases seeded."), indicator: "green" }); this.load_kanban(project); },
				});
			});
		} else {
			const curIdx = ms.findIndex((m) => m.status !== "Approved");
			const rows = ms.map((m, i) => {
				const st = m.status === "Approved" ? "done" : i === curIdx ? "active" : "up";
				const locked = m.status === "Approved";
				return `
				<div class="duty-phase-row duty-phase-${st}" data-id="${esc(m.name)}">
					<span class="duty-phase-ix">${st === "done" ? "✓" : i + 1}</span>
					<div class="duty-phase-main">
						<div class="duty-phase-title">${esc(m.title)}${m.status === "Awaiting Approval" ? ` <span class="duty-phase-wait">⏳ ${__("awaiting client")}</span>` : ""}</div>
						<div class="duty-phase-meta">${esc(m.status)}${m.target_date ? ` · 🎯 ${esc(m.target_date)}` : ""} · ${m.cards_done || 0}/${m.cards_total || 0} ${__("tasks")}${m.est_hours ? ` · ⏱ <span class="${m.act_hours > m.est_hours ? "duty-est-over" : ""}">${m.act_hours || 0}h/${m.est_hours}h</span>` : m.act_hours ? ` · ⏱ ${m.act_hours}h` : ""}${m.baselined && m.slip_days !== null && m.slip_days !== undefined ? ` · <span class="duty-phase-slip ${m.slip_days > 0 ? "late" : m.slip_days < 0 ? "early" : "onplan"}">${m.slip_days > 0 ? `⚠ +${m.slip_days}d vs plan` : m.slip_days < 0 ? `${m.slip_days}d vs plan` : "✓ on plan"}</span>` : ""}</div>
					</div>
					<div class="duty-phase-acts">
						<a data-a="up" title="${__("Move up")}">▲</a>
						<a data-a="down" title="${__("Move down")}">▼</a>
						<a data-a="tasks" title="${__("Add or remove tasks")}">📋</a>
						${!locked ? `<a data-a="edit" title="${__("Edit phase")}">✎</a>` : ""}
						${st === "active" && m.status !== "In Progress" ? `<a data-a="start" title="${__("Mark in progress")}">▶</a>` : ""}
						${!locked && m.status !== "Awaiting Approval" ? `<a data-a="ask" title="${__("Request client sign-off")}">✅</a>` : ""}
						${!locked ? `<a data-a="del" title="${__("Delete phase")}">🗑</a>` : ""}
					</div>
					${(m.tasks || []).length ? `<div class="duty-phase-tasks">${m.tasks.map((tk) => `<div class="duty-phase-task"><span class="duty-pt-dot ${tk.status === "Done" ? "done" : ""}"></span><span class="duty-pt-title">${esc(tk.title)}</span><span class="duty-pt-st">${esc(tk.status || "")}</span>${tk.assignee ? `<span class="duty-pt-who">${esc(tk.assignee)}</span>` : ""}</div>`).join("")}</div>` : `<div class="duty-phase-tasks empty">${__("No tasks in this phase yet — 📋 to add.")}</div>`}
				</div>`;
			}).join("");
			const anyBaselined = ms.some((m) => m.baselined);
			const maxSlip = ms.reduce((mx, m) => (m.slip_days != null && m.slip_days > mx ? m.slip_days : mx), 0);
			const baselineBar = anyBaselined
				? `<div class="duty-baseline-bar on"><span>📏 ${__("Baselined")}${maxSlip > 0 ? ` · <b class="duty-phase-slip late">worst slip +${maxSlip}d</b>` : ` · <b class="duty-phase-slip onplan">on plan</b>`}</span><a class="duty-baseline-set muted">${__("Re-baseline")}</a></div>`
				: `<div class="duty-baseline-bar"><span class="muted">📏 ${__("Not baselined — freeze the agreed plan to track slip against it.")}</span><button class="btn btn-xs btn-primary duty-baseline-set">${__("Set baseline")}</button></div>`;
			$p.html(`
				${baselineBar}
				<div class="duty-phase-list">${rows}</div>
				<div class="duty-phase-add">
					<input type="text" class="form-control input-sm duty-newphase" placeholder="${__("Add a phase title and press Enter…")}" style="max-width:340px;display:inline-block">
				</div>`);
			$p.find(".duty-baseline-set").on("click", () => {
				const go = () => frappe.call({
					method: "duty_board.client_room.project_set_baseline",
					args: { project: project },
					freeze: true,
					callback: (r) => { frappe.show_alert({ message: __("Baseline set — {0} phases frozen.", [(r.message || {}).phases_baselined || 0]), indicator: "green" }); this.load_kanban(project); },
				});
				if (anyBaselined) frappe.confirm(__("Re-baseline this project? The frozen plan is replaced by the current dates — do this only for a deliberate, agreed re-plan."), go);
				else go();
			});
			$p.find(".duty-phase-acts a").on("click", (e) => {
				const a = $(e.currentTarget).data("a");
				const id = $(e.currentTarget).closest(".duty-phase-row").data("id");
				const done = () => this.load_kanban(project);
				if (a === "up" || a === "down") return frappe.call({ method: "duty_board.client_room.milestone_move", args: { id: id, direction: a }, callback: done });
				if (a === "start") return frappe.call({ method: "duty_board.client_room.milestone_set_status", args: { id: id, status: "In Progress" }, callback: done });
				if (a === "ask") return frappe.confirm(__("Tell the client this phase is complete and request their formal sign-off?"), () => frappe.call({ method: "duty_board.client_room.milestone_request_approval", args: { id: id }, callback: done }));
				if (a === "del") return frappe.confirm(__("Delete this phase? Its tasks are kept but unlinked."), () => frappe.call({ method: "duty_board.client_room.milestone_delete", args: { id: id }, callback: done }));
				if (a === "tasks") {
					const m = (ms || []).find((z) => z.name === id) || {};
					frappe.call({ method: "duty_board.client_room.project_milestone_task_options", args: { id: id }, callback: (r) => {
						const opts = r.message || [];
						const pd = new frappe.ui.Dialog({ title: `📋 ${frappe.utils.escape_html(m.title || "")} — ${__("tasks in this phase")}` });
						$(pd.body).html(opts.length
							? opts.map((o) => `<label style="display:flex;gap:8px;align-items:baseline;padding:5px 2px;border-bottom:1px dashed var(--border-color);font-size:var(--text-sm)"><input type="checkbox" value="${o.name}" ${o.checked ? "checked" : ""}><b>${frappe.utils.escape_html(o.title)}</b><span class="text-muted">${frappe.utils.escape_html(o.column)}</span>${o.elsewhere ? `<span class="duty-lead-chip">${__("in another phase")}</span>` : ""}</label>`).join("")
								+ `<p class="text-muted duty-attach-hint">${__("Ticked tasks belong to this phase; on the client's plan their title and status become visible under it.")}</p><button type="button" class="btn btn-sm btn-primary duty-pt-save">${__("Save")}</button>`
							: `<div class="text-muted">${__("This project has no tasks yet. Add tasks on the Board, then attach them here.")}</div>`);
						$(pd.body).find(".duty-pt-save").on("click", () => {
							const picked = $(pd.body).find("input:checked").map((i, el) => el.value).get();
							frappe.call({ method: "duty_board.client_room.milestone_set_tasks", args: { id: id, tasks: JSON.stringify(picked) }, callback: () => { pd.hide(); frappe.show_alert({ message: __("Phase tasks updated."), indicator: "green" }); done(); } });
						});
						pd.show();
					}});
					return;
				}
				if (a === "edit") {
					const m = (ms || []).find((z) => z.name === id) || {};
					frappe.prompt(
						[
							{ fieldname: "title", fieldtype: "Data", label: __("Phase title"), default: m.title || "", reqd: 1 },
							{ fieldname: "target_date", fieldtype: "Date", label: __("Target date"), default: m.target_date || null },
							{ fieldname: "description", fieldtype: "Small Text", label: __("Description"), default: m.description || "" },
						],
						(v) => frappe.call({
							method: "duty_board.client_room.milestone_update",
							args: { id: id, title: v.title, target_date: v.target_date || null, description: v.description || "" },
							callback: () => { frappe.show_alert({ message: __("Phase updated."), indicator: "green" }); done(); },
						}),
						__("Edit phase"), __("Save")
					);
					return;
				}
			});
			$p.find(".duty-newphase").on("keydown", (e) => {
				if (e.key !== "Enter") return;
				const t = e.target.value.trim();
				if (!t) return;
				e.target.value = "";
				frappe.call({
					method: "duty_board.client_room.project_milestone_add",
					args: { project: project, title: t },
					callback: () => this.load_kanban(project),
				});
			});
		}
	}

	kb_card(t) {
		const who = t.assignee
			? `<span style="color:${this.user_color(t.assignee)}">${frappe.utils.escape_html((this.name_map[t.assignee] || t.assignee).split(" ")[0])}</span>`
			: `<span class="text-muted">${__("unassigned")}</span>`;
		return `
			<div class="duty-kb-card" draggable="true" data-name="${t.name}" style="border-left: 3px solid ${this._kb_color || "var(--border-color)"}">
				<div class="duty-kb-top">
					<span class="duty-sev duty-sev-${(t.urgency || "medium").toLowerCase()}">${__(t.urgency)}</span>
					${t.due_date ? `<span class="duty-kb-due ${t.overdue ? "duty-issue-overdue" : ""}">${t.overdue ? "⚠ " : ""}${frappe.datetime.str_to_user(t.due_date)}</span>` : ""}
				</div>
				<div class="duty-kb-title">${frappe.utils.escape_html(t.title)}</div>
				${t.milestone && this._ms_names && this._ms_names[t.milestone] ? `<div class="duty-kb-ms">🚩 ${frappe.utils.escape_html(this._ms_names[t.milestone])}</div>` : ""}
				${t.blocked ? `<div class="duty-kb-blk">🔒 ${__("blocked by")} ${frappe.utils.escape_html(t.blocked_title || "")}</div>` : ""}
				${t.file_count ? `<span class="duty-kb-files">📎 ${t.file_count}</span>` : ""}
				<div class="duty-kb-meta">
					${who}
					<span class="duty-lead-badges">
						${t.awaiting_client && t.column !== "Completed" ? `<span class="duty-cr-mswait">⏳ ${__("client")}</span>` : ""}
						${(t.working || []).length ? `<span class="duty-kb-working">⏱ ${t.working.map((u) => `<b style="color:${this.user_color(u)}">${frappe.utils.escape_html((this.name_map[u] || u).split(" ")[0])}</b>`).join(", ")}</span>` : ""}
						${t.stale_days >= 7 && t.column !== "Completed" ? `<span class="duty-stale ${t.stale_days >= 14 ? "duty-stale-red" : ""}">🕸 ${t.stale_days}d</span>` : ""}
						${t.notes ? `<span>💬 ${frappe.utils.escape_html(t.notes)}</span>` : ""}
						${t.subs_total ? `<span style="font-weight:700;color:${t.subs_done === t.subs_total ? "#15803d" : "#6B7772"}">☑ ${t.subs_done}/${t.subs_total}</span>` : ""}
					</span>
				</div>
			</div>`;
	}

	render_kanban(project, data) {
		if (project !== this.current_project) return;
		this._ms_names = {};
		(data.milestones || []).forEach((m) => { this._ms_names[m.name] = m.title; });
		const $wrap = this.$projects.find(".duty-kanban-wrap").empty();
		const proj = (this._projects || []).find((p) => p.name === project);
		this._kb_color = this.proj_color(project);
		const $bar = $(`
			<div class="duty-kb-bar">
				<a class="duty-pj-back">‹ ${__("Projects")}</a>
				<span>
					<b style="color:${this._kb_color}">${frappe.utils.escape_html(proj ? proj.project_name : project)}</b>
					${proj && proj.customer ? `<span class="duty-proj-cust-inline">· ${frappe.utils.escape_html(proj.customer)}</span>` : ""}
				</span>
				<span class="duty-pj-views">
					<a class="duty-pj-v ${(this._pj_view || "board") === "board" ? "on" : ""}" data-v="board">▦ ${__("Board")}</a>
					<a class="duty-pj-v ${this._pj_view === "cal" ? "on" : ""}" data-v="cal">📅 ${__("Calendar")}</a>
					<a class="duty-pj-v ${this._pj_view === "phases" ? "on" : ""}" data-v="phases">🚩 ${__("Phases")}${(data.milestones || []).length ? ` <b>${data.milestones.length}</b>` : ""}</a>
					<a class="duty-pj-v ${this._pj_view === "risks" ? "on" : ""}" data-v="risks">⚠ ${__("Risks")}</a>
					<a class="duty-kb-dense" title="${__("Toggle density")}">${(localStorage.getItem("duty_kb_density") || "comfortable") === "compact" ? "▤ " + __("Compact") : "▢ " + __("Comfortable")}</a>
				</span>
				<a class="duty-proj-staffb">👥 ${__("Team")}${(data.staff || []).length ? ` <b>${data.staff.length}</b>` : ""}</a>
				<a class="duty-proj-cons">👷 ${__("Consultants")}${(data.consultants || []).length ? ` <b>${data.consultants.length}</b>` : ""}</a>
				<a class="duty-proj-archive">${__("Archive project")}</a>
			</div>
		`).appendTo($wrap);
		$bar.find(".duty-pj-back").on("click", () => this.$projects.removeClass("pj-detail"));
		$bar.find(".duty-pj-v").on("click", (e) => {
			this._pj_view = $(e.currentTarget).data("v");
			this.render_kanban(project, data);
		});
		$bar.find(".duty-proj-staffb").on("click", () => {
			frappe.call({
				method: "duty_board.projects.project_staff_options",
				args: { project: this.current_project },
				callback: (r) => {
					const R = r.message || {};
					const rows = R.options || [];
					const d = new frappe.ui.Dialog({
						title: __("Project team"),
						primary_action_label: R.can_edit ? __("Save team") : __("Close"),
						primary_action: () => {
							if (!R.can_edit) return d.hide();
							const users = $(d.body).find("input.duty-tm:checked").map((_i, el) => $(el).val()).get();
							frappe.call({
								method: "duty_board.projects.project_staff_set",
								args: { project: this.current_project, users: JSON.stringify(users) },
								callback: () => {
									d.hide();
									frappe.show_alert({ message: __("Team saved."), indicator: "green" });
									this.load_kanban(this.current_project);
								},
							});
						},
					});
					$(d.body).html(
						rows.map((u) => `<label class="duty-px-row"><input type="checkbox" class="duty-tm" value="${u.user}" ${u.member ? "checked" : ""} ${R.can_edit ? "" : "disabled"}><span class="duty-px-t">${frappe.utils.escape_html(u.full_name)}</span></label>`).join("")
						|| `<div class="text-muted">${__("No staff in the rates roster yet — add them in Duty Settings.")}</div>`
					);
					d.show();
				},
			});
		});
		$bar.find(".duty-proj-cons").on("click", () => {
			frappe.call({
				method: "duty_board.projects.list_consultants",
				callback: (r) => {
					const all = r.message || [];
					if (!all.length) {
						frappe.msgprint(__("No consultants exist yet — invite one from a client room's Members panel first."));
						return;
					}
					const pd = new frappe.ui.Dialog({
						title: __("Project consultants"),
						fields: [{
							fieldname: "users", fieldtype: "MultiSelectList", label: __("Granted consultants"),
							get_data: () => all.map((c) => ({ value: c.user, description: c.full_name })),
						}],
						primary_action_label: __("Save"),
						primary_action: (v) => {
							pd.hide();
							frappe.call({
								method: "duty_board.projects.set_project_consultants",
								args: { project: project, users: JSON.stringify(v.users || []) },
								callback: () => {
									frappe.show_alert({ message: __("Consultant access saved."), indicator: "green" });
									this.load_kanban(project);
								},
							});
						},
					});
					pd.show();
					(data.consultants || []).forEach((u) => pd.fields_dict.users.set_value ? null : null);
					try { pd.fields_dict.users.set_value(data.consultants || []); } catch (e) { /* older control */ }
				},
			});
		});
		$bar.find(".duty-proj-archive").on("click", () =>
			frappe.confirm(__("Archive this project? Its board disappears from the tabs (nothing is deleted)."), () =>
				frappe.call({
					method: "duty_board.projects.archive_project",
					args: { name: project },
					callback: () => {
						this.current_project = null;
						this.refresh_projects();
					},
				})
			)
		);
		if ((this._pj_view || "board") === "cal") {
			this.render_calendar(project, data, $wrap);
			return;
		}
		if (this._pj_view === "phases") {
			this.render_phases(project, data, $wrap);
			return;
		}
		if (this._pj_view === "risks") {
			this.render_risks(project, $wrap);
			return;
		}
		const dense = (localStorage.getItem("duty_kb_density") || "comfortable") === "compact";
		$bar.find(".duty-kb-dense").on("click", () => {
			localStorage.setItem("duty_kb_density", dense ? "comfortable" : "compact");
			this.render_kanban(project, data);
		});
		const $board = $(`<div class="duty-kanban ${dense ? "duty-kb-compact" : ""}"></div>`).appendTo($wrap);
		this._kb_expand = this._kb_expand || {};
		(data.columns || []).forEach((col) => {
			const cards = (data.tasks && data.tasks[col]) || [];
			if (!cards.length && col !== "To Do" && !this._kb_expand[col]) {
				const $slim = $(`<div class="duty-kb-col duty-kb-colslim" data-col="${col}" title="${__("Show {0}", [__(col)])}"><span>${__(col)} · 0</span></div>`).appendTo($board);
				$slim.on("click", () => { this._kb_expand[col] = 1; this.render_kanban(project, data); });
				return;
			}
			const $col = $(`
				<div class="duty-kb-col" data-col="${col}">
					<div class="duty-kb-col-head">${__(col)} <span class="duty-kb-count">${cards.length}</span></div>
					${col === "To Do" ? `<input type="text" class="form-control input-sm duty-kb-add" placeholder="${__("Add a task and press Enter...")}">` : ""}
					<div class="duty-kb-cards" data-col="${col}">
						${cards.map((t) => this.kb_card(t)).join("")}
					</div>
				</div>
			`).appendTo($board);

			$col.find(".duty-kb-add").on("keydown", (e) => {
				if (e.key !== "Enter") return;
				const title = e.target.value.trim();
				if (!title) return;
				e.target.value = "";
				frappe.call({
					method: "duty_board.projects.create_task",
					args: { project: project, title: title },
					callback: (r) => r.message && this.render_kanban(project, r.message),
				});
			});

			$col.on("dragover", (e) => {
				e.preventDefault();
				$col.addClass("duty-kb-over");
			});
			$col.on("dragleave drop", () => $col.removeClass("duty-kb-over"));
			$col.on("drop", (e) => {
				e.preventDefault();
				const name = e.originalEvent.dataTransfer.getData("text");
				if (!name) return;
				if (this._is_consultant && col === "Completed") {
					frappe.prompt(
						{ fieldname: "hours", fieldtype: "Float", label: __("Hours spent on this task"), reqd: 1 },
						(v) => frappe.call({
							method: "duty_board.projects.move_task",
							args: { name: name, column: col, hours: v.hours },
							callback: (r) => {
								if (r.message) this.render_kanban(project, r.message);
								this.refresh_projects_counts();
							},
						}),
						__("Log your time"),
						__("Complete task")
					);
					return;
				}
				frappe.call({
					method: "duty_board.projects.move_task",
					args: { name: name, column: col },
					callback: (r) => {
						if (r.message) this.render_kanban(project, r.message);
						this.refresh_projects_counts();
						if (this._open_room) this.load_client_room(this._open_room);
					},
				});
			});
		});

		const task_index = {};
		(data.columns || []).forEach((c) =>
			((data.tasks && data.tasks[c]) || []).forEach((t) => (task_index[t.name] = t))
		);
		$board.find(".duty-kb-card").each((_, el) => {
			const $card = $(el);
			el.addEventListener("dragstart", (e) => {
				e.dataTransfer.setData("text", $card.data("name"));
			});
			$card.on("click", () =>
				frappe.call({
					method: "duty_board.projects.get_card",
					args: { name: $card.data("name") },
					callback: (r) => r.message && this.task_dialog(project, r.message),
				})
			);
		});
	}

	refresh_projects_counts() {
		frappe.call({
			method: "duty_board.projects.get_projects",
			callback: (r) => {
				this._projects = r.message || [];
				this.render_project_tabs();
			},
		});
	}

	staff_options() {
		return [{ label: __("Unassigned"), value: "" }].concat(
			[{ user: frappe.session.user, full_name: __("Me") }]
				.concat(this.team_members())
				.map((x) => ({ label: x.full_name, value: x.user }))
		);
	}

	task_dialog(project, t) {
		if (!t) return;
		const esc = frappe.utils.escape_html;
		if (!this._$tdrawer) {
			this._$tdrawer = $(`
				<div class="duty-idrawer duty-tdrawer" style="display:none">
					<div class="duty-id-head"><b class="duty-id-title"></b><a class="duty-td-x">✕</a></div>
					<div class="duty-id-body"><div class="duty-td-form"></div><div class="duty-td-extras"></div></div>
					<div class="duty-ld-bar duty-td-bar"></div>
				</div>`).appendTo(document.body);
		}
		const $dw = this._$tdrawer;
		$dw.find(".duty-id-title").text(t.title.slice(0, 50));
		const d = {
			fields_dict: { extras: { wrapper: $dw.find(".duty-td-extras")[0] } },
			show: () => {
				$dw.show();
				$("body").addClass("duty-idrawer-open");
			},
			hide: () => {
				$dw.hide();
				$("body").removeClass("duty-idrawer-open");
			},
		};
		$dw.find(".duty-td-x").off("click").on("click", () => d.hide());
		$dw.find(".duty-td-form").html(`
			<div class="duty-ld-form">
				<label class="duty-ld-f duty-ld-wide"><span>${__("Task")}</span><input type="text" data-f="title" value="${esc(t.title)}"></label>
				<label class="duty-ld-f"><span>${__("Assign to")}</span><select data-f="assignee"><option value=""></option>${this.staff_options().filter((o) => o.value).map((o) => `<option value="${o.value}" ${o.value === (t.assignee || "") ? "selected" : ""}>${esc(o.label)}</option>`).join("")}</select></label>
				<label class="duty-ld-f"><span>${__("Due Date")}</span><input type="date" data-f="due_date" value="${t.due_date || ""}"></label>
				<label class="duty-ld-f"><span>${__("Urgency")}</span><select data-f="urgency">${["Low", "Medium", "High", "Critical"].map((s) => `<option ${(t.urgency || "Medium") === s ? "selected" : ""}>${s}</option>`).join("")}</select></label>
				<label class="duty-ld-f"><span>${__("Column")}</span><select data-f="column">${["To Do", "In Progress", "Completed", "Suspended"].map((s) => `<option ${t.column === s ? "selected" : ""}>${s}</option>`).join("")}</select></label>
				<label class="duty-ld-f"><span>🚩 ${__("Phase")}</span><select data-f="milestone"><option value="">${__("— none —")}</option>${Object.entries(this._ms_names || {}).map(([id, nm]) => `<option value="${id}" ${t.milestone === id ? "selected" : ""}>${esc(nm)}</option>`).join("")}</select></label>
				<label class="duty-ld-f"><span>🔒 ${__("Blocked by")}</span><select data-f="blocked_by"><option value="">${__("— nothing —")}</option>${(t.task_options || []).map((o) => `<option value="${o.name}" ${t.blocked_by === o.name ? "selected" : ""}>${esc(o.title)}</option>`).join("")}</select></label>
				<label class="duty-ld-f"><span>⏱ ${__("Est. hours")}</span><input type="number" step="0.5" min="0" data-f="estimate_hours" value="${t.estimate_hours || ""}" placeholder="${__("e.g. 4")}">${t.actual_hours ? `<small class="duty-est-act ${t.estimate_hours && t.actual_hours > t.estimate_hours ? "over" : ""}">${__("logged")} ${t.actual_hours}h${t.estimate_hours ? ` / ${t.estimate_hours}h` : ""}</small>` : ""}</label>
				<div class="duty-ld-files">
					<span class="duty-ld-files-h">📎 ${__("Files")}</span>
					<div class="duty-tf-list">${(t.files || []).map((f) => `<span class="duty-tf-chip" data-url="${f.file_url}" data-kind="${f.kind}" data-fn="${frappe.utils.escape_html(f.file_name || "")}">${f.kind === "image" ? "🖼" : f.kind === "pdf" ? "📄" : "📁"} ${frappe.utils.escape_html(f.file_name || "file")}<a class="duty-tf-del" data-file="${f.name}" title="${__("Remove")}">✕</a></span>`).join("")}</div>
					<label class="btn btn-xs btn-default duty-tf-add">＋ ${__("Add files")}<input type="file" multiple style="display:none"></label>
				</div>
				<label class="duty-td-chk"><input type="checkbox" data-f="client_visible" ${t.client_visible ? "checked" : ""}> ${__("Visible to client (shows on their portal)")}</label>
				<label class="duty-td-chk"><input type="checkbox" data-f="awaiting_client" ${t.awaiting_client ? "checked" : ""}> ⏳ ${__("Awaiting client action (nudges them on the portal)")}</label>
				<label class="duty-ld-f duty-ld-wide"><span>${__("Description")}</span><textarea data-f="description" rows="3">${esc(t.description || "")}</textarea></label>
			</div>`);
		$dw.find(".duty-td-bar").html(`
			<button class="btn btn-sm btn-primary duty-td-save">${__("Save")}</button>
			<button class="btn btn-sm btn-default duty-td-del">${__("Delete")}</button>`);
		$dw.find(".duty-td-save").off("click").on("click", () => {
			const v = {};
			$dw.find(".duty-td-form [data-f]").each((_, el) => {
				v[$(el).data("f")] = el.type === "checkbox" ? (el.checked ? 1 : 0) : $(el).val();
			});
			if (this._is_consultant && v.column === "Completed" && t.column !== "Completed" && !v.hours) {
				frappe.prompt(
					{ fieldname: "hours", fieldtype: "Float", label: __("Hours spent on this task"), reqd: 1 },
					(pv) => {
						v.hours = pv.hours;
						$dw.find(".duty-td-save").trigger("saveWith", [v]);
					},
					__("Log your time"),
					__("Save")
				);
				return;
			}
			d.hide();
			frappe.call({
				method: "duty_board.projects.update_task",
				args: {
					name: t.name,
					title: v.title,
					assignee: v.assignee || null,
					due_date: v.due_date || null,
					urgency: v.urgency,
					column: v.column,
					description: v.description || null,
					client_visible: v.client_visible ? 1 : 0,
					awaiting_client: v.awaiting_client ? 1 : 0,
					hours: v.hours || null,
					milestone: v.milestone || null,
					blocked_by: v.blocked_by || null,
					estimate_hours: v.estimate_hours || null,
				},
				callback: (r) => {
					if (r.message) this.render_kanban(project, r.message);
					this.refresh_projects_counts();
					if (this._open_room) this.load_client_room(this._open_room);
				},
			});
		});
		$dw.off("saveWith").on("saveWith", ".duty-td-save", (e, v2) => {
			d.hide();
			frappe.call({
				method: "duty_board.projects.update_task",
				args: {
					name: t.name, title: v2.title, assignee: v2.assignee || null,
					due_date: v2.due_date || null, urgency: v2.urgency, column: v2.column,
					description: v2.description || null,
					client_visible: v2.client_visible ? 1 : 0,
					awaiting_client: v2.awaiting_client ? 1 : 0, hours: v2.hours,
					milestone: v2.milestone || null,
					blocked_by: v2.blocked_by || null,
					estimate_hours: v2.estimate_hours || null,
				},
				callback: (r) => {
					if (r.message) this.render_kanban(project, r.message);
					this.refresh_projects_counts();
					if (this._open_room) this.load_client_room(this._open_room);
				},
			});
		});
		$dw.find(".duty-td-del").off("click").on("click", () => {
			frappe.confirm(__("Delete this task?"), () => {
				d.hide();
				frappe.call({
					method: "duty_board.projects.delete_task",
					args: { name: t.name },
					callback: (r) => {
						if (r.message) this.render_kanban(project, r.message);
						this.refresh_projects_counts();
					},
				});
			});
		});
		const me_working = (t.working || []).includes(frappe.session.user);
		const $x = $(d.fields_dict.extras.wrapper).html(`
			${(t.working || []).length ? `<div class="duty-issue-meta">⏱ ${__("Working on it now")}: ${t.working.map((u) => `<span style="color:${this.user_color(u)}">${frappe.utils.escape_html((this.name_map[u] || u).split(" ")[0])}</span>`).join(", ")}</div>` : ""}
			<div class="duty-lead-close" style="justify-content:flex-start; margin-top:8px">
				${t.column !== "Completed" && !me_working ? `<button type="button" class="btn btn-sm btn-default duty-card-start">▶ ${__("Start work")}</button>` : ""}
				${me_working ? `<button type="button" class="btn btn-sm btn-default duty-card-stop">⏸ ${__("Stop work")}</button>` : ""}
			</div>
			<div class="duty-lead-section">☑ ${__("Subtasks")}${t.subs_total ? ` <span class="text-muted" style="font-weight:400">${t.subs_done}/${t.subs_total}</span>` : ""}</div>
			<div class="duty-subs">
				${(t.subtasks || []).map((s) => `
				<div class="duty-sub" style="display:flex;gap:9px;align-items:center;padding:5px 0;border-bottom:1px solid #F0EEE8">
					<input type="checkbox" data-sub="${s.row}" ${s.status === "Done" ? "checked" : ""}>
					<span style="flex:1;min-width:0;${s.status === "Done" ? "text-decoration:line-through;color:#96A09B" : ""}">${frappe.utils.escape_html(s.title)}${s.note ? ` <span class="text-muted" title="${frappe.utils.escape_html(s.note)}">🗒</span>` : ""}</span>
					${s.assignee_first ? `<span class="text-muted" style="font-size:11.5px;white-space:nowrap">${frappe.utils.escape_html(s.assignee_first)}</span>` : ""}
					${s.due_date ? `<span class="text-muted" style="font-size:11.5px;white-space:nowrap">${s.due_date.slice(5)}</span>` : ""}
					<a data-subedit="${s.row}" style="cursor:pointer;color:#96A09B" title="${__("Edit")}">✎</a>
					<a data-subdel="${s.row}" style="cursor:pointer;color:#B0443C" title="${__("Remove")}">×</a>
				</div>`).join("")}
				<div style="display:flex;gap:7px;margin:8px 0 2px">
					<input type="text" class="form-control input-sm duty-sub-new" placeholder="${__("Add a subtask…")}">
					<button type="button" class="btn btn-sm btn-default duty-sub-add">＋</button>
				</div>
			</div>
			<div class="duty-lead-section">💬 ${__("Chat")}</div>
			<div class="duty-lead-notes">
				${(t.notes_list || t.notes || []).map
					? ""
					: ""}
			</div>
		`);
		const notes = Array.isArray(t.notes) ? t.notes : [];
		$x.find(".duty-lead-notes").html(
			notes.length
				? notes
						.map(
							(n) =>
								`<div class="duty-lead-note"><b>${frappe.utils.escape_html(n.who)}</b> <span class="duty-msg-time">${frappe.datetime.str_to_user(n.when)}</span><br>${this.fmt_note(n.note)}</div>`
						)
						.join("")
				: `<div class="text-muted">${__("No notes yet.")}</div>`
		);
		$x.append(`
			<div class="duty-lead-addnote">
				<input type="text" class="form-control input-sm duty-cn-text" placeholder="${__("Message this thread — @ to mention, Enter to send...")}">
			</div>
		`);
		const reopen = (r) => {
			d.hide();
			if (r.message) this.task_dialog(project, r.message);
			this.load_kanban(project);
			if (this._open_room) this.load_client_room(this._open_room);
		};
		const subCall = (method, args) =>
			frappe.call({ method: "duty_board.projects." + method, args: args, callback: (r) => reopen(r) });
		$x.find("[data-sub]").on("change", (e) =>
			subCall("subtask_toggle", { task: t.name, row: $(e.currentTarget).data("sub") })
		);
		$x.find("[data-subdel]").on("click", (e) =>
			frappe.confirm(__("Remove this subtask?"), () =>
				subCall("subtask_delete", { task: t.name, row: $(e.currentTarget).data("subdel") })
			)
		);
		$x.find("[data-subedit]").on("click", (e) => {
			const row = $(e.currentTarget).data("subedit");
			const s = (t.subtasks || []).find((z) => z.row === row) || {};
			frappe.prompt(
				[
					{ fieldname: "title", fieldtype: "Data", label: __("Subtask"), default: s.title, reqd: 1 },
					{ fieldname: "assignee", fieldtype: "Autocomplete", label: __("Assignee"), options: this.staff_options(), default: s.assignee || "" },
					{ fieldname: "due_date", fieldtype: "Date", label: __("Due (on or before the card due date)"), default: s.due_date || "" },
					{ fieldname: "note", fieldtype: "Small Text", label: __("Note"), default: s.note || "" },
				],
				(v) => subCall("subtask_update", { task: t.name, row: row, title: v.title, assignee: v.assignee || "", due_date: v.due_date || "", note: v.note || "" }),
				__("Edit subtask"), __("Save")
			);
		});
		const addSub = () => {
			const title = ($x.find(".duty-sub-new").val() || "").trim();
			if (!title) return;
			frappe.prompt(
				[
					{ fieldname: "assignee", fieldtype: "Autocomplete", label: __("Assignee"), options: this.staff_options() },
					{ fieldname: "due_date", fieldtype: "Date", label: __("Due (on or before the card due date)") },
					{ fieldname: "note", fieldtype: "Small Text", label: __("Note") },
				],
				(v) => subCall("subtask_add", { task: t.name, title: title, assignee: v.assignee || null, due_date: v.due_date || null, note: v.note || null }),
				__("New subtask"), __("Add")
			);
		};
		$x.find(".duty-sub-add").on("click", addSub);
		$x.find(".duty-sub-new").on("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); addSub(); } });
		$x.find(".duty-card-start").on("click", () =>
			frappe.call({
				method: "duty_board.projects.start_card_work",
				args: { name: t.name },
				callback: (r) => {
					reopen(r);
					this.refresh(true);
				},
			})
		);
		$x.find(".duty-card-stop").on("click", () =>
			frappe.call({
				method: "duty_board.projects.stop_card_work",
				args: { name: t.name },
				callback: (r) => {
					reopen(r);
					this.refresh(true);
				},
			})
		);
		this.attach_mention_picker($x.find(".duty-cn-text"));
		this._open_card_ctx = { id: t.name, $x: $x };
		d.onhide = () => {
			if (this._open_card_ctx && this._open_card_ctx.id === t.name) this._open_card_ctx = null;
		};
		$x.find(".duty-cn-text").on("keydown", (e) => {
			if (e.key !== "Enter") return;
			e.preventDefault();
			e.stopPropagation();
			const note = e.target.value.trim();
			if (!note) return;
			frappe.call({
				method: "duty_board.projects.add_card_note",
				args: { name: t.name, note: note },
				callback: reopen,
			});
		});

		// --- task file attachments: preview, upload, delete ---
		const tfReload = () => frappe.call({ method: "duty_board.projects.get_card", args: { name: t.name }, callback: (rr) => { if (rr.message) { d.hide(); this.task_dialog(project, rr.message); } } });
		$dw.find(".duty-tf-chip").off("click").on("click", (e) => {
			if ($(e.target).hasClass("duty-tf-del")) return;
			const $c = $(e.currentTarget);
			const url = $c.data("url"), kind = $c.data("kind"), fn = $c.data("fn");
			if (kind === "image") {
				const pd = new frappe.ui.Dialog({ title: fn, size: "extra-large" });
				$(pd.body).html(`<div style="text-align:center"><img src="${url}" style="max-width:100%;max-height:74vh;border-radius:8px"></div>`);
				pd.show();
			} else if (kind === "pdf") {
				const pd = new frappe.ui.Dialog({ title: fn, size: "extra-large" });
				$(pd.body).html(`<iframe src="${url}" style="width:100%;height:76vh;border:none;border-radius:8px"></iframe>`);
				pd.show();
			} else {
				window.open(url, "_blank");
			}
		});
		$dw.find(".duty-tf-del").off("click").on("click", (e) => {
			e.stopPropagation();
			const file = $(e.currentTarget).data("file");
			frappe.confirm(__("Remove this file from the task?"), () =>
				frappe.call({ method: "duty_board.projects.task_file_delete", args: { name: t.name, file: file }, callback: (rr) => { if (rr.message) { d.hide(); this.task_dialog(project, rr.message); } } }));
		});
		$dw.find(".duty-tf-add input").off("change").on("change", async (e) => {
			const files = Array.from(e.target.files || []);
			if (!files.length) return;
			frappe.show_alert({ message: __("Uploading {0} file(s)…", [files.length]), indicator: "blue" });
			for (const f of files) {
				const fd = new FormData();
				fd.append("file", f, f.name);
				fd.append("is_private", "1");
				fd.append("doctype", "Duty Project Task");
				fd.append("docname", t.name);
				await fetch("/api/method/upload_file", { method: "POST", headers: { "X-Frappe-CSRF-Token": frappe.csrf_token }, body: fd });
			}
			frappe.show_alert({ message: __("Uploaded."), indicator: "green" });
			tfReload();
		});
		d.show();
	}

	new_project_dialog() {
		frappe.prompt(
			[
				{ fieldname: "project_name", fieldtype: "Data", label: __("Project name"), reqd: 1 },
				{ fieldname: "customer", fieldtype: "Link", label: __("Customer"), options: "Customer", reqd: 1 },
				{ fieldname: "target_date", fieldtype: "Date", label: __("Target Date") },
			],
			(v) => {
				frappe.call({
					method: "duty_board.projects.create_project",
					args: { project_name: v.project_name, customer: v.customer, target_date: v.target_date || null },
					callback: (r) => {
						this.current_project = r.message;
						localStorage.setItem("duty_proj", r.message);
						this.refresh_projects();
					},
				});
			},
			__("New Project"),
			__("Create")
		);
	}

	// ---------------- Clients face ----------------

	refresh_clients(silent) {
		frappe.call({
			method: "duty_board.client_room.get_rooms",
			freeze: false,
			error: (x) => this._poll_failed(x),
			callback: (r) => {
				this._fail_count = 0;
				this._rooms = r.message || [];
				this.render_room_list();
				if (this._open_room) this.load_client_room(this._open_room, true);
			},
		});
	}

	render_room_list() {
		const $list = this.$clients.find(".duty-cr-list").empty();
		const $bar = $(`
			<div class="duty-cr-bar">
				<b>🤝 ${__("Client Rooms")}<span class="duty-cr-barjoins"></span></b>
				<button class="btn btn-sm btn-primary duty-cr-new">＋ ${__("New Room")}</button>
			</div>
		`).appendTo($list);
		$bar.find(".duty-cr-new").on("click", () =>
			frappe.prompt(
				[
					{ fieldname: "customer", fieldtype: "Link", label: __("Customer"), options: "Customer", reqd: 1 },
					{ fieldname: "unit", fieldtype: "Data", label: __("Unit"), default: "General",
					  description: __("General, HR, Finance… separate rooms keep departments confidential.") },
				],
				(v) =>
					frappe.call({
						method: "duty_board.client_room.create_room",
						args: { customer: v.customer, unit: v.unit || "General" },
						callback: (r) => {
							this.refresh_clients();
							if (r.message) this.open_client_room(r.message);
						},
					}),
				__("New Client Room"),
				__("Create")
			)
		);
		if (!(this._rooms || []).length) {
			$list.append(`<div class="text-muted duty-plan-empty">${__("No client rooms yet.")}</div>`);
			return;
		}
		const cust_unread = {};
		const cust_unread_sys = {};
		const cust_joins = {};
		let total_unread = 0;
		let total_joins = 0;
		this._rooms.forEach((r) => {
			cust_unread[r.customer] = (cust_unread[r.customer] || 0) + (r.unread_client || 0);
			cust_unread_sys[r.customer] = (cust_unread_sys[r.customer] || 0) + (r.unread_other || 0);
			cust_joins[r.customer] = (cust_joins[r.customer] || 0) + (r.join_requests || 0);
			total_unread += r.unread_client ? 1 : 0;
			total_joins += r.join_requests || 0;
		});
		$(".duty-cr-barjoins").html(
			total_joins ? ` <span class="duty-cr-joinpill">🙋 ${total_joins} ${__("waiting")}</span>` : ""
		);
		const cr_attn2 = total_unread + total_joins;
		$(".duty-tab-clients").text(cr_attn2).toggle(cr_attn2 > 0);
		const _q = (this._cr_q || "").toLowerCase();
		const _match = (r) => !_q || (r.customer || "").toLowerCase().includes(_q) || (r.unit || "").toLowerCase().includes(_q);
		const $sr = $(`<div class="duty-cr-search"><input type="text" class="form-control input-sm" placeholder="${__("Search clients & rooms…")}" value="${frappe.utils.escape_html(this._cr_q || "")}"></div>`).appendTo($list);
		$sr.find("input").on("input", frappe.utils.debounce((e) => {
			this._cr_q = e.target.value;
			this.render_room_list();
		}, 250)).on("keydown", (e) => { if (e.key === "Escape") { e.target.value = ""; this._cr_q = ""; this.refresh_clients(); } });
		const room_row = (r) => `
			<a class="duty-cr-secrow" data-room="${r.name}">
				<span class="duty-cr-secmain"><b>${frappe.utils.escape_html(r.customer)}</b><span class="duty-cr-secunit">${frappe.utils.escape_html(r.unit || "General")}</span>
				${r.unread_client ? `<span class="duty-cr-unread">${r.unread_client}</span>` : ""}${r.unread_other ? `<span class="duty-cr-unread duty-cr-unread-sys">${r.unread_other}</span>` : ""}</span>
				${r.last ? `<span class="duty-cr-secprev">${frappe.utils.escape_html(r.last)}</span>` : ""}
				${r.last_when ? `<span class="duty-cr-sectime">${this.fmt_stamp(r.last_when)}</span>` : ""}
			</a>`;
		const unread_rooms = (this._rooms || []).filter((r) => _match(r) && (r.unread_client || r.unread_other));
		const recent_rooms = (this._rooms || [])
			.filter((r) => _match(r) && r.last_when && !(r.unread_client || r.unread_other))
			.sort((a, b) => (b.last_when || "").localeCompare(a.last_when || ""))
			.slice(0, 6);
		if (unread_rooms.length) {
			$list.append(`<div class="duty-cr-sech">${__("Unread")}</div>`);
			const $u = $(`<div></div>`).appendTo($list);
			$u.html(unread_rooms.map(room_row).join(""));
		}
		if (recent_rooms.length && !_q) {
			$list.append(`<div class="duty-cr-sech">${__("Recent")}</div>`);
			const $rc = $(`<div></div>`).appendTo($list);
			$rc.html(recent_rooms.map(room_row).join(""));
		}
		$list.find(".duty-cr-secrow").on("click", (e) => this.open_client_room($(e.currentTarget).data("room")));
		$list.append(`<div class="duty-cr-sech">${__("All clients")}</div>`);
		let prev_cust = null;
		this._rooms.filter(_match).forEach((r) => {
			const folded = !(this._cr_open || {})[r.customer];
			if (r.customer !== prev_cust) {
				prev_cust = r.customer;
				$(`<div class="duty-cr-cust"><span class="duty-cr-caret">${folded ? "▸" : "▾"}</span> ${frappe.utils.escape_html(r.customer)}${folded && cust_unread[r.customer] ? ` <span class="duty-cr-unread" title="${__("new client message(s)")}">${cust_unread[r.customer]}</span>` : ""}${folded && cust_unread_sys[r.customer] ? ` <span class="duty-cr-unread duty-cr-unread-sys" title="${__("system & colleague message(s)")}">${cust_unread_sys[r.customer]}</span>` : ""}${folded && cust_joins[r.customer] ? ` <span class="duty-cr-joinpill">🙋 ${cust_joins[r.customer]}</span>` : ""}</div>`)
					.appendTo($list)
					.on("click", () => {
						this._cr_open = this._cr_open || {};
						if (folded) this._cr_open[r.customer] = 1;
						else delete this._cr_open[r.customer];
						this.render_room_list();
					});
			}
			if (folded) return;
			$(`
				<a class="duty-cr-item ${r.name === this._open_room ? "active" : ""} ${r.status !== "Active" ? "duty-cr-frozen" : ""}">
					<b style="color:${this.proj_color(r.name)}">${r.health ? `<span class="duty-health duty-health-${r.health.state}" title="${frappe.utils.escape_html((r.health.reasons || []).join(" · ") || __("healthy"))}">●</span> ` : ""}${frappe.utils.escape_html(r.unit || "General")}${r.renewal ? (r.renewal.frozen ? ` <span class="duty-renew duty-renew-frozen">⏸</span>` : r.renewal.days_left < 0 ? ` <span class="duty-renew duty-renew-over">🔴 ${-r.renewal.days_left}d</span>` : r.renewal.days_left <= 30 ? ` <span class="duty-renew duty-renew-warn">⏳ ${r.renewal.days_left}d</span>` : "") : ""}${r.unread_client ? ` <span class="duty-cr-unread" title="${__("new client message(s)")}">${r.unread_client}</span>` : ""}${r.unread_other ? ` <span class="duty-cr-unread duty-cr-unread-sys" title="${__("system & colleague message(s)")}">${r.unread_other}</span>` : ""}${r.join_requests ? ` <span class="duty-cr-joinpill" title="${__("Join requests awaiting approval")}">🙋 ${r.join_requests}</span>` : ""}${r.renewal ? (r.renewal.frozen ? ` <span class="duty-renew duty-renew-frozen">⏸</span>` : r.renewal.days_left < 0 ? ` <span class="duty-renew duty-renew-over" title="${__("renewal overdue")}">🔴 ${-r.renewal.days_left}d</span>` : r.renewal.days_left <= 30 ? ` <span class="duty-renew duty-renew-warn" title="${__("renews soon")}">⏳ ${r.renewal.days_left}d</span>` : "") : ""}</b>
					${r.status !== "Active" ? `<span class="duty-cr-status">${__(r.status)}</span>` : ""}
					<span class="duty-cr-last">${frappe.utils.escape_html(r.last || "")}</span>
					<span class="duty-cr-members">👥 ${r.members}</span>
				</a>
			`)
				.appendTo($list)
				.on("click", () => this.open_client_room(r.name));
		});
	}

	jump_to_msg(msg_id) {
		const $t = $(`.duty-cr-msgs .duty-cr-msg[data-name="${msg_id}"]`);
		if (!$t.length) {
			frappe.show_alert(
				{ message: __("The origin message is further up — load earlier messages, then try again."), indicator: "orange" },
				4
			);
			return false;
		}
		$t[0].scrollIntoView({ behavior: "smooth", block: "center" });
		$t.addClass("duty-msg-flash");
		setTimeout(() => $t.removeClass("duty-msg-flash"), 2000);
		return true;
	}

	view_origin(room_name, msg_id) {
		if (this._open_room === room_name && $(".duty-cr-msgs").length) {
			this.jump_to_msg(msg_id);
			return;
		}
		if (this._is_consultant) {
			this.show_face("chat");
			this.open_convo("room", String(room_name));
		} else {
			this.show_face("clients");
			this.open_client_room(room_name);
		}
		setTimeout(() => this.jump_to_msg(msg_id), 1300);
	}

	open_client_room(name) {
		this._open_room = name;
		frappe.call({
			method: "duty_board.client_room.mark_room_seen",
			args: { name: name },
			callback: () => this.refresh_clients(true),
		});
		this.render_room_list();
		this.load_client_room(name);
	}

	load_client_room(name, silent) {
		this._open_room = name;
		frappe.call({
			method: "duty_board.client_room.get_room",
			args: { name: name },
			callback: (r) => r.message && this.render_client_room(r.message),
		});
	}

	// The server has always paginated (before / has_more); neither front end used
	// it, so chat was capped at the newest 40 messages with no way back. Fetch the
	// page before the oldest message on screen and prepend it, holding the
	// reader's scroll position so the view does not jump.
	cr_load_older($wrap) {
		const $btn = $wrap.find(".duty-cr-older");
		const $box = $wrap.find(".duty-cr-msgs");
		const oldest = $box.find(".duty-cr-msg").first().data("creation");
		if (!oldest || !this._open_room) return;
		$btn.prop("disabled", true).text(__("Loading…"));
		const prevH = $box[0].scrollHeight;
		frappe.call({
			method: "duty_board.client_room.get_room",
			args: { name: this._open_room, before: oldest },
			callback: (r) => {
				const msgs = (r.message && r.message.messages) || [];
				if (!msgs.length) {
					$btn.remove();
					return;
				}
				$btn.after(msgs.map((m) => this.cr_msg(m)).join(""));
				if (r.message.has_more) $btn.prop("disabled", false).text("↑ " + __("Load older messages"));
				else $btn.remove();
				$box[0].scrollTop = $box[0].scrollHeight - prevH;
			},
			error: () => $btn.prop("disabled", false).text("↑ " + __("Load older messages")),
		});
	}

	cr_msg(m) {
		return `
			<div class="duty-cr-msg ${m.internal ? "duty-cr-internal" : m.mine ? "duty-cr-mine" : m.is_staff ? "duty-cr-staff" : "duty-cr-client"}" data-name="${m.name}" data-creation="${m.creation}" data-who="${frappe.utils.escape_html((m.who || m.owner).split(" ")[0])}" data-msg="${frappe.utils.escape_html((m.message || "\u{1F4CE}").slice(0, 80))}">
				<a class="duty-cr-reply" title="${__("Reply")}">↩</a>
				<span class="duty-msg-who" style="color:${this.user_color(m.owner)}">${m.internal ? "🔒 " : ""}${frappe.utils.escape_html((m.who || m.owner).split(" ")[0])}${m.is_staff ? "" : ` · ${__("client")}`}</span>
				${m.ref ? `<a class="duty-cr-quote" data-target="${m.ref}"><b>${frappe.utils.escape_html(m.ref_who || "")}</b>: ${frappe.utils.escape_html(m.ref_text || "")}</a>` : ""}
				<span class="duty-msg-text">${this.linkify(frappe.utils.escape_html(m.message))}</span>
				${m.attachment_url ? `<span class="duty-cr-att">${m.is_image ? `<a href="/api/method/duty_board.client_room.room_file?msg=${m.name}" target="_blank"><img src="/api/method/duty_board.client_room.room_file?msg=${m.name}"></a>` : m.is_audio ? `<audio controls preload="none" src="/api/method/duty_board.client_room.room_file?msg=${m.name}" style="display:block;margin-top:6px;max-width:240px"></audio>` : `<a class="duty-issue-filelink" href="/api/method/duty_board.client_room.room_file?msg=${m.name}" target="_blank">📎 ${frappe.utils.escape_html(m.attachment_name || "file")}</a>`}</span>` : ""}
				<span class="duty-msg-time">${frappe.datetime.str_to_user(m.creation)}${this.edited_tag(m)}</span>
				${m.mine && this.can_edit(m.creation) ? `<a class="duty-cr-edit" data-name="${m.name}" data-text="${frappe.utils.escape_html(m.message || "")}" data-att="${m.attachment_url ? 1 : 0}" title="${__("Edit")}">✏</a>` : ""}
				${m.is_staff ? "" : `<a class="duty-cr-mktask" data-mid="${m.name}" data-text="${frappe.utils.escape_html(m.message.slice(0, 120))}" title="${__("Make task from this")}">➕</a><a class="duty-cr-mkchreq" data-mid="${m.name}" data-text="${frappe.utils.escape_html(m.message.slice(0, 120))}" title="${__("Draft change request from this")}">💱</a>`}
			</div>`;
	}

	render_client_room(x) {
		if (x.name !== this._open_room) return;
		const $room = this._cr_host().show();
		this.$clients.addClass("cr-room-open");
		const counts = { Queued: 0, "In Progress": 0, Done: 0 };
		(x.tasks || []).forEach((t) => (counts[t.status] = (counts[t.status] || 0) + 1));
		$room.html(`
			<div class="duty-cr-ribbon">🤝 ${__("{0} can read this room — whispers 🔒 excepted", [frappe.utils.escape_html(x.customer)])}</div>
			<div class="duty-cr-mtabs"><a data-rt="chat" class="on">💬 ${__("Chat")}</a><a data-rt="tasks">📋 ${__("Tasks")}</a></div>
			<div class="duty-cr-head">
				<a class="duty-cr-back">‹ ${__("Rooms")}</a>
				<b>${frappe.utils.escape_html(x.customer)}</b>
				<span class="duty-cr-taskchips">📋 ${counts.Queued} ${__("queued")} · ${counts["In Progress"]} ${__("in progress")} · ${counts.Done} ${__("done")}</span>
				<span class="duty-cr-owner" title="${__("Account manager")}">★ ${x.owner_user ? frappe.utils.escape_html((this.name_map[x.owner_user] || x.owner_user).split(" ")[0]) : `<i>${__("unowned")}</i>`}</span>
				${(() => {
					const seen = (x.members || []).map((m) => m.last_seen).filter(Boolean).sort().pop();
					return seen ? `<span class="duty-cr-lastseen">👀 ${__("client seen")} ${frappe.datetime.comment_when(seen)}</span>` : "";
				})()}
				<a class="duty-cr-academy" title="${__("Training Academy")}">🎓</a>
				<a class="duty-cr-deps" title="${__("Client dependencies — what we're waiting on")}">📋</a>
				<a class="duty-cr-scope" title="${__("Room scope & support plan")}">⚖</a>
				<a class="duty-cr-uat" title="${__("Acceptance testing (UAT)")}">🧪</a>
				<a class="duty-cr-tl" title="${__("Delivery accountability timeline")}">📜</a>
				<a class="duty-cr-metrics" title="${__("Live metrics for this customer")}">📈</a>
				<a class="duty-cr-report" title="${__("Generate last month's service report")}">📊</a>
				<a class="duty-cr-rename" title="${__("Rename room")}">✏</a>
				<a class="duty-cr-delete" title="${__("Delete room (System Manager)")}">🗑</a>
				<span class="duty-cr-tools">
					<a class="duty-cr-shelfbtn">📚 ${__("Shelf")}</a>
					<a class="duty-cr-membersbtn">👥 ${__("Members")}${(x.requests || []).length ? ` <b class="duty-cr-reqbadge">${x.requests.length}</b>` : ""}</a>${this._is_consultant ? "" : `<a class="duty-cr-accessbtn" title="${__("Which staff see this room")}">🔑</a>`}
					${frappe.user.has_role("System Manager") ? `<a class="duty-cr-freeze">${x.status === "Active" ? "🧊 " + __("Freeze") : "▶ " + __("Unfreeze")}</a>` : ""}
				</span>
			</div>
			<div class="duty-cr-main">
			<div class="duty-cr-chatcol">
			<div class="duty-cr-msgs">${x.has_more ? `<button class="btn btn-xs btn-default duty-cr-older">↑ ${__("Load older messages")}</button>` : ""}${(x.messages || []).map((m) => this.cr_msg(m)).join("") || `<div class="text-muted">${__("No messages yet.")}</div>`}</div>
			<div class="duty-cr-typing" style="display:none"></div>
			<div class="duty-cr-replychip"></div>
			<div class="duty-cr-pending"></div>
			<div class="duty-cr-emojis" style="display:none"></div>
			<div class="duty-cr-intbanner" style="display:none">🔒 ${__("Internal note — only Xlevel staff can see this")}</div>
			<div class="duty-cr-compose">
				<span class="duty-md"><a class="duty-md-c on">${__("Client reply")}</a><a class="duty-md-i">🔒 ${__("Internal")}</a></span>
				<input type="checkbox" class="duty-cr-internal-toggle" hidden>
				<label class="duty-cr-attach" title="${__("Attach image / file")}">📎<input type="file" hidden></label>
				<a class="duty-cr-emojibtn" title="${__("Emoji")}">😊</a>
				<a class="duty-cr-mic" title="${__("Hold to record a voice note")}">🎙</a>
				<textarea rows="2" class="form-control duty-cr-input" placeholder="${__("Message {0}... Enter to send", [frappe.utils.escape_html(x.customer)])}"></textarea>
				<button type="button" class="btn btn-primary btn-sm duty-cr-send">${__("Send")}</button>
			</div>
			</div>
			<div class="duty-cr-side ${this._cr_tasks_open === false ? "folded" : ""}">
			<div class="duty-cr-tasksbar">
				<a class="duty-cr-taskstoggle"><b>${this._cr_tasks_open === false ? "◂" : "▸"} 📋 ${this._cr_tasks_open === false ? "" : `${__("Tasks")} (${(x.tasks || []).length})`}</b></a>
				${this._cr_tasks_open === false ? "" : `<select class="form-control input-sm duty-cr-tfilter">
					<option value="">${__("All")}</option>
					<option ${this._cr_tfilter === "Queued" ? "selected" : ""}>Queued</option>
					<option ${this._cr_tfilter === "In Progress" ? "selected" : ""}>In Progress</option>
					<option ${this._cr_tfilter === "Done" ? "selected" : ""}>Done</option>
				</select>`}
			</div>
			<div class="duty-cr-sidebody">
			<div class="duty-cr-tasks">
				${(x.tasks || [])
					.filter((t) => !this._cr_tfilter || t.status === this._cr_tfilter)
					.map(
						(t) => `
					<a class="duty-cr-task" data-name="${t.name}" data-kind="${t.kind}">
						<span class="duty-crt-pill duty-crt-${(t.status || "").replace(/ /g, "").toLowerCase()}">${__(t.status)}</span>
						<span class="duty-crt-title">${t.kind === "issue" ? "⚠ " : "📁 "}${t.client_requested ? "🙋 " : ""}${frappe.utils.escape_html(t.title)}</span>
						${t.assignee_first ? `<span class="duty-crt-who">${frappe.utils.escape_html(t.assignee_first)}</span>` : ""}
						${t.reported ? `<span class="duty-crt-stamps">${__("Rep")} ${t.reported.slice(0, 10)}${t.started ? ` · ${__("Start")} ${t.started.slice(0, 10)}` : ""}${t.done ? ` · ${__("Done")} ${t.done.slice(0, 10)}` : ""}</span>` : ""}
					</a>`
					)
					.join("")}
				<a class="duty-cr-openissues">⚠ ${__("Open issue register for {0}", [frappe.utils.escape_html(x.customer)])} ›</a>
			</div>
			<div class="duty-cr-mstones"></div>
			<div class="duty-cr-chreqs"></div>
			<div class="duty-cr-meetings"></div>
			<div class="duty-cr-unsettled"></div>
			</div>
			</div>
			</div>
		`);
		const $msgs = $room.find(".duty-cr-msgs");
		$msgs.scrollTop($msgs[0].scrollHeight);
		const $input = $room.find(".duty-cr-input");
		const $int = $room.find(".duty-cr-internal-toggle");
		const restyle = () => {
			const on = $int.is(":checked");
			$room.find(".duty-cr-compose").toggleClass("duty-cr-composing-internal", on);
			$room.find(".duty-md-c").toggleClass("on", !on);
			$room.find(".duty-md-i").toggleClass("on", on);
			$room.find(".duty-cr-intbanner").toggle(on);
			$room.find(".duty-cr-send").text(on ? __("Post internal note") : __("Send"))
				.toggleClass("duty-send-internal", on);
			$input.attr("placeholder", on
				? __("Internal note — invisible to the client…")
				: __("Message {0}... Enter to send", [frappe.utils.escape_html(x.customer)]));
		};
		$room.find(".duty-md-c").on("click", () => { $int.prop("checked", false); restyle(); $input.focus(); });
		$room.find(".duty-md-i").on("click", () => { $int.prop("checked", true); restyle(); $input.focus(); });
		$int.on("change", restyle);
		this._cr_reply = null;
		const show_reply = () => {
			const $rc = $room.find(".duty-cr-replychip").empty();
			if (this._cr_reply) {
				$(`<span class="duty-file-chip">↩ <b>${frappe.utils.escape_html(this._cr_reply.who)}</b>: ${frappe.utils.escape_html(this._cr_reply.text)} <a>×</a></span>`)
					.appendTo($rc)
					.find("a")
					.on("click", () => {
						this._cr_reply = null;
						show_reply();
					});
			}
		};
		const $msgs2 = $room.find(".duty-cr-msgs");
		$msgs2.on("click", ".duty-cr-edit", (e) => {
			const $t = $(e.currentTarget);
			this.edit_prompt("room", $t.data("name"), $t.data("text"), !!$t.data("att"),
				() => { if (this._open_room) this.load_client_room(this._open_room); });
		});
		$msgs2.on("click", ".duty-cr-older", () => this.cr_load_older($room));
		// delegated so messages prepended by "load older" are live too, and read
		// from the DOM rather than x.messages, which only holds the newest page
		$msgs2.on("click", ".duty-cr-reply", (e) => {
			const $m = $(e.currentTarget).closest(".duty-cr-msg");
			if (!$m.length) return;
			this._cr_reply = {
				name: $m.data("name"),
				who: $m.data("who"),
				text: $m.data("msg"),
			};
			if (mm.internal) {
				$int.prop("checked", true);
				restyle();
			}
			show_reply();
			$input.trigger("focus");
		});
		$msgs2.find(".duty-cr-quote").on("click", (e) => {
			const target = $(e.currentTarget).data("target");
			const $t = $msgs2.find(`.duty-cr-msg[data-name="${target}"]`);
			if (!$t.length) {
				frappe.show_alert({ message: __("That message is further up the history."), indicator: "orange" }, 3);
				return;
			}
			$t[0].scrollIntoView({ behavior: "smooth", block: "center" });
			$t.addClass("duty-msg-flash");
			setTimeout(() => $t.removeClass("duty-msg-flash"), 1600);
		});
		const EMOJIS = ["😀","😂","🙏","👍","👌","🙌","🎉","❤️","🔥","💯","😅","😢","😡","🤔","👀","✅","❌","⏳","📌","💡","📞","🤝","🚀","🙈"];
		$room.find(".duty-cr-emojibtn").on("click", () => {
			const $e = $room.find(".duty-cr-emojis");
			if ($e.is(":visible")) return $e.hide();
			if (!$e.children().length) {
				EMOJIS.forEach((em) =>
					$(`<a>${em}</a>`)
						.appendTo($e)
						.on("click", () => {
							const el = $input[0];
							const p = el.selectionStart || el.value.length;
							el.value = el.value.slice(0, p) + em + el.value.slice(p);
							el.focus();
							el.selectionStart = el.selectionEnd = p + em.length;
						})
				);
			}
			$e.css("display", "flex");
		});
		this._cr_pending = null;
		const show_pending = () => {
			const $p = $room.find(".duty-cr-pending").empty();
			if (this._cr_pending) {
				$(`<span class="duty-file-chip">📎 ${frappe.utils.escape_html(this._cr_pending.name)} <a>×</a></span>`)
					.appendTo($p)
					.find("a")
					.on("click", () => {
						this._cr_pending = null;
						show_pending();
					});
			}
		};
		const take_file = (f) => {
			if (!f) return;
			if (f.size > 15 * 1024 * 1024) {
				frappe.msgprint(__("File too large (max 15 MB)."));
				return;
			}
			this._cr_pending = f;
			show_pending();
		};
		$room.find(".duty-cr-mtabs a").on("click", (e) => {
			const rt = $(e.currentTarget).data("rt");
			$room.find(".duty-cr-mtabs a").removeClass("on");
			$(e.currentTarget).addClass("on");
			$room.toggleClass("rt-tasks", rt === "tasks");
		});
		$room.find(".duty-cr-attach input").on("change", (e) => {
			take_file(e.target.files[0]);
			e.target.value = "";
		});
		this.bind_recorder($room.find(".duty-cr-mic"), (file) => take_file(file));
		$input.on("paste", (e) => {
			for (const it of (e.originalEvent.clipboardData || {}).items || []) {
				if (it.kind === "file") {
					const f = it.getAsFile();
					if (f) {
						e.preventDefault();
						take_file(f);
						break;
					}
				}
			}
		});
		const send = async () => {
			const text = ($input.val() || "").trim();
			if (!text && !this._cr_pending) return;
			$input.val("");
			let up = null;
			if (this._cr_pending) {
				try {
					up = await this.upload_private_file(this._cr_pending);
					this._cr_pending = null;
					show_pending();
				} catch (err) {
					frappe.msgprint(__("Upload failed: {0}", [frappe.utils.escape_html(err.message || "")]));
					return;
				}
			}
			frappe.call({
				method: "duty_board.client_room.post_message",
				args: {
					name: x.name,
					message: text,
					internal: $int.is(":checked") ? 1 : 0,
					attachment_url: up ? up.file_url : null,
					attachment_name: up ? up.file_name : null,
					ref: this._cr_reply ? this._cr_reply.name : null,
				},
				callback: (r) => r.message && this.render_client_room(r.message),
			});
		};
		$room.find(".duty-cr-send").on("click", send);
		if (!this._draft_guard) {
			this._draft_guard = 1;
			this._drafts = {};
			this._draft_intent = 0;
			$(document).on("input.dutydraft", ".duty-cr-input, .duty-chat-input, textarea", (e) => {
				const k = e.currentTarget.className + (this._room_open || "");
				this._drafts[k] = $(e.currentTarget).val();
			});
			$(document).on("click.dutydraft keydown.dutydraft", (e) => {
				if (e.type === "click" || e.key === "Enter") this._draft_intent = Date.now();
			});
			setInterval(() => {
				$(".duty-cr-input, .duty-chat-input").each((_, el) => {
					const k = el.className + (this._room_open || "");
					const d3 = this._drafts[k];
					if (!d3 || $(el).val() || document.activeElement === el) return;
					if (Date.now() - this._draft_intent < 2500) delete this._drafts[k]; // sent or cleared on purpose
					else $(el).val(d3); // wiped by a re-render — bring it back
				});
			}, 800);
		}
		this._room_open = x.name;
		this.attach_mention_picker(
			$input,
			() =>
				(x.members || []).map((m) => ({
					user: m.user,
					full_name: `${m.full_name} · ${__("client")}`,
				}))
		);
		$input.on("keydown", (e) => {
			if (e.key === "Enter" && !e.shiftKey) {
				e.preventDefault();
				send();
			}
		});
		$room.find(".duty-cr-mktask").on("click", (e) => {
			const seed = $(e.currentTarget).data("text");
			const mid = $(e.currentTarget).data("mid");
			frappe.prompt(
				[
					{ fieldname: "title", fieldtype: "Data", label: __("Issue title"), default: seed, reqd: 1 },
					{ fieldname: "detail", fieldtype: "Small Text", label: __("Details (client-visible)") },
				],
				(v) =>
					frappe.call({
						method: "duty_board.client_room.make_task_from_message",
						args: { name: x.name, title: v.title, detail: v.detail || null, msg: mid || null },
						callback: (r) => r.message && this.render_client_room(r.message),
					}),
				__("Log client-visible issue"),
				__("Create")
			);
		});
		$room.find(".duty-cr-mkchreq").on("click", (e) => {
			const mid = $(e.currentTarget).data("mid");
			const seed = $(e.currentTarget).data("text");
			frappe.prompt(
				[{ fieldname: "title", fieldtype: "Data", label: __("Change request title"), default: seed, reqd: 1 }],
				(v) =>
					frappe.call({
						method: "duty_board.client_room.chreq_from_message",
						args: { name: x.name, msg: mid, title: v.title },
						callback: (r) => {
							if (r.message) {
								this.render_client_room(r.message);
								if (this._is_consultant && r.message.new_cr) {
									this.consultant_cr_edit(r.message.new_cr, { title: r.message.new_cr_title });
								} else {
									this.chreqs_dialog(r.message);
								}
							}
						},
					}),
				__("Draft change request — the client's message becomes the original request"),
				__("Draft")
			);
		});
		$room.find(".duty-cr-taskstoggle").on("click", () => {
			this._cr_tasks_open = this._cr_tasks_open === false;
			this.render_client_room(x);
		});
		$room.find(".duty-cr-tfilter").on("change", (e) => {
			this._cr_tfilter = e.target.value;
			this.render_client_room(x);
		});
		$room.find(".duty-cr-task").on("click", (e) => {
			const $t = $(e.currentTarget);
			if ($t.data("kind") === "issue") {
				this.issue_detail_dialog($t.data("name"));
			} else {
				frappe.call({
					method: "duty_board.projects.get_card",
					args: { name: $t.data("name") },
					callback: (r) => r.message && this.task_dialog(r.message.project, r.message),
				});
			}
		});
		$room.find(".duty-cr-openissues").on("click", () => {
			this._force_cfilter = true;
			this.issue_customer_filter = x.customer;
			this.issues_open = true;
			this.show_face("issues");
			this.refresh(true);
		});
		const $us = $room.find(".duty-cr-unsettled");
		if ($us.length && (x.unsettled || []).length) {
			$us.html(
				`<div class="duty-lead-section">📅 ${__("How did these go?")}</div>` +
					x.unsettled
						.map(
							(m) => `
					<div class="duty-cr-meeting">
						<b>${frappe.utils.escape_html(m.topic)}</b>
						<span>${frappe.datetime.str_to_user(m.meeting_date).slice(0, 5)} ${m.start_time}</span>
						<a class="duty-cr-mheld" data-id="${m.name}">✓ ${__("Held")}</a>
						<a class="duty-cr-mmissed" data-id="${m.name}">✗ ${__("Missed")}</a>
					</div>`
						)
						.join("")
			);
			const settle = (id, outcome) =>
				frappe.prompt(
					{ fieldname: "note", fieldtype: "Small Text", label: __("Note (client sees this — optional)") },
					(v) =>
						frappe.call({
							method: "duty_board.client_room.settle_meeting_outcome",
							args: { id: id, outcome: outcome, note: v.note || null },
							callback: (r) => r.message && this.render_client_room(r.message),
						}),
					outcome === "Held" ? __("Meeting held") : __("Meeting missed"),
					__("Save")
				);
			$us.find(".duty-cr-mheld").on("click", (e) => settle($(e.currentTarget).data("id"), "Held"));
			$us.find(".duty-cr-mmissed").on("click", (e) => settle($(e.currentTarget).data("id"), "Missed"));
		} else if ($us.length) {
			$us.empty();
		}
		const $ms = $room.find(".duty-cr-mstones");
		if ($ms.length) {
			const mst = x.milestones || [];
			const projCount = new Set(mst.map((m) => m.project).filter(Boolean)).size;
			if (projCount > 1) {
				// Multi-project room: the blended strip is meaningless — point to the
				// Projects face where each project's phases are managed on their own.
				$ms.html(`
					<div class="duty-lead-section">🏁 ${__("Phases")}</div>
					<div class="text-muted" style="font-size:var(--text-sm)">${__("This client has multiple projects. Manage each project's phases on the")} <a class="duty-cr-msgoproj" style="cursor:pointer;font-weight:600">${__("Projects face")}</a>.</div>
				`);
			} else {
				const done = mst.filter((m) => m.status === "Approved").length;
				const waiting = mst.filter((m) => m.status === "Awaiting Approval").length;
				const current = mst.find((m) => m.status === "In Progress");
				$ms.html(`
					<div class="duty-lead-section">🏁 ${__("Phases")} <a class="duty-cr-msgoproj" style="cursor:pointer">${__("Manage ›")}</a></div>
					${mst.length
						? `<div class="duty-cr-msline">
								<div class="duty-cr-msbar"><i style="width:${Math.round((done / mst.length) * 100)}%"></i></div>
								<span>${done}/${mst.length} ${__("approved")}${waiting ? ` · <b class="duty-cr-mswait">⏳ ${waiting} ${__("awaiting client")}</b>` : ""}${current ? ` · 🔵 ${frappe.utils.escape_html(current.title)}` : ""}</span>
							</div>`
						: `<div class="text-muted" style="font-size:var(--text-sm)">${__("No phases yet — manage on the Projects face.")}</div>`}
				`);
			}
			$ms.find(".duty-cr-msgoproj").on("click", () => this.show_face("projects"));
		}
		const $cq = $room.find(".duty-cr-chreqs");
		if ($cq.length) {
			const crs = x.change_requests || [];
			const waiting = crs.filter((c) => c.status === "Awaiting Approval").length;
			const approved = crs.filter((c) => ["Approved", "In Delivery", "Delivered"].includes(c.status));
			const declined = crs.filter((c) => c.status === "Declined").length;
			$cq.html(`
				<div class="duty-lead-section">💱 ${__("Change requests")} <a class="duty-cr-cqmanage">${__("Manage")}</a></div>
				${crs.length
					? `<div class="text-muted" style="font-size:var(--text-sm)">
							${approved.length}/${crs.length} ${__("approved")}${waiting ? ` · <b class="duty-cr-mswait">⏳ ${waiting} ${__("awaiting client")}</b>` : ""}${declined ? ` · ↩ ${declined} ${__("declined")}` : ""}${approved.length ? ` · ${approved.map((c) => c.approved_fmt).filter(Boolean).join(" + ") || ""}` : ""}
						</div>`
					: `<div class="text-muted" style="font-size:var(--text-sm)">${__("No change requests — paid scope beyond the subscription starts here.")}</div>`}
			`);
			$cq.find(".duty-cr-cqmanage").on("click", () => this.chreqs_dialog(x));
		}
		const $mt = $room.find(".duty-cr-meetings");
		if ($mt.length && (x.meetings || []).length) {
			$mt.html(
				`<div class="duty-lead-section">📅 ${__("Meetings")}</div>` +
					x.meetings
						.map(
							(m) => `
					<div class="duty-cr-meeting">
						<span class="duty-cr-mstatus ${m.status === "Confirmed" ? "ok" : "wait"}">${m.status === "Confirmed" ? "✅" : "⏳"}</span>
						<b>${frappe.utils.escape_html(m.topic)}</b>
						<span>${frappe.datetime.str_to_user(m.meeting_date).slice(0, 5)} ${m.start_time} · ${m.staff.map(frappe.utils.escape_html).join(", ")}${m.requested_first ? ` · 🙋 ${frappe.utils.escape_html(m.requested_first)}` : ""}</span>
						${m.status === "Pending" ? `<a class="duty-cr-mconfirm" data-id="${m.name}">✔ ${__("Confirm")}</a><a class="duty-cr-msuggest" data-id="${m.name}" data-topic="${frappe.utils.escape_html(m.topic)}" title="${__("Suggest another time")}">↷</a><a class="duty-cr-mdecline" data-id="${m.name}">✖</a>` : ""}
					</div>`
						)
						.join("")
			);
			$mt.find(".duty-cr-mconfirm").on("click", (e) => {
				const $row = $(e.currentTarget).closest("div");
				const roomName = x.name;
				frappe.call({
					method: "duty_board.client_room.confirm_meeting",
					args: { id: $(e.currentTarget).data("id") },
					callback: (r) => {
						// Optimistic: flip this row now; full re-render follows.
						$row.find(".duty-cr-mconfirm, .duty-cr-msuggest, .duty-cr-mdecline").remove();
						$row.find(".pill").removeClass("queued").addClass("done").text("✅ " + __("Confirmed"));
						$row.append(`<span style="color:#0E8A63;font-weight:700;font-size:12px"> ✅ ${__("Confirmed")}</span>`);
						if (r.message) this.render_client_room(r.message);
						else this.load_client_room(roomName);
					},
				});
			});
			$mt.find(".duty-cr-msuggest").on("click", (e) =>
				this.suggest_meeting_dialog(
					$(e.currentTarget).data("id"),
					$(e.currentTarget).data("topic"),
					(r) => r.message && this.render_client_room(r.message)
				)
			);
			$mt.find(".duty-cr-mdecline").on("click", (e) => {
				const id = $(e.currentTarget).data("id");
				frappe.prompt(
					{ fieldname: "reason", fieldtype: "Small Text", label: __("Why not? (client sees this)") },
					(v) =>
						frappe.call({
							method: "duty_board.client_room.decline_meeting",
							args: { id: id, reason: v.reason || null },
							callback: (r) => r.message && this.render_client_room(r.message),
						}),
					__("Decline meeting"),
					__("Decline")
				);
			});
		} else if ($mt.length) {
			$mt.empty();
		}
		$room.find(".duty-cr-shelfbtn").on("click", () => this.room_shelf_dialog(x));
		$room.find(".duty-cr-back").on("click", () => this.$clients.removeClass("cr-room-open"));
		$room.find(".duty-cr-academy").on("click", () => this.academy_dialog(x));
		$room.find(".duty-cr-deps").on("click", () => this.deps_dialog(x));
		$room.find(".duty-cr-uat").on("click", () => this.uat_dialog(x));
		$room.find(".duty-cr-tl").on("click", () => this.timeline_dialog(x));
		$room.find(".duty-cr-scope").on("click", () => {
			frappe.call({ method: "duty_board.client_room.room_projects", args: { name: x.name }, callback: (pr) => {
			  const projs = pr.message || [];
			  frappe.call({ method: "frappe.client.get_value", args: { doctype: "Client Room", filters: { name: x.name }, fieldname: ["scope_note", "support_plan", "project", "is_financial_room"] }, callback: (rv) => {
				const cur = rv.message || {};
				const d = new frappe.ui.Dialog({
					title: __("Room scope"),
					fields: [
						{ fieldname: "support_plan", fieldtype: "Data", label: __("Support plan (shown to client, e.g. 'Unlimited support · changes quoted via CR')"), default: cur.support_plan || "" },
						{ fieldname: "scope_note", fieldtype: "Small Text", label: __("Contract scope — supported modules & boundaries"), default: cur.scope_note || "" },
						{ fieldname: "projects_html", fieldtype: "HTML", label: __("Projects in this room") },
						{ fieldname: "is_financial_room", fieldtype: "Check", label: __("📊 Financial Room — statements, announcements & review actions for this customer live here (one per customer)"), default: cur.is_financial_room || 0 },
					],
					primary_action_label: __("Save"),
					primary_action: (v) => {
						const picked = [];
						d.$wrapper.find(".duty-projpick:checked").each((i, el) => picked.push($(el).val()));
						frappe.call({ method: "duty_board.commercial.set_room_scope", args: { name: x.name, scope_note: v.scope_note || "", support_plan: v.support_plan || "", is_financial_room: v.is_financial_room ? 1 : 0 } });
						frappe.call({ method: "duty_board.client_room.room_assign_projects", args: { name: x.name, project_names: JSON.stringify(picked) }, callback: () => { d.hide(); frappe.show_alert({ message: __("⚖ Scope & projects saved"), indicator: "green" }); this.render_client_room(x); } });
					},
				});
				const rows = projs.map((p) => `<label style="display:flex;gap:8px;align-items:center;padding:5px 0"><input type="checkbox" class="duty-projpick" value="${frappe.utils.escape_html(p.name)}" ${p.mine ? "checked" : ""}> <span>${frappe.utils.escape_html(p.label)}${p.other_room ? ` <span style="color:#B45309;font-size:11px">(currently in another room — ticking moves it here)</span>` : ""}</span></label>`).join("");
				d.fields_dict.projects_html.$wrapper.html(`<div style="border:1px solid #e6e6e6;border-radius:8px;padding:8px 12px">${rows || `<span class="text-muted">${__("No projects for this customer yet.")}</span>`}<div class="text-muted" style="font-size:11px;margin-top:6px">${__("A project belongs to exactly one room. Ticking it here moves it here.")}</div></div>`);
				d.show();
			  }});
			}});
		});
		$room.find(".duty-cr-metrics").on("click", () =>
			frappe.call({
				method: "duty_board.client_room.room_metrics",
				args: { name: x.name },
				callback: (r) => {
					const m = r.message || {};
					const d = new frappe.ui.Dialog({ title: `📈 ${frappe.utils.escape_html(x.customer || "")} — ${__("Live metrics")}` });
					const tile = (v, l) => (v === null || v === undefined) ? "" : `<div class="duty-mtile"><b>${frappe.utils.escape_html(String(v))}</b><span>${frappe.utils.escape_html(l)}</span></div>`;
					$(d.body).html(`<div class="duty-mtiles">
						${tile(m.open_now, __("open now"))}
						${tile(m.new_30, __("new · 30 days"))}
						${tile(m.resolved_30, __("completed · 30 days"))}
						${tile(m.avg_ack, __("avg response"))}
						${tile(m.avg_res, __("avg resolution"))}
						${tile(m.ack_pct !== null ? m.ack_pct + "%" : null, __("responded within SLA"))}
						${tile(m.res_pct !== null ? m.res_pct + "%" : null, __("resolved within SLA"))}
						${tile(m.avg_stars !== null ? "★ " + m.avg_stars : null, __("client rating") + ` (${m.rated_n})`)}
						${tile(m.ms_pct !== null ? m.ms_pct + "%" : null, __("milestones approved") + ` (${m.ms_done}/${m.ms_total})`)}
					</div>`);
					if (!$(d.body).find(".duty-mtile").length)
						$(d.body).html(`<div class="text-muted">${__("Numbers appear as work happens.")}</div>`);
					d.show();
				},
			})
		);
		$room.find(".duty-cr-report").on("click", () =>
			frappe.confirm(
				__("Generate last month's service report and place it on this room's shelf? The client is notified."),
				() =>
					frappe.call({
						method: "duty_board.client_room.generate_service_report",
						args: { name: x.name },
						callback: (r) => {
							if (r.message)
								frappe.show_alert({
									message: __("📊 {0} report published to the shelf", [r.message.label]),
									indicator: "green",
								});
							this.load_client_room(x.name);
						},
					})
			)
		);
		$room.find(".duty-cr-rename").on("click", () =>
			frappe.prompt(
				{ fieldname: "unit", fieldtype: "Data", label: __("Room name"), default: x.unit || "General", reqd: 1 },
				(v) =>
					frappe.call({
						method: "duty_board.client_room.rename_room_unit",
						args: { name: x.name, unit: v.unit },
						callback: (r) => {
							if (r.message) this.render_client_room(r.message);
							this.refresh_clients(true);
						},
					}),
				__("Rename room"),
				__("Rename")
			)
		);
		$room.find(".duty-cr-delete").on("click", () =>
			frappe.confirm(
				__("Delete <b>{0} · {1}</b>?<br><br>All messages, members, shelf documents and meetings in this room are permanently removed. Client-visible issues survive and move to the General room.", [
					frappe.utils.escape_html(x.customer),
					frappe.utils.escape_html(x.unit || "General"),
				]),
				() =>
					frappe.call({
						method: "duty_board.client_room.delete_room",
						args: { name: x.name },
						callback: () => {
							this._open_room = null;
							this.refresh_clients();
							frappe.show_alert({ message: __("Room deleted"), indicator: "orange" });
						},
					})
			)
		);
		$room.find(".duty-cr-owner").on("click", () =>
			frappe.prompt(
				{
					fieldname: "owner",
					fieldtype: "Autocomplete",
					label: __("Account manager"),
					options: this.staff_options(),
					default: x.owner_user || "",
				},
				(v) =>
					frappe.call({
						method: "duty_board.client_room.set_room_owner",
						args: { name: x.name, owner: v.owner || null },
						callback: (r) => r.message && this.render_client_room(r.message),
					}),
				__("Who owns this account?"),
				__("Set")
			)
		);
		$room.find(".duty-cr-membersbtn").on("click", () => this.room_members_dialog(x));
		$room.find(".duty-cr-accessbtn").on("click", () => {
			frappe.call({
				method: "duty_board.client_room.room_staff_access",
				args: { name: x.name },
				callback: (r) => {
					const a = r.message || {};
					if (!a.can_edit) {
						frappe.msgprint(__("Only the room owner{0} or a System Manager can curate staff access.", [a.owner ? ` (${frappe.utils.escape_html(this.name_map[a.owner] || a.owner)})` : ""]));
						return;
					}
					const staff = Object.keys(this.name_map || {}).map((u) => ({ value: u, description: this.name_map[u] }));
					const d2 = new frappe.ui.Dialog({
						title: __("🔑 Staff access — {0}", [frappe.utils.escape_html(x.customer)]),
						fields: [
							{ fieldname: "note", fieldtype: "HTML", options: `<p style="font-size:12px;color:#65736F">${__("Leave EMPTY and every staff member sees this room (the default). Add names and only they, the owner, and System Managers see it. Consultants are governed separately by Members.")}</p>` },
							{ fieldname: "users", fieldtype: "MultiSelectPills", label: __("Staff who see this room"), get_data: () => staff, default: a.users || [] },
							{ fieldname: "owner", fieldtype: "Autocomplete", label: __("Room owner"), options: staff.map((s) => ({ value: s.value, label: s.description })), default: a.owner || "" },
						],
						primary_action_label: __("Save"),
						primary_action: (v) => {
							d2.hide();
							frappe.call({
								method: "duty_board.client_room.set_room_staff_access",
								args: { name: x.name, users: v.users || [], owner: v.owner || "" },
								callback: () => frappe.show_alert({ message: __("🔑 Access updated."), indicator: "green" }),
							});
						},
					});
					d2.show();
				},
			});
		});
		$room.find(".duty-cr-freeze").on("click", () =>
			frappe.call({
				method: "duty_board.client_room.set_room_status",
				args: { name: x.name, status: x.status === "Active" ? "Frozen" : "Active" },
				callback: () => this.load_client_room(x.name),
			})
		);
	}

	pricing_dialog() {
		frappe.call({
			method: "duty_board.commercial.pricing_queue",
			callback: (r) => {
				const q = (r.message || {}).queue || [];
				const d = new frappe.ui.Dialog({ title: __("💼 CRs awaiting your pricing"), size: "large" });
				$(d.body).html(
					q.length
						? q.map((z) => `<div style="border:1px solid #e2e8f0;border-radius:8px;padding:8px;margin-bottom:8px${z.age_days > 2 ? ";background:#fffbeb" : ""}">
							<b>${frappe.utils.escape_html(z.customer)}</b> · ${frappe.utils.escape_html(z.title)}
							<span style="float:right;font-size:11px;font-weight:700;color:${z.age_days > 2 ? "#b45309" : "#64748b"}">${z.age_days}d ${__("waiting")}</span>
							<div class="text-muted" style="font-size:12px;margin:4px 0">${frappe.utils.escape_html((z.original_request || z.reason || "").slice(0, 300))}</div>
							<button class="btn btn-xs btn-primary" data-price="${z.name}">${__("Decide")}</button>
						</div>`).join("")
						: `<p class="text-muted">${__("Queue clear — nothing awaiting pricing.")}</p>`
				);
				$(d.body).find("[data-price]").on("click", (e) => {
					const id = $(e.currentTarget).data("price");
					frappe.prompt(
						[
							{ fieldname: "decision", fieldtype: "Select", label: __("Decision"), options: ["Priced", "Covered by Subscription", "Goodwill", "Rejected", "Deferred"], reqd: 1 },
							{ fieldname: "price", fieldtype: "Currency", label: __("Price (₦, for Priced)") },
							{ fieldname: "estimate_hours", fieldtype: "Float", label: __("Estimated hours") },
							{ fieldname: "note", fieldtype: "Small Text", label: __("Note (kept on the CR)") },
						],
						(v) => frappe.call({
							method: "duty_board.commercial.chreq_price",
							args: { name: id, decision: v.decision, price: v.price || 0, estimate_hours: v.estimate_hours || 0, note: v.note || null },
							callback: () => { d.hide(); this.pricing_dialog(); },
						}),
						__("Price this CR"), __("Apply")
					);
				});
				d.show();
			},
		});
	}

	cost_dialog() {
		frappe.call({
			method: "duty_board.commercial.cost_to_serve",
			args: { months: 1 },
			callback: (r) => {
				const m = r.message || {};
				const d = new frappe.ui.Dialog({ title: __("💰 Cost to serve — last {0} month(s)", [m.months]), size: "extra-large" });
				const naira = (v) => (v || v === 0 ? "₦" + Number(v).toLocaleString() : "—");
				$(d.body).html(`
					${!m.rate ? `<div style="background:#fffbeb;border-radius:8px;padding:8px;font-size:12px;margin-bottom:8px">⚠ ${__("Set the blended staff cost rate in Duty Settings to see costs and margins.")}</div>` : ""}
					<table class="table table-sm" style="font-size:12px"><tr><th>${__("Customer")}</th><th>${__("Hours")}</th><th>${__("Support")}</th><th>${__("Delivery")}</th><th>${__("Cost")}</th><th>${__("Known fee/mo")}</th><th></th></tr>
					${(m.rows || []).map((z) => `<tr style="${z.fee_covers === false ? "background:#fef2f2" : ""}">
						<td><b>${frappe.utils.escape_html(z.customer)}</b><br><span class="text-muted">${z.staff_count} ${__("staff")}</span></td>
						<td><b>${z.hours}</b></td><td>${z.support_hours}</td><td>${z.delivery_hours}</td>
						<td>${naira(z.cost)}</td><td>${naira(z.monthly_fee)}</td>
						<td>${z.fee_covers === false ? `<b style="color:#b91c1c">${__("under water")}</b>` : z.fee_covers ? `<span style="color:#15803d">✓</span>` : ""}</td>
					</tr>`).join("")}</table>
					<p class="text-muted" style="font-size:11px">${__("Hours from work sessions with a customer; fee shown where known (accounting fee today). Red rows: attention cost exceeds known fee — a renewal-conversation list, not an invoice list.")}</p>
					<div class="duty-alloc"><div class="text-muted" style="font-size:12px">${__("Loading service-line allocation…")}</div></div>
				`);
				d.show();
				frappe.call({
					method: "duty_board.commercial.service_line_allocation",
					args: { months: 1 },
					callback: (ar) => {
						const a = ar.message || {};
						const lines = a.lines || [];
						const hdr = lines.map((l) => `<th>${frappe.utils.escape_html(l.replace("Accounting Service", "Accounting").replace("Internal & Product", "Internal"))}</th>`).join("");
						const body = (a.rows || []).map((p) => `<tr>
							<td><b>${frappe.utils.escape_html(p.full_name)}</b></td>
							${lines.map((l) => `<td>${p.lines[l] ? `<b>${p.lines[l]}</b>` : `<span class="text-muted">—</span>`}</td>`).join("")}
							<td><b>${p.total_hours}</b></td><td>${naira(p.cost)}</td>
						</tr>`).join("");
						$(d.body).find(".duty-alloc").html(`
							<h5 style="margin:14px 0 6px">👤 ${__("By person × service line — hours (last month)")}</h5>
							<table class="table table-sm" style="font-size:12px"><tr><th>${__("Person")}</th>${hdr}<th>${__("Total")}</th><th>${__("Cost")}</th></tr>${body}</table>
							<p class="text-muted" style="font-size:11px">${__("Untyped = unlinked sessions logged before service lines existed (or a person's first unlinked session). Bulk-classify history once and the column empties; the sticky default keeps it empty.")}</p>
							<div class="duty-pay"><div class="text-muted" style="font-size:12px">${__("Loading payouts…")}</div></div>
						`);
						const loadPay = (py, pm) => {
							$(d.body).find(".duty-pay").html(`<div class="text-muted" style="font-size:12px">${__("Loading payouts…")}</div>`);
							frappe.call({
								method: "duty_board.earnings.earnings_summary",
								args: py ? { year: py, month: pm } : {},
								callback: (pr) => {
									const P = pr.message || {};
									const T = { h: 0, ha: 0, rc: 0, ra: 0, pa: 0, g: 0 };
									const rows = (P.rows || []).map((p) => {
										T.h += p.paid_hours; T.ha += p.hours_amt; T.rc += p.res_count; T.ra += p.res_amt; T.pa += p.phase_amt; T.g += p.grand;
										return `<tr>
										<td><b>${frappe.utils.escape_html(p.full_name)}</b></td>
										<td>${p.paid_hours}h${p.capped ? " ⛔" : ""}<div class="text-muted" style="font-size:10.5px">${p.linked_hours}h ${__("linked")} / ${p.unlinked_hours}h ${__("unlinked")}</div></td>
										<td>${naira(p.hours_amt)}</td>
										<td>${p.res_count}</td>
										<td>${naira(p.res_amt)}</td>
										<td>${naira(p.phase_amt)}</td>
										<td><b>${naira(p.grand)}</b></td>
									</tr>`;
									}).join("");
									const nd = frappe.datetime.now_date().split("-");
									const cy = parseInt(nd[0]), cm = parseInt(nd[1]);
									const ly = cm === 1 ? cy - 1 : cy, lm = cm === 1 ? 12 : cm - 1;
									const isCur = P.month === cm && P.year === cy;
									$(d.body).find(".duty-pay").html(`
										<h5 style="margin:14px 0 6px">💵 ${__("Payouts")} — ${frappe.utils.escape_html(P.label || "")}
											<span class="duty-pay-tog"><a data-y="${cy}" data-m="${cm}" class="${isCur ? "on" : ""}">${__("This month")}</a><a data-y="${ly}" data-m="${lm}" class="${isCur ? "" : "on"}">${__("Last month")}</a></span></h5>
										${rows ? `<table class="table table-sm" style="font-size:12px"><tr><th>${__("Person")}</th><th>${__("Paid hours")}</th><th>${__("Hours ₦")}</th><th>${__("Res.")}</th><th>${__("Res. ₦")}</th><th>${__("Phase ₦")}</th><th>${__("Total")}</th></tr>${rows}
										<tr class="duty-pay-tot"><td><b>${__("Total to pay")}</b></td><td><b>${Math.round(T.h * 10) / 10}h</b></td><td><b>${naira(T.ha)}</b></td><td><b>${T.rc}</b></td><td><b>${naira(T.ra)}</b></td><td><b>${naira(T.pa)}</b></td><td><b>${naira(T.g)}</b></td></tr></table>
										${P.closed ? `<p style="font-size:12px;color:#0B6B4F;font-weight:700">🔒 ${__("Closed")} ${frappe.utils.escape_html(P.closed_on || "")}${P.closed_by ? ` ${__("by")} ${frappe.utils.escape_html(P.closed_by)}` : ""} — ${__("these figures are frozen.")}</p>` : !isCur ? `<button class="btn btn-xs btn-default duty-pay-close" data-y="${P.year}" data-m="${P.month}">🔒 ${__("Close")} ${frappe.utils.escape_html(P.label || "")} — ${__("freeze these figures")}</button>` : ""}
										<p class="text-muted" style="font-size:11px">${__("⛔ = monthly cap reached. Watch the unlinked share — a rising unlinked fraction means hours are drifting away from issues and tasks.")}</p>` : `<p class="text-muted" style="font-size:12px">${__("No earnings recorded for")} ${frappe.utils.escape_html(P.label || "")}.</p>`}`);
									$(d.body).find(".duty-pay-tog a").on("click", (ev) => loadPay($(ev.currentTarget).data("y"), $(ev.currentTarget).data("m")));
									$(d.body).find(".duty-pay-close").on("click", (ev) => {
										const y = $(ev.currentTarget).data("y"), m = $(ev.currentTarget).data("m");
										frappe.confirm(__("Close this month? Figures freeze permanently — rate changes and record edits will no longer move them."), () =>
											frappe.call({ method: "duty_board.earnings.close_month", args: { year: y, month: m }, callback: () => { frappe.show_alert({ message: __("Month closed."), indicator: "green" }); loadPay(y, m); } }));
									});
								},
							});
						};
						loadPay();
					},
				});
			},
		});
	}

	book_matcher(query, cb) {
		const d = new frappe.ui.Dialog({ title: __("🔎 Find the book"), size: "large" });
		let settled = false;
		const done = (meta) => { if (!settled) { settled = true; d.hide(); cb(meta); } };
		$(d.body).html(`
			<div style="display:flex;gap:8px;margin-bottom:10px">
				<input type="text" class="form-control input-sm duty-bkm-q">
				<button class="btn btn-sm btn-primary duty-bkm-go">${__("Search")}</button>
			</div>
			<div class="duty-bkm-res"><div class="text-muted">${__("Searching…")}</div></div>
			<a class="duty-bkm-none" style="cursor:pointer;font-size:12.5px;color:#6B7772;display:inline-block;margin-top:8px">${__("Skip — fill details by hand")}</a>`);
		const $res = $(d.body).find(".duty-bkm-res");
		const run = (q) => {
			$res.html(`<div class="text-muted">${__("Searching…")}</div>`);
			frappe.call({
				method: "duty_board.library.search_books",
				args: { query: q },
				callback: (r) => {
					const hits = r.message || [];
					if (!hits.length) {
						$res.html(`<div class="text-muted">${__("No matches for")} “${frappe.utils.escape_html(q)}” — ${__("try fewer or different words.")}</div>`);
						return;
					}
					$res.html(
						hits.map((h, i) => `
						<div class="duty-bkm" data-i="${i}" style="display:flex;gap:12px;border:1px solid #E8E5DD;border-radius:10px;padding:10px 12px;margin-bottom:8px;cursor:pointer">
							${h.thumbnail ? `<img src="${h.thumbnail}" style="width:52px;height:78px;object-fit:cover;border-radius:6px;flex:none">` : `<div style="width:52px;height:78px;background:#EFEDE6;border-radius:6px;flex:none"></div>`}
							<div style="min-width:0">
								<b style="font-size:13.5px">${frappe.utils.escape_html(h.title)}${h.subtitle ? `: ${frappe.utils.escape_html(h.subtitle)}` : ""}</b>
								<div class="text-muted" style="font-size:12px">${frappe.utils.escape_html(h.authors)}${h.year ? ` · ${h.year}` : ""}${h.publisher ? ` · ${frappe.utils.escape_html(h.publisher)}` : ""}${h.pages ? ` · ${h.pages}p` : ""}</div>
								${h.description ? `<div class="text-muted" style="font-size:11.5px;margin-top:3px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${frappe.utils.escape_html(h.description)}</div>` : ""}
							</div>
						</div>`).join("")
					);
					$res.find(".duty-bkm").on("click", (e) => done(hits[$(e.currentTarget).data("i")]));
				},
				error: () => {
					$res.html(`<div style="color:#B0443C;font-size:12.5px">${__("Book search is unreachable from the server (outbound access to googleapis.com). You can still fill details by hand.")}</div>`);
				},
			});
		};
		$(d.body).find(".duty-bkm-q").val(query).on("keydown", (e) => { if (e.key === "Enter") run($(e.currentTarget).val()); });
		$(d.body).find(".duty-bkm-go").on("click", () => run($(d.body).find(".duty-bkm-q").val()));
		$(d.body).find(".duty-bkm-none").on("click", () => done(null));
		d.on_hide = () => { if (!settled) { settled = true; cb(null); } };
		d.show();
		run(query);
	}

	refresh_library() {
		frappe.call({
			method: "duty_board.library.library",
			callback: (r) => {
				const m0 = r.message || {};
				this._lib_books = m0.books || [];
				this._lib_mgr = !!m0.manager;
				this._lib_render();
			},
		});
	}

	_lib_grad(seed) {
		const G = [
			["#123C35", "#0E8A63"], ["#1C2E4A", "#3D6B9E"], ["#4A1C3A", "#9E3D6B"],
			["#4A3A1C", "#B27409"], ["#233229", "#5C8A6E"], ["#2F1C4A", "#6B3D9E"],
		];
		let h = 0;
		for (const c of seed || "x") h = (h * 31 + c.charCodeAt(0)) | 0;
		const g = G[Math.abs(h) % G.length];
		return `linear-gradient(150deg, ${g[0]}, ${g[1]})`;
	}

	_lib_render() {
		const esc = frappe.utils.escape_html;
		const books = this._lib_books || [];
		const mgr = this._lib_mgr;
		const q = (this._lib_q || "").toLowerCase();
		const cat = this._lib_cat || "All";
		const $L = this.$library.empty();
		const counts = {};
		books.forEach((b) => {
			const c = b.category || __("Uncategorised");
			counts[c] = (counts[c] || 0) + 1;
		});
		const cats = Object.keys(counts).sort((a, b2) => (a === __("Uncategorised")) - (b2 === __("Uncategorised")) || a.localeCompare(b2));
		const visible = books.filter((b) =>
			(cat === "All" || (b.category || __("Uncategorised")) === cat) &&
			(!q || (b.title + " " + (b.author || "")).toLowerCase().includes(q))
		);
		const chip = (c, n) => `<a class="duty-lb-chip ${cat === c ? "on" : ""}" data-cat="${esc(c)}">${esc(__(c))}${n != null ? ` <i>${n}</i>` : ""}</a>`;
		$L.append(`
			<div class="duty-lb-head">
				<h3>📚 ${__("Library")}</h3>
				<input type="text" class="duty-lb-search" placeholder="🔎 ${__("Search title or author…")}" value="${esc(this._lib_q || "")}">
				${mgr ? `<span class="duty-lb-admin"><input type="file" accept=".pdf,.epub" class="duty-bk-file"><button class="btn btn-sm btn-primary duty-bk-up">＋ ${__("Add book")}</button></span>` : ""}
			</div>
			<div class="duty-lb-chips">${chip("All", books.length)}${cats.map((c) => chip(c, counts[c])).join("")}</div>`);

		const TILE = (b, mini) => {
			const done = b.pct >= 100;
			const cover = b.cover
				? `<span class="duty-lb-cover" style="background-image:url('${esc(b.cover)}')"></span>`
				: `<span class="duty-lb-cover duty-lb-fallback" style="background:${this._lib_grad(b.title)}"><i>${esc(b.title)}</i></span>`;
			const ring = b.pct > 0 && !done
				? `<span class="duty-lb-ring" style="background:conic-gradient(#FFC53D ${b.pct * 3.6}deg, rgba(255,255,255,.28) 0)"><i>${b.pct}%</i></span>`
				: done ? `<span class="duty-lb-ring duty-lb-done">✓</span>`
				: `<span class="duty-lb-newtag">${__("new")}</span>`;
			const stars = b.rating_n ? `★ ${b.rating_avg}` : "";
			return `
			<a class="duty-lb-tile ${mini ? "duty-lb-mini" : ""}" data-book="${b.name}">
				<span class="duty-lb-coverwrap">${cover}${ring}${mgr && !mini ? `<span class="duty-lb-menu" data-book="${b.name}">⋯</span>` : ""}</span>
				<span class="duty-lb-title">${esc(b.title)}</span>
				<span class="duty-lb-meta">${esc(b.author || "")}</span>
				<span class="duty-lb-meta2">${b.chapter_count} ${__("ch")}${b.words ? ` · ${Math.round(b.words / 200)}m` : ""}${stars ? ` · <b>${stars}</b>` : ""}</span>
			</a>`;
		};

		const reading = visible.filter((b) => b.pct > 0 && b.pct < 100)
			.sort((a, b2) => (b2.last_read_at || "").localeCompare(a.last_read_at || ""));
		if (reading.length && !q) {
			$L.append(`
				<div class="duty-lb-cat"><b>🔥 ${__("Continue reading")}</b></div>
				<div class="duty-lb-shelf">${reading.map((b) => TILE(b, true)).join("")}</div>`);
		}
		if (!visible.length) {
			$L.append(`<div class="duty-lb-empty">${q ? __("Nothing matches — try fewer letters.") : __("No books on this shelf yet.")}</div>`);
		}
		cats.filter((c) => cat === "All" || c === cat).forEach((c) => {
			const shelf = visible.filter((b) => (b.category || __("Uncategorised")) === c)
				.sort((a, b2) => (b2.pct > 0 && b2.pct < 100) - (a.pct > 0 && a.pct < 100) || a.title.localeCompare(b2.title));
			if (!shelf.length) return;
			$L.append(`
				<div class="duty-lb-cat"><b>${esc(c)}</b><span>${shelf.length}</span></div>
				<div class="duty-lb-shelf">${shelf.map((b) => TILE(b)).join("")}</div>`);
		});

		// ── bindings ──
		$L.find(".duty-lb-search").on("input", (e) => {
			this._lib_q = $(e.currentTarget).val();
			clearTimeout(this._lib_t);
			this._lib_t = setTimeout(() => {
				const pos = $L.find(".duty-lb-search")[0];
				this._lib_render();
				const el = this.$library.find(".duty-lb-search")[0];
				el.focus();
				el.setSelectionRange(el.value.length, el.value.length);
			}, 180);
		});
		$L.find(".duty-lb-chip").on("click", (e) => {
			this._lib_cat = $(e.currentTarget).data("cat");
			this._lib_render();
		});
		$L.find(".duty-lb-tile").on("click", (e) => {
			if ($(e.target).is(".duty-lb-menu")) return;
			e.preventDefault();
			this.open_reader($(e.currentTarget).data("book"));
		});
		$L.find(".duty-lb-menu").on("click", (e) => {
			e.preventDefault();
			e.stopPropagation();
			$(".duty-lb-pop").remove();
			const bk = $(e.currentTarget).data("book");
			const $pop = $(`
				<div class="duty-lb-pop">
					<a class="duty-bk-edit" data-book="${bk}">✎ ${__("Edit")}</a>
					<a class="duty-bk-fetch" data-book="${bk}">🔎 ${__("Fetch cover & info")}</a>
					<a class="duty-bk-del" data-book="${bk}">🗑 ${__("Remove")}</a>
				</div>`).appendTo(document.body);
			const r2 = e.currentTarget.getBoundingClientRect();
			$pop.css({ top: r2.bottom + 4 + "px", left: Math.max(8, r2.right - 170) + "px" });
			setTimeout(() => $(document).one("click.dutylbpop", () => $pop.remove()), 0);
			this._lib_bind_admin($pop);
		});
		this._lib_bind_admin($L);
		if (mgr) {
			$L.find(".duty-bk-up").on("click", () => {
				const f = $L.find(".duty-bk-file")[0].files[0];
				if (!f) {
					$L.find(".duty-bk-file").trigger("click");
					return;
				}
				const guess = f.name.replace(/\.(pdf|epub)$/i, "").replace(/[_\-]+/g, " ").replace(/\(z-lib[^)]*\)|z-?library|1lib\.\w+/gi, "").trim();
				this.book_matcher(guess, (meta) =>
				frappe.prompt(
					[
						{ fieldname: "title", fieldtype: "Data", label: __("Title"), default: (meta && meta.title) || guess, reqd: 1 },
						{ fieldname: "author", fieldtype: "Data", label: __("Author"), default: (meta && meta.authors) || "" },
						{ fieldname: "category", fieldtype: "Data", label: __("Category (shelf section, e.g. Leadership, ERP, Sales)"), default: (meta && meta.categories) || "" },
						{ fieldname: "description", fieldtype: "Small Text", label: __("Why the team should read it"), default: (meta && meta.description) || "" },
					],
					(v) => {
						v.cover_url = (meta && meta.thumbnail) || null;
						const fd = new FormData();
						fd.append("file", f);
						fd.append("is_private", "1");
						fetch("/api/method/upload_file", { method: "POST", headers: { "X-Frappe-CSRF-Token": frappe.csrf_token }, body: fd })
							.then((res) => res.json())
							.then((j) => {
								const url = j.message && j.message.file_url;
								if (!url) throw new Error("upload failed");
								return frappe.call({ method: "duty_board.library.convert_pdf", args: { file_url: url, title: v.title, author: v.author || null, category: v.category || null, description: v.description || null, cover_url: v.cover_url } });
							})
							.then(() => frappe.show_alert({ message: __("📚 Converting in the background — you'll be notified when it's on the shelf."), indicator: "blue" }))
							.catch(() => frappe.msgprint(__("Upload failed — try again.")));
					},
					__("New book"), __("Convert")
				));
			});
		}
	}

	_lib_bind_admin($host) {
		const books = this._lib_books || [];
		$host.find(".duty-bk-fetch").off("click").on("click", (e) => {
			e.stopPropagation();
			$(".duty-lb-pop").remove();
			const bk = $(e.currentTarget).data("book");
			const b = books.find((x) => x.name === bk) || {};
			this.book_matcher(b.title + " " + (b.author || ""), (meta) => {
				if (!meta) return;
				frappe.call({
					method: "duty_board.library.apply_book_meta",
					args: { book: bk, title: meta.title, author: meta.authors || "", description: meta.description || "", category: b.category || meta.categories || "", cover_url: meta.thumbnail || null },
					callback: () => this.refresh_library(),
				});
			});
		});
		$host.find(".duty-bk-del").off("click").on("click", (e) => {
			e.stopPropagation();
			$(".duty-lb-pop").remove();
			const bk = $(e.currentTarget).data("book");
			frappe.confirm(__("Remove this book and everyone's reading progress in it?"), () =>
				frappe.call({ method: "duty_board.library.delete_book", args: { book: bk }, callback: () => this.refresh_library() })
			);
		});
		$host.find(".duty-bk-edit").off("click").on("click", (e) => {
			e.stopPropagation();
			$(".duty-lb-pop").remove();
			const bk = $(e.currentTarget).data("book");
			const b = books.find((x) => x.name === bk) || {};
			frappe.prompt(
				[
					{ fieldname: "title", fieldtype: "Data", label: __("Title"), default: b.title, reqd: 1 },
					{ fieldname: "author", fieldtype: "Data", label: __("Author"), default: b.author || "" },
					{ fieldname: "category", fieldtype: "Data", label: __("Category"), default: b.category || "" },
					{ fieldname: "description", fieldtype: "Small Text", label: __("Description"), default: b.description || "" },
				],
				(v) => frappe.call({ method: "duty_board.library.update_book", args: { book: bk, title: v.title, author: v.author || "", category: v.category || "", description: v.description || "" }, callback: () => this.refresh_library() }),
				__("Edit book"), __("Save")
			);
		});
	}

	open_reader(book) {
		frappe.call({
			method: "duty_board.library.open_book",
			args: { book: book },
			callback: (r) => {
				const m = r.message;
				if (!m) return;
				const $L = this.$library.empty();
				let cur = m.current;
				let opened_at = Date.now();
				const doneSet = new Set(m.done || []);
				$L.append(`
					<div class="duty-rd-head" style="display:flex;align-items:center;gap:12px;margin:4px 0 10px;flex-wrap:wrap">
						<a class="duty-rd-back" style="cursor:pointer;font-weight:600;color:#6B7772">‹ ${__("Library")}</a>
						<b style="font-size:16px">${frappe.utils.escape_html(m.title)}</b>
						${m.author ? `<span class="text-muted" style="font-size:12.5px">${frappe.utils.escape_html(m.author)}</span>` : ""}
						<span style="margin-left:auto" class="duty-rd-stars"></span>
						<a class="duty-rd-revs" style="cursor:pointer;font-size:12.5px;color:#0E5A4A"></a>
						<span class="duty-rd-opts" style="display:inline-flex;gap:2px;background:#f0efe9;border-radius:8px;padding:2px;margin-left:6px">
							<a class="duty-rd-opt" data-o="toc" title="${__("Show/hide contents")}">☰</a>
							<a class="duty-rd-opt" data-o="two" title="${__("Two-page spread")}">▥</a>
							<a class="duty-rd-opt" data-o="just" title="${__("Justify text")}">≣</a>
							<a class="duty-rd-aa" title="${__("Appearance")}">⚙ Aa</a>
							<a class="duty-rd-bmk" title="${__("Bookmark this spot")}">🔖</a>
							<a class="duty-rd-zenbtn" title="${__("Immersive mode")}">⛶</a>
							<a class="duty-rd-listen" title="${__("Listen to this chapter")}">🔊</a>
							<a class="duty-rd-marks" title="${__("Highlights & bookmarks")}">🖍</a>
							<a class="duty-rd-find" title="${__("Search inside this book")}">🔎</a>
						</span>
					</div>
					<div class="duty-rd-revpanel" style="display:none;border:1px solid #E8E5DD;border-radius:12px;padding:12px 14px;margin-bottom:10px"></div>
					<div class="duty-rd-hlpanel" style="display:none"></div>
					<div class="duty-rd-findpanel" style="display:none"></div>
					<div class="duty-rd-prog">
						<input type="range" class="duty-rd-scrub" min="0" max="1000" value="0" list="duty-rd-ticks">
						<datalist id="duty-rd-ticks"></datalist>
						<span></span>
					</div>
					<div style="display:flex;gap:20px">
						<div class="duty-rd-toc" style="width:250px;flex:none;position:sticky;top:60px;align-self:flex-start;max-height:calc(100vh - 140px);overflow-y:auto;border-right:1px solid #E8E5DD;padding-right:10px"></div>
						<div class="duty-rd-col" style="flex:1;min-width:0">
							<div class="duty-rd-scroller"><div class="duty-rd-body" style="font-size:16px;line-height:1.8;color:#182420"></div></div>
							<div class="duty-rd-nav" style="display:flex;gap:8px;padding:16px 0 40px;border-top:1px solid #E8E5DD;margin-top:18px;align-items:center">
								<button class="btn btn-sm btn-default duty-rd-prev">‹ ${__("Previous")}</button>
								<span class="duty-rd-pgbtns" style="display:none;margin:0 auto">
									<button class="btn btn-sm btn-default duty-rd-pgprev">‹ ${__("Page")}</button>
									<button class="btn btn-sm btn-default duty-rd-pgnext">${__("Page")} ›</button>
								</span>
								<button class="btn btn-sm btn-primary duty-rd-next" style="margin-left:auto">${__("Finish chapter & continue")} ›</button>
							</div>
						</div>
					</div>`);
				const $toc = $L.find(".duty-rd-toc");
				const $bd = $L.find(".duty-rd-body");
				const $sc = $L.find(".duty-rd-scroller");
				const chIdx = (name) => m.chapters.findIndex((c) => c.name === name);
				const prefs = Object.assign({ toc: 1, two: 0, just: 1, fs: 16, serif: 0, lh: 0, theme: "paper", rate: 1, ls: 0, ps: 0, mg: 0, dys: 0, flip: 1 }, JSON.parse(localStorage.getItem("duty_rd_prefs") || "{}"));
				const GAP = 56;
				const applyPrefs = () => {
					localStorage.setItem("duty_rd_prefs", JSON.stringify(prefs));
					$L.find(".duty-rd-opt").each((_, el) => {
						const on = prefs[$(el).data("o")];
						$(el).css({ padding: "3px 9px", "border-radius": "6px", cursor: "pointer", "text-decoration": "none",
							background: on ? "#fff" : "transparent", color: on ? "#182420" : "#6B7772",
							"box-shadow": on ? "0 1px 2px rgba(0,0,0,.08)" : "none", "font-weight": on ? "700" : "400" });
					});
					$toc.toggle(!!prefs.toc);
					let th = prefs.theme || "paper";
					if (th === "auto") th = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "night" : "paper";
					this.$library.removeClass("duty-th-paper duty-th-sepia duty-th-night").addClass("duty-th-" + th);
					if (prefs.dys && !document.getElementById("duty-dys-font")) {
						$('<link id="duty-dys-font" rel="stylesheet" href="https://fonts.cdnfonts.com/css/open-dyslexic">').appendTo("head");
					}
					const fam = prefs.dys ? "'Open-Dyslexic', 'OpenDyslexic', sans-serif" : prefs.serif ? "Georgia, 'Times New Roman', serif" : "";
					$bd.css({ "font-size": prefs.fs + "px", "line-height": prefs.lh ? "2.02" : "1.78",
						"font-family": fam, "letter-spacing": (prefs.ls || 0) + "px",
						"text-align": prefs.just ? "justify" : "left", hyphens: prefs.just ? "auto" : "none" });
					let $dyn = $("#duty-rd-dyn");
					if (!$dyn.length) $dyn = $('<style id="duty-rd-dyn"></style>').appendTo("head");
					$dyn.text(`.duty-rd-body p { margin-bottom: ${(0.9 + (prefs.ps || 0)).toFixed(2)}em; } .duty-rd-col { padding: 0 ${prefs.mg || 0}px; }`);
					$L.find(".duty-rd-pgbtns").toggle(!!prefs.two);
					if (prefs.two) {
						$sc.css({ height: "calc(100vh - 250px)", "overflow-x": "auto", "overflow-y": "hidden" });
						$bd.css({ "max-width": "none" });
						requestAnimationFrame(() => {
							const w = $sc[0].clientWidth;
							const colw = Math.floor((w - GAP) / 2);
							$bd.css({ height: "100%", "column-width": colw + "px", "column-gap": GAP + "px", "column-fill": "auto" });
							const el = $sc[0];
							const step = el.clientWidth + GAP;
							el.scrollLeft = Math.round(el.scrollLeft / step) * step;
						});
					} else {
						$sc.css({ height: "", "overflow-x": "", "overflow-y": "" });
						$bd.css({ "max-width": "68ch", height: "", "column-width": "", "column-gap": "", "column-fill": "" });
						$L.find(".duty-rd-nav").css("max-width", "68ch");
					}
				};
				const pgSnap = () => {
					const el = $sc[0];
					const step = el.clientWidth + GAP;
					el.scrollLeft = Math.round(el.scrollLeft / step) * step;
				};
				const pageBy = (dir) => {
					const el = $sc[0];
					if (prefs.flip && prefs.two) {
						const $t = $(`<div class="duty-rd-turn ${dir > 0 ? "duty-turn-fwd" : "duty-turn-bck"}"></div>`).appendTo($sc.parent().css("position", "relative"));
						setTimeout(() => $t.remove(), 560);
					}
					pgSnap();
					el.scrollBy({ left: dir * (el.clientWidth + GAP), behavior: "smooth" });
				};
				const renderToc = () => {
					$toc.empty();
					m.chapters.forEach((c) => {
						$(`<a style="display:block;padding:6px 8px;border-radius:8px;margin:1px 0;cursor:pointer;font-size:12.5px;${c.name === cur ? "background:#eef2f0;font-weight:700" : ""};color:#182420;text-decoration:none">${doneSet.has(c.name) ? "✅ " : ""}${c.idx_no}. ${frappe.utils.escape_html(c.title)}</a>`)
							.appendTo($toc)
							.on("click", () => go(c.name, 0));
					});
				};
				const loadReviews = () =>
					frappe.call({
						method: "duty_board.library.book_reviews",
						args: { book: book },
						callback: (rr) => {
							const rv = rr.message || { rows: [], avg: 0, n: 0 };
							const mine = rv.rows.find((z) => z.mine) || {};
							const stars = mine.stars || 0;
							$L.find(".duty-rd-stars").html(
								[1, 2, 3, 4, 5].map((i) => `<a data-s="${i}" style="cursor:pointer;font-size:17px;color:${i <= stars ? "#A96F1A" : "#D8D4C8"};text-decoration:none">★</a>`).join("")
							);
							$L.find(".duty-rd-stars a").on("click", (e) => {
								const s = $(e.currentTarget).data("s");
								frappe.prompt(
									{ fieldname: "review", fieldtype: "Small Text", label: __("A line for your colleagues (optional)"), default: mine.review || "" },
									(v) => frappe.call({ method: "duty_board.library.rate_book", args: { book: book, stars: s, review: v.review || "" }, callback: loadReviews }),
									__("Rate “{0}” — {1}★", [m.title, s]), __("Save")
								);
							});
							$L.find(".duty-rd-revs").text(rv.n ? `💬 ${rv.n} ${__("review(s)")} · ${rv.avg}★` : __("be the first to review"));
							$L.find(".duty-rd-revpanel").html(
								rv.rows.filter((z) => z.stars || z.review).map((z) => `
								<div style="padding:7px 0;border-bottom:1px solid #F0EEE8;font-size:13px">
									<b>${frappe.utils.escape_html(z.who)}</b>
									<span style="color:#A96F1A">${"★".repeat(z.stars || 0)}</span>
									<span class="text-muted" style="font-size:11px;float:right">${z.when}</span>
									${z.review ? `<div style="margin-top:2px">${frappe.utils.escape_html(z.review)}</div>` : ""}
								</div>`).join("") || `<div class="text-muted">${__("No reviews yet.")}</div>`
							);
						},
					});
				$L.find(".duty-rd-revs").on("click", () => $L.find(".duty-rd-revpanel").slideToggle(120));
				const save = (donech) => {
					let pct;
					if (prefs.two) {
						const el = $sc[0];
						pct = el.scrollWidth > el.clientWidth ? Math.round((el.scrollLeft / (el.scrollWidth - el.clientWidth)) * 100) : 100;
					} else {
						pct = document.documentElement.scrollHeight > window.innerHeight
							? Math.round((window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100)
							: 100;
					}
					const mins = Math.round((Date.now() - opened_at) / 60000);
					opened_at = Date.now();
					frappe.call({ method: "duty_board.library.mark", args: { book: book, chapter: cur, scroll_pct: pct, minutes: mins, done: donech || null }, callback: () => {} });
				};
				const curPct = () => {
					if (prefs.two) {
						const el = $sc[0];
						return el.scrollWidth > el.clientWidth ? Math.round((el.scrollLeft / (el.scrollWidth - el.clientWidth)) * 100) : 100;
					}
					return document.documentElement.scrollHeight > window.innerHeight
						? Math.round((window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100) : 100;
				};
				const N = m.chapters.length || 1;
				const updProg = () => {
					const pct = curPct();
					const words = ($bd.text() || "").split(/\s+/).length;
					const left = Math.max(0, Math.ceil((words * (1 - pct / 100)) / 220));
					if (!this._scrub_drag) $L.find(".duty-rd-scrub").val(Math.round(((chIdx(cur) + pct / 100) / N) * 1000));
					$L.find(".duty-rd-prog span").text(left > 0 ? __("≈ {0} min left in this chapter", [left]) : __("chapter end"));
				};
				$L.find("#duty-rd-ticks").html(m.chapters.map((_, i2) => `<option value="${Math.round((i2 / N) * 1000)}"></option>`).join(""));
				$L.find(".duty-rd-scrub")
					.on("input", (e) => {
						this._scrub_drag = 1;
						const v = parseInt($(e.currentTarget).val(), 10) / 1000;
						const ci = Math.min(N - 1, Math.floor(v * N));
						$L.find(".duty-rd-prog span").text("→ " + (ci + 1) + ". " + (m.chapters[ci] || {}).title);
					})
					.on("change", (e) => {
						this._scrub_drag = 0;
						const v = parseInt($(e.currentTarget).val(), 10) / 1000;
						const ci = Math.min(N - 1, Math.floor(v * N));
						const inPct = Math.round((v * N - ci) * 100);
						go(m.chapters[ci].name, inPct);
					});
				const zen = (on) => {
					this.$library.toggleClass("duty-rd-zenmode", on === undefined ? !this.$library.hasClass("duty-rd-zenmode") : !!on);
					if (this.$library.hasClass("duty-rd-zenmode") && !$L.find(".duty-rd-zenx").length)
						$(`<a class="duty-rd-zenx">✕</a>`).appendTo($L).on("click", () => zen(0));
					if (!this.$library.hasClass("duty-rd-zenmode")) $L.find(".duty-rd-zenx").remove();
				};
				$L.find(".duty-rd-zenbtn").on("click", () => zen());
				const applyKeep = () => {
					const pct0 = curPct();
					applyPrefs();
					requestAnimationFrame(() => {
						if (!prefs.two) {
							const h = document.documentElement.scrollHeight - window.innerHeight;
							window.scrollTo(0, (h * pct0) / 100);
						}
						updProg();
					});
				};
				$L.find(".duty-rd-aa").on("click", (e) => {
					e.stopPropagation();
					$(".duty-rd-aapanel").remove();
					const seg = (f, opts) => opts.map(([v, l]) => `<a class="duty-aa-seg ${String(prefs[f]) === String(v) ? "on" : ""}" data-f="${f}" data-v="${v}">${l}</a>`).join("");
					const slid = (f, min, max, step, label) => `<label class="duty-aa-row"><span>${label}</span><input type="range" data-f="${f}" min="${min}" max="${max}" step="${step}" value="${prefs[f] || 0}"></label>`;
					const $pn = $(`
						<div class="duty-rd-aapanel">
							<div class="duty-aa-row"><span>${__("Theme")}</span><span class="duty-aa-segs">${seg("theme", [["paper", "☀"], ["sepia", "🟤"], ["night", "🌙"], ["auto", "A"]])}</span></div>
							<div class="duty-aa-row"><span>${__("Size")}</span><span class="duty-aa-segs"><a class="duty-aa-fs" data-d="-1">A−</a><b class="duty-aa-fsv">${prefs.fs}</b><a class="duty-aa-fs" data-d="1">A＋</a></span></div>
							<div class="duty-aa-row"><span>${__("Font")}</span><span class="duty-aa-segs">${seg("serif", [[0, "Sans"], [1, "Serif"]])}<a class="duty-aa-seg ${prefs.dys ? "on" : ""}" data-f="dys" data-v="${prefs.dys ? 0 : 1}">${__("Dyslexic")}</a></span></div>
							<details ${prefs.ls || prefs.ps || prefs.mg ? "open" : ""}><summary>${__("Advanced")}</summary>
								${slid("ls", 0, 1.5, 0.1, __("Letter spacing"))}
								${slid("ps", 0, 1.2, 0.1, __("Paragraph gap"))}
								${slid("mg", 0, 90, 6, __("Margins"))}
								<div class="duty-aa-row"><span>${__("Line height")}</span><span class="duty-aa-segs">${seg("lh", [[0, __("Normal")], [1, __("Loose")]])}</span></div>
								<div class="duty-aa-row"><span>${__("Page turn")}</span><span class="duty-aa-segs">${seg("flip", [[1, __("Flip")], [0, __("Plain")]])}</span></div>
							</details>
						</div>`).appendTo($L.find(".duty-rd-head"));
					const persist = () => { localStorage.setItem("duty_rd_prefs", JSON.stringify(prefs)); applyKeep(); };
					$pn.find(".duty-aa-seg").on("click", (e2) => {
						const f = $(e2.currentTarget).data("f");
						let v = $(e2.currentTarget).data("v");
						prefs[f] = f === "theme" ? String(v) : parseFloat(v);
						persist();
						$pn.remove();
						$L.find(".duty-rd-aa").trigger("click");
					});
					$pn.find(".duty-aa-fs").on("click", (e2) => {
						prefs.fs = Math.min(23, Math.max(13, prefs.fs + parseInt($(e2.currentTarget).data("d"), 10)));
						$pn.find(".duty-aa-fsv").text(prefs.fs);
						persist();
					});
					$pn.find("input[type=range]").on("input", (e2) => {
						prefs[$(e2.currentTarget).data("f")] = parseFloat($(e2.currentTarget).val());
						persist();
					});
					setTimeout(() => $(document).one("click.dutyaa", (e2) => { if (!$(e2.target).closest(".duty-rd-aapanel").length) $pn.remove(); }), 0);
				});
				// ── bookmarks ──
				let bmk_rows = [];
				const bmkLoad = (cb) => frappe.call({ method: "duty_board.library.bookmarks", args: { book: book }, callback: (rr) => { bmk_rows = rr.message || []; cb && cb(); } });
				$L.find(".duty-rd-bmk").on("click", () => {
					frappe.prompt({ fieldname: "note", fieldtype: "Data", label: __("A word to remember this spot (optional)") },
						(v) => frappe.call({
							method: "duty_board.library.bookmark_add",
							args: { book: book, chapter: cur, scroll_pct: curPct(), note: v.note || null },
							callback: (rr) => { bmk_rows = rr.message || []; frappe.show_alert({ message: __("🔖 Bookmarked"), indicator: "green" }); },
						}), __("🔖 Bookmark this spot"), __("Save"));
				});
				bmkLoad();
				// ── welcome back ──
				if (m.last_read_at) {
					const away = Math.floor((Date.now() - new Date(m.last_read_at.replace(" ", "T")).getTime()) / 86400000);
					if (away >= 14) {
						frappe.call({
							method: "duty_board.library.my_highlights",
							args: { book: book },
							callback: (rr) => {
								const hls = (rr.message || []).filter((h) => h.chapter === cur).slice(0, 3);
								const $wb = $(`
									<div class="duty-rd-wb">
										<b>👋 ${__("Welcome back — it's been {0} days.", [away])}</b>
										<span>${__("You left off here in")} “${frappe.utils.escape_html((m.chapters[chIdx(cur)] || {}).title || "")}”.</span>
										${hls.length ? `<i>${__("Your marks from this chapter")}:</i>` + hls.map((h) => `<q>“${frappe.utils.escape_html(h.text.slice(0, 120))}…”</q>`).join("") : ""}
										<a class="duty-wb-x">✕</a>
									</div>`).insertAfter($L.find(".duty-rd-prog"));
								$wb.find(".duty-wb-x").on("click", () => $wb.slideUp(140));
							},
						});
					}
				}
				// ── listen mode ──
				const spk = { on: 0, i: 0, units: [], paused: 0 };
				const spkStop = () => {
					spk.on = 0; spk.paused = 0;
					try { window.speechSynthesis.cancel(); } catch (e) {}
					$bd.find(".duty-rd-speaking").removeClass("duty-rd-speaking");
					$L.find(".duty-rd-audio").remove();
					$L.find(".duty-rd-listen").removeClass("on");
				};
				this._rd_stop = spkStop;
				const spkUnits = () => {
					const out = [];
					$bd.find("p, li, h1, h2, h3, h4, blockquote").each((_, el) => {
						const t = $(el).text().trim();
						if (!t) return;
						(t.match(/[^.!?]+[.!?]+["')\]]*|[^.!?]+$/g) || [t]).forEach((sent) => {
							if (sent.trim()) out.push({ el, text: sent.trim() });
						});
					});
					return out;
				};
				const spkNext = () => {
					if (!spk.on || spk.paused) return;
					if (spk.i >= spk.units.length) {
						const i2 = chIdx(cur);
						if (i2 < m.chapters.length - 1) {
							doneSet.add(cur); save(cur);
							go(m.chapters[i2 + 1].name, 0);
							setTimeout(() => { if (spk.on) { spk.units = spkUnits(); spk.i = 0; spkNext(); } }, 900);
						} else spkStop();
						return;
					}
					const u = spk.units[spk.i];
					$bd.find(".duty-rd-speaking").removeClass("duty-rd-speaking");
					$(u.el).addClass("duty-rd-speaking");
					if (spk.i % 3 === 0) u.el.scrollIntoView({ block: "center", behavior: "smooth" });
					const utt = new SpeechSynthesisUtterance(u.text);
					utt.rate = prefs.rate || 1;
					if (spk.voice) utt.voice = spk.voice;
					utt.onend = () => { spk.i++; spkNext(); };
					utt.onerror = () => { spk.i++; spkNext(); };
					window.speechSynthesis.speak(utt);
				};
				const spkBar = () => {
					const $b = $(`
						<div class="duty-rd-audio">
							<a class="duty-au-skip" data-d="-3">⏪</a>
							<a class="duty-au-pp">⏸</a>
							<a class="duty-au-skip" data-d="3">⏩</a>
							<a class="duty-au-stop">⏹</a>
							<select class="duty-au-sleep"><option value="0">💤 ${__("Off")}</option><option value="10">10m</option><option value="20">20m</option><option value="30">30m</option></select>
							<select class="duty-au-rate">${[0.8, 0.9, 1, 1.1, 1.2, 1.35, 1.5].map((x) => `<option value="${x}" ${x === (prefs.rate || 1) ? "selected" : ""}>${x}×</option>`).join("")}</select>
							<select class="duty-au-voice"><option value="">${__("Device voice")}</option></select>
						</div>`).appendTo($L);
					const fillVoices = () => {
						const vs = window.speechSynthesis.getVoices().filter((v) => v.lang && v.lang.startsWith("en"));
						const $v = $b.find(".duty-au-voice");
						$v.find("option:not(:first)").remove();
						vs.forEach((v, i2) => $v.append(`<option value="${i2}">${v.name.replace(/(Microsoft |Google )/, "")}</option>`));
						$v.data("voices", vs);
					};
					fillVoices();
					window.speechSynthesis.onvoiceschanged = fillVoices;
					$b.find(".duty-au-pp").on("click", (e) => {
						spk.paused = !spk.paused;
						$(e.currentTarget).text(spk.paused ? "⏵" : "⏸");
						if (spk.paused) window.speechSynthesis.cancel();
						else spkNext();
					});
					$b.find(".duty-au-stop").on("click", spkStop);
					$b.find(".duty-au-skip").on("click", (e) => {
						spk.i = Math.max(0, Math.min(spk.units.length - 1, spk.i + parseInt($(e.currentTarget).data("d"), 10)));
						if (spk.on && !spk.paused) { window.speechSynthesis.cancel(); spkNext(); }
					});
					$b.find(".duty-au-sleep").on("change", (e) => {
						clearTimeout(this._au_sleep);
						const mins2 = parseInt($(e.currentTarget).val(), 10);
						if (mins2) this._au_sleep = setTimeout(() => { spkStop(); frappe.show_alert({ message: __("💤 Sleep timer — the voice rests."), indicator: "blue" }); }, mins2 * 60000);
					});
					$b.find(".duty-au-rate").on("change", (e) => {
						prefs.rate = parseFloat($(e.currentTarget).val());
						localStorage.setItem("duty_rd_prefs", JSON.stringify(prefs));
						if (spk.on && !spk.paused) { window.speechSynthesis.cancel(); spkNext(); }
					});
					$b.find(".duty-au-voice").on("change", (e) => {
						const vs = $(e.currentTarget).data("voices") || [];
						spk.voice = vs[parseInt($(e.currentTarget).val(), 10)] || null;
						if (spk.on && !spk.paused) { window.speechSynthesis.cancel(); spkNext(); }
					});
				};
				$L.find(".duty-rd-listen").on("click", () => {
					if (spk.on) return spkStop();
					if (!window.speechSynthesis) return frappe.msgprint(__("This browser can't speak — try Chrome or Safari."));
					spk.on = 1; spk.paused = 0;
					spk.units = spkUnits();
					// start from roughly where the eye is
					spk.i = Math.floor(spk.units.length * (curPct() / 100) * 0.98);
					$L.find(".duty-rd-listen").addClass("on");
					spkBar();
					spkNext();
				});
				// ── highlights: mark, render, share ──
				let hl_rows = [];
				const hlWrap = (g) => {
					// wrap the first in-node occurrence of g.text; cross-node
					// passages fall back to a paragraph edge-mark
					const norm = (t) => t.replace(/\s+/g, " ");
					const target = norm(g.text);
					const walker = document.createTreeWalker($bd[0], NodeFilter.SHOW_TEXT);
					let node;
					while ((node = walker.nextNode())) {
						const i = norm(node.nodeValue).indexOf(target);
						if (i < 0) continue;
						// map normalized index back to the raw string
						let raw = 0, seen = 0;
						const rawNorm = norm(node.nodeValue);
						while (seen < i && raw < node.nodeValue.length) {
							if (!/\s/.test(node.nodeValue[raw]) || !/\s/.test(node.nodeValue[raw + 1] || "x")) seen++;
							raw++;
						}
						try {
							const r2 = document.createRange();
							r2.setStart(node, Math.min(raw, node.nodeValue.length));
							r2.setEnd(node, Math.min(raw + g.text.length, node.nodeValue.length));
							const mk = document.createElement("mark");
							mk.className = "duty-hl" + (g.mine ? " duty-hl-mine" : "") + (g.n > 1 ? " duty-hl-shared" : "");
							mk.dataset.mine = g.mine || "";
							mk.dataset.n = g.n;
							mk.dataset.users = (g.users || []).join(", ");
							mk.dataset.notes = JSON.stringify(g.notes || []);
							mk.title = g.n > 1 ? __("{0} colleagues highlighted this", [g.n]) : (g.users || [])[0] || "";
							r2.surroundContents(mk);
							return true;
						} catch (e2) { return false; }
					}
					// fallback: edge-mark the containing paragraph
					const probe = target.slice(0, 40).toLowerCase();
					const $p2 = $bd.find("p, li, blockquote").filter((_, el) => $(el).text().replace(/\s+/g, " ").toLowerCase().includes(probe)).first();
					if ($p2.length) $p2.addClass("duty-hl-para").attr("title", (g.users || []).join(", "));
					return false;
				};
				const hlRender = () => {
					$bd.find("mark.duty-hl").each((_, el) => { $(el).replaceWith($(el).text()); });
					$bd.find(".duty-hl-para").removeClass("duty-hl-para");
					hl_rows.forEach(hlWrap);
					$bd[0].normalize();
				};
				const hlLoad = () =>
					frappe.call({
						method: "duty_board.library.highlights",
						args: { chapter: cur },
						callback: (rr) => { hl_rows = rr.message || []; hlRender(); },
					});
				const hlAdd = (text, note) =>
					frappe.call({
						method: "duty_board.library.highlight_add",
						args: { book: book, chapter: cur, text: text, note: note || null },
						callback: (rr) => {
							hl_rows = rr.message || [];
							hlRender();
							frappe.show_alert({ message: __("🖍 Highlighted — the team can see your marks."), indicator: "green" });
						},
					});
				const $selbar = $(`<div class="duty-rd-selbar" style="display:none"><a class="duty-sb-hl">🖍 ${__("Highlight")}</a><a class="duty-sb-note">📝 ${__("Note")}</a></div>`).appendTo(document.body);
				const selText = () => String(window.getSelection() || "").replace(/\s+/g, " ").trim();
				$bd.on("mouseup.dutyhl touchend.dutyhl", () => {
					setTimeout(() => {
						const t = selText();
						if (t.length < 3 || t.length > 500) { $selbar.hide(); return; }
						try {
							const rect = window.getSelection().getRangeAt(0).getBoundingClientRect();
							$selbar.css({ top: Math.max(8, rect.top - 40) + "px", left: Math.max(8, rect.left + rect.width / 2 - 70) + "px" }).show();
						} catch (e2) {}
					}, 10);
				});
				$(document).on("mousedown.dutyhl", (e) => { if (!$(e.target).closest(".duty-rd-selbar").length) $selbar.hide(); });
				$selbar.find(".duty-sb-hl").on("click", () => { const t = selText(); $selbar.hide(); window.getSelection().removeAllRanges(); if (t) hlAdd(t); });
				$selbar.find(".duty-sb-note").on("click", () => {
					const t = selText();
					$selbar.hide(); window.getSelection().removeAllRanges();
					if (!t) return;
					frappe.prompt({ fieldname: "note", fieldtype: "Small Text", label: __("Your note on this passage"), reqd: 1 },
						(v) => hlAdd(t, v.note), __("📝 Note"), __("Save"));
				});
				$bd.on("click.dutyhl", "mark.duty-hl", (e) => {
					e.stopPropagation();
					const $m = $(e.currentTarget);
					const notes = JSON.parse($m.data("notes") || "[]");
					$(".duty-lb-pop").remove();
					const $pop = $(`
						<div class="duty-lb-pop duty-hl-pop">
							<div class="duty-hl-who">🖍 ${frappe.utils.escape_html($m.data("users") || "")}</div>
							${notes.map((z) => `<div class="duty-hl-note"><b>${frappe.utils.escape_html(z.who)}:</b> ${frappe.utils.escape_html(z.note)}</div>`).join("")}
							<a class="duty-hl-qcbtn">🖼 ${__("Make a quote card")}</a>
							${$m.data("mine") ? `<a class="duty-hl-rm">🗑 ${__("Remove my highlight")}</a>` : ""}
						</div>`).appendTo(document.body);
					const rc = e.currentTarget.getBoundingClientRect();
					$pop.css({ top: rc.bottom + 6 + "px", left: Math.max(8, Math.min(window.innerWidth - 260, rc.left)) + "px", width: "250px" });
					setTimeout(() => $(document).one("click.dutyhlpop", () => $pop.remove()), 0);
					$pop.find(".duty-hl-qcbtn").on("click", () => { $pop.remove(); quoteCard($m.text(), null); });
					$pop.find(".duty-hl-rm").on("click", () => {
						$pop.remove();
						const stash = { text: $m.text(), note: (JSON.parse($m.data("notes") || "[]").find((z) => true) || {}).note };
						frappe.call({
							method: "duty_board.library.highlight_remove",
							args: { name: $m.data("mine") },
							callback: (rr) => {
								hl_rows = rr.message || [];
								hlRender();
								const $u = $(`<div class="duty-rd-undo">${__("Highlight removed")} · <a>${__("Undo")}</a></div>`).appendTo(document.body);
								const t2 = setTimeout(() => $u.remove(), 6000);
								$u.find("a").on("click", () => { clearTimeout(t2); $u.remove(); hlAdd(stash.text, stash.note); });
							},
						});
					});
				});
				const quoteCard = (text, note) => {
					const cv = document.createElement("canvas");
					cv.width = 1080; cv.height = 1080;
					const cx = cv.getContext("2d");
					const grad = cx.createLinearGradient(0, 0, 1080, 1080);
					grad.addColorStop(0, "#123C35"); grad.addColorStop(1, "#0A211C");
					cx.fillStyle = grad; cx.fillRect(0, 0, 1080, 1080);
					cx.fillStyle = "rgba(255,197,61,.9)"; cx.font = "220px Georgia"; cx.fillText("“", 60, 240);
					cx.fillStyle = "#F2F6F4"; cx.font = "600 46px Georgia";
					const words2 = text.split(" ");
					let line = "", y = 330;
					const lines = [];
					words2.forEach((w) => {
						if (cx.measureText(line + " " + w).width > 880) { lines.push(line); line = w; } else line = line ? line + " " + w : w;
					});
					lines.push(line);
					lines.slice(0, 10).forEach((l2) => { cx.fillText(l2, 100, y); y += 66; });
					if (lines.length > 10) { cx.fillText("…", 100, y); y += 66; }
					cx.fillStyle = "#7BE3B0"; cx.font = "700 34px Segoe UI, Arial";
					cx.fillText("— " + (m.author || m.title).slice(0, 44), 100, Math.min(940, y + 60));
					cx.fillStyle = "rgba(231,240,236,.75)"; cx.font = "600 26px Segoe UI, Arial";
					cx.fillText(m.title.slice(0, 52), 100, Math.min(980, y + 104));
					cx.fillStyle = "rgba(255,197,61,.85)"; cx.font = "800 22px Segoe UI, Arial";
					cx.fillText("XLEVEL · LIBRARY", 100, 1030);
					const url = cv.toDataURL("image/png");
					const d2 = new frappe.ui.Dialog({ title: __("🖼 Quote card"), fields: [{ fieldname: "h", fieldtype: "HTML" }], primary_action_label: __("📣 Share to team room"),
						primary_action: () => {
							d2.hide();
							fetch(url).then((r3) => r3.blob()).then((bl) => {
								const fd = new FormData();
								fd.append("file", bl, "quote.png");
								fd.append("is_private", "0");
								return fetch("/api/method/upload_file", { method: "POST", headers: { "X-Frappe-CSRF-Token": frappe.csrf_token }, body: fd });
							}).then((r3) => r3.json()).then((j2) => {
								const furl = j2.message && j2.message.file_url;
								return frappe.call({ method: "duty_board.api.send_message", args: { message: `📚 “${text.slice(0, 180)}” — ${m.title}`, attachment: furl, attachment_name: "quote.png" } });
							}).then(() => frappe.show_alert({ message: __("📣 Shared with the team."), indicator: "green" }));
						} });
					d2.show();
					$(d2.body).find('[data-fieldname="h"]').html(`<img src="${url}" style="width:100%;border-radius:14px"><a class="btn btn-sm btn-default" download="quote.png" href="${url}" style="margin-top:8px">⬇ ${__("Download")}</a>`);
				};
				$L.find(".duty-rd-marks").on("click", () => {
					const $pn = $L.find(".duty-rd-hlpanel");
					if ($pn.is(":visible")) return $pn.slideUp(120);
					frappe.call({
						method: "duty_board.library.my_highlights",
						args: { book: book },
						callback: (rr) => {
							const rows2 = rr.message || [];
							bmkLoad(() => {
								$pn.html(`
									${bmk_rows.length ? `<div class="duty-hl-sect">🔖 ${__("Bookmarks")}</div>` + bmk_rows.map((bm) => `
										<a class="duty-hl-row duty-bm-row" data-ch="${bm.chapter}" data-pct="${bm.scroll_pct}">
											<i>${bm.idx_no}. ${frappe.utils.escape_html(bm.ch_title)} · ${Math.round(bm.scroll_pct)}%</i>
											${bm.note ? `<span>${frappe.utils.escape_html(bm.note)}</span>` : ""}
											<em class="duty-bm-rm" data-n="${bm.name}">✕</em>
										</a>`).join("") : ""}
									<div class="duty-hl-sect">🖍 ${__("Highlights")} ${rows2.length ? `<em class="duty-hl-md">⬇ ${__("Export .md")}</em>` : ""}</div>
									${rows2.length ? rows2.map((h, i3) => `
									<a class="duty-hl-row" data-ch="${h.chapter}" data-i="${i3}">
										<i>${h.idx_no}. ${frappe.utils.escape_html(h.ch_title)}</i>
										<span>“${frappe.utils.escape_html(h.text.slice(0, 140))}${h.text.length > 140 ? "…" : ""}”</span>
										${h.note ? `<b>📝 ${frappe.utils.escape_html(h.note)}</b>` : ""}
										<em class="duty-hl-qc" data-i="${i3}">🖼</em>
									</a>`).join("") : `<div class="text-muted" style="padding:8px">${__("No highlights yet — select any passage to mark it.")}</div>`}`).slideDown(120);
								$pn.find(".duty-hl-row").on("click", (e) => {
									if ($(e.target).is(".duty-hl-qc,.duty-bm-rm")) return;
									$pn.slideUp(120);
									go($(e.currentTarget).data("ch"), $(e.currentTarget).data("pct") || 0);
								});
								$pn.find(".duty-hl-qc").on("click", (e) => {
									e.stopPropagation();
									const h = rows2[$(e.currentTarget).data("i")];
									quoteCard(h.text, h.note);
								});
								$pn.find(".duty-bm-rm").on("click", (e) => {
									e.stopPropagation();
									frappe.call({ method: "duty_board.library.bookmark_remove", args: { name: $(e.currentTarget).data("n") },
										callback: (rr2) => { bmk_rows = rr2.message || []; $pn.slideUp(80); $L.find(".duty-rd-marks").trigger("click"); } });
								});
								$pn.find(".duty-hl-md").on("click", (e) => {
									e.stopPropagation();
									const md = `# ${m.title}\n${m.author ? "*" + m.author + "*\n" : ""}\n` + rows2.map((h) => `> ${h.text}\n${h.note ? "\n📝 " + h.note + "\n" : ""}\n— ${h.idx_no}. ${h.ch_title}\n`).join("\n");
									const a2 = document.createElement("a");
									a2.href = URL.createObjectURL(new Blob([md], { type: "text/markdown" }));
									a2.download = m.title.replace(/[^\w ]+/g, "").slice(0, 50) + " - highlights.md";
									a2.click();
								});
							});
						},
					});
				});
				$L.find(".duty-rd-find").on("click", () => {
					frappe.prompt({ fieldname: "q", fieldtype: "Data", label: __("Find in this book"), reqd: 1 },
						(v) => frappe.call({
							method: "duty_board.library.search_in_book",
							args: { book: book, q: v.q },
							callback: (rr) => {
								const res = rr.message || [];
								const $pn = $L.find(".duty-rd-findpanel");
								const bold = (s2) => frappe.utils.escape_html(s2).replace(new RegExp("(" + v.q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "ig"), "<b>$1</b>");
								$pn.html(res.length ? res.map((z) => `
									<a class="duty-hl-row" data-ch="${z.chapter}"><i>${z.idx_no}. ${frappe.utils.escape_html(z.title)}</i><span>${bold(z.snippet)}</span></a>`).join("")
									: `<div class="text-muted" style="padding:8px">${__("“{0}” isn't in this book.", [frappe.utils.escape_html(v.q)])}</div>`).slideDown(120);
								$pn.find(".duty-hl-row").on("click", (e) => {
									$pn.slideUp(120);
									go($(e.currentTarget).data("ch"), 0);
									setTimeout(() => {
										const probe = v.q.toLowerCase();
										const $p3 = $bd.find("p, li, blockquote").filter((_, el) => $(el).text().toLowerCase().includes(probe)).first();
										if ($p3.length) { $p3[0].scrollIntoView({ block: "center", behavior: "smooth" }); $p3.addClass("duty-hl-flash"); setTimeout(() => $p3.removeClass("duty-hl-flash"), 2600); }
									}, 700);
								});
							},
						}), __("🔎 Search inside the book"), __("Find"));
				});
				let scrollT = null;
				this._rd_scroll = () => {
					clearTimeout(scrollT);
					scrollT = setTimeout(() => { if (this.face === "library" && this._reading === book) { save(null); updProg(); } }, 1500);
				};
				$(window).off("scroll.dutyrd").on("scroll.dutyrd", this._rd_scroll);
				this._reading = book;
				const wake = async () => {
					try { this._wakelock = await navigator.wakeLock.request("screen"); } catch (e2) {}
				};
				if (navigator.wakeLock) {
					wake();
					$(document).off("visibilitychange.dutywake").on("visibilitychange.dutywake", () => {
						if (document.visibilityState === "visible" && this._reading) wake();
					});
				}
				const go = (name, scrollPct) => {
					frappe.call({
						method: "duty_board.library.chapter",
						args: { name: name },
						callback: (rr) => {
							cur = name;
							if (spk.on) { try { window.speechSynthesis.cancel(); } catch (e2) {} spk.units = []; spk.i = 0; }
							$bd.html(rr.message.content || `<p class="text-muted">${__("Empty chapter.")}</p>`);
							renderToc();
							applyPrefs();
							hlLoad();
							setTimeout(updProg, 300);
							requestAnimationFrame(() => {
								if (prefs.two) {
									const el = $sc[0];
									const step = el.clientWidth + GAP;
									const raw = scrollPct ? ((el.scrollWidth - el.clientWidth) * scrollPct) / 100 : 0;
									el.scrollLeft = Math.round(raw / step) * step;
								} else {
									const h = document.documentElement.scrollHeight - window.innerHeight;
									window.scrollTo(0, scrollPct ? (h * scrollPct) / 100 : 0);
								}
							});
							save(null);
						},
					});
				};
				$L.find(".duty-rd-back").on("click", () => { spkStop(); clearTimeout(this._au_sleep); save(null); this._reading = null; this._rd_stop = null; try { this._wakelock && this._wakelock.release(); } catch (e2) {} $(document).off("keydown.dutyrd visibilitychange.dutywake"); this.refresh_library(); });
				$L.find(".duty-rd-opt").on("click", (e) => {
					const o = $(e.currentTarget).data("o");
					prefs[o] = prefs[o] ? 0 : 1;
					applyPrefs();
				});
				$L.find(".duty-rd-fs").on("click", (e) => {
					prefs.fs = Math.min(22, Math.max(13, (prefs.fs || 16) + parseInt($(e.currentTarget).data("d"), 10)));
					applyPrefs();
				});
				$L.find(".duty-rd-pgprev").on("click", () => pageBy(-1));
				$L.find(".duty-rd-pgnext").on("click", () => pageBy(1));
				$(document).off("keydown.dutyrd").on("keydown.dutyrd", (e) => {
					if (this.face !== "library" || !this._reading) return;
					const tag = (document.activeElement || {}).tagName || "";
					if (/INPUT|TEXTAREA|SELECT/.test(tag) || $(".modal:visible").length) return;
					if (e.key === "Escape") { zen(0); return; }
					if (prefs.two) {
						if (!e.shiftKey && ["Enter", "PageDown", " ", "ArrowRight"].includes(e.key)) { e.preventDefault(); pageBy(1); }
						else if (["PageUp", "ArrowLeft"].includes(e.key) || (e.shiftKey && ["Enter", " "].includes(e.key))) { e.preventDefault(); pageBy(-1); }
					} else if (e.key === "Enter") {
						e.preventDefault();
						window.scrollBy({ top: (e.shiftKey ? -1 : 1) * window.innerHeight * 0.85, behavior: "smooth" });
					}
				});
				$L.find(".duty-rd-prev").on("click", () => { const i = chIdx(cur); if (i > 0) go(m.chapters[i - 1].name, 0); });
				$L.find(".duty-rd-next").on("click", () => {
					doneSet.add(cur);
					save(cur);
					const i = chIdx(cur);
					const done_title = (m.chapters[i] || {}).title || "";
					if (i < m.chapters.length - 1) {
						go(m.chapters[i + 1].name, 0);
						frappe.show_alert({ message: __("✓ “{0}” done — next: {1}", [done_title.slice(0, 40), (m.chapters[i + 1].title || "").slice(0, 40)]), indicator: "green" });
					} else {
						renderToc();
						this.confetti();
						frappe.show_alert({ message: __("📚 Book finished — rate it for the team!"), indicator: "green" });
					}
				});
				$bd.html(m.content || "");
				renderToc();
				loadReviews();
				applyPrefs();
				hlLoad();
				requestAnimationFrame(() => {
					const sp = m.scroll_pct || 0;
					if (sp > 1 && !prefs.two) {
						const h = document.documentElement.scrollHeight - window.innerHeight;
						window.scrollTo(0, (h * sp) / 100);
					}
					updProg();
				});
				$sc.off("click.dutyzone").on("click.dutyzone", (e) => {
					if ($(e.target).closest("a, mark, button, input, select, .duty-rd-nav, .duty-rd-audio").length) return;
					if (window.getSelection && String(window.getSelection())) return;
					const mob = $("body").hasClass("duty-mobile");
					const x = e.clientX / window.innerWidth;
					const Lz = mob ? 0.3 : 0.15;
					const Rz = mob ? 0.7 : 0.85;
					if (x < Lz) prefs.two ? pageBy(-1) : window.scrollBy({ top: -window.innerHeight * 0.85, behavior: "smooth" });
					else if (x > Rz) prefs.two ? pageBy(1) : window.scrollBy({ top: window.innerHeight * 0.85, behavior: "smooth" });
					else if (mob) zen();
				});
				let tX = null;
				$sc.off("touchstart.dutyzone touchend.dutyzone")
					.on("touchstart.dutyzone", (e) => { tX = e.originalEvent.touches[0].clientX; })
					.on("touchend.dutyzone", (e) => {
						if (tX === null) return;
						const dx = e.originalEvent.changedTouches[0].clientX - tX;
						tX = null;
						if (Math.abs(dx) < 70) return;
						if (dx < 0) $L.find(".duty-rd-next").trigger("click");
						else $L.find(".duty-rd-prev").trigger("click");
					});
				$sc.on("scroll", () => { if (prefs.two) this._rd_scroll(); });
				$(window).off("resize.dutyrd").on("resize.dutyrd", () => { if (this._reading) applyPrefs(); });
				requestAnimationFrame(() => {
					if (prefs.two) {
						const el = $sc[0];
						el.scrollLeft = m.scroll_pct ? ((el.scrollWidth - el.clientWidth) * m.scroll_pct) / 100 : 0;
					} else {
						const h = document.documentElement.scrollHeight - window.innerHeight;
						window.scrollTo(0, m.scroll_pct ? (h * m.scroll_pct) / 100 : 0);
					}
				});
			},
		});
	}

	suggest_meeting_dialog(id, topic, after) {
		this._sg_slot = null;
		const d = new frappe.ui.Dialog({
			title: __("↷ Suggest another time — {0}", [topic || __("meeting")]),
			fields: [
				{ fieldname: "date", fieldtype: "Date", label: __("Day"), reqd: 1, change: () => load() },
				{ fieldname: "slots", fieldtype: "HTML" },
			],
			primary_action_label: __("Send suggestion"),
			primary_action: (v) => {
				if (!this._sg_slot) return frappe.msgprint(__("Pick one of the free slots."));
				frappe.call({
					method: "duty_board.client_room.suggest_meeting_time",
					args: { id: id, date: v.date, time: this._sg_slot },
					callback: (r) => {
						d.hide();
						frappe.show_alert({ message: __("Suggestion posted in the client's room."), indicator: "green" });
						after && after(r);
					},
				});
			},
		});
		const load = () => {
			const dt = d.get_value("date");
			if (!dt) return;
			d.fields_dict.slots.$wrapper.html(`<div class="text-muted">${__("Checking the team's calendar…")}</div>`);
			frappe.call({
				method: "duty_board.client_room.meeting_slots_staff",
				args: { id: id, date: dt },
				callback: (r) => {
					const slots = r.message || [];
					this._sg_slot = null;
					d.fields_dict.slots.$wrapper.html(
						slots.length
							? `<div class="duty-sg-slots">${slots.map((s) => `<a class="duty-sg-slot" data-s="${s}">${s}</a>`).join("")}</div>`
							: `<div class="text-muted">${__("No free slots that day — try another.")}</div>`
					);
					d.fields_dict.slots.$wrapper.find(".duty-sg-slot").on("click", (e) => {
						this._sg_slot = $(e.currentTarget).data("s");
						d.fields_dict.slots.$wrapper.find(".duty-sg-slot").removeClass("on");
						$(e.currentTarget).addClass("on");
					});
				},
			});
		};
		d.show();
		d.fields_dict.date.$input && d.fields_dict.date.$input.attr("min", frappe.datetime.get_today());
	}

	academy_health_link() {
		/* Somebody looking for anything academy-related opens the room dialog
		   first, so the cross-room view must be reachable from inside it and
		   not only from the page menu two levels out. */
		return `<a class="duty-ah-open" style="cursor:pointer;font-size:12px;font-weight:600">\u{1F4C8} ${__("Academy health (all clients)")}</a>`;
	}

	lesson_questions_dialog() {
		const esc = frappe.utils.escape_html;
		const d = new frappe.ui.Dialog({ title: `\u2753 ${__("Lesson questions")}`, size: "extra-large" });
		let status = "Open";
		const load = () =>
			frappe.call({
				method: "duty_board.academy.questions", args: { status: status },
				callback: (r) => {
					const rows = r.message || [];
					$(d.body).html(`
						<div style="margin-bottom:10px">
							<button class="btn btn-xs ${status === "Open" ? "btn-primary" : "btn-default"} duty-q-f" data-s="Open">${__("Open")}</button>
							<button class="btn btn-xs ${status === "Answered" ? "btn-primary" : "btn-default"} duty-q-f" data-s="Answered">${__("Answered")}</button>
							<button class="btn btn-xs ${status === "All" ? "btn-primary" : "btn-default"} duty-q-f" data-s="All">${__("All")}</button>
						</div>
						${rows.length ? rows.map((q) => `
						<div class="duty-q-card" data-n="${esc(q.name)}">
							<div class="duty-q-meta"><b>${esc(q.who)}</b> \u00b7 ${esc(q.customer)} \u00b7 ${esc(q.module_title || "")} \u2014 ${esc(q.lesson_title || "")}
								${q.status === "Open" && q.waiting_days > 1 ? `<span class="duty-q-old">${q.waiting_days} ${__("days waiting")}</span>` : ""}</div>
							<div class="duty-q-q">${esc(q.question)}</div>
							${q.answer ? `<div class="duty-q-a"><b>${esc(q.answered_by || "")}</b>${q.published ? ` <span class="duty-q-pub">${__("published")}</span>` : ""}<div>${esc(q.answer)}</div></div>` : ""}
							${q.status === "Open" ? `
								<textarea class="form-control duty-q-in" rows="3" placeholder="${__("Write the answer the learner will read")}"></textarea>
								<label class="duty-q-pubchk"><input type="checkbox" class="duty-q-pubbox" checked> ${__("Publish on the lesson so others do not have to ask")}</label>
								<button class="btn btn-sm btn-primary duty-q-send">${__("Send answer")}</button>` : ""}
						</div>`).join("")
							: `<div class="text-muted">${__("Nothing here.")}</div>`}`);
					$(d.body).find(".duty-q-f").on("click", (e) => { status = $(e.currentTarget).data("s"); load(); });
					$(d.body).find(".duty-q-send").on("click", (e) => {
						const $c = $(e.currentTarget).closest(".duty-q-card");
						const txt = $c.find(".duty-q-in").val();
						if (!txt || txt.trim().length < 5) { frappe.msgprint(__("Write an answer first.")); return; }
						$(e.currentTarget).prop("disabled", true);
						frappe.call({
							method: "duty_board.academy.answer_question",
							args: { name: $c.data("n"), answer: txt, publish: $c.find(".duty-q-pubbox").is(":checked") ? 1 : 0 },
							callback: () => { frappe.show_alert({ message: __("Answer sent"), indicator: "green" }); load(); },
						});
					});
				},
			});
		load();
		d.show();
	}

	academy_health_css() {
		if (document.getElementById("duty-ah-css")) return;
		const s = document.createElement("style");
		s.id = "duty-ah-css";
		s.textContent = `
			.duty-ah-top { display: flex; flex-wrap: wrap; gap: 8px; }
			.duty-ah-chip { background: #F4F7F6; border-radius: 8px; padding: 6px 11px; font-size: 12px; color: #6B7C77; }
			.duty-ah-chip b { font-size: 15px; color: #0A473F; margin-right: 4px; }
			.duty-ah-chip.warn { background: #FFF7E6; color: #7A5312; }
			.duty-ah-chip.warn b { color: #B27409; }
			.duty-ah-hot td { background: #FFFCF5; }
			.duty-ah-go { cursor: pointer; font-weight: 600; }
			.duty-q-card { border: 1px solid #E4EAE8; border-radius: 10px; padding: 12px 14px; margin-bottom: 10px; }
			.duty-q-meta { font-size: 12px; color: #6B7C77; margin-bottom: 6px; }
			.duty-q-old { background: #FFF7E6; color: #B27409; border-radius: 99px; padding: 2px 9px; font-weight: 700; margin-left: 6px; }
			.duty-q-q { font-size: 14px; line-height: 1.55; margin-bottom: 8px; }
			.duty-q-a { background: #F4F7F6; border-radius: 8px; padding: 10px 12px; font-size: 13px; line-height: 1.55; }
			.duty-q-pub { color: #0C6B4F; font-size: 11px; text-transform: uppercase; letter-spacing: .8px; }
			.duty-q-pubchk { display: block; font-weight: 400; font-size: 12.5px; margin: 8px 0; }`;
		document.head.appendChild(s);
	}

	academy_health_dialog() {
		this.academy_health_css();
		const esc = frappe.utils.escape_html;
		const d = new frappe.ui.Dialog({ title: `\u{1F4C8} ${__("Academy health")}`, size: "extra-large" });
		d.set_primary_action(`\u{1F9FE} ${__("Seat orders")}`, () => { d.hide(); this.academy_orders_dialog(); });
		frappe.call({
			method: "duty_board.academy.health",
			callback: (r) => {
				const res = r.message || { rooms: [], totals: {} };
				const t = res.totals;
				const chip = (n, label, warn) =>
					`<span class="duty-ah-chip${warn && n ? " warn" : ""}"><b>${n}</b> ${label}</span>`;
				$(d.body).html(`
					<div class="duty-ah-top">
						${chip(t.rooms || 0, __("rooms"))}
						${chip(t.attention || 0, __("need attention"), 1)}
						${chip(t.never || 0, __("never signed in"), 1)}
						${chip(t.stalled || 0, __("not started"), 1)}
						${chip(t.blocked || 0, __("blocked"), 1)}
						${chip(t.idle_seats || 0, __("idle seats"), 1)}
						${chip(t.waiting_orders || 0, __("orders waiting"), 1)}
					</div>
					${res.rooms.length ? `<table class="table table-sm" style="font-size:12px;margin-top:12px">
						<tr><th>${__("Customer")}</th><th>${__("People")}</th><th>${__("Assigned")}</th>
						<th>${__("Complete")}</th><th>${__("Never in")}</th><th>${__("Not started")}</th>
						<th>${__("Overdue")}</th><th>${__("Blocked")}</th><th>${__("Idle seats")}</th><th>${__("Waiting")}</th></tr>
						${res.rooms.map((x) => `<tr class="${x.score ? "duty-ah-hot" : ""}">
							<td><a class="duty-ah-go" data-r="${esc(x.room)}">${esc(x.customer)}</a></td>
							<td>${x.members}</td><td>${x.assigned}</td>
							<td>${x.complete}${x.rate === null ? "" : ` (${x.rate}%)`}</td>
							<td>${x.never ? `<b title="${esc((x.never_names || []).join(", "))}">${x.never}</b>` : "\u2014"}</td>
							<td>${x.stalled || "\u2014"}</td><td>${x.overdue || "\u2014"}</td>
							<td>${x.blocked ? `<b>${x.blocked}</b>` : "\u2014"}</td>
							<td>${x.idle_seats ? `<b>${x.idle_seats}</b>` : "\u2014"}</td>
							<td>${x.waiting_orders || "\u2014"}</td></tr>`).join("")}
					</table>
					<p class="text-muted" style="font-size:11.5px;margin-top:10px">${__("Sorted worst first. Never-signed-in and idle seats weigh heaviest — those are the states where a client has paid and received nothing. Hover a never-signed-in count to see who.")}</p>`
						: `<div class="text-muted">${__("No active rooms with members.")}</div>`}
				`);
				$(d.body).find(".duty-ah-go").on("click", (e) => {
					const room = $(e.currentTarget).data("r");
					d.hide();
					frappe.set_route("Form", "Client Room", room);
				});
			},
		});
		d.show();
	}

	academy_orders_dialog() {
		const esc = frappe.utils.escape_html;
		const d = new frappe.ui.Dialog({ title: `\u{1F9FE} ${__("Academy seat orders")}`, size: "extra-large" });
		const money = (v) => format_currency(v, "NGN");
		const load = () =>
			frappe.call({
				method: "duty_board.academy.orders",
				callback: (r) => {
					const rows = r.message || [];
					$(d.body).html(rows.length ? `
						<table class="table table-sm" style="font-size:12px">
							<tr><th>${__("Order")}</th><th>${__("Customer")}</th><th>${__("Track")}</th>
							<th>${__("Seats")}</th><th>${__("Total")}</th><th>${__("Status")}</th><th></th></tr>
							${rows.map((o) => `<tr>
								<td>${esc(o.name)}</td><td>${esc(o.customer)}</td><td>${esc(o.track_title)}</td>
								<td>${o.seats}</td><td>${money(o.total)}</td>
								<td>${o.status === "Requested" ? `<b style="color:#B45309">${esc(o.status)}</b>` : esc(o.status)}</td>
								<td>${o.status === "Requested"
									? `<a class="duty-ao-ok" data-n="${esc(o.name)}">${__("Approve")}</a> \u00b7 <a class="duty-ao-no" data-n="${esc(o.name)}">${__("Decline")}</a>`
									: esc(o.payment_ref || "")}</td></tr>`).join("")}
						</table>
						<p class="text-muted" style="font-size:11.5px">${__("Approving is the act that confirms money arrived. Seats activate immediately and the client is emailed.")}</p>`
						: `<div class="text-muted">${__("No seat orders yet.")}</div>`);
					$(d.body).find(".duty-ao-ok").on("click", (e) => {
						const n = $(e.currentTarget).data("n");
						const ad = new frappe.ui.Dialog({
							title: __("Approve {0}", [n]),
							fields: [
								{ fieldname: "payment_ref", fieldtype: "Data", label: __("Payment reference"), reqd: 1,
								  description: __("Bank reference or receipt number — this is your record that payment landed.") },
								{ fieldname: "expires_on", fieldtype: "Date", label: __("Seats expire on (optional)") },
							],
							primary_action_label: __("Activate seats"),
							primary_action: (v) => {
								ad.hide();
								frappe.call({
									method: "duty_board.academy.order_approve",
									args: { name: n, payment_ref: v.payment_ref, expires_on: v.expires_on },
									callback: () => { frappe.show_alert({ message: __("Seats activated"), indicator: "green" }); load(); },
								});
							},
						});
						ad.show();
					});
					$(d.body).find(".duty-ao-no").on("click", (e) => {
						const n = $(e.currentTarget).data("n");
						frappe.prompt(
							{ fieldname: "reason", fieldtype: "Small Text", label: __("Reason") },
							(v) => frappe.call({
								method: "duty_board.academy.order_decline",
								args: { name: n, reason: v.reason },
								callback: load,
							}),
							__("Decline {0}", [n]), __("Decline")
						);
					});
				},
			});
		load();
		d.show();
	}

	cohorts_dialog(x) {
		const esc = frappe.utils.escape_html;
		const d = new frappe.ui.Dialog({ title: `\u{1F465} ${frappe.utils.escape_html(x.customer || "")} \u2014 ${__("Training cohorts")}`, size: "extra-large" });
		const call = (m, args, cb) =>
			frappe.call({ method: `duty_board.cohort.${m}`, args: args || {}, callback: (r) => cb && cb(r.message) });
		const wtext = (w) => {
			if (!w || w.state === "none") return __("no exam window");
			if (w.state === "early") return `\u{1F512} ${__("opens")} ${frappe.datetime.str_to_user(w.opens_on)}`;
			if (w.state === "closed") return `\u{1F512} ${__("closed")} ${frappe.datetime.str_to_user(w.closes_on)}`;
			return `\u{1F7E2} ${__("window open")}${w.closes_on ? ` \u00b7 ${__("until")} ${frappe.datetime.str_to_user(w.closes_on)}` : ""}`;
		};
		const list = () =>
			call("cohort_list", { room: x.name }, (rows) => {
				rows = rows || [];
				$(d.body).html(`
					<div style="display:flex;gap:10px;align-items:center;margin-bottom:12px">
						<button type="button" class="btn btn-sm btn-primary duty-coh-new">\uFF0B ${__("New cohort")}</button>
						<span class="text-muted" style="font-size:12px">${__("A cohort is one group of this client's staff running a track together, with a session date and an exam window.")}</span>
					</div>
					${rows.length
						? rows.map((c) => `
						<div class="duty-cr-msrow" style="cursor:pointer" data-coh="${esc(c.name)}">
							<b>${esc(c.title)}</b>
							<span class="text-muted" style="font-size:12px;margin-left:8px">${esc(c.status)} \u00b7 ${c.enrolled_count}/${c.member_count} ${__("enrolled")}</span>
							<span class="text-muted" style="font-size:12px;margin-left:auto">${wtext(c.window)}</span>
						</div>`).join("")
						: `<div class="text-muted">${__("No cohorts yet for this client.")}</div>`}
				`);
				$(d.body).find("[data-coh]").on("click", (e) => detail($(e.currentTarget).data("coh")));
				$(d.body).find(".duty-coh-new").on("click", () => newCohort());
			});
		const newCohort = () => {
			frappe.call({
				method: "duty_board.client_room.room_tracks_for_assign",
				args: { name: x.name },
				callback: (r) => {
					const tracks = r.message || [];
					if (!tracks.length) {
						frappe.msgprint(__("This room's products carry no client certification tracks yet."));
						return;
					}
					const nd = new frappe.ui.Dialog({
						title: __("New cohort"),
						fields: [
							{ fieldname: "title", fieldtype: "Data", label: __("Title"), reqd: 1,
							  description: __("How this group will be referred to, e.g. “Finance team \u2014 October intake”") },
							{ fieldname: "track", fieldtype: "Select", label: __("Certification track"), reqd: 1,
							  options: tracks.map((t) => `${t.name}|${t.title} (${t.module_count})`).join("\n") },
						],
						primary_action_label: __("Create"),
						primary_action: (v) => {
							nd.hide();
							call("cohort_create", { room: x.name, title: v.title, track: String(v.track).split("|")[0] },
								(c) => detail(c.name));
						},
					});
					// show titles, submit ids
					nd.fields_dict.track.df.options = tracks.map((t) => ({ value: t.name, label: `${t.title} \u00b7 ${t.module_count} ${__("courses")}` }));
					nd.fields_dict.track.refresh();
					nd.show();
				},
			});
		};
		const dateField = (c, key, label) =>
			`<div style="display:flex;gap:8px;align-items:center;margin:5px 0">
				<span style="min-width:150px;font-size:12.5px">${label}</span>
				<input type="datetime-local" class="form-control input-sm duty-coh-dt" data-key="${key}" value="${c[key] ? String(c[key]).replace(" ", "T").slice(0, 16) : ""}" style="max-width:230px">
			</div>`;
		const detail = (name) =>
			call("cohort_get", { name: name }, (c) => {
				$(d.body).html(`
					<a class="duty-coh-back" style="cursor:pointer;font-size:12.5px">\u2190 ${__("All cohorts")}</a>
					<h4 style="margin:8px 0 2px">${esc(c.title)}</h4>
					<div class="text-muted" style="font-size:12px;margin-bottom:10px">${esc(c.name)} \u00b7 ${esc(c.status)} \u00b7 ${c.courses.length} ${__("courses")} \u00b7 ${wtext(c.window)}</div>
					${dateField(c, "session_on", __("Live session"))}
					${dateField(c, "opens_on", __("Exam window opens"))}
					${dateField(c, "closes_on", __("Exam window closes"))}
					<div class="duty-lead-section" style="margin-top:14px">\u{1F465} ${__("Members")}</div>
					${c.people.length
						? c.people.map((p) => `
						<div class="duty-cr-msrow">
							<label style="margin:0;font-weight:400;font-size:12.5px"><input type="checkbox" class="duty-coh-att" data-u="${esc(p.trainee)}" ${p.attended ? "checked" : ""}> ${__("attended")}</label>
							<b style="margin-left:10px">${esc(p.trainee_name)}</b>
							<span class="text-muted" style="font-size:12px;margin-left:auto">${p.enrolled ? `${p.done}/${p.total} ${__("complete")}` : __("not enrolled")}</span>
							${p.enrolled ? "" : `<a class="duty-coh-rm" data-u="${esc(p.trainee)}" style="cursor:pointer;margin-left:10px" title="${__("Remove")}">\u2715</a>`}
						</div>`).join("")
						: `<div class="text-muted">${__("No members yet.")}</div>`}
					<div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">
						<button type="button" class="btn btn-sm btn-default duty-coh-add">\uFF0B ${__("Add member")}</button>
						<button type="button" class="btn btn-sm btn-primary duty-coh-enrol">\u{1F393} ${__("Enrol everyone")}</button>
						<button type="button" class="btn btn-sm btn-default duty-coh-score">\u{1F4CA} ${__("Scorecard")}</button>
						${c.status === "Closed" ? "" : `<button type="button" class="btn btn-sm btn-default duty-coh-close">${__("Close cohort")}</button>`}
					</div>
					<p class="text-muted" style="font-size:11.5px;margin-top:10px">${__("Enrolling is safe to repeat — existing course records are adopted, never duplicated.")}</p>
				`);
				$(d.body).find(".duty-coh-back").on("click", list);
				$(d.body).find(".duty-coh-score").on("click", () => scorecard(name));
				$(d.body).find(".duty-coh-dt").on("change", (e) => {
					const $i = $(e.currentTarget);
					call("cohort_set", { name: name, field: $i.data("key"), value: ($i.val() || "").replace("T", " ") }, () => detail(name));
				});
				$(d.body).find(".duty-coh-att").on("change", (e) => {
					const $i = $(e.currentTarget);
					call("cohort_attendance", { name: name, user: $i.data("u"), attended: $i.is(":checked") ? 1 : 0 });
				});
				$(d.body).find(".duty-coh-rm").on("click", (e) =>
					call("cohort_remove_member", { name: name, user: $(e.currentTarget).data("u") }, () => detail(name)));
				$(d.body).find(".duty-coh-close").on("click", () =>
					frappe.confirm(__("Close this cohort? Its exam window still governs."), () =>
						call("cohort_close", { name: name }, () => detail(name))));
				$(d.body).find(".duty-coh-enrol").on("click", () =>
					call("cohort_enrol", { name: name }, (res) => {
						frappe.show_alert({
							message: __("{0} created, {1} adopted", [res.created, res.adopted]),
							indicator: "green",
						});
						detail(name);
					}));
				$(d.body).find(".duty-coh-add").on("click", () =>
					call("cohort_candidates", { room: x.name }, (pool) => {
						const taken = new Set(c.people.map((p) => p.trainee));
						const free = (pool || []).filter((p) => !taken.has(p.user));
						if (!free.length) return frappe.msgprint(__("Every active room member is already in this cohort."));
						const ad = new frappe.ui.Dialog({
							title: __("Add member"),
							fields: [{ fieldname: "user", fieldtype: "Select", label: __("Person"), reqd: 1,
								options: free.map((p) => ({ value: p.user, label: p.full_name })) }],
							primary_action_label: __("Add"),
							primary_action: (v) => { ad.hide(); call("cohort_add_member", { name: name, user: v.user }, () => detail(name)); },
						});
						ad.show();
					}));
			});
		const pct = (v) => (v === null || v === undefined ? "\u2014" : `${v}%`);
		const scorecard = (name) =>
			call("cohort_scorecard", { name: name }, (s) => {
				const band = (p) => (p >= 70 ? "#0E8A63" : p >= 50 ? "#C99A2E" : "#C2410C");
				$(d.body).html(`
					<a class="duty-coh-back2" style="cursor:pointer;font-size:12.5px">\u2190 ${__("Back to cohort")}</a>
					<h4 style="margin:8px 0 2px">\u{1F4CA} ${esc(s.title)}</h4>
					<div class="text-muted" style="font-size:12px;margin-bottom:12px">${esc(s.customer)} \u00b7 ${s.attended}/${s.members} ${__("attended")} \u00b7 ${s.sat} ${__("sat")} \u00b7 ${__("pass rate")} ${pct(s.pass_rate)} \u00b7 ${__("average")} ${pct(s.average)}</div>
					<div class="duty-lead-section">${__("By course")}</div>
					<table class="table table-sm" style="font-size:12px">
						<tr><th>${__("Course")}</th><th>${__("Sat")}</th><th>${__("Passed")}</th><th>${__("Pass rate")}</th><th>${__("Average")}</th></tr>
						${s.courses.map((c) => `<tr><td>${esc(c.title)}</td><td>${c.sat}</td><td>${c.passed}</td><td>${pct(c.pass_rate)}</td><td>${pct(c.average)}</td></tr>`).join("")}
					</table>
					${s.areas.length
						? `<div class="duty-lead-section">${__("Weakest areas")} <span class="text-muted" style="font-weight:400;font-size:11.5px">\u00b7 ${__("first attempts only")}</span></div>
						${s.areas.slice(0, 8).map((a) => `
						<div style="display:flex;gap:10px;align-items:center;margin:5px 0;font-size:12px">
							<span style="flex:0 0 38%">${esc(a.topic)}</span>
							<span style="flex:1;height:8px;background:#E9EFEC;border-radius:99px;overflow:hidden"><i style="display:block;height:8px;width:${a.pct}%;background:${band(a.pct)}"></i></span>
							<span class="text-muted" style="flex:0 0 80px;text-align:right">${a.pct}% (${a.right}/${a.total})</span>
						</div>`).join("")}`
						: `<p class="text-muted" style="font-size:12px;margin-top:10px">${__("No area breakdown yet — the question bank for these courses carries no topics. Add a Topic to each Duty Quiz Question and this fills in.")}</p>`}
					<div class="duty-lead-section">${__("Roster")}</div>
					<table class="table table-sm" style="font-size:12px">
						<tr><th>${__("Name")}</th><th>${__("Session")}</th><th>${__("Complete")}</th><th>${__("Average")}</th></tr>
						${s.people.map((p) => `<tr><td>${esc(p.trainee_name)}</td><td>${p.attended ? "\u2713" : "\u2014"}</td><td>${p.complete}/${p.total}</td><td>${p.average === null ? __("did not sit") : p.average + "%"}</td></tr>`).join("")}
					</table>
					<div class="text-muted" style="font-size:11.5px;margin-top:10px">\u23F1 ${__("Integrity")}: ${s.integrity.timed} ${__("timed attempts")} \u00b7 ${s.integrity.timeouts} ${__("timed out")} \u00b7 ${s.integrity.blurs} ${__("focus losses")}. ${__("Staff view only — never printed for the client.")}</div>
					<div style="display:flex;gap:8px;margin-top:14px">
						<button type="button" class="btn btn-sm btn-primary duty-coh-pub">\u{1F4E4} ${__("Publish to client's Documents")}</button>
					</div>
				`);
				$(d.body).find(".duty-coh-back2").on("click", () => detail(name));
				$(d.body).find(".duty-coh-pub").on("click", () =>
					frappe.confirm(__("Publish this scorecard to the client's Documents shelf and announce it in the room?"), () =>
						call("cohort_scorecard_publish", { name: name }, (res) => {
							frappe.show_alert({ message: __("Scorecard published"), indicator: "green" });
							if (res && res.file_url) window.open(res.file_url, "_blank");
						})));
			});
		list();
		d.show();
	}

	team_training_dialog() {
		frappe.call({
			method: "duty_board.client_room.training_team_overview",
			callback: (r) => {
				const m = r.message || { people: [] };
				const d = new frappe.ui.Dialog({ title: __("🎓 Team training & certification"), size: "extra-large" });
				if (frappe.user.has_role("System Manager")) {
					d.set_secondary_action_label(`⏱ ${__("Exam forensics")}`);
					d.set_secondary_action(() => {
						frappe.call({
							method: "duty_board.client_room.quiz_forensics",
							callback: (fr) => {
								const rows = fr.message || [];
								const fd = new frappe.ui.Dialog({ title: `⏱ ${__("Timed-exam forensics")}`, size: "extra-large" });
								$(fd.body).html(rows.length ? `
									<table class="table table-sm" style="font-size:12px">
									<tr><th>${__("Person")}</th><th>${__("Module")}</th><th>${__("When")}</th><th>${__("Score")}</th><th>${__("Avg s/q")}</th><th>${__("Spread")}</th><th>${__("Timeouts")}</th><th>${__("Tab-outs")}</th><th></th></tr>
									${rows.map((x) => `<tr class="${x.flag ? "duty-fx-flag" : ""}">
										<td><b>${frappe.utils.escape_html(x.user)}</b></td><td>${frappe.utils.escape_html(x.module)}</td><td>${x.when}</td>
										<td>${x.score}%${x.passed ? " ✅" : ""}</td><td>${x.avg_s}s</td><td title="${(x.times || []).join(", ")}s">${x.spread_s}s</td>
										<td>${x.timeouts || 0}</td><td>${x.blurs || 0}</td><td>${x.flag ? `<b style="color:#C2410C">⚠ ${__("review")}</b>` : ""}</td>
									</tr>`).join("")}
									</table>
									<p class="text-muted" style="font-size:11px">${__("⚠ = uniform answer times (low spread at unhurried pace) or tab-outs on nearly every question — the lookup/AI signature. Hover Spread for per-question times. A flag is a conversation, not a verdict.")}</p>`
									: `<p class="text-muted">${__("No timed attempts yet.")}</p>`);
								fd.show();
							},
						});
					});
				}
				const detail_html = (
					(m.people || []).map((p) => `
					<div style="border:1px solid #E8E5DD;border-radius:12px;padding:11px 14px;margin-bottom:10px">
						<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
							<b style="font-size:14px">${frappe.utils.escape_html(p.name)}</b>
							<span style="font-size:11.5px;font-weight:700;border-radius:99px;padding:3px 10px;background:${p.completed === p.assigned ? "#E4EEEA" : "#FBF3E4"};color:${p.completed === p.assigned ? "#0E5A4A" : "#A96F1A"}">${p.completed}/${p.assigned} ${__("courses complete")}</span>
							${(p.certificates || []).map((c) => `<span title="${frappe.utils.escape_html(c.title)} · ${c.on}" style="font-size:11.5px;background:#EFEDE6;border-radius:99px;padding:3px 10px">🎓 ${frappe.utils.escape_html(c.product || c.title)}</span>`).join("")}
							<span class="text-muted" style="font-size:11.5px;margin-left:auto">${p.last_active ? __("last active") + " " + p.last_active : __("no activity yet")}</span>
						</div>
						<div style="margin-top:7px">
							${(p.rows || []).map((z) => `
							<div style="display:flex;gap:9px;align-items:center;padding:4px 0;border-bottom:1px solid #F5F3EE;font-size:12.5px">
								<span>${z.status === "Completed" ? "✅" : z.lessons_done ? "▶" : "○"}</span>
								<span style="flex:1;min-width:0">${frappe.utils.escape_html(z.title)}${z.product ? ` <span class="text-muted" style="font-size:11px">· ${frappe.utils.escape_html(z.product)}</span>` : ""}</span>
								<span class="text-muted" style="font-size:11.5px;white-space:nowrap">${z.lessons_done}/${z.lessons_total} ${__("lessons")}</span>
								${z.quiz_attempts ? `<span title="${z.quiz_attempts} ${__("attempt(s) in total")}" style="font-size:11.5px;white-space:nowrap;font-weight:700;color:${z.quiz_passed ? "#0E5A4A" : "#A96F1A"}">${__("quiz")} ${z.quiz_best}% ${z.quiz_passed ? `✓ ${z.quiz_to_pass === 1 ? __("first try") : __("passed on attempt {0}", [z.quiz_to_pass])}` : `${__("not passed")} · ${z.quiz_attempts}× ${__("so far")}`}</span>` : ""}
								${z.completed_on ? `<span class="text-muted" style="font-size:11px;white-space:nowrap">${z.completed_on}</span>` : ""}
							</div>`).join("")}
						</div>
					</div>`).join("") || `<div class="text-muted">${__("No staff training assignments yet — assign tracks from the Me face (My training → Assign to a colleague).")}</div>`
				);
				const esc = frappe.utils.escape_html;
				const people = m.people || [];
				const ckeys = [];
				const seen = {};
				people.forEach((p) => (p.rows || []).forEach((z) => {
					const k = z.title + (z.product ? " · " + z.product : "");
					if (!seen[k]) { seen[k] = 1; ckeys.push({ k: k, title: z.title }); }
				}));
				const cell = (z) => {
					if (!z) return `<td class="tm-c tm-none">—</td>`;
					const tip = `${esc(z.title)} · ${z.lessons_done}/${z.lessons_total} ${__("lessons")}${z.quiz_attempts ? ` · ${__("quiz best")} ${z.quiz_best}%${z.quiz_passed ? " ✓" : ` (${z.quiz_attempts}×)`}` : ""}`;
					if (z.status === "Completed") return `<td class="tm-c tm-done" title="${tip}">✓</td>`;
					if (z.quiz_attempts && !z.quiz_passed) return `<td class="tm-c tm-fail" title="${tip}">${z.quiz_best}%</td>`;
					if (z.lessons_done) return `<td class="tm-c tm-prog" title="${tip}">${z.lessons_done}/${z.lessons_total}</td>`;
					return `<td class="tm-c tm-zero" title="${tip}">○</td>`;
				};
				const matrix_html = people.length && ckeys.length
					? `<div class="tm-wrap"><table class="tm">
						<thead><tr><th>${__("Staff")}</th>${ckeys.map((c) => `<th title="${esc(c.k)}">${esc(c.title)}</th>`).join("")}</tr></thead>
						<tbody>${people.map((p) => {
							const map = {};
							(p.rows || []).forEach((z) => (map[z.title + (z.product ? " · " + z.product : "")] = z));
							return `<tr><th>${esc(p.name)}</th>${ckeys.map((c) => cell(map[c.k])).join("")}</tr>`;
						}).join("")}</tbody></table></div>
						<div class="tm-legend"><span class="tm-done">✓</span> ${__("completed")} · <span class="tm-prog">n/n</span> ${__("in progress")} · <span class="tm-fail">%</span> ${__("quiz not yet passed")} · ○ ${__("not started")} · — ${__("not assigned")}</div>`
					: detail_html;
				$(d.body).html(`
					<div class="tm-tabs"><a class="on" data-t="matrix">▦ ${__("Matrix")}</a><a data-t="detail">☰ ${__("Detail")}</a></div>
					<div class="tm-body"></div>`);
				const show_t = (t) => {
					$(d.body).find(".tm-tabs a").removeClass("on").filter(`[data-t="${t}"]`).addClass("on");
					$(d.body).find(".tm-body").html(t === "matrix" ? matrix_html : detail_html);
				};
				$(d.body).find(".tm-tabs a").on("click", (e) => show_t($(e.currentTarget).data("t")));
				show_t("matrix");
				d.show();
			},
		});
	}

	timeline_dialog(x) {
		frappe.call({
			method: "duty_board.timeline.timeline",
			args: { room: x.name },
			callback: (r) => {
				const t = r.message || { events: [], summary: {} };
				const d = new frappe.ui.Dialog({ title: __("📜 {0} — Delivery timeline", [x.customer]), size: "extra-large" });
				const CHIP = { client: ["CLIENT", "#A96F1A", "#FBF3E4"], xlevel: ["XLEVEL", "#0E5A4A", "#E4EEEA"], info: ["", "", ""] };
				$(d.body).html(`
					<div style="border:1px solid #E8E5DD;border-radius:10px;padding:10px 14px;margin-bottom:12px;font-size:13px">
						<b>${__("Attributed waiting time")}</b> — ${__("client")}: <b style="color:#A96F1A">${t.summary.client_days || 0} ${__("day(s)")}</b> ·
						Xlevel: <b style="color:#0E5A4A">${t.summary.xlevel_days || 0} ${__("day(s)")}</b>
						<div class="text-muted" style="font-size:11.5px;margin-top:3px">${__("Client days = dependency lateness + CR approval waits · Xlevel days = acceptance-defect open time. Every line is a recorded system event.")}</div>
					</div>
					<div style="max-height:55vh;overflow-y:auto">
						${(t.events || []).map((e) => {
							const c = CHIP[e.who] || CHIP.info;
							return `<div style="display:flex;gap:10px;align-items:baseline;padding:5px 2px;border-bottom:1px solid #F0EEE8;font-size:12.5px">
								<span class="text-muted" style="white-space:nowrap;font-size:11.5px">${e.when}</span>
								<span>${e.icon}</span>
								<span style="flex:1">${frappe.utils.escape_html(e.text)}</span>
								${c[0] ? `<span style="font-size:9px;font-weight:800;letter-spacing:1px;color:${c[1]};background:${c[2]};border-radius:99px;padding:2px 8px">${c[0]}</span>` : ""}
							</div>`;
						}).join("") || `<div class="text-muted">${__("Nothing recorded yet.")}</div>`}
					</div>
					<button class="btn btn-sm btn-default" data-pdf style="margin-top:10px">📄 ${__("Export as PDF")}</button>`);
				$(d.body).find("[data-pdf]").on("click", (e) => {
					$(e.currentTarget).prop("disabled", true).text(__("Generating…"));
					frappe.call({
						method: "duty_board.timeline.timeline_pdf",
						args: { room: x.name },
						callback: (rr) => {
							if (rr.message && rr.message.file_url) window.open(rr.message.file_url, "_blank");
							$(e.currentTarget).prop("disabled", false).text("📄 " + __("Export as PDF"));
						},
					});
				});
				d.show();
			},
		});
	}

	uat_dialog(x) {
		frappe.call({
			method: "duty_board.uat.uat_state",
			args: { room: x.name },
			callback: (r) => {
				const m = r.message || {};
				const rows = m.rows || [];
				const p = m.progress || {};
				const d = new frappe.ui.Dialog({ title: __("🧪 {0} — Acceptance testing", [x.customer]), size: "extra-large" });
				const CH = { "Passed": "✅", "Failed": "❌", "Blocked": "⛔", "Blocked by Issue": "🔧", "Waived": "⚪", "Awaiting Client": "🕐" };
				const reload = () => { d.hide(); this.uat_dialog(x); };
				const call = (method, args) => frappe.call({ method: "duty_board.uat." + method, args: args, callback: reload });
				const secs = {};
				rows.forEach((z) => (secs[z.section || "General"] = secs[z.section || "General"] || []).push(z));
				$(d.body).html(`
					${m.uat_due && !m.signoff ? `<div class="text-muted" style="font-size:12px;margin-bottom:6px">🗓 ${__("Window ends")} ${m.uat_due}</div>` : ""}
					${m.signoff ? `<div style="background:#E4EEEA;border-radius:10px;padding:9px 12px;font-size:13px;margin-bottom:10px">✍ <b>${__("Signed off")}</b> ${__("by")} ${frappe.utils.escape_html(m.signoff.signed_full)} · ${m.signoff.signed_at} · ${m.signoff.passed}/${m.signoff.total} ${__("passed")}${m.signoff.exceptions ? `<br><span class="text-muted" style="font-size:12px">${__("Exceptions")}: ${frappe.utils.escape_html(m.signoff.exceptions)}</span>` : ""}</div>` : ""}
					${rows.length ? `<div style="font-size:12.5px;margin-bottom:8px"><b>${p.passed || 0}</b>/${p.total || 0} ${__("passed")}${p.failed ? ` · <b style="color:#b91c1c">${p.failed} ${__("failed")}</b>` : ""}${p.blocked ? ` · ${p.blocked} ${__("blocked")}` : ""}${p.waived ? ` · ${p.waived} ${__("waived")}` : ""}${p.awaiting ? ` · ${p.awaiting} ${__("awaiting client")}` : ""}</div>` : ""}
					${!rows.length ? `
						<p class="text-muted">${__("No acceptance cases yet — pick which template bank(s) to seed for this engagement.")} ${(m.templates || []).length ? "" : __("None exist yet — a manager creates them under Duty UAT Template.")}</p>
						<button class="btn btn-sm btn-primary" data-seed ${(m.templates || []).length ? "" : "disabled"}>🧪 ${__("Seed UAT…")}</button>`
					: Object.keys(secs).map((s) => `
						<div style="font-size:11px;font-weight:800;letter-spacing:1px;margin:10px 0 4px;color:#6B7772;text-transform:uppercase">${frappe.utils.escape_html(s)}</div>
						${secs[s].map((z) => `
						<div style="border:1px solid #E8E5DD;border-radius:10px;padding:8px 11px;margin-bottom:6px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
							<span>${CH[z.status] || ""}</span>
							<b style="font-size:13px;flex:1;min-width:180px">${z.code ? `<span class="text-muted" style="font-weight:600;font-size:11px">${frappe.utils.escape_html(z.code)}</span> ` : ""}${frappe.utils.escape_html(z.title)}</b>
							<span class="text-muted" style="font-size:11.5px">${z.attempts.length ? z.attempts.length + "× " + __("tested") : ""}</span>
							<span class="text-muted" style="font-size:11.5px;font-weight:700">${__(z.status)}</span>
							${z.issue ? `<a style="font-size:11.5px" onclick="frappe.set_route('Form','Duty Issue','${z.issue}')">🔧 ${z.issue}</a>` : ""}
							<span style="white-space:nowrap">
								${z.status !== "Waived" && !m.signoff ? `<button class="btn btn-xs btn-default" data-rec="${z.name}" title="${__("Record a result on the client's behalf")}">✍ ${__("record")}</button>` : ""}
								<button class="btn btn-xs btn-default" data-edit="${z.name}">✎</button>
								${m.manager && z.status !== "Waived" && !m.signoff ? `<button class="btn btn-xs btn-default" data-waive="${z.name}">${__("waive")}</button>` : ""}
								<button class="btn btn-xs btn-default" data-del="${z.name}" style="color:#B0443C">×</button>
							</span>
						</div>`).join("")}`).join("") + `
						<button class="btn btn-sm btn-primary" data-addcase style="margin-top:6px">＋ ${__("Add a case for this engagement")}</button>
						${!m.signoff ? `<button class="btn btn-sm btn-default" data-seed style="margin-top:6px">🧪 ${__("Seed another template…")}</button>` : ""}
						${m.manager && Object.keys(rows.reduce((a, z) => { if (z.template) a[z.template] = 1; return a; }, {})).length && !m.signoff ? `<button class="btn btn-sm btn-default" data-unseed style="margin-top:6px;color:#B0443C">${__("Unseed a template…")}</button>` : ""}`}
				`);
				const seededFrom = {};
				rows.forEach((z) => { if (z.template) seededFrom[z.template] = 1; });
				const roomProds = (m.room_products || "").toLowerCase();
				$(d.body).find("[data-seed]").on("click", () =>
					frappe.prompt(
						[{
							fieldname: "templates", fieldtype: "MultiCheck", label: __("Template banks to seed"), columns: 2,
							options: (m.templates || []).map((t) => ({
								label: seededFrom[t] ? t + " (" + __("already seeded") + ")" : t,
								value: t,
								checked: !seededFrom[t] && roomProds.indexOf(t.toLowerCase()) >= 0 ? 1 : 0,
							})),
						},
						{ fieldname: "due", fieldtype: "Date", label: __("Testing window ends (optional — drives client reminders)") }],
						(v) => {
							const chosen = v.templates || [];
							if (!chosen.length) return;
							call("uat_seed", { room: x.name, templates: chosen.join(","), due: v.due || null });
						},
						__("Seed acceptance tests"), __("Seed")
					)
				);
				$(d.body).find("[data-unseed]").on("click", () =>
					frappe.prompt(
						{ fieldname: "template", fieldtype: "Select", label: __("Remove untested cases seeded from"), options: Object.keys(seededFrom), reqd: 1 },
						(v) => call("uat_unseed", { room: x.name, template: v.template }),
						__("Unseed template"), __("Remove")
					)
				);
				$(d.body).find("[data-addcase]").on("click", () => frappe.prompt(
					[
						{ fieldname: "section", fieldtype: "Data", label: __("Section"), default: "General" },
						{ fieldname: "title", fieldtype: "Data", label: __("Scenario"), reqd: 1 },
						{ fieldname: "steps", fieldtype: "Small Text", label: __("Steps") },
						{ fieldname: "expected", fieldtype: "Small Text", label: __("Expected result") },
					],
					(v) => call("uat_case_add", { room: x.name, title: v.title, section: v.section, steps: v.steps || null, expected: v.expected || null }),
					__("New acceptance case"), __("Add")
				));
				$(d.body).find("[data-edit]").on("click", (e) => {
					const id = $(e.currentTarget).data("edit");
					const z = rows.find((q) => q.name === id) || {};
					frappe.prompt(
						[
							{ fieldname: "section", fieldtype: "Data", label: __("Section"), default: z.section },
							{ fieldname: "title", fieldtype: "Data", label: __("Scenario"), default: z.title, reqd: 1 },
							{ fieldname: "steps", fieldtype: "Small Text", label: __("Steps"), default: z.steps },
							{ fieldname: "expected", fieldtype: "Small Text", label: __("Expected result"), default: z.expected },
						],
						(v) => call("uat_case_update", { name: id, title: v.title, section: v.section, steps: v.steps || "", expected: v.expected || "" }),
						__("Edit case"), __("Save")
					);
				});
				$(d.body).find("[data-rec]").on("click", (e) => {
					const id = $(e.currentTarget).data("rec");
					frappe.prompt(
						[
							{ fieldname: "result", fieldtype: "Select", label: __("Result"), options: ["Pass", "Fail", "Blocked"], reqd: 1 },
							{ fieldname: "observed", fieldtype: "Small Text", label: __("What happened (required for Fail/Blocked)") },
						],
						(v) => call("uat_record", { name: id, result: v.result, observed: v.observed || null }),
						__("Record on client's behalf"), __("Record")
					);
				});
				$(d.body).find("[data-waive]").on("click", (e) => frappe.prompt(
					{ fieldname: "reason", fieldtype: "Data", label: __("Waived because"), reqd: 1 },
					(v) => call("uat_waive", { name: $(e.currentTarget).data("waive"), reason: v.reason }),
					__("Waive case"), __("Waive")
				));
				$(d.body).find("[data-del]").on("click", (e) => frappe.confirm(__("Delete this case (and its attempt history)?"), () =>
					call("uat_case_delete", { name: $(e.currentTarget).data("del") })
				));
				d.show();
			},
		});
	}

	deps_dialog(x) {
		frappe.call({
			method: "duty_board.commercial.deps_list",
			args: { room: x.name },
			callback: (r) => {
				const rows = r.message || [];
				const d = new frappe.ui.Dialog({ title: __("📋 Awaiting from {0}", [x.customer]), size: "large" });
				const badge = (s, o) => s === "Received" ? "✅" : s === "Waived" ? "⚪" : s === "Provided" ? "📨" : o ? "🔴" : "🕐";
				$(d.body).html(`
					${rows.length ? `<table class="table table-sm" style="font-size:12px"><tr><th></th><th>${__("Item")}</th><th>${__("Due")}</th><th>${__("Age")}</th><th>${__("Blocks")}</th><th></th></tr>
					${rows.map((z) => `<tr style="${z.overdue ? "background:#fef2f2" : ""}">
						<td>${badge(z.status, z.overdue)}</td>
						<td><b>${frappe.utils.escape_html(z.title)}</b><br><span class="text-muted">${frappe.utils.escape_html(z.category || "")}${z.provided_note ? " · 💬 " + frappe.utils.escape_html(z.provided_note) : ""}</span></td>
						<td>${z.due_date || "—"}${z.overdue ? `<br><b style="color:#b91c1c">${z.days_late}d ${__("late")}</b>` : ""}</td>
						<td>${z.age_days}d${z.remind_count ? `<br>🔔×${z.remind_count}` : ""}</td>
						<td style="max-width:140px">${frappe.utils.escape_html(z.blocks || "")}</td>
						<td style="white-space:nowrap">
							${z.status === "Awaiting" || z.status === "Provided" ? `<button class="btn btn-xs btn-success" data-recv="${z.name}">✓ ${__("received")}</button> <button class="btn btn-xs btn-default" data-rem="${z.name}">🔔</button>` : ""}
							${z.status === "Provided" ? `<button class="btn btn-xs btn-default" data-back="${z.name}" title="${__("not usable — reopen")}">↩</button>` : ""}
							${z.status === "Awaiting" ? `<button class="btn btn-xs btn-default" data-waive="${z.name}">${__("waive")}</button>` : ""}
						</td></tr>`).join("")}</table>` : `<p class="text-muted">${__("Nothing awaited from this client.")}</p>`}
					<button class="btn btn-sm btn-primary" data-adddep>＋ ${__("New dependency")}</button>
				`);
				const reload = () => { d.hide(); this.deps_dialog(x); };
				$(d.body).find("[data-recv]").on("click", (e) => frappe.call({ method: "duty_board.commercial.dep_receive", args: { name: $(e.currentTarget).data("recv") }, callback: reload }));
				$(d.body).find("[data-rem]").on("click", (e) => frappe.call({ method: "duty_board.commercial.dep_remind", args: { name: $(e.currentTarget).data("rem") }, callback: () => frappe.show_alert({ message: __("🔔 Reminder posted to the room"), indicator: "blue" }) }));
				$(d.body).find("[data-back]").on("click", (e) => frappe.prompt({ fieldname: "note", fieldtype: "Data", label: __("Why isn't it usable?") }, (v) => frappe.call({ method: "duty_board.commercial.dep_reopen", args: { name: $(e.currentTarget).data("back"), note: v.note }, callback: reload }), __("Reopen"), __("Reopen")));
				$(d.body).find("[data-waive]").on("click", (e) => frappe.prompt({ fieldname: "reason", fieldtype: "Data", label: __("Reason") }, (v) => frappe.call({ method: "duty_board.commercial.dep_waive", args: { name: $(e.currentTarget).data("waive"), reason: v.reason }, callback: reload }), __("Waive"), __("Waive")));
				$(d.body).find("[data-adddep]").on("click", () => frappe.prompt(
					[
						{ fieldname: "title", fieldtype: "Data", label: __("What do we need?"), reqd: 1 },
						{ fieldname: "category", fieldtype: "Select", label: __("Category"), options: ["Data / Template", "Opening Balances", "Master Data", "Approval / Sign-off", "Credentials / Access", "Process Decision", "Test Results / UAT", "Training Attendance", "Document", "Payment", "Named Staff", "Other"], default: "Other" },
						{ fieldname: "detail", fieldtype: "Small Text", label: __("Detail / format expected") },
						{ fieldname: "due_date", fieldtype: "Date", label: __("Due") },
						{ fieldname: "blocks", fieldtype: "Data", label: __("What this blocks (shown to management)") },
					],
					(v) => frappe.call({ method: "duty_board.commercial.dep_add", args: { room: x.name, title: v.title, category: v.category, detail: v.detail || null, due_date: v.due_date || null, blocks: v.blocks || null }, callback: reload }),
					__("New dependency"), __("Request")
				));
				d.show();
			},
		});
	}

	academy_dialog(x) {
		const d = new frappe.ui.Dialog({ title: `🎓 ${frappe.utils.escape_html(x.customer || "")} — ${__("Training Academy")}`, size: "large" });
		d.set_primary_action(`\u{1F465} ${__("Cohorts")}`, () => { d.hide(); this.cohorts_dialog(x); });
		d.set_secondary_action_label(`\u{1F9FE} ${__("Seat orders")}`);
		d.set_secondary_action(() => { d.hide(); this.academy_orders_dialog(); });
		d.$wrapper.on("click", ".duty-ah-open", () => { d.hide(); this.academy_health_dialog(); });
		setTimeout(() => d.$wrapper.find(".modal-footer").prepend(`<span style="margin-right:auto;padding-left:4px">${this.academy_health_link()}</span>`), 0);
		const load = () =>
			frappe.call({
				method: "duty_board.client_room.room_training",
				args: { name: x.name },
				callback: (r) =>
					frappe.call({
						method: "duty_board.client_room.training_modules",
						callback: (mr) => render(r.message || [], mr.message || []),
					}),
			});
		const render = (rows, mods) => {
			const members = (x.members || []).filter((m) => m.user);
			const by_trainee = {};
			rows.forEach((r) => {
				(by_trainee[r.trainee_name] = by_trainee[r.trainee_name] || []).push(r);
			});
			$(d.body).html(`
				<div class="duty-acad-row" style="background:var(--bg-light-gray,#F4F7F6);border-radius:8px;padding:7px 10px">
					🛒 <b>${__("Products")}</b>
					<span class="text-muted">${x.products ? frappe.utils.escape_html(x.products) : __("none — members inherit no certification tracks")}</span>
					<a class="duty-acad-prods" style="margin-left:auto;cursor:pointer">✎ ${__("Edit")}</a>
				</div>
				${Object.keys(by_trainee)
					.map(
						(t) => `
					<div class="duty-lead-section">👤 ${frappe.utils.escape_html(t)}</div>
					${by_trainee[t]
						.map(
							(r) => `
						<div class="duty-acad-row">
							${r.status === "Completed" ? "🏅" : "📖"} <b>${frappe.utils.escape_html(r.module_title)}</b>
							${r.product ? `<span class="text-muted">${frappe.utils.escape_html(r.product)}</span>` : ""}
							${r.status === "Completed"
								? `<span class="duty-acad-done">✓ ${__("certified")} ${r.completed_on}</span>`
								: `<button type="button" class="btn btn-xs btn-primary duty-acad-complete" data-id="${r.name}">🏅 ${__("Mark completed — issue certificate")}</button>`}
						</div>`
						)
						.join("")}`
					)
					.join("") || `<div class="text-muted">${__("No training assigned in this room yet.")}</div>`}
				<div class="duty-lead-section">＋ ${__("Assign training")}</div>
				<div class="duty-cr-addmem" style="flex-wrap:wrap">
					<select class="form-control input-sm duty-acad-user" style="flex:1">
						${members.map((m) => `<option value="${frappe.utils.escape_html(m.user)}">${frappe.utils.escape_html(m.full_name || m.user)}</option>`).join("")}
					</select>
					<select class="form-control input-sm duty-acad-mod" style="flex:1">
						${mods.map((m) => `<option value="${m.name}">${frappe.utils.escape_html((m.product ? m.product + " · " : "") + m.title)}</option>`).join("")}
					</select>
					<button type="button" class="btn btn-sm btn-primary duty-acad-assign">＋</button>
					<a class="duty-acad-newmod" style="cursor:pointer;font-size:var(--text-xs);align-self:center">＋ ${__("new module")}</a>
				</div>
				<div class="duty-cr-addmem duty-acad-trackrow" style="flex-wrap:wrap;margin-top:6px;display:none">
					<select class="form-control input-sm duty-acad-track" style="flex:1"></select>
					<button type="button" class="btn btn-sm btn-primary duty-acad-assigntrack">🎓 ${__("Assign whole track")}</button>
				</div>
			`);
			frappe.call({
				method: "duty_board.client_room.room_tracks_for_assign",
				args: { name: x.name },
				callback: (tr) => {
					const tracks = tr.message || [];
					if (!tracks.length) return;
					const $row = $(d.body).find(".duty-acad-trackrow");
					$row.find(".duty-acad-track").html(
						tracks
							.map(
								(t) =>
									`<option value="${t.name}">🎓 ${frappe.utils.escape_html((t.product ? t.product + " · " : "") + t.title)} (${t.module_count} ${__("courses")})</option>`
							)
							.join("")
					);
					$row.show();
					$row.find(".duty-acad-assigntrack").on("click", () =>
						frappe.call({
							method: "duty_board.client_room.training_assign_track_room",
							args: {
								name: x.name,
								track: $row.find(".duty-acad-track").val(),
								user: $(d.body).find(".duty-acad-user").val(),
							},
							callback: (rr) => {
								const m = rr.message || {};
								frappe.show_alert({
									message: __("🎓 Track assigned: {0} new, {1} already had.", [m.created || 0, m.existing || 0]),
									indicator: "green",
								});
								d.hide();
								this.academy_dialog(x);
							},
						})
					);
				},
			});
			$(d.body).find(".duty-acad-assign").on("click", () =>
				frappe.call({
					method: "duty_board.client_room.training_assign",
					args: {
						name: x.name,
						module: $(d.body).find(".duty-acad-mod").val(),
						user: $(d.body).find(".duty-acad-user").val(),
					},
					callback: () => load(),
				})
			);
			$(d.body).find(".duty-acad-complete").on("click", (e) =>
				frappe.confirm(
					__("Mark completed and issue the branded certificate to the client's shelf?"),
					() =>
						frappe.call({
							method: "duty_board.client_room.training_complete",
							args: { record: $(e.currentTarget).data("id") },
							callback: () => {
								load();
								this.load_client_room(x.name);
							},
						})
				)
			);
			$(d.body).find(".duty-acad-newmod").on("click", () =>
				frappe.prompt(
					[
						{ fieldname: "title", fieldtype: "Data", label: __("Module title"), reqd: 1 },
						{ fieldname: "product", fieldtype: "Link", options: "Duty Product", label: __("Product") },
					],
					(v) =>
						frappe.call({
							method: "duty_board.client_room.training_module_add",
							args: { title: v.title, product: v.product || "" },
							callback: () => load(),
						}),
					__("New training module"),
					__("Add")
				)
			);
		};
		$(d.body).on("click", ".duty-acad-prods", () =>
			frappe.call({
				method: "duty_board.client_room.product_options",
				callback: (pr) => {
					const opts = pr.message || [];
					if (!opts.length)
						return frappe.msgprint(
							__("No products defined yet — product names come from your certification tracks and training modules in the desk.")
						);
					const current = (x.products || "").split(",").map((s) => s.trim()).filter(Boolean);
					frappe.prompt(
						[
							{
								fieldname: "products",
								fieldtype: "MultiCheck",
								label: __("Products"),
								columns: 2,
								options: opts.map((o) => ({ label: o, value: o, checked: current.includes(o) })),
							},
						],
						(v) =>
							frappe.call({
								method: "duty_board.client_room.room_set_products",
								args: { name: x.name, products: (v.products || []).join(", ") },
								callback: (r) => {
									if (r.message) {
										x.products = r.message.products;
										this.render_client_room(r.message);
										load();
									}
								},
							}),
						__("Room products — members see and can pursue the client tracks of these products"),
						__("Save")
					);
				},
			})
		);
		load();
		d.show();
	}

	chreqs_dialog(x) {
		if (!document.getElementById("xcr-css")) {
			const f = document.createElement("link");
			f.rel = "stylesheet";
			f.href = "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600&display=swap";
			document.head.appendChild(f);
			const s = document.createElement("style");
			s.id = "xcr-css";
			s.textContent = `
			.xcr{--ink:#182420;--mut:#6B7772;--fnt:#96A09B;--ln:#E8E5DD;--soft:#EFEDE6;--brand:#0E5A4A;--bsoft:#E4EEEA;--amber:#A96F1A;--asoft:#FBF3E4;--red:#B0443C;--good:#2E7D5B;font-size:13.5px;color:var(--ink)}
			.xcr-sum{font-size:12px;color:var(--mut);margin:0 2px 12px}
			.xcr-row{display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px solid var(--ln);border-radius:12px;margin-bottom:8px;cursor:pointer;background:#fff;transition:box-shadow .1s}
			.xcr-row:hover{box-shadow:0 2px 10px -4px rgba(24,36,32,.18)}
			.xcr-dot{width:10px;height:10px;border-radius:50%;flex:none}
			.xcr-row .t{font-weight:600;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
			.xcr-row .s{font-size:12px;color:var(--fnt);margin-left:auto;white-space:nowrap;display:flex;gap:10px;align-items:center}
			.xcr-chip{font-size:11px;font-weight:700;letter-spacing:.04em;border-radius:99px;padding:3px 10px;background:var(--soft);color:var(--mut);white-space:nowrap}
			.xcr-chip.amber{background:var(--asoft);color:var(--amber)}
			.xcr-chip.green{background:var(--bsoft);color:var(--brand)}
			.xcr-chip.red{background:#FBEDEB;color:var(--red)}
			.xcr-amt{font-family:'Fraunces',serif;font-weight:600;font-size:14px;color:var(--ink)}
			.xcr-back{font-size:12.5px;font-weight:600;color:var(--mut);cursor:pointer;display:inline-block;margin-bottom:10px}
			.xcr-back:hover{color:var(--ink)}
			.xcr-h{font-family:'Fraunces',serif;font-weight:600;font-size:20px;letter-spacing:-.01em;margin:0 0 10px}
			.xcr-steps{display:flex;gap:0;margin:14px 0 16px}
			.xcr-step{flex:1;text-align:center;font-size:10.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--fnt);position:relative;padding-top:14px}
			.xcr-step::before{content:"";position:absolute;top:4px;left:50%;transform:translateX(-50%);width:9px;height:9px;border-radius:50%;background:var(--ln)}
			.xcr-step::after{content:"";position:absolute;top:8px;left:calc(50% + 8px);right:calc(-50% + 8px);height:2px;background:var(--ln)}
			.xcr-step:last-child::after{display:none}
			.xcr-step.on{color:var(--brand)}.xcr-step.on::before{background:var(--brand)}
			.xcr-step.now{color:var(--ink)}.xcr-step.now::before{background:var(--brand);box-shadow:0 0 0 3px var(--bsoft)}
			.xcr-step.bad{color:var(--red)}.xcr-step.bad::before{background:var(--red)}
			.xcr-note{border-radius:10px;padding:9px 12px;font-size:12.5px;margin-bottom:12px}
			.xcr-note.amber{background:var(--asoft);color:var(--amber)}
			.xcr-note.green{background:var(--bsoft);color:var(--brand)}
			.xcr-f{display:grid;grid-template-columns:110px 1fr;gap:7px 14px;margin:12px 0}
			.xcr-f dt{font-size:10.5px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:var(--fnt);padding-top:2px}
			.xcr-f dd{margin:0;font-size:13px;color:var(--ink);white-space:pre-wrap}
			.xcr-acts{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;padding-top:12px;border-top:1px solid var(--ln)}
			.xcr-acts button{border:0;border-radius:9px;padding:7px 14px;font-size:12.5px;font-weight:600;cursor:pointer;background:var(--soft);color:var(--ink)}
			.xcr-acts button.pri{background:var(--brand);color:#fff}
			.xcr-acts button.dngr{background:#FBEDEB;color:var(--red)}
			.xcr-new{display:flex;gap:8px;margin-top:12px}
			.xcr-new input{flex:1;border:1px solid var(--ln);border-radius:10px;padding:8px 12px;font-size:13px}
			.xcr-new button{border:0;border-radius:10px;padding:8px 16px;background:var(--brand);color:#fff;font-weight:600;cursor:pointer}
			.xcr-empty{color:var(--fnt);font-size:13px;padding:18px 4px}`;
			document.head.appendChild(s);
		}
		const d = new frappe.ui.Dialog({ title: `${frappe.utils.escape_html(x.customer || "")} — ${__("Change requests")}`, size: "large" });
		let view = null;
		const PRICE_CHIP = (c) => {
			const ps = c.pricing_status || "Awaiting Pricing";
			if (c.status === "Declined") return `<span class="xcr-chip red">${__("declined")}</span>`;
			if (ps === "Awaiting Pricing") return `<span class="xcr-chip amber">${__("awaiting pricing")}</span>`;
			if (ps === "Priced") return `<span class="xcr-amt">${frappe.utils.escape_html(c.cost_fmt || "")}</span>`;
			if (ps === "Covered by Subscription") return `<span class="xcr-chip green">${__("covered")}</span>`;
			if (ps === "Goodwill") return `<span class="xcr-chip green">${__("goodwill")}</span>`;
			return `<span class="xcr-chip">${__(ps.toLowerCase())}</span>`;
		};
		const DOT = (c) =>
			c.status === "Declined" ? "var(--red)"
			: ["Approved", "Delivered"].includes(c.status) ? "var(--good)"
			: c.status === "In Delivery" ? "#0E7490"
			: (c.pricing_status || "Awaiting Pricing") === "Awaiting Pricing" || c.status === "Awaiting Approval" ? "var(--amber)"
			: "var(--fnt)";
		const call = (method, args) =>
			frappe.call({
				method: "duty_board.client_room." + method,
				args: args,
				callback: (r) => {
					if (r.message) {
						render(r.message);
						this.render_client_room(r.message);
					}
				},
			});
		const stepper = (c) => {
			const ps = c.pricing_status || "Awaiting Pricing";
			const free = ["Covered by Subscription", "Goodwill"].includes(ps);
			const steps = free
				? [__("Drafted"), ps === "Goodwill" ? __("Goodwill") : __("Covered"), __("In delivery"), __("Delivered")]
				: [__("Drafted"), __("Priced"), __("Client approval"), __("Approved"), __("In delivery"), __("Delivered")];
			let idx = 0;
			if (free) idx = c.status === "Delivered" ? 3 : c.status === "In Delivery" ? 2 : 1;
			else if (c.status === "Delivered") idx = 5;
			else if (c.status === "In Delivery") idx = 4;
			else if (c.status === "Approved") idx = 3;
			else if (c.status === "Awaiting Approval") idx = 2;
			else idx = ps === "Priced" ? 1 : 0;
			const bad = c.status === "Declined";
			return `<div class="xcr-steps">${steps
				.map((s, i) => `<div class="xcr-step ${bad && i === 2 ? "bad" : i < idx ? "on" : i === idx ? "now" : ""}">${s}</div>`)
				.join("")}</div>`;
		};
		const render = (data) => {
			const crs = data.change_requests || [];
			if (view && !crs.some((z) => z.name === view)) view = null;
			if (!view) {
				const waitP = crs.filter((z) => (z.pricing_status || "Awaiting Pricing") === "Awaiting Pricing" && z.status !== "Declined").length;
				const waitC = crs.filter((z) => z.status === "Awaiting Approval").length;
				$(d.body).html(`<div class="xcr">
					<div class="xcr-sum">${crs.length} ${__("total")}${waitP ? ` · <b style="color:var(--amber)">${waitP} ${__("awaiting pricing")}</b>` : ""}${waitC ? ` · ${waitC} ${__("with the client")}` : ""}</div>
					${crs.length ? crs.map((c) => `
						<div class="xcr-row" data-open="${c.name}">
							<span class="xcr-dot" style="background:${DOT(c)}"></span>
							<span class="t">${frappe.utils.escape_html(c.title)}</span>
							<span class="s">
								${c.cards_total ? `<span>${c.cards_done}/${c.cards_total} ${__("tasks")}</span>` : ""}
								${PRICE_CHIP(c)}
								<span class="xcr-chip">${__(c.status)}</span>
								<span style="color:var(--ln)">›</span>
							</span>
						</div>`).join("") : `<div class="xcr-empty">${__("No change requests yet — work beyond the subscription starts its life here.")}</div>`}
					<div class="xcr-new">
						<input type="text" maxlength="140" placeholder="${__("New change request — title…")}">
						<button>＋ ${__("Draft it")}</button>
					</div>
				</div>`);
				$(d.body).find(".xcr-row").on("click", (e) => { view = $(e.currentTarget).data("open"); render(data); });
				const $in = $(d.body).find(".xcr-new input");
				$(d.body).find(".xcr-new button").on("click", () => {
					const t = ($in.val() || "").trim();
					if (t) call("chreq_add", { name: x.name, title: t });
				});
				return;
			}
			const c = crs.find((z) => z.name === view);
			const ps = c.pricing_status || "Awaiting Pricing";
			const locked = ["Approved", "In Delivery", "Delivered"].includes(c.status);
			const F = [
				[__("Request"), c.original_request], [__("Why"), c.reason], [__("Scope"), c.scope_impact],
				[__("Timeline"), c.timeline_impact], [__("Resources"), c.resource_impact], [__("Risks"), c.risks],
			].filter((z) => (z[1] || "").trim());
			$(d.body).html(`<div class="xcr">
				<span class="xcr-back">‹ ${__("All change requests")}</span>
				<div class="xcr-h">${frappe.utils.escape_html(c.title)}</div>
				<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
					${PRICE_CHIP(c)}<span class="xcr-chip">${__(c.status)}</span>
					${c.invoice_status ? `<span class="xcr-chip ${c.invoice_status === "Paid" ? "green" : "amber"}">${__(c.invoice_status.toLowerCase())}</span>` : ""}
					${c.cards_total ? `<span class="xcr-chip">${c.cards_done}/${c.cards_total} ${__("tasks")}</span>` : ""}
				</div>
				${stepper(c)}
				${c.status === "Draft" && ps === "Awaiting Pricing" ? `<div class="xcr-note amber">⏳ ${this.is_pricer ? __("In YOUR pricing queue — decide below and it moves.") : __("In the pricing queue — it reaches the client once priced or covered.")}</div>` : ""}
				${c.status === "Draft" && ps === "Priced" ? `<div class="xcr-note green">${__("Priced and ready — send it to the client for formal approval.")}</div>` : ""}
				${["Covered by Subscription", "Goodwill"].includes(ps) && !locked && c.status !== "Declined" ? `<div class="xcr-note green">${__("No charge — work can proceed; start delivery when ready.")}</div>` : ""}
				${c.status === "Awaiting Approval" ? `<div class="xcr-note amber">${__("With the client for sign-off.")}</div>` : ""}
				${c.status === "Declined" ? `<div class="xcr-note amber">↩ ${frappe.utils.escape_html(c.decline_reason || __("Declined by the client."))}</div>` : ""}
				${["Approved", "In Delivery", "Delivered"].includes(c.status) && c.approved_full ? `<div class="xcr-note green">✍ ${__("Approved by")} ${frappe.utils.escape_html(c.approved_full)} · ${frappe.utils.escape_html(c.approved_at || "")}</div>` : ""}
				${F.length ? `<dl class="xcr-f">${F.map((z) => `<dt>${z[0]}</dt><dd>${frappe.utils.escape_html(z[1])}</dd>`).join("")}</dl>` : ""}
				<div class="xcr-acts">
					${ps === "Awaiting Pricing" && c.status !== "Declined" && this.is_pricer ? `<button data-a="price" class="pri">${__("Price now")}</button>` : ""}
					${!locked ? `<button data-a="edit">${__("Edit")}</button>` : ""}
					<button data-a="tasks">${__("Tasks")}</button>
					<button data-a="newtask">＋ ${__("New task")}</button>
					${c.source_message ? `<button data-a="origin">${__("Origin")}</button>` : ""}
					${c.status === "Draft" && ps === "Priced" ? `<button data-a="ask" class="pri">${__("Send for approval")}</button>` : ""}
					${!locked && ["Covered by Subscription", "Goodwill"].includes(ps) && c.status !== "Declined" ? `<button data-a="deliver" class="pri">${__("Start delivery")}</button>` : ""}
					${c.status === "Awaiting Approval" ? `<button data-a="recall">${__("Recall")}</button>` : ""}
					${c.status === "Declined" ? `<button data-a="reopen">${__("Revise")}</button>` : ""}
					${c.status === "Approved" ? `<button data-a="deliver" class="pri">${__("Start delivery")}</button>` : ""}
					${c.status === "In Delivery" ? `<button data-a="done" class="pri">${__("Mark delivered")}</button>` : ""}
					${["Draft", "Declined"].includes(c.status) ? `<button data-a="del" class="dngr">${__("Delete")}</button>` : ""}
				</div>
			</div>`);
			$(d.body).find(".xcr-back").on("click", () => { view = null; render(data); });
			$(d.body).find(".xcr-acts button").on("click", (e) => {
				const a = $(e.currentTarget).data("a");
				const id = c.name;
				if (a === "price")
					return frappe.prompt(
						[
							{ fieldname: "decision", fieldtype: "Select", label: __("Decision"), options: ["Priced", "Covered by Subscription", "Goodwill", "Rejected", "Deferred"], reqd: 1 },
							{ fieldname: "price", fieldtype: "Currency", label: __("Price (₦, for Priced)") },
							{ fieldname: "estimate_hours", fieldtype: "Float", label: __("Estimated hours") },
							{ fieldname: "note", fieldtype: "Small Text", label: __("Note (kept on the CR)") },
						],
						(v) =>
							frappe.call({
								method: "duty_board.commercial.chreq_price",
								args: { name: id, decision: v.decision, price: v.price || 0, estimate_hours: v.estimate_hours || 0, note: v.note || null },
								callback: () =>
									frappe.call({
										method: "duty_board.client_room.get_room",
										args: { name: x.name },
										callback: (rr) => {
											if (rr.message) {
												render(rr.message);
												this.render_client_room(rr.message);
											}
										},
									}),
							}),
						__("Price this CR"),
						__("Apply")
					);
				if (a === "ask")
					return frappe.confirm(
						__("Send “{0}” to the client for formal approval? They will see the scope, cost and timeline impacts.", [frappe.utils.escape_html(c.title)]),
						() => call("chreq_request_approval", { id: id })
					);
				if (a === "newtask")
					return frappe.prompt(
						[
							{ fieldname: "title", fieldtype: "Data", label: __("Task title"), reqd: 1 },
							{ fieldname: "assignee", fieldtype: "Autocomplete", label: __("Assignee"), options: this.staff_options() },
							{ fieldname: "due_date", fieldtype: "Date", label: __("Due") },
						],
						(v) => call("chreq_new_task", { id: id, title: v.title, assignee: v.assignee || null, due_date: v.due_date || null }),
						__("New delivery task for this CR"),
						__("Create")
					);
				if (a === "origin") { d.hide(); return this.jump_to_msg(c.source_message); }
				if (a === "recall") return call("chreq_set_status", { id: id, status: "Draft" });
				if (a === "deliver") return call("chreq_set_status", { id: id, status: "In Delivery" });
				if (a === "done") return call("chreq_set_status", { id: id, status: "Delivered" });
				if (a === "reopen") return call("chreq_reopen", { id: id });
				if (a === "del")
					return frappe.confirm(__("Delete this change request?"), () => { view = null; call("chreq_delete", { id: id }); });
				if (a === "tasks") {
					return frappe.call({
						method: "duty_board.client_room.chreq_task_options",
						args: { id: id },
						callback: (r) => {
							const opts = r.message || {};
							if (!opts.project) {
								frappe.msgprint(__("Link a project to this room first — tasks live on the project board."));
								return;
							}
							const td = new frappe.ui.Dialog({ title: `${__("Tasks delivering")} “${frappe.utils.escape_html(c.title || "")}”` });
							$(td.body).html(
								(opts.tasks || [])
									.map(
										(t) => `
								<label class="duty-cr-mstask ${t.elsewhere ? "elsewhere" : ""}" style="display:flex;gap:8px;align-items:center;padding:4px 0">
									<input type="checkbox" data-name="${t.name}" ${t.checked ? "checked" : ""} ${t.elsewhere ? "disabled" : ""}>
									<span>${frappe.utils.escape_html(t.title)}</span>
									<span class="text-muted" style="margin-left:auto">${__(t.column)}${t.elsewhere ? " · " + __("on another CR") : ""}</span>
								</label>`
									)
									.join("") || `<div class="text-muted">${__("No cards on this project board yet.")}</div>`
							);
							td.set_primary_action(__("Save"), () => {
								const chosen = [];
								$(td.body).find("input:checked").each(function () {
									chosen.push($(this).data("name"));
								});
								frappe.call({
									method: "duty_board.client_room.chreq_set_tasks",
									args: { id: id, tasks: JSON.stringify(chosen) },
									callback: (r2) => {
										td.hide();
										if (r2.message) {
											render(r2.message);
											this.render_client_room(r2.message);
										}
									},
								});
							});
							td.show();
						},
					});
				}
				if (a === "edit") {
					return frappe.prompt(
						[
							{ fieldname: "title", fieldtype: "Data", label: __("Title"), default: c.title, reqd: 1 },
							{ fieldname: "reason", fieldtype: "Small Text", label: __("Business reason"), default: c.reason },
							{ fieldname: "scope_impact", fieldtype: "Text", label: __("Scope impact (client sees this)"), default: c.scope_impact },
							{ fieldname: "timeline_impact", fieldtype: "Data", label: __("Timeline impact — e.g. +2 weeks"), default: c.timeline_impact },
							{ fieldname: "cost_impact", fieldtype: "Currency", label: __("Cost impact"), default: c.cost_impact },
							{ fieldname: "resource_impact", fieldtype: "Small Text", label: __("Resources"), default: c.resource_impact },
							{ fieldname: "risks", fieldtype: "Small Text", label: __("Risks"), default: c.risks },
							{ fieldname: "quotation", fieldtype: "Link", options: "Quotation", label: __("Quotation"), default: c.quotation },
						],
						(v) =>
							call("chreq_update", {
								id: id, title: v.title, reason: v.reason || null,
								scope_impact: v.scope_impact || null, timeline_impact: v.timeline_impact || null,
								cost_impact: v.cost_impact || 0, resource_impact: v.resource_impact || null,
								risks: v.risks || null, quotation: v.quotation || null,
							}),
						__("Edit change request"),
						__("Save")
					);
				}
			});
		};
		render(x);
		d.show();
	}

	room_shelf_dialog(x) {
		const d = new frappe.ui.Dialog({ title: `📚 ${frappe.utils.escape_html(x.customer || "")} — ${__("Shelf")}` });
		const load = () =>
			frappe.call({
				method: "duty_board.client_room.get_room",
				args: { name: x.name },
				callback: (r) => r.message && render(r.message.shelf || []),
			});
		const render = (docs) => {
			$(d.body).html(`
				<div class="duty-cr-shelflist">
					${docs
						.map(
							(s) =>
								`<div class="duty-cr-mem"><a href="/api/method/duty_board.client_room.staff_shelf_file?id=${encodeURIComponent(s.name)}" target="_blank"><b>📄 ${frappe.utils.escape_html(s.title)}</b></a> ${s.category ? `<span class="duty-lead-chip">${frappe.utils.escape_html(s.category)}</span>` : ""} <span class="text-muted">${s.creation}</span> <a class="duty-cr-shelfrm" data-name="${s.name}" style="margin-left:auto;color:var(--red-600,#dc2626)">${__("Remove")}</a></div>`
						)
						.join("") || `<div class="text-muted">${__("Empty shelf — add the manuals and agreements this client should always have.")}</div>`}
				</div>
				<div class="duty-lead-section">＋ ${__("Add document")}</div>
				<div class="duty-cr-addmem" style="flex-wrap:wrap">
					<input type="text" class="form-control input-sm duty-sh-title" placeholder="${__("Title")}" style="flex:2">
					<input type="text" class="form-control input-sm duty-sh-cat" placeholder="${__("Category (optional)")}" style="flex:1">
					<label class="btn btn-sm btn-default" style="margin:0">📎 ${__("Choose file")}<input type="file" hidden class="duty-sh-file"></label>
					<button type="button" class="btn btn-sm btn-primary duty-sh-add">＋ ${__("Publish")}</button>
				</div>
				<p class="text-muted duty-attach-hint">${__("Everything here is permanently visible on the client's portal.")}</p>
			`);
			let pending = null;
			$(d.body).find(".duty-sh-file").on("change", (e) => {
				pending = e.target.files[0] || null;
				if (pending) $(e.target).parent().contents().first()[0].textContent = "📎 " + pending.name.slice(0, 24) + " ";
			});			$(d.body).find(".duty-cr-shelfrm").on("click", (e) =>
				frappe.confirm(__("Remove from the client's shelf?"), () =>
					frappe.call({
						method: "duty_board.client_room.shelf_remove",
						args: { doc_name: $(e.currentTarget).data("name") },
						callback: load,
					})
				)
			);
			$(d.body).find(".duty-sh-add").on("click", async () => {
				const title = $(d.body).find(".duty-sh-title").val().trim();
				const cat = $(d.body).find(".duty-sh-cat").val().trim();
				if (!title || !pending) {
					frappe.msgprint(__("A title and a file are both needed."));
					return;
				}
				try {
					const up = await this.upload_private_file(pending);
					frappe.call({
						method: "duty_board.client_room.shelf_add",
						args: {
							name: x.name,
							title: title,
							category: cat || null,
							attachment_url: up.file_url,
							attachment_name: up.file_name,
						},
						callback: (r) => r.message && render(r.message.shelf || []),
					});
				} catch (err) {
					frappe.msgprint(__("Upload failed: {0}", [frappe.utils.escape_html(err.message || "")]));
				}
			});
		};
		render(x.shelf || []);
		d.show();
	}

	room_members_dialog(x) {
		const d = new frappe.ui.Dialog({ title: `👥 ${frappe.utils.escape_html(x.customer || "")}` });
		const render = (data) => {
			$(d.body).html(`
				<div class="duty-cr-memlist">
					${(data.members || [])
						.map(
							(m) =>
								`<div class="duty-cr-mem">${m.is_admin ? "★ " : ""}<b>${frappe.utils.escape_html(m.full_name)}</b>${m.member_type === "Consultant" ? ` <span class="duty-cons-chip">${__("CONSULTANT")}</span>` : ""} <span class="text-muted">${frappe.utils.escape_html(m.user)}${m.is_admin ? " · " + __("administrator") : ""}</span> <a class="duty-cr-memadmin" data-name="${m.name}" data-on="${m.is_admin ? 0 : 1}">${m.is_admin ? "☆ " + __("Demote") : "★ " + __("Make admin")}</a> <a class="duty-cr-memrm" data-name="${m.name}">${__("Remove")}</a></div>`
						)
						.join("") || `<div class="text-muted">${__("No client members yet.")}</div>`}
				</div>
				${
					(data.requests || []).length
						? `<div class="duty-lead-section">🙋 ${__("Waiting for approval")}</div>` +
							data.requests
								.map(
									(q) =>
										`<div class="duty-cr-mem"><b>${frappe.utils.escape_html(q.full_name)}</b> <span class="text-muted">${frappe.utils.escape_html(q.email)}${q.phone ? " · " + frappe.utils.escape_html(q.phone) : ""}</span> <a class="duty-cr-approve" data-name="${q.name}">✔ ${__("Approve")}</a> <a class="duty-cr-rejectq" data-name="${q.name}">✖</a></div>`
								)
								.join("")
						: ""
				}
				<div class="duty-lead-section">🔗 ${__("Invite link")}</div>
				<div class="duty-cr-joinlink">
					<input type="text" class="form-control input-sm" readonly value="${frappe.utils.escape_html(data.join_url || "")}">
					<button type="button" class="btn btn-sm btn-default duty-cr-copylink">${__("Copy")}</button>
				</div>
				<p class="text-muted duty-attach-hint">${__("Share this with the client — anyone who submits the form appears above for approval.")}</p>
				<div class="duty-cr-addmem">
					<input type="text" class="form-control input-sm duty-cr-em" placeholder="${__("client email")}">
					<input type="text" class="form-control input-sm duty-cr-nm" placeholder="${__("full name")}">
					<button type="button" class="btn btn-sm btn-primary duty-cr-addbtn">＋</button>
				</div>
				<p class="text-muted duty-attach-hint">${__("New members get a welcome email with a password link. Their portal: {0}", ["<b>" + location.origin + "/portal</b>"])}</p>
				<div class="duty-lead-section">👷 ${__("External consultant")}</div>
				<div class="duty-cr-addmem">
					<input type="text" class="form-control input-sm duty-cr-cem" placeholder="${__("consultant email")}">
					<input type="text" class="form-control input-sm duty-cr-cnm" placeholder="${__("full name")}">
					<button type="button" class="btn btn-sm btn-default duty-cr-caddbtn">👷 ＋</button>
				</div>
				<p class="text-muted duty-attach-hint">${__("Creates their consultant login (welcome email with password link), joins them to this room, and leaves an internal note. They see this room's conversation and their assigned issues — nothing else.")}</p>
				<div class="duty-lead-section">📅 ${__("Bookable for meetings")}</div>
				<div class="duty-cr-bookable">
					${[{ user: frappe.session.user, full_name: frappe.session.user_fullname || frappe.session.user }]
						.concat(this.team_members() || [])
						.filter((s, i, arr) => s.user !== "Administrator" && arr.findIndex((z) => z.user === s.user) === i)
						.map(
							(s) =>
								`<label style="margin-right:12px;font-size:var(--text-sm)"><input type="checkbox" value="${frappe.utils.escape_html(s.user)}" ${(data.meeting_staff || []).includes(s.user) ? "checked" : ""}> ${frappe.utils.escape_html((s.full_name || s.user).split(" ")[0])}</label>`
						)
						.join("")}
					<button type="button" class="btn btn-sm btn-primary duty-cr-booksave">${__("Save")}</button>
				</div>
				<p class="text-muted duty-attach-hint">${__("Ticked staff appear in the client's meeting picker. Nobody ticked = everyone bookable.")}</p>
			`);
			$(d.body).find(".duty-cr-booksave").on("click", () => {
				const users = $(d.body)
					.find(".duty-cr-bookable input:checked")
					.map((i, el) => el.value)
					.get();
				frappe.call({
					method: "duty_board.client_room.set_meeting_staff",
					args: { name: x.name, users: JSON.stringify(users) },
					callback: (r) => r.message && render(r.message),
				});
			});
			$(d.body).find(".duty-cr-addbtn").on("click", () => {
				const email = $(d.body).find(".duty-cr-em").val().trim();
				const nm = $(d.body).find(".duty-cr-nm").val().trim();
				if (!email) return;
				frappe.call({
					method: "duty_board.client_room.add_member",
					args: { name: x.name, email: email, full_name: nm },
					callback: (r) => r.message && render(r.message),
				});
			});
			$(d.body).find(".duty-cr-copylink").on("click", (e) => {
				const $inp = $(d.body).find(".duty-cr-joinlink input");
				$inp.trigger("select");
				try {
					navigator.clipboard.writeText($inp.val());
					frappe.show_alert({ message: __("Link copied"), indicator: "green" }, 3);
				} catch (err) {
					document.execCommand("copy");
				}
			});
			$(d.body).find(".duty-cr-approve").on("click", (e) =>
				frappe.call({
					method: "duty_board.client_room.approve_join",
					args: { request_name: $(e.currentTarget).data("name") },
					callback: (r) => r.message && render(r.message),
				})
			);
			$(d.body).find(".duty-cr-rejectq").on("click", (e) =>
				frappe.call({
					method: "duty_board.client_room.reject_join",
					args: { request_name: $(e.currentTarget).data("name") },
					callback: (r) => r.message && render(r.message),
				})
			);
			$(d.body).find(".duty-cr-memadmin").on("click", (e) =>
				frappe.call({
					method: "duty_board.client_room.member_set_admin",
					args: { member_name: $(e.currentTarget).data("name"), on: $(e.currentTarget).data("on") },
					callback: (r) => {
						if (r.message) {
							render(r.message);
							this.render_client_room(r.message);
						}
					},
				})
			);
			$(d.body).find(".duty-cr-caddbtn").on("click", () => {
				const email = $(d.body).find(".duty-cr-cem").val().trim();
				const nm = $(d.body).find(".duty-cr-cnm").val().trim();
				if (!email) return;
				frappe.call({
					method: "duty_board.client_room.invite_consultant",
					args: { room: x.name, email: email, full_name: nm || null },
					callback: (r) => {
						if (!r.message) return;
						frappe.show_alert({
							message: r.message.created
								? __("Consultant created and joined — welcome email sent.")
								: __("Consultant joined this room."),
							indicator: "green",
						});
						d.hide();
						this.load_client_room(x.name);
					},
				});
			});
			$(d.body).find(".duty-cr-memrm").on("click", (e) =>
				frappe.confirm(__("Remove this member's access?"), () =>
					frappe.call({
						method: "duty_board.client_room.remove_member",
						args: { member_name: $(e.currentTarget).data("name") },
						callback: () => this.load_client_room(x.name),
					}).then(() => d.hide())
				)
			);
		};
		render(x);
		d.show();
	}

	// ---------------- Sales face ----------------

	attach_mention_picker($input, extra) {
		const $wrap = $input.parent();
		$wrap.addClass("duty-mention-host");
		const $dd = $('<div class="duty-mention-dd" style="display:none"></div>').appendTo($wrap);
		const staff = () =>
			[{ user: frappe.session.user, full_name: this.name_map[frappe.session.user] || frappe.session.user }]
				.concat(this.team_members())
				.concat((typeof extra === "function" ? extra() : extra) || []);
		const frag = () => {
			const v = $input.val();
			const pos = $input[0].selectionStart;
			const m = v.slice(0, pos).match(/@([A-Za-z0-9._-]*)$/);
			return m ? { start: pos - m[0].length, text: m[1], pos: pos } : null;
		};
		const close = () => $dd.hide().empty();
		const render = () => {
			const f = frag();
			if (!f) return close();
			const q = f.text.toLowerCase();
			const opts = staff()
				.filter(
					(s) =>
						(s.full_name || s.user).toLowerCase().includes(q) ||
						s.user.toLowerCase().includes(q)
				)
				.slice(0, 6);
			if (!opts.length) return close();
			$dd.empty().show();
			opts.forEach((s) => {
				$(
					`<a class="duty-mention-opt" style="color:${this.user_color(s.user)}">${frappe.utils.escape_html(s.full_name || s.user)}</a>`
				)
					.appendTo($dd)
					.on("mousedown", (e) => {
						e.preventDefault();
						const f2 = frag();
						if (!f2) return close();
						const v = $input.val();
						const first = (s.full_name || s.user).split(" ")[0];
						$input.val(v.slice(0, f2.start) + "@" + first + " " + v.slice(f2.pos));
						close();
						$input.focus();
					});
			});
		};
		$input.on("input keyup click", render);
		$input.on("blur", () => setTimeout(close, 150));
		$input.on("keydown", (e) => {
			if (e.key === "Enter" && $dd.is(":visible")) {
				e.preventDefault();
				e.stopImmediatePropagation();
				$dd.find(".duty-mention-opt").first().trigger("mousedown");
			}
			if (e.key === "Escape") close();
		});
	}

	update_notes($x, notes) {
		notes = Array.isArray(notes) ? notes : [];
		$x.find(".duty-lead-notes").html(
			notes.length
				? notes
						.map(
							(n) =>
								`<div class="duty-lead-note"><b>${frappe.utils.escape_html(n.who)}</b> <span class="duty-msg-time">${frappe.datetime.str_to_user(n.when)}</span><br>${this.fmt_note(n.note)}</div>`
						)
						.join("")
				: `<div class="text-muted">${__("No messages yet.")}</div>`
		);
	}

	fmt_note(text) {
		return frappe.utils
			.escape_html(text || "")
			.replace(/@([A-Za-z0-9._-]+)/g, '<b class="duty-note-mention">@$1</b>');
	}

	naira(v) {
		if (v === null || v === undefined) return "";
		try {
			return format_currency(v || 0, frappe.boot.sysdefaults.currency);
		} catch (e) {
			return (v || 0).toLocaleString();
		}
	}

	refresh_sales(silent) {
		frappe.call({
			method: "duty_board.sales.get_pipeline",
			freeze: false,
			error: (x) => this._poll_failed(x),
			callback: (r) => {
				this._fail_count = 0;
				if (r.message) this.render_pipeline(r.message);
			},
		});
	}

	render_radar(rows, $wrap) {
		const esc = frappe.utils.escape_html;
		const HEAT = { Hot: "🔥", Warm: "🌤", Cool: "❄️" };
		const $r = $(`
			<div class="duty-radar">
				<div class="duty-radar-head">
					<b>👁 ${__("Radar")}</b><span>${__("companies we're watching — zero contact yet")}</span>
					<a class="duty-radar-add">＋ ${__("Watch a company")}</a>
				</div>
				<div class="duty-radar-shelf">
					${rows.map((x) => `
					<a class="duty-radar-card duty-heat-${(x.heat || "Warm").toLowerCase()}" data-name="${x.name}">
						<span class="duty-radar-top">${HEAT[x.heat] || "🌤"} <b>${esc(x.company)}</b>${x.sector ? `<i>${esc(x.sector)}</i>` : ""}</span>
						${x.angle ? `<span class="duty-radar-angle">${esc(x.angle.slice(0, 110))}${x.angle.length > 110 ? "…" : ""}</span>` : ""}
						${x.trigger ? `<span class="duty-radar-trig">🎯 ${esc(x.trigger.slice(0, 70))}</span>` : ""}
						${x.est_worth ? `<span class="duty-radar-worth">${this.naira(x.est_worth)}</span>` : ""}
					</a>`).join("") || `<div class="duty-radar-empty">${__("Nothing on the radar — add the first company you're eyeing.")}</div>`}
				</div>
			</div>`).appendTo($wrap);
		const rowsBy = {};
		rows.forEach((x) => (rowsBy[x.name] = x));
		const openDlg = (x) => {
			const d = new frappe.ui.Dialog({
				title: `👁 ${x ? esc(x.company) : __("Watch a company")}`,
				fields: [
					{ fieldname: "company", fieldtype: "Data", label: __("Company"), default: x ? x.company : "", reqd: 1 },
					{ fieldname: "sector", fieldtype: "Data", label: __("Sector"), default: x ? x.sector : "" },
					{ fieldname: "heat", fieldtype: "Select", label: __("Heat"), options: "Hot\nWarm\nCool", default: x ? x.heat : "Warm" },
					{ fieldname: "angle", fieldtype: "Small Text", label: __("The angle — why we're watching"), default: x ? x.angle : "" },
					{ fieldname: "trigger", fieldtype: "Data", label: __("Trigger — what opens the door"), default: x ? x.trigger : "" },
					{ fieldname: "est_worth", fieldtype: "Currency", label: __("Estimated worth if landed"), default: x ? x.est_worth : "" },
					{ fieldname: "link", fieldtype: "Data", label: __("Source link"), default: x ? x.link : "" },
					...(x ? [{ fieldname: "log", fieldtype: "HTML" }, { fieldname: "signal", fieldtype: "Data", label: __("New signal (funding news, churn, tender…)") }] : []),
				],
				primary_action_label: x ? __("Save") : __("Start watching"),
				primary_action: (v) => {
					d.hide();
					const args = { company: v.company, sector: v.sector || "", angle: v.angle || "", heat: v.heat, trigger: v.trigger || "", est_worth: v.est_worth || 0, link: v.link || "" };
					const after = () => {
						if (x && v.signal) frappe.call({ method: "duty_board.sales.radar_note", args: { name: x.name, note: v.signal }, callback: () => this.refresh_sales() });
						else this.refresh_sales();
					};
					if (x) frappe.call({ method: "duty_board.sales.radar_update", args: Object.assign({ name: x.name }, args), callback: after });
					else frappe.call({ method: "duty_board.sales.radar_add", args: args, callback: after });
				},
			});
			if (x) {
				d.set_secondary_action_label(__("📣 Promote to Lead"));
				d.set_secondary_action(() => {
					d.hide();
					frappe.confirm(__("Contact has started with {0}? This creates a pipeline lead and retires the radar entry.", [esc(x.company)]), () =>
						frappe.call({
							method: "duty_board.sales.radar_promote",
							args: { name: x.name },
							callback: (r2) => {
								frappe.show_alert({ message: __("📣 {0} is now a lead — the watch is over.", [esc(x.company)]), indicator: "green" });
								this.refresh_sales();
							},
						})
					);
				});
				$(d.body).append(`<a class="duty-radar-drop">🗑 ${__("Drop from radar")}</a>`);
				$(d.body).find(".duty-radar-drop").on("click", () => {
					d.hide();
					frappe.prompt({ fieldname: "reason", fieldtype: "Data", label: __("Why drop them? (kept as memory)") },
						(v2) => frappe.call({ method: "duty_board.sales.radar_drop", args: { name: x.name, reason: v2.reason || "" }, callback: () => this.refresh_sales() }),
						__("Drop {0}", [esc(x.company)]), __("Drop"));
				});
				const log = (x.notes || "").split("\n").filter(Boolean);
				$(d.body).find('[data-fieldname="log"]').html(
					log.length ? `<div class="duty-radar-log"><b>${__("Signals log")}</b>${log.map((l2) => `<div>${esc(l2)}</div>`).join("")}</div>` : ""
				);
				if (x.link) $(d.body).prepend(`<a href="${esc(x.link)}" target="_blank" rel="noopener" class="duty-radar-visit">🔗 ${esc(x.link.slice(0, 60))}</a>`);
			}
			d.show();
		};
		$r.find(".duty-radar-add").on("click", () => openDlg(null));
		$r.find(".duty-radar-card").on("click", (e) => { e.preventDefault(); openDlg(rowsBy[$(e.currentTarget).data("name")]); });
	}

	render_my_rooms() {
		frappe.call({
			method: "duty_board.client_room.my_rooms_summary",
			error: () => {},
			callback: (r) => {
				const d = r.message;
				if (!d || !this.$me || !this.$me.length) return;
				this.$me.find(".duty-myrooms").remove();
				if (!(d.owned || []).length && !(d.member || []).length) return;
				const esc = frappe.utils.escape_html;
				const chip = (x) => `<a class="duty-mr-chip" data-room="${x.name}">${esc(x.customer)}${x.unit ? ` · ${esc(x.unit)}` : ""}</a>`;
				const $c = $(`
					<div class="duty-myrooms">
						${(d.owned || []).length ? `<div class="duty-mr-sect"><b>🔑 ${__("Rooms I own")}</b><span>${d.owned.map(chip).join("")}</span></div>` : ""}
						${(d.member || []).length ? `<div class="duty-mr-sect"><b>💬 ${__("My rooms")}</b><span>${d.member.map(chip).join("")}</span></div>` : ""}
					</div>`);
				const $g = this.$me.find(".duty-radar-daily");
				if ($g.length) $c.insertAfter($g);
				else {
					const $g2 = this.$me.find(".duty-gamify");
					if ($g2.length) $c.insertAfter($g2);
					else $c.prependTo(this.$me);
				}
				$c.find(".duty-mr-chip").on("click", (e) => {
					const room = $(e.currentTarget).data("room");
					if (this._is_consultant) {
						this.show_face("chat");
						setTimeout(() => this.open_convo("room", String(room)), 400);
					} else {
						this.show_face("clients");
						setTimeout(() => this.open_client_room(room), 400);
					}
				});
			},
		});
	}

	render_radar_today() {
		frappe.call({
			method: "duty_board.sales.radar_today",
			error: () => {},
			callback: (r) => {
				const x = r.message;
				if (!x || !this.$me || !this.$me.length) return;
				this.$me.find(".duty-radar-daily").remove();
				const HEAT = { Hot: "🔥", Warm: "🌤", Cool: "❄️" };
				const $c = $(`
					<div class="duty-radar-daily">
						<b>👁 ${__("On your radar today")}</b>
						<span class="duty-rdd-co">${HEAT[x.heat] || "🌤"} ${frappe.utils.escape_html(x.company)}${x.sector ? ` · ${frappe.utils.escape_html(x.sector)}` : ""}</span>
						${x.angle ? `<q>${frappe.utils.escape_html(x.angle.slice(0, 160))}</q>` : ""}
						${x.trigger ? `<i>🎯 ${frappe.utils.escape_html(x.trigger)}</i>` : ""}
					</div>`);
				const $g = this.$me.find(".duty-gamify");
				if ($g.length) $c.insertAfter($g);
				else $c.prependTo(this.$me);
				this.render_my_rooms();
			},
		});
	}

	lead_card(l) {
		const owner = `<span style="color:${this.user_color(l.lead_owner)}">${frappe.utils.escape_html((this.name_map[l.lead_owner] || l.lead_owner).split(" ")[0])}</span>`;
		return `
			<div class="duty-kb-card duty-lead-card" draggable="true" data-name="${l.name}" style="border-left: 3px solid ${this.user_color(l.lead_owner)}">
				<div class="duty-lead-company">${frappe.utils.escape_html(l.company)}</div>
				${l.value ? `<div class="duty-lead-value">${this.naira(l.value)}</div>` : ""}
				${l.contact_name ? `<div class="duty-lead-contact">${frappe.utils.escape_html(l.contact_name)}</div>` : ""}
				<div class="duty-kb-meta">
					${owner}
					<span class="duty-lead-badges">
						${l.stale_days >= 7 ? `<span class="duty-stale ${l.stale_days >= 14 ? "duty-stale-red" : ""}" title="${__("Days since last touch")}">🕸 ${l.stale_days}d</span>` : ""}
						${l.expected_close ? `<span class="${l.close_overdue ? "duty-lead-over" : ""}" title="${__("Expected close")}">🎯 ${frappe.datetime.str_to_user(l.expected_close)}</span>` : ""}
						${l.tasks_open ? `<span class="${l.tasks_overdue ? "duty-lead-over" : ""}">📋 ${l.tasks_open}</span>` : ""}
						${l.notes ? `<span>💬 ${frappe.utils.escape_html(l.notes)}</span>` : ""}
						${l.no_step ? `<span class="duty-step-none" title="${__("No next step — every open lead needs one")}">❗ ${__("no next step")}</span>` : l.next_step ? `<span class="duty-step ${l.step_overdue ? "duty-lead-over" : ""}" title="${frappe.utils.escape_html(l.next_step)}">📞 ${l.next_step_due ? frappe.datetime.str_to_user(l.next_step_due).slice(0, 17) : ""}</span>` : ""}
						${l.meeting_next ? `<span title="${__("Next meeting")}">📅 ${l.meeting_next.slice(5, 16)}</span>` : ""}
					</span>
				</div>
			</div>`;
	}

	bind_erp_bar() {
		$(document).off("click.dutyerp");
		$(document).on("click.dutyerp", ".duty-erp-push", (e) => {
			const lead = $(e.currentTarget).closest(".duty-erp-bar").data("lead");
			frappe.call({ method: "duty_board.sales.erp_lead_push", args: { name: lead },
				callback: (r) => { frappe.show_alert({ message: __("✓ ERPNext lead {0} created.", [r.message.erp_lead]), indicator: "green" }); this.refresh_sales(); } });
		});
		$(document).on("click.dutyerp", ".duty-erp-quote", (e) => {
			const lead = $(e.currentTarget).closest(".duty-erp-bar").data("lead");
			const d2 = new frappe.ui.Dialog({
				title: __("🧾 Quotation lines"),
				fields: [{ fieldname: "lines", fieldtype: "Table", cannot_add_rows: false, in_place_edit: true,
					fields: [
						{ fieldname: "description", fieldtype: "Data", label: __("Description"), in_list_view: 1, columns: 5 },
						{ fieldname: "qty", fieldtype: "Float", label: __("Qty"), in_list_view: 1, columns: 2 },
						{ fieldname: "rate", fieldtype: "Currency", label: __("Rate"), in_list_view: 1, columns: 3 },
					], data: [] }],
				primary_action_label: __("Create & attach quotation"),
				primary_action: (v) => {
					d2.hide();
					frappe.call({ method: "duty_board.sales.quote_create",
						args: { name: lead, items: JSON.stringify(v.lines || []) },
						callback: (r) => { frappe.show_alert({ message: __("🧾 {0} created — PDF attached to the lead.", [r.message.erp_quotation]), indicator: "green" }); this.refresh_sales(); } });
				} });
			d2.show();
		});
		$(document).on("click.dutyerp", ".duty-erp-attach", (e) => {
			const lead = $(e.currentTarget).closest(".duty-erp-bar").data("lead");
			frappe.prompt([
				{ fieldname: "f", fieldtype: "Attach", label: __("Proposal file"), reqd: 1 },
				{ fieldname: "label", fieldtype: "Data", label: __("Label (optional)") },
			], (v) => frappe.call({ method: "duty_board.sales.attach_proposal", args: { name: lead, file_url: v.f, label: v.label || "" },
				callback: () => frappe.show_alert({ message: __("📎 Proposal attached."), indicator: "green" }) }),
				__("📎 Attach a proposal"), __("Attach"));
		});
		$(document).on("click.dutyerp", ".duty-erp-won", (e) => {
			const lead = $(e.currentTarget).closest(".duty-erp-bar").data("lead");
			frappe.confirm(__("Close this lead as WON? A Customer is created in ERPNext and the quotation becomes a submitted Sales Order — this ends the sales process."), () =>
				frappe.call({ method: "duty_board.sales.lead_won_convert", args: { name: lead },
					callback: (r) => { this.confetti(); frappe.show_alert({ message: __("🏆 {0} · {1} — sales process complete.", [r.message.erp_customer, r.message.erp_sales_order]), indicator: "green" }); this.refresh_sales(); } }));
		});
	}

	render_pipeline(data) {
		this.bind_erp_bar();
		this.$sales
			.find(".duty-sales-total")
			.html(
				`💼 <b>${__("Pipeline")}</b> · ${data.total.count} ${__("leads")}` +
					(data.total.no_step ? ` · <b class="duty-step-none">❗ ${data.total.no_step} ${__("without next step")}</b>` : "") +
					(data.show_values && data.total.value != null
						? ` · <b class="duty-lead-value">${this.naira(data.total.value)}</b> ${__("open")}`
						: "")
			);
		const $wrap = this.$sales.find(".duty-sales-wrap").empty();
		this.render_radar(data.radar || [], $wrap);
		const $board = $(`<div class="duty-kanban duty-sales-kanban"></div>`).appendTo($wrap);
		const index = {};
		(data.stages || []).forEach((stage) => {
			const col = (data.pipeline && data.pipeline[stage]) || { leads: [], count: 0, value: 0 };
			col.leads.forEach((l) => (index[l.name] = l));
			const $col = $(`
				<div class="duty-kb-col" data-col="${stage}">
					<div class="duty-kb-col-head">
						<span>${__(stage)} <span class="duty-kb-count">${col.count}</span></span>
						<span class="duty-kb-sum">${col.value ? this.naira(col.value) : ""}</span>
					</div>
					<div class="duty-kb-cards" data-col="${stage}">
						${col.leads.map((l) => this.lead_card(l)).join("")}
					</div>
				</div>
			`).appendTo($board);
			$col.on("dragover", (e) => {
				e.preventDefault();
				$col.addClass("duty-kb-over");
			});
			$col.on("dragleave drop", () => $col.removeClass("duty-kb-over"));
			$col.on("drop", (e) => {
				e.preventDefault();
				const name = e.originalEvent.dataTransfer.getData("text");
				if (!name) return;
				frappe.call({
					method: "duty_board.sales.move_lead",
					args: { name: name, stage: stage },
					callback: (r) => r.message && this.render_pipeline(r.message),
				});
			});
		});
		$board.find(".duty-lead-card").each((_, el) => {
			const $card = $(el);
			el.addEventListener("dragstart", (e) =>
				e.dataTransfer.setData("text", $card.data("name"))
			);
			$card.on("click", () => this.lead_dialog($card.data("name")));
		});
	}

	new_lead_dialog() {
		const d = new frappe.ui.Dialog({
			title: `💼 ${__("New Lead")}`,
			fields: [
				{ fieldname: "company", fieldtype: "Data", label: __("Company / Prospect"), reqd: 1 },
				{
					fieldname: "lead_owner",
					fieldtype: "Autocomplete",
					label: __("Owner"),
					options: this.staff_options().filter((o) => o.value),
					default: frappe.session.user,
					reqd: 1,
				},
				{ fieldname: "value", fieldtype: "Currency", label: __("Lead Value") },
				{ fieldname: "contact_name", fieldtype: "Data", label: __("Contact Name") },
				{ fieldname: "email", fieldtype: "Data", label: __("Email") },
				{ fieldname: "phone", fieldtype: "Data", label: __("Phone") },
				{ fieldname: "expected_close", fieldtype: "Date", label: __("Expected Close") },
				{
					fieldname: "source",
					fieldtype: "Select",
					label: __("Source"),
					options: "\nReferral\nExisting Client\nWebsite\nCold Outreach\nEvent\nOther",
				},
				{ fieldname: "description", fieldtype: "Small Text", label: __("What they do & need") },
			],
			primary_action_label: __("Create"),
			primary_action: (v) => {
				d.hide();
				frappe.call({
					method: "duty_board.sales.create_lead",
					args: v,
					callback: () => this.refresh_sales(),
				});
			},
		});
		d.show();
	}

	lead_dialog(name) {
		frappe.call({
			method: "duty_board.sales.get_lead",
			args: { name: name },
			callback: (r) => r.message && this.render_lead_dialog(r.message),
		});
	}

	lead_step_prompt(x) {
		frappe.prompt(
			[
				{ fieldname: "step", fieldtype: "Data", label: __("Next step (e.g. Call Mrs Ade re: quotation)"), reqd: 1, default: x.next_step || "" },
				{ fieldname: "due", fieldtype: "Datetime", label: __("When"), reqd: 1, default: x.next_step_due || "" },
			],
			(v) => frappe.call({
				method: "duty_board.sales.lead_set_step",
				args: { name: x.name, step: v.step, due: v.due },
				callback: (r) => {
					if (!r.message) return;
					frappe.show_alert({ message: __("📞 Next step set — reminder will fire."), indicator: "green" });
					this.render_lead_dialog(r.message);
					this.refresh_sales(true);
				},
			}),
			__("Next step — {0}", [x.company]), __("Set")
		);
	}

	lead_meet_dialog(x) {
		const d = new frappe.ui.Dialog({
			title: `📅 ${__("Meeting — {0}", [x.company])}`,
			fields: [
				{ fieldname: "topic", fieldtype: "Data", label: __("Topic"), default: `${x.company} — sales meeting` },
				{ fieldname: "date", fieldtype: "Date", label: __("Day"), reqd: 1 },
				{ fieldname: "slot_html", fieldtype: "HTML" },
			],
		});
		const $slots = () => $(d.fields_dict.slot_html.wrapper);
		const load = () => {
			const day = d.get_value("date");
			if (!day) return;
			$slots().html(`<span class="text-muted">${__("Checking availability…")}</span>`);
			frappe.call({
				method: "duty_board.sales.lead_meeting_slots",
				args: { name: x.name, date: day },
				callback: (r) => {
					const slots = (r.message && r.message.slots) || [];
					$slots().html(slots.length
						? `<div class="duty-slot-grid">${slots.map((s) => `<button class="btn btn-xs btn-default" data-s="${s}">${s}</button>`).join("")}</div>`
						: `<span class="text-muted">${__("No slots that day — weekends, leave and holidays are blocked.")}</span>`);
					$slots().find("button").on("click", (e) => {
						const s = $(e.currentTarget).data("s");
						frappe.call({
							method: "duty_board.sales.lead_schedule_meeting",
							args: { name: x.name, meeting_date: day, start_time: s, topic: d.get_value("topic") },
							callback: (rr) => {
								if (!rr.message) return;
								d.hide();
								frappe.show_alert({ message: __("📅 Meeting scheduled — it's on the calendar with reminders."), indicator: "green" });
								this.render_lead_dialog(rr.message);
								this.refresh_sales(true);
							},
						});
					});
				},
			});
		};
		d.fields_dict.date.$input.on("change", load);
		d.show();
	}

	render_lead_dialog(x) {
		const esc = frappe.utils.escape_html;
		if (!this._$ldrawer) {
			this._$ldrawer = $(`
				<div class="duty-ldrawer" style="display:none">
					<div class="duty-ld-head"></div>
					<div class="duty-ld-tabs"><a class="on" data-t="act">💬 ${__("Activity & tasks")}</a><a data-t="det">✎ ${__("Details")}</a></div>
					<div class="duty-ld-body">
						<div class="duty-ld-activity"></div>
						<div class="duty-ld-details" style="display:none"></div>
					</div>
					<div class="duty-ld-bar"></div>
				</div>`).appendTo(document.body);
			this._$ldrawer.on("click", ".duty-ld-tabs a", (e) => {
				const t = $(e.currentTarget).data("t");
				this._$ldrawer.find(".duty-ld-tabs a").removeClass("on").filter(`[data-t="${t}"]`).addClass("on");
				this._$ldrawer.find(".duty-ld-activity").toggle(t === "act");
				this._$ldrawer.find(".duty-ld-details").toggle(t === "det");
			});
			this._$ldrawer.on("click", ".duty-step-set, .duty-step-edit", () => this.lead_step_prompt(this._lead_ctx));
			this._$ldrawer.on("click", ".duty-step-done", () => {
				const lx = this._lead_ctx;
				frappe.prompt(
					{ fieldname: "outcome", fieldtype: "Data", label: __("Outcome (what happened?)") },
					(v) => frappe.call({
						method: "duty_board.sales.lead_complete_step",
						args: { name: lx.name, outcome: v.outcome || "" },
						callback: (r) => {
							if (!r.message) return;
							this.render_lead_dialog(r.message);
							this.refresh_sales(true);
							this.lead_step_prompt(r.message);
						},
					}),
					__("Step done — {0}", [this._lead_ctx.company]), __("Done")
				);
			});
			this._$ldrawer.on("click", ".duty-meet-new", () => this.lead_meet_dialog(this._lead_ctx));
			this._$ldrawer.on("click", ".duty-meet-log", (e) => {
				const mid = $(e.currentTarget).data("m");
				frappe.prompt(
					{ fieldname: "note", fieldtype: "Small Text", label: __("How did it go?"), reqd: 1 },
					(v) => frappe.call({
						method: "duty_board.sales.lead_meeting_outcome",
						args: { meeting: mid, note: v.note },
						callback: (r) => r.message && this.render_lead_dialog(r.message),
					}),
					__("Meeting outcome"), __("Log")
				);
			});
		}
		const $dw = this._$ldrawer.show();
		const d = {
			onhide: null,
			hide: () => {
				if (d.onhide) d.onhide();
				$dw.hide();
			},
			fields_dict: { extras: { wrapper: $dw.find(".duty-ld-activity")[0] } },
		};
		this._lead_dialog = d;
		const stages = ["New", "Contacted", "Proposal", "Negotiation", "Awaiting Payment"];
		$dw.find(".duty-ld-head").html(`
			<a class="duty-ld-x">✕</a>
			<b class="duty-ld-co">${esc(x.company)}</b>
			<div class="duty-ld-chips">
				<select class="duty-ld-stage">${stages.map((s) => `<option ${x.stage === s ? "selected" : ""}>${__(s)}</option>`).join("")}</select>
				${x.value ? `<span class="duty-ld-val">${esc(x.value_fmt || String(x.value))}</span>` : ""}
				${x.lead_owner ? `<span class="duty-ld-own" style="color:${this.user_color(x.lead_owner)}">${esc((this.name_map[x.lead_owner] || x.lead_owner).split(" ")[0])}</span>` : ""}
				${x.expected_close ? `<span class="duty-ld-close-d">🗓 ${frappe.datetime.str_to_user(x.expected_close)}</span>` : ""}
			</div>`);
		$dw.find(".duty-ld-x").on("click", () => d.hide());
		$dw.find(".duty-ld-stage").on("change", (e) =>
			frappe.call({
				method: "duty_board.sales.move_lead",
				args: { name: x.name, stage: e.target.value },
				callback: () => this.refresh_sales(),
			})
		);
		const F = (fn, label, val, type) => `<label class="duty-ld-f"><span>${label}</span><input type="${type || "text"}" data-f="${fn}" value="${esc(val == null ? "" : String(val))}"></label>`;
		$dw.find(".duty-ld-details").html(`
			<div class="duty-ld-form">
				${F("company", __("Company / Prospect"), x.company)}
				<label class="duty-ld-f"><span>${__("Owner")}</span><select data-f="lead_owner">${this.staff_options().filter((o) => o.value).map((o) => `<option value="${o.value}" ${o.value === x.lead_owner ? "selected" : ""}>${esc(o.label)}</option>`).join("")}</select></label>
				${x.can_edit_value ? F("value", __("Lead Value"), x.value, "number") : ""}
				${F("contact_name", __("Contact Name"), x.contact_name)}
				${F("email", __("Email"), x.email)}
				${F("phone", __("Phone"), x.phone)}
				${F("expected_close", __("Expected Close"), x.expected_close || "", "date")}
				<label class="duty-ld-f"><span>${__("Source")}</span><select data-f="source">${["", "Referral", "Existing Client", "Website", "Cold Outreach", "Event", "Other"].map((s) => `<option value="${s}" ${x.source === s ? "selected" : ""}>${s ? __(s) : ""}</option>`).join("")}</select></label>
				<div class="duty-erp-bar" data-lead="${x.name}">
					${x.erp_lead ? `<a class="duty-erp-open" href="/app/lead/${esc(x.erp_lead)}" target="_blank" rel="noopener" title="${__("Open in ERPNext")}">✓ ${esc(x.erp_lead)}</a>` : `<a class="duty-erp-push">ERP ⇢ ${__("Create Lead")}</a>`}
					${x.erp_quotation ? `<a class="duty-erp-open" href="/app/quotation/${esc(x.erp_quotation)}" target="_blank" rel="noopener" title="${__("Open the quotation")}">🧾 ${esc(x.erp_quotation)}</a><a class="duty-erp-quote" title="${__("Another quotation")}">➕</a>` : `<a class="duty-erp-quote" ${x.erp_lead ? "" : 'style="opacity:.45"'}>🧾 ${__("Quotation")}</a>`}
					<a class="duty-erp-attach">📎 ${__("Proposal")}</a>
					<a class="duty-erp-open" href="/app/duty-lead/${esc(x.name)}" target="_blank" rel="noopener" title="${__("All attached documents")}">🗂 ${__("Files")}</a>
					${x.erp_sales_order ? `<a class="duty-erp-open" href="/app/sales-order/${esc(x.erp_sales_order)}" target="_blank" rel="noopener" title="${__("Open the sales order")}">🏆 ${esc(x.erp_sales_order)}</a>` : `<a class="duty-erp-won" ${x.erp_quotation ? "" : 'style="opacity:.45"'}>🏆 ${__("Won → Customer + SO")}</a>`}
				</div>
				${(x.files || []).length ? `<div class="duty-ld-docs"><b>🗂 ${__("Documents")}</b>${x.files.map((f) => `<a href="${esc(f.file_url)}" target="_blank" rel="noopener">${f.file_name.toLowerCase().endsWith(".pdf") ? "🧾" : "📎"} ${esc(f.file_name)}<i>${esc((f.creation || "").slice(0, 10))}</i></a>`).join("")}</div>` : ""}
				<label class="duty-ld-f duty-ld-wide"><span>${__("What they do & need")}</span><textarea data-f="description" rows="3">${esc(x.description || "")}</textarea></label>
			</div>
			<button class="btn btn-primary btn-sm duty-ld-save">${__("Save details")}</button>`);
		$dw.find(".duty-ld-save").on("click", () => {
			const v = {};
			$dw.find(".duty-ld-details [data-f]").each((_, el) => (v[$(el).data("f")] = $(el).val()));
			frappe.call({
				method: "duty_board.sales.update_lead",
				args: Object.assign({ name: x.name }, v),
				callback: (r) => {
					frappe.show_alert({ message: __("Saved."), indicator: "green" });
					this.refresh_sales();
					r.message ? this.render_lead_dialog(r.message) : this.lead_dialog(x.name);
				},
			});
		});
		const digits = (x.phone || "").replace(/[^0-9]/g, "").replace(/^0/, "234");
		$dw.find(".duty-ld-bar").html(`
			${x.email ? `<a class="duty-ldb" href="mailto:${esc(x.email)}">✉ ${__("Email")}</a>` : ""}
			${x.phone ? `<a class="duty-ldb" href="tel:${esc(x.phone)}">📞 ${__("Call")}</a>` : ""}
			${digits.length > 9 ? `<a class="duty-ldb" href="https://wa.me/${digits}" target="_blank">💬 WhatsApp</a>` : ""}
			<a class="duty-ldb duty-ldb-won">🏆 ${__("Won")}</a>
			<a class="duty-ldb duty-ldb-lost">✖ ${__("Lost")}</a>`);
		$dw.find(".duty-ldb-won").on("click", () => $dw.find(".duty-lead-won").trigger("click"));
		$dw.find(".duty-ldb-lost").on("click", () => $dw.find(".duty-lead-lost").trigger("click"));
		const contact_bits = [];
		if (x.email) contact_bits.push(`<a href="mailto:${x.email}">✉ ${frappe.utils.escape_html(x.email)}</a>`);
		if (x.phone) contact_bits.push(`<a href="tel:${x.phone}">📞 ${frappe.utils.escape_html(x.phone)}</a>`);
		this._lead_ctx = x;
		const $x = $(d.fields_dict.extras.wrapper).html(`
			${contact_bits.length ? `<div class="duty-lead-links">${contact_bits.join(" · ")}</div>` : ""}
			<div class="duty-lead-section">📞 ${__("Next step")}</div>
			<div class="duty-ld-step">
				${x.next_step ? `<div class="duty-ld-step-cur ${x.step_overdue ? "over" : ""}"><b>${esc(x.next_step)}</b><span class="text-muted"> · ${x.next_step_due ? frappe.datetime.str_to_user(x.next_step_due) : ""} · ${esc((this.name_map || {})[x.next_step_user] || x.next_step_user || "")}</span> <button class="btn btn-xs btn-primary duty-step-done">✓ ${__("Done")}</button> <a class="duty-step-edit" title="${__("Replace")}">✎</a></div>` : `<span class="duty-step-none">❗ ${__("No next step — every open lead needs one.")}</span> <button class="btn btn-xs btn-primary duty-step-set">＋ ${__("Set next step")}</button>`}
			</div>
			<div class="duty-lead-section">📅 ${__("Meetings")}</div>
			<div class="duty-ld-meets">
				${(x.meetings || []).map((m) => `<div class="duty-ld-meet"><b>${frappe.datetime.str_to_user(m.meeting_date)} ${m.start_time || ""}</b> · ${esc(m.topic)} ${m.outcome ? `<span class="text-muted">— ${esc(m.outcome_note || m.outcome)}</span>` : m.past ? `<a class="duty-meet-log" data-m="${m.name}">📝 ${__("log outcome")}</a>` : ""}</div>`).join("") || `<div class="text-muted" style="font-size:12px">${__("None yet.")}</div>`}
				<button class="btn btn-xs btn-default duty-meet-new">📅 ${__("Schedule meeting")}</button>
			</div>
			<div class="duty-lead-section">📋 ${__("Tasks")}</div>
			<div class="duty-lead-tasks">
				${(x.tasks || [])
					.map(
						(t) => `
					<label class="duty-lead-task ${t.status === "Done" ? "duty-lead-task-done" : ""}">
						<input type="checkbox" data-name="${t.name}" ${t.status === "Done" ? "checked" : ""}>
						<span>${frappe.utils.escape_html(t.description)}</span>
						${t.date ? `<span class="duty-kb-due ${t.overdue ? "duty-issue-overdue" : ""}">${frappe.datetime.str_to_user(t.date)}</span>` : ""}
						${t.due_time ? `<span class="duty-time-chip">${t.due_time}</span>` : ""}
						<span style="color:${this.user_color(t.user)}">${frappe.utils.escape_html((this.name_map[t.user] || t.user).split(" ")[0])}</span>
					</label>`
					)
					.join("") || `<div class="text-muted">${__("No tasks yet.")}</div>`}
			</div>
			<div class="duty-lead-addtask">
				<input type="text" class="form-control input-sm duty-lt-desc" placeholder="${__("New task...")}">
				<input type="date" class="form-control input-sm duty-lt-date">
				<input type="time" class="form-control input-sm duty-lt-time">
				<select class="form-control input-sm duty-lt-who">
					${this.staff_options().filter((o) => o.value).map((o) => `<option value="${o.value}" ${o.value === x.lead_owner ? "selected" : ""}>${frappe.utils.escape_html(o.label)}</option>`).join("")}
				</select>
				<button type="button" class="btn btn-sm btn-default duty-lt-add">＋</button>
			</div>
			<div class="duty-lead-section">💬 ${__("Chat")}</div>
			<div class="duty-lead-notes">
				${(x.notes || [])
					.map(
						(n) => `<div class="duty-lead-note"><b>${frappe.utils.escape_html(n.who)}</b> <span class="duty-msg-time">${frappe.datetime.str_to_user(n.when)}</span><br>${this.fmt_note(n.note)}</div>`
					)
					.join("") || `<div class="text-muted">${__("No notes yet.")}</div>`}
			</div>
			<div class="duty-lead-addnote">
				<input type="text" class="form-control input-sm duty-ln-text" placeholder="${__("Message this thread — @ to mention, Enter to send...")}">
			</div>
			<div class="duty-lead-close">
				<button type="button" class="btn btn-sm btn-success duty-lead-won">🏆 ${__("Mark Won")}</button>
				<button type="button" class="btn btn-sm btn-default duty-lead-lost">✖ ${__("Mark Lost")}</button>
			</div>
		`);
		$x.find("input[type=checkbox]").on("change", (e) =>
			frappe.call({
				method: "duty_board.sales.toggle_lead_task",
				args: { name: $(e.target).data("name"), done: e.target.checked ? 1 : 0 },
				callback: (r) => r.message && this.render_lead_dialog(r.message),
			})
		);
		const add_task = () => {
			const desc = $x.find(".duty-lt-desc").val().trim();
			if (!desc) return;
			frappe.call({
				method: "duty_board.sales.add_lead_task",
				args: {
					lead: x.name,
					description: desc,
					date: $x.find(".duty-lt-date").val() || null,
					time: $x.find(".duty-lt-time").val() || null,
					assignee: $x.find(".duty-lt-who").val(),
				},
				callback: (r) => r.message && this.render_lead_dialog(r.message),
			});
		};
		$x.find(".duty-lt-add").on("click", (e) => {
			e.preventDefault();
			add_task();
		});
		$x.find(".duty-lt-desc").on("keydown", (e) => {
			if (e.key !== "Enter") return;
			e.preventDefault();
			e.stopPropagation();
			add_task();
		});
		this.attach_mention_picker($x.find(".duty-ln-text"));
		this._open_lead_ctx = { id: x.name, $x: $x };
		d.onhide = () => {
			if (this._open_lead_ctx && this._open_lead_ctx.id === x.name) this._open_lead_ctx = null;
		};
		$x.find(".duty-ln-text").on("keydown", (e) => {
			if (e.key !== "Enter") return;
			e.preventDefault();
			e.stopPropagation();
			const note = e.target.value.trim();
			if (!note) return;
			frappe.call({
				method: "duty_board.sales.add_lead_note",
				args: { lead: x.name, note: note },
				callback: (r) => r.message && this.render_lead_dialog(r.message),
			});
		});
		const close_lead = (outcome) =>
			frappe.confirm(
				outcome === "Won"
					? __("Mark {0} as WON? 🎉 It moves to the Won archive.", [frappe.utils.escape_html(x.company)])
					: __("Mark {0} as lost? It moves to the Lost archive.", [frappe.utils.escape_html(x.company)]),
				() => {
					d.hide();
					frappe.call({
						method: "duty_board.sales.close_lead",
						args: { name: x.name, outcome: outcome },
						callback: (r) => {
							if (r.message) this.render_pipeline(r.message);
							if (outcome === "Won")
								frappe.show_alert(
									{ message: `🎉 ${frappe.utils.escape_html(x.company)} — ${__("WON!")}`, indicator: "green" },
									7
								);
						},
					});
				}
			);
		$x.find(".duty-lead-won").on("click", () => close_lead("Won"));
		$x.find(".duty-lead-lost").on("click", () => close_lead("Lost"));
		d.show();
	}

	closed_leads_dialog(outcome) {
		frappe.call({
			method: "duty_board.sales.get_closed_leads",
			args: { outcome: outcome },
			callback: (r) => {
				const rows = r.message || [];
				const d = new frappe.ui.Dialog({
					title: outcome === "Won" ? `🏆 ${__("Won leads")}` : `✖ ${__("Lost leads")}`,
				});
				$(d.body).html(
					rows.length
						? rows
								.map(
									(l) => `
							<div class="duty-lead-closedrow">
								<b>${frappe.utils.escape_html(l.company)}</b>
								${l.value ? `<span class="duty-lead-value">${this.naira(l.value)}</span>` : ""}
								<span style="color:${this.user_color(l.lead_owner)}">${frappe.utils.escape_html((this.name_map[l.lead_owner] || l.lead_owner).split(" ")[0])}</span>
								${l.closed_on ? `<span class="duty-msg-time">${frappe.datetime.str_to_user(l.closed_on)}</span>` : ""}
								<a class="duty-lead-reopen" data-name="${l.name}">${__("Reopen")}</a>
							</div>`
								)
								.join("")
						: `<div class="text-muted">${__("Nothing here yet.")}</div>`
				);
				$(d.body)
					.find(".duty-lead-reopen")
					.on("click", (e) =>
						frappe.call({
							method: "duty_board.sales.reopen_lead",
							args: { name: $(e.currentTarget).data("name") },
							callback: () => {
								d.hide();
								this.refresh_sales();
							},
						})
					);
				d.show();
			},
		});
	}

	note_dialog(session, activity, can_add) {
		const d = new frappe.ui.Dialog({
			title: __("Notes — {0}", [frappe.utils.escape_html((activity || "").slice(0, 40))]),
		});
		const render_list = (notes) => {
			const items = (notes || [])
				.map(
					(n) => `
					<div class="duty-note-item">
						<div class="duty-note-meta">
							<span style="color:${this.user_color(n.user)}">${frappe.utils.escape_html((n.full_name || n.user).split(" ")[0])}</span>
							<span class="text-muted">${frappe.datetime.str_to_user(n.creation)}</span>
						</div>
						<div class="duty-note-text">${frappe.utils.escape_html(n.note)}</div>
					</div>`
				)
				.join("");
			$(d.body)
				.find(".duty-note-list")
				.html(items || `<div class="text-muted">${__("No notes yet.")}</div>`);
		};
		$(d.body).html(`
			<div class="duty-note-list"></div>
			${
				can_add
					? `<div class="duty-note-add">
						<textarea rows="2" class="form-control duty-note-input"
							placeholder="${__("Add a note... Enter to save, Shift+Enter for a new line")}"></textarea>
						<button class="btn btn-primary btn-sm duty-note-save">${__("Add")}</button>
					</div>`
					: ""
			}
		`);
		frappe.call({
			method: "duty_board.api.get_task_notes",
			args: { session: session },
			callback: (r) => render_list(r.message),
		});
		const save = () => {
			const val = ($(d.body).find(".duty-note-input").val() || "").trim();
			if (!val) return;
			$(d.body).find(".duty-note-input").val("");
			frappe.call({
				method: "duty_board.api.add_task_note",
				args: { session: session, note: val },
				callback: (r) => {
					render_list(r.message);
					this.refresh(true);
				},
			});
		};
		$(d.body).find(".duty-note-save").on("click", save);
		$(d.body).find(".duty-note-input").on("keydown", (e) => {
			if (e.key === "Enter" && !e.shiftKey) {
				e.preventDefault();
				save();
			}
		});
		d.show();
	}

	async upload_private_file(file) {
		const fd = new FormData();
		fd.append("file", file, file.name);
		fd.append("is_private", "1");
		const res = await fetch("/api/method/upload_file", {
			method: "POST",
			headers: { "X-Frappe-CSRF-Token": frappe.csrf_token },
			body: fd,
		});
		let out = {};
		try {
			out = await res.json();
		} catch (e) {
			throw new Error(
				res.status === 413
					? __("The file is larger than the server allows — ask the admin to raise max_file_size.")
					: `HTTP ${res.status}`
			);
		}
		const fu = out.message && out.message.file_url;
		if (!res.ok || !fu) {
			let emsg = out.exception || `HTTP ${res.status}`;
			try {
				const sm = JSON.parse(JSON.parse(out._server_messages)[0]);
				if (sm && sm.message) emsg = sm.message.replace(/<[^>]+>/g, "");
			} catch (e) {
				/* keep emsg */
			}
			throw new Error(emsg);
		}
		return { file_url: fu, file_name: file.name };
	}

	dm_att_html(m) {
		if (!m.attachment_url) return "";
		const url = `/api/method/duty_board.dm.dm_file?msg=${encodeURIComponent(m.name)}`;
		const ext = (m.attachment_name || "").toLowerCase().split(".").pop();
		if (["png", "jpg", "jpeg", "gif", "webp"].includes(ext))
			return `<span class="duty-dm-att" style="display:block;margin-top:6px"><a href="${url}" target="_blank"><img src="${url}" style="max-width:220px;max-height:220px;border-radius:8px" loading="lazy"></a></span>`;
		if (["webm", "ogg", "mp3", "m4a", "wav"].includes(ext))
			return `<span class="duty-dm-att" style="display:block;margin-top:6px"><audio controls preload="none" src="${url}" style="max-width:240px"></audio></span>`;
		if (["mp4", "mov", "m4v", "3gp"].includes(ext))
			return `<span class="duty-dm-att" style="display:block;margin-top:6px"><video controls preload="metadata" src="${url}" style="max-width:260px;max-height:220px;border-radius:8px"></video></span>`;
		return `<span class="duty-dm-att" style="display:block;margin-top:6px"><a href="${url}" target="_blank">📎 ${frappe.utils.escape_html(m.attachment_name || "file")}</a></span>`;
	}

	wire_dm_attach($send, $input) {
		let pending = null;
		const $btn = $(
			`<label class="btn btn-default btn-sm duty-dm-attach" title="${__("Attach a photo, video or file")}" style="margin:0;align-self:flex-end">📎<input type="file" hidden accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip"></label>`
		);
		const $chip = $(
			`<div class="duty-dm-pend text-muted" style="display:none;font-size:12px;padding:2px 2px 4px;cursor:pointer" title="${__("Remove")}"></div>`
		);
		$send.prepend($btn);
		$send.before($chip);
		const show = () => {
			if (pending) $chip.text(`📎 ${pending.name} ✕`).show();
			else $chip.hide();
		};
		const take = (f) => {
			if (!f) return;
			if (f.size > 25 * 1024 * 1024) {
				frappe.msgprint(__("That file is larger than 25 MB — send something smaller."));
				return;
			}
			pending = f;
			show();
		};
		$btn.find("input").on("change", (e) => {
			take(e.target.files[0]);
			e.target.value = "";
		});
		$chip.on("click", () => {
			pending = null;
			show();
		});
		$input.on("paste", (e) => {
			for (const it of (e.originalEvent.clipboardData || {}).items || []) {
				if (it.kind === "file") {
					const f = it.getAsFile();
					if (f) {
						e.preventDefault();
						take(f);
						break;
					}
				}
			}
		});
		return {
			has: () => !!pending,
			consume: async () => {
				if (!pending) return null;
				const up = await this.upload_private_file(pending);
				pending = null;
				show();
				return up;
			},
		};
	}

	issue_is_mine(x) {
		const me = frappe.session.user;
		return x.raised_by === me || (x.assignees || []).includes(me);
	}

	kb_dialog() {
		const d = new frappe.ui.Dialog({ title: `📚 ${__("Knowledge Base")}`, size: "large" });
		$(d.body).html(`
			<input type="text" class="form-control duty-kb-q" placeholder="${__("Search solutions… (2+ letters)")}">
			<div class="duty-kb-results" style="margin-top:10px"></div>
		`);
		let t = null;
		$(d.body).find(".duty-kb-q").on("input", (e) => {
			clearTimeout(t);
			t = setTimeout(() => {
				frappe.call({
					method: "duty_board.api.kb_search",
					args: { query: e.target.value },
					callback: (r) => {
						const rows = r.message || [];
						$(d.body).find(".duty-kb-results").html(
							rows
								.map(
									(a) => `
							<div class="duty-kb-art">
								<b>${frappe.utils.escape_html(a.title)}</b>
								${a.product ? `<span class="duty-lead-chip">${frappe.utils.escape_html(a.product)}</span>` : ""}
								${a.problem ? `<div class="text-muted" style="font-size:var(--text-xs)">${frappe.utils.escape_html(a.problem.slice(0, 160))}</div>` : ""}
								<div class="duty-kb-sol">${frappe.utils.escape_html(a.solution)}</div>
							</div>`
								)
								.join("") || `<div class="text-muted">${__("Nothing yet — resolve issues and promote the good ones.")}</div>`
						);
					},
				});
			}, 250);
		});
		d.show();
		setTimeout(() => $(d.body).find(".duty-kb-q").trigger("focus"), 200);
	}

	team_load_dialog() {
		const d = new frappe.ui.Dialog({ title: `👥 ${__("Team load & skills")}`, size: "large" });
		const render = (rows) => {
			$(d.body).html(
				(rows || [])
					.map(
						(r) => `
					<div class="duty-load-row">
						<b>${frappe.utils.escape_html(r.full_name)}</b>
						<span class="duty-load-n ${r.open + r.in_progress >= 5 ? "hot" : ""}">${r.open} ${__("open")} · ${r.in_progress} ${__("active")}</span>
						<span class="duty-load-skills">
							${r.skills.map((s) => `<span class="duty-lead-chip">${frappe.utils.escape_html(s.skill)} <a data-id="${s.name}" data-user="${frappe.utils.escape_html(r.user)}" class="duty-skill-x">×</a></span>`).join("")}
							<a class="duty-skill-add" data-user="${frappe.utils.escape_html(r.user)}">＋ ${__("skill")}</a>
						</span>
					</div>`
					)
					.join("")
			);
			$(d.body).find(".duty-skill-add").on("click", (e) =>
				frappe.prompt(
					{ fieldname: "skill", fieldtype: "Data", label: __("Skill (e.g. ZhiftPOS, Payroll, Stock)"), reqd: 1 },
					(v) =>
						frappe.call({
							method: "duty_board.api.skill_add",
							args: { user: $(e.currentTarget).data("user"), skill: v.skill },
							callback: (r) => render(r.message),
						}),
					__("Add skill"),
					__("Add")
				)
			);
			$(d.body).find(".duty-skill-x").on("click", (e) =>
				frappe.call({
					method: "duty_board.api.skill_remove",
					args: { name: $(e.currentTarget).data("id") },
					callback: (r) => render(r.message),
				})
			);
		};
		frappe.call({
			method: "duty_board.api.staff_workload",
			callback: (r) => render(r.message),
		});
		d.show();
	}

	me_day_dialog(day) {
		const m = this._me_data || {};
		const items = (m.day_items || {})[day] || { meetings: [], tasks: [] };
		const esc = frappe.utils.escape_html;
		const d = new frappe.ui.Dialog({ title: `📆 ${day}` });
		$(d.body).html(`
			${items.meetings.length ? `<div class="duty-lead-section">📅 ${__("Meetings")}</div>` : ""}
			${items.meetings.map((mt) => `
				<div class="duty-day-row">
					<b>${esc(mt.time || "")}</b> ${esc(mt.topic)}
					${mt.customer ? `<span class="text-muted">· ${esc(mt.customer)}</span>` : ""}
					${mt.status === "Pending" ? `<span class="duty-day-pending">${__("pending")}</span>` : ""}
					<a class="duty-day-move" data-kind="meeting" data-name="${esc(mt.name)}" title="${__("Reschedule")}">✎</a>
				</div>`).join("")}
			${(items.todos || []).length ? `<div class="duty-lead-section">📋 ${__("Plan items")}</div>` : ""}
			${(items.todos || []).map((td) => `
				<div class="duty-day-row duty-day-todo">
					<input type="checkbox" data-name="${esc(td.name)}" ${td.done ? "checked" : ""}>
					<b>${esc(td.time || "")}</b> <span class="${td.done ? "duty-todo-done" : ""}">${esc(td.text)}</span>
					${td.customer ? `<span class="text-muted">· ${esc(td.customer)}</span>` : ""}
					<a class="duty-day-move" data-kind="todo" data-name="${esc(td.name)}" title="${__("Move")}">✎</a>
				</div>`).join("")}
			${items.tasks.length ? `<div class="duty-lead-section">⚠ ${__("Tasks due")}</div>` : ""}
			${items.tasks.map((t) => `
				<div class="duty-day-row duty-day-task" data-name="${esc(t.name)}">
					<span class="duty-sev duty-sev-${(t.severity || "medium").toLowerCase()}">${__(t.severity || "Medium")}</span>
					${esc(t.title)} <span class="text-muted">· ${esc(t.customer || "")}</span>
					<a class="duty-day-move" data-kind="task" data-name="${esc(t.name)}" title="${__("Change due date")}">✎</a>
				</div>`).join("")}
			${!items.meetings.length && !items.tasks.length ? `<div class="text-muted">${__("Nothing scheduled.")}</div>` : ""}
			<div class="duty-day-actions">
				<button class="btn btn-xs btn-default duty-day-newtodo">＋ ${__("To-do")}</button>
				<button class="btn btn-xs btn-default duty-day-newtask">＋ ${__("Task due this day")}</button>
				<button class="btn btn-xs btn-primary duty-day-newmeet">＋ ${__("Meeting")}</button>
			</div>
		`);
		$(d.body).find(".duty-day-move").on("click", (e) => {
			e.stopPropagation();
			const kind = $(e.currentTarget).data("kind");
			const name = $(e.currentTarget).data("name");
			d.hide();
			const fields = [{ fieldname: "date", fieldtype: "Date", label: __("New date"), default: day, reqd: 1 }];
			if (kind !== "task") fields.push({ fieldname: "time", fieldtype: "Time", label: __("Time") });
			frappe.prompt(fields, (v) => {
				const done = () => {
					frappe.show_alert({ message: __("Moved"), indicator: "green" });
					this.refresh_me((this._me_data || {}).month);
				};
				if (kind === "meeting")
					frappe.call({ method: "duty_board.api.reschedule_meeting", args: { name, meeting_date: v.date, start_time: v.time || null }, callback: done });
				else if (kind === "todo")
					frappe.call({ method: "duty_board.api.update_todo", args: { name, date: v.date, due_time: v.time || null }, callback: done });
				else
					frappe.call({ method: "duty_board.api.update_issue", args: { name, due_date: v.date }, callback: done });
			}, __("Reschedule"));
		});
		$(d.body).find(".duty-day-todo input").on("change", (e) => {
			frappe.call({
				method: "duty_board.api.toggle_todo",
				args: { name: $(e.currentTarget).data("name"), done: e.currentTarget.checked ? 1 : 0 },
				callback: () => this.refresh_me((this._me_data || {}).month),
			});
		});
		$(d.body).find(".duty-day-task").on("click", (e) => {
			d.hide();
			this.issue_detail_dialog($(e.currentTarget).data("name"));
		});
		$(d.body).find(".duty-day-newtodo").on("click", () => {
			d.hide();
			frappe.prompt(
				[
					{ fieldname: "description", fieldtype: "Data", label: __("To-do"), reqd: 1 },
					{ fieldname: "due_time", fieldtype: "Time", label: __("Time (optional)") },
				],
				(v) =>
					frappe.call({
						method: "duty_board.api.add_todo",
						args: { description: v.description, date: day, due_time: v.due_time || null },
						callback: () => {
							frappe.show_alert({ message: __("Added to your plan"), indicator: "green" });
							this.refresh_me((this._me_data || {}).month);
						},
					}),
				`📋 ${day}`
			);
		});
		$(d.body).find(".duty-day-newtask").on("click", () => {
			d.hide();
			this.create_issue_dialog({ due_date: day });
		});
		$(d.body).find(".duty-day-newmeet").on("click", () => {
			d.hide();
			this.me_meeting_dialog(day);
		});
		d.show();
	}

	me_meeting_dialog(day) {
		const md = new frappe.ui.Dialog({
			title: __("📅 New Meeting"),
			fields: [
				{ fieldname: "topic", fieldtype: "Data", label: __("Topic"), reqd: 1 },
				{ fieldname: "meeting_date", fieldtype: "Date", label: __("Date"), default: day, reqd: 1 },
				{ fieldname: "start_time", fieldtype: "Time", label: __("Time") },
				{ fieldname: "duration_mins", fieldtype: "Int", label: __("Duration (mins)"), default: 30 },
				{ fieldname: "customer", fieldtype: "Link", options: "Customer", label: __("Customer (optional — the room hears about it)") },
				{
					fieldname: "attendees",
					fieldtype: "MultiSelectList",
					label: __("Attendees"),
					get_data: () =>
						this.team_members().map((t) => ({ value: t.user, description: t.full_name })),
				},
			],
			primary_action_label: __("Schedule"),
			primary_action: (v) => {
				frappe.call({
					method: "duty_board.api.create_meeting",
					args: {
						topic: v.topic,
						meeting_date: v.meeting_date,
						start_time: v.start_time || null,
						duration_mins: v.duration_mins || 30,
						customer: v.customer || null,
						attendees: v.attendees && v.attendees.length ? JSON.stringify(v.attendees) : null,
					},
					callback: () => {
						md.hide();
						frappe.show_alert({ message: __("Meeting scheduled"), indicator: "green" });
						this.refresh_me((this._me_data || {}).month);
					},
				});
			},
		});
		md.show();
	}

	load_updates(x, $host) {
		const render = (rows) => {
			$host.html(`
				<div class="duty-lead-section">📝 ${__("Updates")}</div>
				${(rows || [])
					.map(
						(u) => `<div class="duty-upd-row"><span class="duty-upd-meta">${frappe.utils.escape_html(u.by)} · ${frappe.utils.escape_html(u.when)}${u.row && !u.self && !this._is_consultant ? ` <a class="duty-kudo ${u.mine ? "duty-kudo-mine" : ""}" data-row="${u.row}" title="${u.mine ? __("You applauded this") : __("Applaud this update")}">👏${u.kudos ? ` ${u.kudos}` : ""}</a>` : u.kudos ? ` <span class="duty-kudo duty-kudo-ro">👏 ${u.kudos}</span>` : ""}</span>${frappe.utils.escape_html(u.note)}</div>`
					)
					.join("") || `<div class="text-muted" style="font-size:var(--text-xs)">${__("No updates yet — post progress and the client's room hears it.")}</div>`}
				<div class="duty-upd-compose">
					<input type="text" class="form-control input-sm duty-upd-in" placeholder="${__("Post a progress update…")}">
					<button type="button" class="btn btn-xs btn-primary duty-upd-send">${__("Post")}</button>
				</div>
			`);
			const post = () => {
				const note = $host.find(".duty-upd-in").val().trim();
				if (!note) return;
				frappe.call({
					method: "duty_board.api.issue_update_add",
					args: { name: x.name, note },
					callback: (r) => render(r.message),
				});
			};
			$host.find(".duty-kudo[data-row]").not(".duty-kudo-mine").on("click", (e) => {
				frappe.call({
					method: "duty_board.gamify.kudos_give",
					args: { row: $(e.currentTarget).data("row") },
					callback: () => {
						frappe.show_alert({ message: __("👏 Applauded"), indicator: "green" });
						frappe.call({ method: "duty_board.api.issue_updates", args: { name: x.name }, callback: (r) => render(r.message) });
					},
				});
			});
			$host.find(".duty-upd-send").on("click", post);
			$host.find(".duty-upd-in").on("keydown", (e) => {
				if (e.key === "Enter") post();
			});
		};
		frappe.call({
			method: "duty_board.api.issue_updates",
			args: { name: x.name },
			callback: (r) => render(r.message),
		});
	}

	load_similar(x, $host) {
		frappe.call({
			method: "duty_board.api.similar_issues",
			args: { name: x.name },
			callback: (r) => {
				const m = r.message || {};
				if (!(m.issues || []).length && !(m.kb || []).length) return;
				$host.html(`
					<div class="duty-lead-section">🧠 ${__("Similar past work")}</div>
					${(m.kb || [])
						.map(
							(k) => `<div class="duty-sim-row">📚 <b>${frappe.utils.escape_html(k.title)}</b><span class="text-muted">${frappe.utils.escape_html(k.solution)}</span></div>`
						)
						.join("")}
					${(m.issues || [])
						.map(
							(i) => `<div class="duty-sim-row">✅ <b>${frappe.utils.escape_html(i.title)}</b> <span class="duty-lead-chip">${frappe.utils.escape_html(i.customer || "")}</span>${i.resolution ? `<span class="text-muted">${frappe.utils.escape_html(i.resolution)}</span>` : ""}</div>`
						)
						.join("")}
				`);
			},
		});
	}

	sla_chip(x) {
		const s = x.sla || {};
		const live = (v) => v && (v.state === "pending" || v.state === "overdue");
		const pick = live(s.ack) ? s.ack : live(s.res) ? s.res : null;
		if (!pick) return "";
		if (pick.state === "overdue")
			return `<span class="duty-sla duty-sla-over">🔴 SLA ${frappe.utils.escape_html(pick.detail || "")}</span>`;
		if (pick.state === "pending")
			return `<span class="duty-sla">⏳ ${frappe.utils.escape_html(pick.detail || "")}</span>`;
		return "";
	}

	sla_meta(x) {
		const s = x.sla || {};
		const bit = (label, v) => {
			if (!v || !v.state) return "";
			if (v.state === "met") return `<span class="duty-sla duty-sla-met">✓ ${label} ${__("SLA met")}</span>`;
			if (v.state === "missed") return `<span class="duty-sla duty-sla-over">✗ ${label} ${__("SLA missed")}</span>`;
			if (v.state === "overdue") return `<span class="duty-sla duty-sla-over">🔴 ${label} ${frappe.utils.escape_html(v.detail || "")}</span>`;
			return `<span class="duty-sla">⏳ ${label} ${frappe.utils.escape_html(v.detail || "")}</span>`;
		};
		const a = bit(__("response"), s.ack);
		const b = bit(__("resolution"), s.res);
		return a || b ? `<div class="duty-issue-meta">${a} ${b}</div>` : "";
	}

	render_issues(issues, me) {
		this._issues = issues = issues || [];
		this._issues_me = me;
		const $wrap = this.$issues.find(".duty-issues").empty();
		const $rail = this.$issues.find(".duty-issues-rail");
		if (!me) {
			$rail.hide();
			return;
		}
		this.check_overdue_issues(issues);
		this.issues_open = true;
		this.issue_status_filter = this.issue_status_filter || "open";
		if (this._iv_init === undefined) {
			this._iv_init = true;
			const saved = localStorage.getItem("duty_iv");
			if (saved === null) {
				this.issue_user_filter = "__me__";
			} else if (saved === "unassigned") this.issue_user_filter = "__none__";
			else if (saved === "mine") this.issue_user_filter = "__me__";
			else if (saved === "overdue") this._iss_overdue = true;
		}

		$rail.find(".duty-issues-rail-badge").text(issues.length).toggle(issues.length > 0);
		this._issues_open = issues.length;
		$(".duty-tab-issues").text(issues.length).toggle(issues.length > 0);
		this._badge_more();
		this.body.toggleClass("duty-issues-collapsed", !this.issues_open);
		$wrap.toggle(this.issues_open);
		$rail.toggle(!this.issues_open);
		$rail.off("click").on("click", () => {
			this.issues_open = true;
			localStorage.setItem("duty_issues_side", "1");
			this.render_issues(this._issues, this._issues_me);
		});
		if (!this.issues_open) return;

		const scope = this.issue_status_filter;
		let items;
		if (scope === "open") {
			items = issues;
		} else if (this._issues_alt && this._issues_alt_scope === scope) {
			items = this._issues_alt;
		} else {
			$wrap.html(
				`<div class="duty-issues-card"><div class="text-muted" style="margin-top:8px">${__("Loading...")}</div></div>`
			);
			frappe.call({
				method: "duty_board.api.get_issues",
				args: { scope: scope },
				callback: (r) => {
					this._issues_alt = r.message || [];
					this._issues_alt_scope = scope;
					this.render_issues(this._issues, this._issues_me);
				},
				error: () => {
					$wrap.html(
						`<div class="duty-issues-card"><div class="text-muted" style="margin-top:8px">${__("Could not load issues — press F12, check the console, and report the red error.")}</div></div>`
					);
				},
			});
			return;
		}

		const mine = issues.filter((x) => this.issue_is_mine(x)).length;
		const ufilter = this.issue_user_filter || "";
		const customers = [...new Set(items.map((x) => x.customer).filter(Boolean))].sort();
		let cfilter = this.issue_customer_filter || "";
		if (this._force_cfilter) {
			if (cfilter && !customers.includes(cfilter)) customers.push(cfilter);
			this._force_cfilter = false;
		} else if (cfilter && !customers.includes(cfilter)) {
			cfilter = "";
			this.issue_customer_filter = "";
		}
		let shown = cfilter ? items.filter((x) => x.customer === cfilter) : items;
		if (this.issue_type_filter) {
			shown = shown.filter((x) => (x.issue_type || "Support") === this.issue_type_filter);
		}
		if (ufilter === "__me__") {
			shown = shown.filter((x) => (x.assignees || []).includes(frappe.session.user));
		} else if (ufilter === "__none__") {
			shown = shown.filter((x) => !(x.assignees || []).length);
		} else if (ufilter) {
			shown = shown.filter((x) => (x.assignees || []).includes(ufilter));
		}
		const today = frappe.datetime.get_today();
		if (this._iss_overdue) {
			shown = shown.filter((x) => x.due_date && x.due_date < today && ["Open", "In Progress"].includes(x.status));
		}

		const rows = shown
			.map((x) => {
				const active = ["Open", "In Progress"].includes(x.status);
				const overdue = x.due_date && x.due_date < today && active;
				const names = (x.assignees || [])
					.map(
						(u) =>
							`<span style="color:${this.user_color(u)}">${frappe.utils.escape_html((this.name_map[u] || u).split(" ")[0])}</span>`
					)
					.join(", ");
				const stamp = x.resolved_at
					? `${__("resolved")} ${this.fmt_stamp(x.resolved_at)}`
					: `${__("raised")} ${this.fmt_stamp(x.creation)}`;
				return `
				<div class="duty-issue-row ${this.issue_is_mine(x) ? "duty-issue-mine" : ""}" data-name="${x.name}">
					<span class="duty-task-customer">${x.customer ? frappe.utils.escape_html(x.customer) : '<i class="duty-ic-empty">—</i>'}</span>
					<span class="duty-sev duty-sev-${(x.severity || "medium").toLowerCase()}">${__(x.severity)}</span>
					<span class="duty-issue-type">${x.issue_type ? frappe.utils.escape_html(x.issue_type) : '<i class="duty-ic-empty">—</i>'}${x.wk_total ? `<span class="duty-wk-chip ${x.wk_done >= x.wk_total ? "duty-wk-full" : ""}" title="${__("Workplan progress")}">${x.wk_done}/${x.wk_total}</span>` : ""}</span>
					<span class="duty-issue-title">${frappe.utils.escape_html(x.title)}</span>
					<span class="duty-issue-who">${names || '<i class="duty-ic-empty">—</i>'}</span>
					<span class="duty-issue-status duty-ist-${x.status.replace(/ /g, "").toLowerCase()}">${__(x.status)}</span>
					<span class="duty-issue-crcol">${x.cr_chip ? `<span class="duty-crpill ${x.cr_go ? "duty-crpill-go" : ""}" title="${frappe.utils.escape_html(x.cr_chip)}">💱 ${frappe.utils.escape_html(x.cr_chip.replace(/^CR · /, ""))}</span>` : ""}</span>
					<span class="duty-issue-due ${overdue ? "duty-issue-overdue" : ""}">${x.due_date && active ? `${overdue ? "⚠ " : ""}${frappe.datetime.str_to_user(x.due_date)}` : '<i class="duty-ic-empty">—</i>'}${this.sla_chip(x)}</span>
					<span class="duty-issue-raised">${stamp}</span>
				</div>`;
			})
			.join("");

		const staff_opts = [
			`<option value="">${__("Anyone")}</option>`,
			`<option value="__me__" ${ufilter === "__me__" ? "selected" : ""}>${__("Me")}</option>`,
		]
			.concat(
				this.team_members().map(
					(t) =>
						`<option value="${t.user}" ${ufilter === t.user ? "selected" : ""}>${frappe.utils.escape_html(t.full_name)}</option>`
				)
			)
			.concat([
				`<option value="__none__" ${ufilter === "__none__" ? "selected" : ""}>${__("Unassigned")}</option>`,
			])
			.join("");

		$wrap.html(`
			<div class="duty-issues-card">
				<div class="duty-chat-head">
					<span>⚠ ${__("Issues")}
						<span class="duty-plan-count">${issues.length} ${__("open")}${mine ? ` · ${mine} ${__("mine")}` : ""}</span>
					</span>
					<span class="duty-chat-tools">
						<a class="duty-issues-collapse" title="${__("Collapse")}">«</a>
					</span>
				</div>
				${(() => {
					const cur = this._iss_overdue ? "overdue" : ufilter === "__me__" ? "mine" : ufilter === "__none__" ? "unassigned" : !ufilter && scope === "open" && !cfilter && !this.issue_type_filter ? "all" : "";
					const pill = (id, label, n) => `<a class="duty-iv ${cur === id ? "on" : ""}" data-iv="${id}">${label}${n !== undefined && n !== null ? ` <b>${n}</b>` : ""}</a>`;
					const unass = issues.filter((x) => !(x.assignees || []).length).length;
					const over = issues.filter((x) => x.due_date && x.due_date < today && ["Open", "In Progress"].includes(x.status)).length;
					return `<div class="duty-ivrow">${pill("mine", __("Mine"), mine)}${pill("unassigned", __("Unassigned"), unass)}${pill("overdue", __("Overdue"), over)}${pill("all", __("All open"), issues.length)}</div>`;
				})()}
				<div class="duty-issues-toolbar">
					<div class="duty-issues-toolbar-row">
						<a class="duty-oncall-chip" title="${__("On-call for out-of-hours urgents — click to change (System Manager)")}">${this._on_call ? `🌙 ${frappe.utils.escape_html(this._on_call.first)}` : `🌙 ${__("no on-call")}`}</a>
						<button class="btn btn-xs btn-default duty-kb-open">📚 ${__("KB")}</button>
						<button class="btn btn-xs btn-default duty-team-load">👥 ${__("Load")}</button>
						<button class="btn btn-xs btn-default duty-issue-new">＋ ${__("New")}</button>
						<button class="btn btn-xs btn-default duty-iss-ftoggle">⚲ ${__("Filters")}${((scope !== "open" ? 1 : 0) + (this.issue_type_filter ? 1 : 0) + (cfilter ? 1 : 0) + (this.issue_user_filter ? 1 : 0)) ? ` <b style="color:#B0443C">${(scope !== "open" ? 1 : 0) + (this.issue_type_filter ? 1 : 0) + (cfilter ? 1 : 0) + (this.issue_user_filter ? 1 : 0)}</b>` : ""}</button>
					</div>
					<div class="duty-iss-filters" style="display:${this._iss_f ? "flex" : "none"}">
					<select class="form-control input-sm duty-issue-scope" title="${__("Status")}">
						<option value="open" ${scope === "open" ? "selected" : ""}>${__("Open")}</option>
						<option value="resolved" ${scope === "resolved" ? "selected" : ""}>${__("Resolved")}</option>
						<option value="closed" ${scope === "closed" ? "selected" : ""}>${__("Closed")}</option>
						<option value="all" ${scope === "all" ? "selected" : ""}>${__("All")}</option>
					</select>
					<select class="form-control input-sm duty-issue-typefilter" title="${__("Filter by type")}">
						<option value="">${__("All types")}</option>
						${["Support", "Bug", "Feature Request", "Configuration", "Training", "Data Correction", "Integration", "Billing", "Implementation", "Enablement"].map((t) => `<option value="${t}" ${this.issue_type_filter === t ? "selected" : ""}>${__(t)}</option>`).join("")}
					</select>
					<select class="form-control input-sm duty-issue-filter" title="${__("Filter by customer")}">
						<option value="">${__("All customers")}</option>
						${customers
							.map(
								(c) =>
									`<option value="${frappe.utils.escape_html(c)}" ${c === cfilter ? "selected" : ""}>${frappe.utils.escape_html(c)}</option>`
							)
							.join("")}
					</select>
					<select class="form-control input-sm duty-issue-user" title="${__("Filter by assignee")}">
						${staff_opts}
					</select>
					</div>
				</div>
				<div class="duty-issues-list">
					${rows ? `<div class="duty-ih"><span>${__("Customer")}</span><span>${__("Priority")}</span><span>${__("Type")}</span><span>${__("Ticket")}</span><span>${__("Assigned")}</span><span>${__("Status")}</span><span>${__("CR")}</span><span>${__("Due")}</span><span>${__("Raised")}</span></div>` : ""}
					${rows || `<div class="text-muted duty-plan-empty">${__("Nothing here with these filters.")}</div>`}
				</div>
			</div>
		`);
		$wrap.find(".duty-iss-ftoggle").on("click", () => {
			this._iss_f = !this._iss_f;
			$wrap.find(".duty-iss-filters").toggle(this._iss_f);
		});
		$wrap.find(".duty-issues-collapse").hide();
		$wrap.find(".duty-issues-collapse").on("click", () => {
			this.issues_open = false;
			localStorage.setItem("duty_issues_side", "0");
			this.render_issues(this._issues, this._issues_me);
		});
		$wrap.find(".duty-iv").on("click", (e) => {
			const v = $(e.currentTarget).data("iv");
			this._iss_overdue = v === "overdue";
			this.issue_user_filter = v === "mine" ? "__me__" : v === "unassigned" ? "__none__" : "";
			if (v === "all") { this.issue_customer_filter = ""; this.issue_type_filter = ""; this.issue_status_filter = "open"; }
			localStorage.setItem("duty_iv", v);
			this.render_issues(this._issues, this._issues_me);
		});
		$wrap.find(".duty-issue-scope").on("change", (e) => {
			this.issue_status_filter = e.target.value;
			this._issues_alt = null;
			this._issues_alt_scope = null;
			this.render_issues(this._issues, this._issues_me);
		});
		$wrap.find(".duty-issue-typefilter").on("change", (e) => {
			this.issue_type_filter = e.target.value || "";
			this.render_issues(this._issues, this._issues_me);
		});
		$wrap.find(".duty-issue-filter").on("change", (e) => {
			this.issue_customer_filter = e.target.value || "";
			this.render_issues(this._issues, this._issues_me);
		});
		$wrap.find(".duty-issue-user").on("change", (e) => {
			this.issue_user_filter = e.target.value || "";
			this.render_issues(this._issues, this._issues_me);
		});
		$wrap.find(".duty-issue-new").on("click", () => this.create_issue_dialog({}));
		$wrap.find(".duty-kb-open").on("click", () => this.kb_dialog());
		$wrap.find(".duty-team-load").on("click", () => this.team_load_dialog());
		$wrap.find(".duty-oncall-chip").on("click", () =>
			frappe.prompt(
				{ fieldname: "user", fieldtype: "Link", options: "User", label: __("On-call person"), default: this._on_call ? this._on_call.user : "" },
				(v) =>
					frappe.call({
						method: "duty_board.api.set_on_call",
						args: { user: v.user || "" },
						callback: () => this.refresh(),
					}),
				__("Set on-call"),
				__("Save")
			)
		);
		$wrap.find(".duty-issue-row").on("click", (e) =>
			this.issue_detail_dialog($(e.currentTarget).data("name"))
		);
	}

	create_issue_dialog(prefill) {
		if (!this._is_consultant && this._enab_templates === undefined) {
			frappe.call({
				method: "duty_board.api.enablement_templates",
				error: () => { this._enab_templates = []; this.create_issue_dialog(prefill); },
				callback: (r) => { this._enab_templates = r.message || []; this.create_issue_dialog(prefill); },
			});
			return;
		}
		prefill = prefill || {};
		const all_staff = () =>
			[{ user: frappe.session.user, full_name: __("Me") }]
				.concat(this.team_members())
				.map((x) => ({ value: x.user, description: x.full_name }));
		const d = new frappe.ui.Dialog({
			title: __("New Issue"),
			fields: [
				{
					fieldname: "title",
					fieldtype: "Data",
					label: __("Title"),
					reqd: 1,
					default: prefill.title || (prefill.description || "").slice(0, 80),
				},
				{
					fieldname: "customer",
					fieldtype: "Autocomplete",
					label: __("Customer"),
					options: (this._cust_opts || []).slice(),
					reqd: 1,
					default: prefill.customer || "",
				},
				{
					fieldname: "severity",
					fieldtype: "Select",
					label: __("Severity"),
					options: "Low\nMedium\nHigh\nCritical",
					default: "Medium",
					reqd: 1,
				},
				{
					fieldname: "issue_type",
					fieldtype: "Select",
					label: __("Type"),
					options: "Support\nBug\nFeature Request\nConfiguration\nTraining\nData Correction\nIntegration\nBilling\nImplementation\nEnablement",
					default: "Support",
				},
				{
					fieldname: "enab_template",
					fieldtype: "Select",
					label: __("Workplan template"),
					options: [""].concat((this._enab_templates || []).map((t) => t.name)).join("\n"),
					depends_on: 'eval:doc.issue_type=="Enablement"',
					description: __("Optional — pre-loads the standard steps. Manage templates in Duty Settings."),
				},
				{
					fieldname: "due_date",
					fieldtype: "Date",
					label: __("Due Date"),
					default: prefill.due_date || undefined,
				},
				{
					fieldname: "assignees",
					fieldtype: "MultiSelectList",
					label: __("Assign to"),
					get_data: all_staff,
				},
				{
					fieldname: "description",
					fieldtype: "Small Text",
					label: __("Description"),
					default: prefill.description || "",
				},
				{ fieldname: "attach_html", fieldtype: "HTML" },
			],
			primary_action_label: __("Create Issue"),
			primary_action: async (v) => {
				const files = this._pending_issue_files || [];
				const uploaded = [];
				if (files.length) {
					frappe.show_alert(
						{ message: __("Uploading {0} file(s)...", [files.length]), indicator: "blue" },
						4
					);
					try {
						for (const f of files) {
							uploaded.push((await this.upload_private_file(f)).file_url);
						}
					} catch (e) {
						frappe.msgprint(
							__("Upload failed: {0}", [frappe.utils.escape_html(e.message || "")])
						);
						return;
					}
				}
				d.hide();
				frappe.call({
					method: "duty_board.api.create_issue",
					args: {
						title: v.title,
						customer: v.customer,
						issue_type: v.issue_type,
						severity: v.severity,
						due_date: v.due_date || null,
						description: v.description || null,
						assignees:
							v.assignees && v.assignees.length ? JSON.stringify(v.assignees) : null,
						source_type: prefill.source_type || "Manual",
						source: prefill.source || null,
						attachments: uploaded.length ? JSON.stringify(uploaded) : null,
					},
					callback: (r) => {
						if (r.message) {
							frappe.show_alert(
								{ message: __("Issue {0} created", [r.message.name]), indicator: "green" },
								5
							);
							if (v.issue_type === "Enablement" && v.enab_template) {
								frappe.call({
									method: "duty_board.api.enablement_apply",
									args: { name: r.message.name, template: v.enab_template },
									callback: () => this.touch_issues(),
								});
							} else this.touch_issues();
						}
					},
				});
			},
		});
		frappe.call({
			method: "duty_board.api.my_customer_options",
			error: () => {},
			callback: (r) => {
				this._cust_opts = r.message || [];
				try {
					d.fields_dict.customer.set_data(this._cust_opts.slice());
				} catch (e) { /* control variant without set_data */ }
			},
		});
		d.show();

		this._pending_issue_files = [];
		const MAX = 25 * 1024 * 1024;
		const $area = $(d.fields_dict.attach_html.wrapper).html(`
			<div class="duty-attach-area">
				<label class="btn btn-xs btn-default">📎 ${__("Attach image / file")}<input type="file" multiple hidden></label>
				<div class="duty-pending-files"></div>
				<div class="text-muted duty-attach-hint">${__("Tip: paste a screenshot straight into the description box.")}</div>
			</div>
		`);
		const add_file = (f) => {
			if (f.size > MAX) {
				frappe.msgprint(__("{0} is too large (max 25 MB).", [frappe.utils.escape_html(f.name)]));
				return;
			}
			this._pending_issue_files.push(f);
			render_chips();
		};
		const render_chips = () => {
			const $c = $area.find(".duty-pending-files").empty();
			this._pending_issue_files.forEach((f, ix) => {
				const $chip = $(
					`<span class="duty-file-chip">📎 ${frappe.utils.escape_html(f.name)} <a>×</a></span>`
				).appendTo($c);
				$chip.find("a").on("click", () => {
					this._pending_issue_files.splice(ix, 1);
					render_chips();
				});
			});
		};
		$area.find("input[type=file]").on("change", (e) => {
			[...e.target.files].forEach(add_file);
			e.target.value = "";
		});
		const $desc = d.fields_dict.description.$input;
		$desc.on("paste", (e) => {
			const items = (e.originalEvent.clipboardData || {}).items || [];
			for (const it of items) {
				if (it.kind === "file") {
					const f = it.getAsFile();
					if (f) {
						e.preventDefault();
						add_file(f);
						break;
					}
				}
			}
		});
	}

	issue_drawer(title) {
		if (!this._$idrawer) {
			this._$idrawer = $(`
				<div class="duty-idrawer" style="display:none">
					<div class="duty-id-head"><b class="duty-id-title"></b><a class="duty-id-x">✕</a></div>
					<div class="duty-id-body"></div>
				</div>`).appendTo(document.body);
			document.addEventListener("keydown", (e) => {
				if (e.key !== "Escape") return;
				if (!this._$idrawer.is(":visible")) return;
				if (e.target.closest && e.target.closest("input,textarea,select,.modal")) return;
				this._idshim && this._idshim.hide();
			});
		}
		const $dw = this._$idrawer;
		$dw.find(".duty-id-title").text(title);
		const shim = {
			body: $dw.find(".duty-id-body")[0],
			show: () => {
				$dw.show();
				$("body").addClass("duty-idrawer-open");
			},
			hide: () => {
				$dw.hide();
				$("body").removeClass("duty-idrawer-open");
			},
		};
		$dw.find(".duty-id-x").off("click").on("click", () => shim.hide());
		this._idshim = shim;
		return shim;
	}

	issue_detail_dialog(name) {
		const d = this.issue_drawer(name);
		const render = (x) => {
			const today = frappe.datetime.get_today();
			const overdue = x.due_date && x.due_date < today && ["Open", "In Progress"].includes(x.status);
			const names = (x.assignees || [])
				.map(
					(u) =>
						`<span style="color:${this.user_color(u)}">${frappe.utils.escape_html((this.name_map[u] || u).split(" ")[0])}</span>`
				)
				.join(", ");
			const i_am_working = (x.working || []).includes(frappe.session.user);
			const working_names = (x.working || [])
				.map(
					(u) =>
						`<span style="color:${this.user_color(u)}">${frappe.utils.escape_html((this.name_map[u] || u).split(" ")[0])}</span>`
				)
				.join(", ");
			$(d.body).html(`
				<div class="duty-issue-detail">
					<div class="duty-issue-detail-head">
						<span class="duty-sev duty-sev-${(x.severity || "medium").toLowerCase()}">${__(x.severity)}</span>
						${x.issue_type ? `<span class="duty-type-chip">${frappe.utils.escape_html(x.issue_type)}</span>` : ""}
						<b>${frappe.utils.escape_html(x.title)}</b>
						<span class="duty-task-customer">${frappe.utils.escape_html(x.customer || "")}</span>
						<span class="duty-issue-status">${__(x.status)}</span>
					</div>
					<div class="text-muted duty-issue-meta">
						${__("Raised by")} ${frappe.utils.escape_html((this.name_map[x.raised_by] || x.raised_by || "").split(" ")[0])}
						· ${frappe.datetime.str_to_user(x.created)}
						${x.due_date ? ` · ${__("Due")} <span class="${overdue ? "duty-issue-overdue" : ""}">${frappe.datetime.str_to_user(x.due_date)}</span>` : ""}
						${x.source_type && x.source_type !== "Manual" ? ` · ${__("From")} ${__(x.source_type)}` : ""}
					</div>
					<div class="duty-id-ctl">
						<label>${__("Severity")}<select class="duty-idc-sev">${["Low", "Medium", "High", "Critical"].map((s) => `<option ${x.severity === s ? "selected" : ""}>${s}</option>`).join("")}</select></label>
						<label>${__("Type")}<select class="duty-idc-type">${["Support", "Bug", "Feature Request", "Configuration", "Training", "Data Correction", "Integration", "Billing", "Implementation", "Enablement"].map((s) => `<option ${(x.issue_type || "Support") === s ? "selected" : ""}>${__(s)}</option>`).join("")}</select></label>
						<label>${__("Due")}<input type="date" class="duty-idc-due" value="${x.due_date || ""}"></label>
						<label>${__("Assigned")}<span class="duty-idc-who">${(x.assignees || []).map((u) => `<span class="duty-idc-chip" style="color:${this.user_color(u)}">${frappe.utils.escape_html((this.name_map[u] || u).split(" ")[0])}<a class="duty-idc-rm" data-user="${u}">✕</a></span>`).join("") || '<i class="duty-ic-empty">—</i>'}</span><a class="duty-idc-assign">＋ ${__("Assign")}</a></label>
					</div>
					${working_names ? `<div class="duty-issue-meta">⏱ ${__("Working on it now")}: ${working_names}</div>` : ""}
					${this.sla_meta(x)}
					${x.change_request ? `<div class="duty-issue-meta duty-id-crline ${x.change_request.go ? "duty-cr-go" : ""}">💱 <b>${frappe.utils.escape_html(x.change_request.title)}</b> · <span class="duty-cr-chiptxt">${frappe.utils.escape_html(x.change_request.chip || "")}</span> <a class="duty-issue-cru" data-cr="${x.change_request.name}">✎ ${__("Update")}</a>${x.change_request.go && x.status === "Open" ? ` <button class="btn btn-sm btn-primary duty-cr-accept">▶ ${__("Accept & start")}</button>` : ""}</div>` : ""}
					<div class="duty-id-tools">
						<button class="btn btn-sm btn-default duty-issue-rca">📋 ${__("RCA report")}</button>
						<button class="btn btn-sm btn-default duty-issue-kb">📚 ${__("Promote to KB")}</button>
						<button class="btn btn-sm btn-default duty-issue-chreq">💱 ${__("Change request")}</button>
					</div>
					<div class="duty-issue-meta">${x.source_message && x.source_type === "Client Room" ? `<a class="duty-issue-origin">💬 ${__("View origin")}</a> · ` : ""}<a class="duty-issue-vis">${x.client_visible ? "👁 " + __("Client-visible — click to hide") : "🙈 " + __("Hidden from client — click to publish")}</a>${x.client_stars ? ` · <span class="duty-stars">${"★".repeat(x.client_stars)}${"☆".repeat(5 - x.client_stars)}</span>` : x.client_rating ? ` · ${x.client_rating === "Up" ? "👍 " + __("Client satisfied") : "👎 " + __("Client unhappy")}` : ""}${x.client_confirmed_at ? ` · <span class="duty-confirmed">✅ ${__("client confirmed")}</span>` : ""}${x.acknowledged_first ? ` · 👀 ${__("Acknowledged by")} ${frappe.utils.escape_html(x.acknowledged_first)}` : x.client_visible ? ` · <a class="duty-issue-ack">👀 ${__("Acknowledge")}</a>` : ""}</div>
					${x.description ? `<div class="duty-issue-details"><b>📄 ${__("Details")}<i>${__("as raised by")} ${frappe.utils.escape_html((this.name_map[x.owner] || x.owner || "").split(" ")[0] || __("client"))}</i></b><div class="duty-idet-body">${frappe.utils.escape_html(x.description).replace(/\n/g, "<br>")}</div></div>` : `<div class="duty-issue-details duty-idet-empty">📄 ${__("No details were written when this was raised.")}</div>`}
					${
						(x.attachments || []).length
							? `<div class="duty-issue-files">${x.attachments
									.map((f) =>
										f.is_image
											? `<a href="${f.file_url}" target="_blank"><img src="${f.file_url}" title="${frappe.utils.escape_html(f.file_name)}"></a>`
											: `<a href="${f.file_url}" target="_blank" class="duty-issue-filelink">📎 ${frappe.utils.escape_html(f.file_name)}</a>`
									)
									.join("")}</div>`
							: ""
					}
					${x.resolution ? `<div class="duty-issue-resolution"><b>${__("Resolution")}:</b> ${frappe.utils.escape_html(x.resolution)}${x.resolved_at ? ` <span class="text-muted">(${frappe.datetime.str_to_user(x.resolved_at)})</span>` : ""}</div>` : ""}
					<div class="duty-upd-host"></div>
					${(() => {
						const cl = x.checklist || [];
						const done = cl.filter((c) => c.done).length;
						const complete = cl.length && done === cl.length;
						return `
						<div class="duty-checklist ${cl.length ? (complete ? "duty-cl-complete" : "duty-cl-open") : "duty-cl-empty"}">
							${!this._is_consultant ? `<a class="duty-issue-merge" title="${__("Fold this duplicate into another ticket")}">⇄ ${__("Merge")}</a>` : ""}${x.issue_type === "Enablement" && !this._is_consultant ? `<a class="duty-enab-promote">⤴ ${__("Promote to Project")}</a><a class="duty-enab-tpl">📋 ${__("Load workplan")}</a>` : ""}
							<div class="duty-cl-head">
								<b>✅ ${__("Checklist")}</b>
								${cl.length ? `<span class="duty-cl-count">${done} / ${cl.length}</span>` : `<span class="duty-cl-optional">${__("optional — but once added, it gates Resolve")}</span>`}
							</div>
							${cl.length ? `<div class="duty-cl-bar"><i style="width:${Math.round((done / cl.length) * 100)}%"></i></div>` : ""}
							${cl.map((c) => `
								<label class="duty-cl-item ${c.done ? "duty-cl-done" : ""} ${!c.done && c.due_date && c.due_date < frappe.datetime.get_today() ? "duty-cl-late" : ""}">
									<input type="checkbox" data-row="${c.row}" ${c.done ? "checked" : ""}>
									<span>${frappe.utils.escape_html(c.item)}</span>
									${c.done && c.done_by ? `<i class="duty-cl-by">${frappe.utils.escape_html((this.name_map[c.done_by] || c.done_by).split(" ")[0])}</i>` : ""}
									${!this._is_consultant || c.assignee ? `<a class="duty-cl-who ${c.assignee ? "duty-cl-set" : ""}" data-row="${c.row}" data-assignee="${c.assignee || ""}" data-due="${c.due_date || ""}">👤 ${c.assignee ? frappe.utils.escape_html((this.name_map[c.assignee] || c.assignee).split(" ")[0]) : "＋"}</a>` : ""}
									${!this._is_consultant || c.due_date ? `<a class="duty-cl-due ${c.due_date ? "duty-cl-set" : ""}" data-row="${c.row}" data-assignee="${c.assignee || ""}" data-due="${c.due_date || ""}">📅 ${c.due_date ? frappe.datetime.str_to_user(c.due_date).slice(0, 5) : "＋"}</a>` : ""}
									<a class="duty-cl-rm" data-row="${c.row}">✕</a>
								</label>`).join("")}
							${cl.length && !complete ? `<div class="duty-cl-warn">⛔ ${__("Resolve and Close are locked until every item is ticked.")}</div>` : ""}
							${cl.length && complete ? `<div class="duty-cl-clear">✔ ${__("All clear — this ticket may be resolved.")}</div>` : ""}
							<div class="duty-cl-addrow">
								<input type="text" class="duty-cl-input" placeholder="${__("Add a checklist item and press Enter…")}">
							</div>
						</div>`;
					})()}
					<div class="duty-issue-actions">
						${["Open", "In Progress"].includes(x.status) && !i_am_working ? `<button class="btn btn-sm btn-default duty-issue-start">▶ ${__("Start work")}</button>` : ""}
						${i_am_working ? `<button class="btn btn-sm btn-default duty-issue-stopwork">⏸ ${__("Stop work")}</button>` : ""}
						${["Open", "In Progress"].includes(x.status) ? `<button class="btn btn-sm btn-primary" data-act="Resolved">${__("Resolve")}</button>` : ""}
						${["Open", "In Progress", "Resolved"].includes(x.status) ? `<button class="btn btn-sm btn-default" data-act="Closed">${__("Close")}</button>` : ""}
						${["Resolved", "Closed"].includes(x.status) ? `<button class="btn btn-sm btn-default" data-act="Open">${__("Reopen")}</button>` : ""}
						${this.issue_is_mine(x) || frappe.user.has_role("System Manager") ? `<label class="btn btn-sm btn-default duty-issue-attach">📎 ${__("Add file")}<input type="file" hidden></label>` : ""}
					</div>
				</div>
			`);
			$(d.body)
				.find(".duty-issue-actions button[data-act]")
				.on("click", (e) => {
					const act = $(e.currentTarget).data("act");
					if (["Resolved", "Closed"].includes(act)) {
						const cl = x.checklist || [];
						if (cl.length && cl.some((c) => !c.done)) {
							frappe.msgprint(__("⛔ The checklist gates this ticket — {0} of {1} items still open. Tick them all, then resolve.", [cl.filter((c) => !c.done).length, cl.length]));
							return;
						}
					}
					const apply = (resolution, hours) =>
						frappe.call({
							method: "duty_board.api.update_issue_status",
							args: { name: name, status: act, resolution: resolution || null, hours: hours || null },
							callback: (r) => {
								if (r.message) render(r.message);
								this.touch_issues();
								if (act === "Resolved" && r.message) this.confetti();
							},
						});
					if (this._is_consultant && act === "Closed") {
						frappe.prompt(
							{ fieldname: "hours", fieldtype: "Float", label: __("Hours spent on this issue"), reqd: 1 },
							(v) => apply(null, v.hours),
							__("Log your time"),
							__("Close issue")
						);
						return;
					}
					if (act === "Resolved") {
						frappe.prompt(
							this._is_consultant
								? [
									{ fieldname: "resolution", fieldtype: "Small Text", label: __("What was done?"), reqd: 1 },
									{ fieldname: "hours", fieldtype: "Float", label: __("Hours spent on this issue"), reqd: 1 },
								]
								: {
								fieldname: "resolution",
								fieldtype: "Small Text",
								label: __("What was done?"),
								reqd: 1,
							},
							(v) => apply(v.resolution, v.hours),
							__("Resolve Issue"),
							__("Resolve")
						);
					} else {
						apply();
					}
				});
			const work_call = (method) =>
				frappe.call({
					method: `duty_board.api.${method}`,
					args: { name: name },
					callback: (r) => {
						if (r.message) render(r.message);
						this.touch_issues();
						if (this._open_room) this.load_client_room(this._open_room);
					},
				});
			$(d.body).find(".duty-issue-ack").on("click", () =>
				frappe.call({
					method: "duty_board.api.acknowledge_issue",
					args: { name: name },
					callback: (r) => {
						if (r.message) render(r.message);
						if (this._open_room) this.load_client_room(this._open_room);
					},
				})
			);
			const inline_save = (extra) =>
				frappe.call({
					method: "duty_board.api.update_issue",
					args: Object.assign({
						name: name,
						severity: $(d.body).find(".duty-idc-sev").val(),
						issue_type: $(d.body).find(".duty-idc-type").val(),
						due_date: $(d.body).find(".duty-idc-due").val() || null,
					}, extra || {}),
					callback: (r) => {
						if (r.message) render(r.message);
						this.refresh();
					},
				});
			$(d.body).find(".duty-checklist input[type=checkbox]").on("change", (e) => {
				frappe.call({
					method: "duty_board.api.checklist_toggle",
					args: { name: name, row: $(e.currentTarget).data("row"), done: e.currentTarget.checked ? 1 : 0 },
					callback: (r) => r.message && render(r.message),
				});
			});
			$(d.body).find(".duty-cl-who, .duty-cl-due").on("click", (e) => {
				e.preventDefault();
				e.stopPropagation();
				if (this._is_consultant) return;
				const $c = $(e.currentTarget);
				const row = $c.data("row");
				const isWho = $c.hasClass("duty-cl-who");
				const staff = Object.keys(this.name_map || {}).map((u) => ({ value: u, label: this.name_map[u] }));
				frappe.prompt(
					isWho
						? { fieldname: "v", fieldtype: "Autocomplete", label: __("Step owner"), options: staff, default: $c.data("assignee") || "" }
						: { fieldname: "v", fieldtype: "Date", label: __("Step due date"), default: $c.data("due") || "" },
					(vals) => frappe.call({
						method: "duty_board.api.checklist_assign",
						args: {
							name: name, row: row,
							assignee: isWho ? vals.v || null : $c.data("assignee") || null,
							due_date: isWho ? $c.data("due") || null : vals.v || null,
						},
						callback: (r) => r.message && render(r.message),
					}),
					isWho ? __("👤 Who owns this step?") : __("📅 When is it due?"), __("Set")
				);
			});
			$(d.body).find(".duty-issue-merge").on("click", () => {
				frappe.prompt(
					{ fieldname: "target", fieldtype: "Data", label: __("Merge INTO ticket (the survivor, e.g. ISS-202608-01234)"), reqd: 1 },
					(v2) => frappe.confirm(
						__("Fold {0} into {1}? Updates, assignees, checklist, hours and files move across; {0} closes as 'Merged into {1}'.", [name, v2.target.trim()]),
						() => frappe.call({
							method: "duty_board.api.merge_issue",
							args: { source: name, target: v2.target.trim() },
							callback: (r) => {
								if (!r.message) return;
								frappe.show_alert({ message: __("⇄ Merged into {0}.", [v2.target.trim()]), indicator: "green" });
								d.hide();
								this.touch_issues();
							},
						})
					),
					__("⇄ Merge duplicate"), __("Merge"));
			});
			$(d.body).find(".duty-enab-tpl").on("click", () => {
				const openPick = () => {
					const names = (this._enab_templates || []).map((t) => t.name);
					if (!names.length) {
						frappe.msgprint(__("No templates yet — define them in Duty Settings → Enablement Templates ([Name] line, then one step per line)."));
						return;
					}
					frappe.prompt(
						{ fieldname: "tpl", fieldtype: "Select", label: __("Workplan template"), options: names.join("\n"), reqd: 1 },
						(v2) => frappe.call({
							method: "duty_board.api.enablement_apply",
							args: { name: name, template: v2.tpl },
							callback: (r) => { if (r.message) { render(r.message); frappe.show_alert({ message: __("📋 Workplan loaded — assign the steps."), indicator: "green" }); } },
						}),
						__("📋 Load a workplan"), __("Load"));
				};
				if (this._enab_templates === undefined) {
					frappe.call({ method: "duty_board.api.enablement_templates", error: () => { this._enab_templates = []; openPick(); }, callback: (r) => { this._enab_templates = r.message || []; openPick(); } });
				} else openPick();
			});
			$(d.body).find(".duty-enab-promote").on("click", () => {
				frappe.confirm(
					__("This enablement has outgrown its ticket? A Duty Project will be created, open workplan steps become project tasks (owners and dates carried), and this ticket closes with the paper trail."),
					() => frappe.call({
						method: "duty_board.api.promote_to_project",
						args: { name: name },
						callback: (r) => {
							if (!r.message) return;
							frappe.show_alert({ message: __("⤴ Project {0} created — {1} step(s) carried.", [r.message.project, r.message.carried]), indicator: "green" });
							d.hide();
							this.touch_issues();
						},
					})
				);
			});
			$(d.body).find(".duty-cl-rm").on("click", (e) => {
				e.preventDefault();
				frappe.call({
					method: "duty_board.api.checklist_remove",
					args: { name: name, row: $(e.currentTarget).data("row") },
					callback: (r) => r.message && render(r.message),
				});
			});
			$(d.body).find(".duty-cl-input").on("keydown", (e) => {
				if (e.key !== "Enter") return;
				const v = $(e.currentTarget).val().trim();
				if (!v) return;
				frappe.call({
					method: "duty_board.api.checklist_add",
					args: { name: name, item: v },
					callback: (r) => {
						if (r.message) {
							render(r.message);
							$(d.body).find(".duty-cl-input").focus();
						}
					},
				});
			});
			$(d.body).find(".duty-idc-rm").on("click", (e) => {
				e.stopPropagation();
				frappe.call({
					method: "duty_board.api.remove_assignee",
					args: { name: name, user: $(e.currentTarget).data("user") },
					callback: (r) => {
						if (r.message) render(r.message);
						this.refresh();
					},
				});
			});
			$(d.body).find(".duty-idc-sev").on("change", () => inline_save());
			$(d.body).find(".duty-idc-type").on("change", () => inline_save());
			$(d.body).find(".duty-idc-due").on("change", () => inline_save());
			$(d.body).find(".duty-idc-assign").on("click", () => {
				const pd = new frappe.ui.Dialog({
					title: __("Assign"),
					fields: [{
						fieldname: "add_assignees", fieldtype: "MultiSelectList", label: __("Add assignees"),
						get_data: () => [{ value: frappe.session.user, description: __("Me") }].concat(
							this.team_members().map((t) => ({ value: t.user, description: t.full_name }))),
					}],
					primary_action_label: __("Assign"),
					primary_action: (v) => { pd.hide(); inline_save({ add_assignees: JSON.stringify(v.add_assignees || []) }); },
				});
				pd.show();
			});
			this.load_updates(x, $(d.body).find(".duty-upd-host"));
			$(d.body).find(".duty-issue-origin").on("click", () => {
				d.hide();
				this.view_origin(x.source, x.source_message);
			});
			$(d.body).find(".duty-issue-cru").on("click", (e) => this.open_cr_editor($(e.currentTarget).data("cr")));
			$(d.body).find(".duty-cr-accept").on("click", () =>
				frappe.call({
					method: "duty_board.api.cr_accept",
					args: { name: name },
					callback: (r) => {
						if (r.message) render(r.message);
						this.refresh();
						frappe.show_alert({ message: __("✅ Accepted — the ticket is In Progress."), indicator: "green" });
					},
				})
			);
			$(d.body).find(".duty-issue-chreq").on("click", () =>
				frappe.confirm(
					__("Draft a change request from this ticket? Use this when the ask is new paid scope, not subscription support."),
					() =>
						frappe.call({
							method: "duty_board.client_room.chreq_from_issue",
							args: { issue: name },
							callback: (r) => {
								if (r.message) {
									d.hide();
									if (this._is_consultant && r.message.new_cr) {
										this.consultant_cr_edit(r.message.new_cr, { title: r.message.new_cr_title });
									} else {
										frappe.show_alert({ message: __("💱 Change request drafted — open the client room to price and send it."), indicator: "green" });
									}
									if (this._open_room === r.message.name) this.render_client_room(r.message);
								}
							},
						})
				)
			);
			$(d.body).find(".duty-issue-kb").on("click", () =>
				frappe.prompt(
					[
						{ fieldname: "title", fieldtype: "Data", label: __("Title"), default: x.title, reqd: 1 },
						{ fieldname: "product", fieldtype: "Data", label: __("Product") },
						{ fieldname: "solution", fieldtype: "Small Text", label: __("Solution"), default: x.resolution, reqd: 1 },
					],
					(v) =>
						frappe.call({
							method: "duty_board.api.kb_promote",
							args: Object.assign({ issue: x.name, problem: x.description || "" }, v),
							callback: () =>
								frappe.show_alert({ message: __("📚 Added to the knowledge base"), indicator: "green" }),
						}),
					__("Promote to knowledge base"),
					__("Promote")
				)
			);
			$(d.body).find(".duty-issue-rca").on("click", () =>
				frappe.call({
					method: "duty_board.client_room.rca_get",
					args: { issue: x.name },
					callback: (r) => {
						const ex = r.message || {};
						frappe.prompt(
							[
								{ fieldname: "what_happened", fieldtype: "Small Text", label: __("What happened"), default: ex.what_happened, reqd: 1 },
								{ fieldname: "root_cause", fieldtype: "Small Text", label: __("Root cause"), default: ex.root_cause, reqd: 1 },
								{ fieldname: "resolution_action", fieldtype: "Small Text", label: __("How we resolved it"), default: ex.resolution_action, reqd: 1 },
								{ fieldname: "prevention", fieldtype: "Small Text", label: __("What we changed so it cannot recur"), default: ex.prevention, reqd: 1 },
							],
							(v) =>
								frappe.call({
									method: "duty_board.client_room.rca_publish",
									args: Object.assign({ issue: x.name }, v),
									callback: () =>
										frappe.show_alert({
											message: __("📋 RCA published to the client's shelf"),
											indicator: "green",
										}),
								}),
							__("Incident report — published to the client's shelf as a branded PDF"),
							ex.what_happened ? __("Republish (updates the shelf copy)") : __("Publish")
						);
					},
				})
			);
			$(d.body).find(".duty-issue-vis").on("click", () =>
				frappe.call({
					method: "duty_board.api.set_issue_visibility",
					args: { name: name, visible: x.client_visible ? 0 : 1 },
					callback: (r) => {
						if (r.message) render(r.message);
						if (this._open_room) this.load_client_room(this._open_room);
					},
				})
			);
			$(d.body).find(".duty-issue-start").on("click", () => work_call("start_issue_work"));
			$(d.body).find(".duty-issue-stopwork").on("click", () => work_call("stop_issue_work"));
			$(d.body).find(".duty-issue-attach input").on("change", async (e) => {
				const f = e.target.files[0];
				e.target.value = "";
				if (!f) return;
				if (f.size > 25 * 1024 * 1024) {
					frappe.msgprint(__("File too large (max 25 MB)."));
					return;
				}
				try {
					const up = await this.upload_private_file(f);
					frappe.call({
						method: "duty_board.api.attach_to_issue",
						args: { name: name, file_url: up.file_url },
						callback: (r) => r.message && render(r.message),
					});
				} catch (err) {
					frappe.msgprint(__("Upload failed: {0}", [frappe.utils.escape_html(err.message || "")]));
				}
			});
			$(d.body).find(".duty-issue-edit").on("click", () => {
				const ed = new frappe.ui.Dialog({
					title: __("Edit Issue"),
					fields: [
						{
							fieldname: "severity",
							fieldtype: "Select",
							label: __("Severity"),
							options: "Low\nMedium\nHigh\nCritical",
							default: x.severity,
						},
						{
							fieldname: "due_date",
							fieldtype: "Date",
							label: __("Due Date"),
							default: x.due_date || "",
						},
						{
							fieldname: "add_assignees",
							fieldtype: "MultiSelectList",
							label: __("Add assignees"),
							get_data: () =>
								[{ value: frappe.session.user, description: __("Me") }].concat(
									this.team_members().map((t) => ({ value: t.user, description: t.full_name }))
								),
						},
					],
					primary_action_label: __("Save"),
					primary_action: (v) => {
						ed.hide();
						frappe.call({
							method: "duty_board.api.update_issue",
							args: {
								name: name,
								severity: v.severity,
								due_date: v.due_date || null,
								add_assignees:
									v.add_assignees && v.add_assignees.length
										? JSON.stringify(v.add_assignees)
										: null,
							},
							callback: (r) => {
								if (r.message) render(r.message);
								this.touch_issues();
							},
						});
					},
				});
				ed.show();
			});
		};
		frappe.call({
			method: "duty_board.api.get_issue",
			args: { name: name },
			callback: (r) => r.message && render(r.message),
		});
		d.show();
	}

	render_me(me) {
		const $me = this.body.find(".duty-me").empty();
		if (!me) {
			$me.html(`<div class="text-muted">${__("Your user is not on the board.")}</div>`);
			return;
		}
		const s = this.status_meta(me.status);
		const on_duty = me.status === "On Duty";
		$me.html(`
			<div class="duty-me-card">
				<div>
					<div class="duty-me-status">
						<span class="duty-dot" style="background:${s.color}"></span>
						${__("You are")} <b style="color:${s.color}">${__(me.status)}</b>
						${me.reason ? `<span class="text-muted">· ${frappe.utils.escape_html(me.reason)}</span>` : ""}
					</div>
					<div class="duty-me-sub text-muted">
						${__("On duty today")}: <b>${this.fmt_duration(me.on_duty_seconds)}</b>
						${me.since ? " · " + __("Since") + " " + this.fmt_time(me.since) : ""}
					</div>
				</div>
				<button class="btn btn-lg ${on_duty ? "btn-danger" : "btn-success"} duty-main-btn">
					${on_duty ? __("Clock Out") : __("Clock In")}
				</button>
			</div>
		`);
		$me.find(".duty-main-btn").on("click", () => {
			on_duty ? this.clock_out_dialog() : this.action("clock_in");
		});
	}

	build_rail() {
		if (this.is_mobile && this.is_mobile()) return;
		let $r = $(".duty-rail");
		if (!$r.length) {
			$r = $('<div class="duty-rail"></div>').appendTo(document.body);
			if (localStorage.getItem("duty_rail") === "min") $("body").addClass("duty-rail-min");
			const sync = () => {
				const here = frappe.get_route_str() === "duty-board";
				$r.toggle(here);
				$("body").toggleClass("duty-has-rail", here);
			};
			frappe.router.on("change", sync);
			sync();
		}
		const ic = (paths) => `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
		$r.html(
			(this.rail || []).map((e) => `<a class="duty-rl ${e.id === (this.face || "board") ? "on" : ""}" data-id="${e.id}" title="${e.label}">${ic(e.ic)}<span>${e.label}</span></a>`).join("") +
			`<a class="duty-rl duty-rl-min" title="${__("Collapse")}">${ic('<path d="m11 17-5-5 5-5"/><path d="m18 17-5-5 5-5"/>')}<span>${__("Collapse")}</span></a>`
		);
		$r.find(".duty-rl").not(".duty-rl-min").on("click", (ev) => {
			const id = $(ev.currentTarget).data("id");
			const e = (this.rail || []).find((x) => x.id === id);
			if (e) e.go();
		});
		$r.find(".duty-rl-min").on("click", () => {
			$("body").toggleClass("duty-rail-min");
			localStorage.setItem("duty_rail", $("body").hasClass("duty-rail-min") ? "min" : "full");
		});
	}

	rail_sync(face) {
		$(".duty-rail .duty-rl").removeClass("on");
		$(`.duty-rail .duty-rl[data-id="${face}"]`).addClass("on");
	}

	render_strip() {
		if (this._is_consultant) { $(".duty-strip").remove(); return; }
		if (this.is_mobile && this.is_mobile()) { $(".duty-strip").remove(); return; }
		let $s = $(".duty-strip");
		if (!$s.length) $s = $('<div class="duty-strip"></div>').appendTo(document.body);
		const me = this._me;
		const face = this.face || "board";
		if (!me || face === "board") { $s.hide(); return; }
		if (!this._strip_tick) {
			this._strip_tick = setInterval(() => this.render_strip(), 30000);
		}
		const on_duty = me.status === "On Duty";
		const t = on_duty && me.task;
		const dur = (s) => this.fmt_duration(s);
		$s.html(
			on_duty
				? t
					? `<span class="ds-dot on"></span><span class="ds-lab">${__("Working on")}</span> <b class="ds-task">${frappe.utils.escape_html(t.activity).slice(0, 44)}</b>${t.customer ? `<span class="ds-cust">${frappe.utils.escape_html(t.customer)}</span>` : ""}<span class="ds-time">${dur(t.seconds)}</span><a class="ds-btn ds-switch">${__("Switch")}</a><a class="ds-btn ds-stop">${__("Stop")}</a>`
					: `<span class="ds-dot on"></span><b>${__("On duty")}</b><span class="ds-time">${dur(me.on_duty_seconds)}</span><span class="ds-idle">${__("no task running")}</span><a class="ds-btn ds-go">${__("Start task")}</a>`
				: `<span class="ds-dot"></span><span class="ds-idle">${__("Off duty")}</span><a class="ds-btn ds-in">${__("Clock in")}</a>`
		).show();
		$s.find(".ds-stop").on("click", () => this.stop_task_flow());
		$s.find(".ds-switch").on("click", () => this.start_task_dialog(true));
		$s.find(".ds-go").on("click", () => this.start_task_dialog(false));
		$s.find(".ds-in").on("click", () => this.action("clock_in"));
	}

	render_paused_strip(data) {
		const host = this.body.find(".duty-me");
		host.find(".duty-paused-strip").remove();
		const stack = (data && data.my_paused) || [];
		if (!stack.length) return;
		const clocked = data.me && data.me.status === "On Duty";
		const esc = frappe.utils.escape_html;
		const $s = $(`
			<div class="duty-paused-strip">
				<div class="duty-paused-head">
					<span class="duty-paused-ic">⏸</span>
					<b>${__("Paused")} (${stack.length})</b>
					${clocked ? "" : `<span class="duty-paused-hint">${__("Clock in to resume")}</span>`}
				</div>
				${stack
					.map(
						(p) => `
				<div class="duty-paused-row" data-name="${esc(p.name)}">
					<span class="duty-paused-txt">
						<b>${esc(p.activity || __("a task"))}</b>${p.customer ? ` · ${esc(p.customer)}` : ""}
						<span class="duty-paused-age">${p.paused_at ? frappe.datetime.comment_when(p.paused_at) : ""}</span>
					</span>
					${clocked ? `<a class="duty-paused-resume">▶ ${__("Resume")}</a>` : ""}
					<a class="duty-paused-dismiss" title="${__("Dismiss")}">✕</a>
				</div>`
					)
					.join("")}
			</div>`);
		host.prepend($s);
		$s.find(".duty-paused-resume").on("click", (e) => {
			frappe.call({
				method: "duty_board.api.resume_paused_task",
				args: { name: $(e.currentTarget).closest(".duty-paused-row").attr("data-name") },
				freeze: true,
				callback: (r) => { if (r.message) this.render(r.message); },
			});
		});
		$s.find(".duty-paused-dismiss").on("click", (e) => {
			frappe.call({
				method: "duty_board.api.dismiss_paused_task",
				args: { name: $(e.currentTarget).closest(".duty-paused-row").attr("data-name") },
				callback: (r) => { if (r.message) this.render(r.message); },
			});
		});
	}

	render_task(me) {
		const $task = this.body.find(".duty-task").empty();
		if (!me || me.status !== "On Duty") return;

		if (me.task) {
			const t = me.task;
			$task.html(`
				<div class="duty-task-card duty-task-running">
					<div class="duty-task-info">
						<div class="duty-task-label">${__("Working on")}</div>
						<div class="duty-task-name">
							${t.todo ? '<span class="duty-plan-tag">' + __("Plan") + "</span> " : ""}
							${frappe.utils.escape_html(t.activity)}
							${t.customer ? `<span class="duty-task-customer">${frappe.utils.escape_html(t.customer)}</span>` : ""}
						</div>
						<div class="text-muted duty-task-since">
							${__("Running")}: <b>${this.fmt_duration(t.seconds)}</b>
							· ${__("Started")} ${this.fmt_time(t.start_time)}
						</div>
					</div>
					<div class="duty-task-actions">
						${t.issue ? `<a class="duty-task-issuechip" title="${__("Open issue")}">${t.issue}</a>` : ""}
						${t.card ? `<a class="duty-task-issuechip" style="border-color:#a7f3d0;color:#0f766e;background:#ecfdf5" data-card="${t.card}" title="${__("Open project card")}">📁</a>` : ""}
						<button class="btn btn-default duty-issue-btn" title="${__("Raise issue from this task")}">⚠</button>
						<button class="btn btn-default duty-note-btn" title="${__("Task notes")}">📝${t.notes ? " " + t.notes : ""}</button>
						<button class="btn btn-default duty-invite-btn" title="${__("Invite a colleague to this task")}">👤+</button>
						<button class="btn btn-default duty-taskcust-btn" title="${__("Set / change customer")}">✎</button>
						<button class="btn btn-default duty-switch-btn" title="${__("Start another task — this one pauses into your tray")}">＋ ${__("Another Task")}</button>
						<button class="btn btn-primary duty-stop-btn">${__("Stop")}</button>
					</div>
				</div>
			`);
			$task.find(".duty-stop-btn").on("click", () => this.stop_task_flow());
			$task.find(".duty-switch-btn").on("click", () => this.start_task_dialog(true));
			$task.find(".duty-invite-btn").on("click", () => this.invite_task_dialog());
			$task.find(".duty-taskcust-btn").on("click", () => this.task_customer_dialog(t.customer));
			$task.find(".duty-note-btn").on("click", () => this.note_dialog(t.name, t.activity, true));
			$task.find(".duty-task-issuechip").on("click", (e) => {
				const card = $(e.currentTarget).data("card");
				if (card) {
					frappe.call({
						method: "duty_board.projects.get_card",
						args: { name: card },
						callback: (r) => r.message && this.task_dialog(r.message.project, r.message),
					});
				} else {
					this.issue_detail_dialog(t.issue);
				}
			});
			$task.find(".duty-issue-btn").on("click", () =>
				this.create_issue_dialog({
					title: t.activity,
					customer: t.customer,
					source_type: "Task",
					source: t.name,
				})
			);
		} else {
			$task.html(`
				<div class="duty-task-card">
					<div class="duty-task-info text-muted">${__("No task running. What are you working on?")}</div>
					<button class="btn btn-primary duty-start-btn">${__("Start Task")}</button>
				</div>
			`);
			$task.find(".duty-start-btn").on("click", () => this.start_task_dialog(false));
		}
	}

	todo_chips(t) {
		let chips = "";
		if (t.lead_title)
			chips += `<span class="duty-lead-chip">💼 ${frappe.utils.escape_html(t.lead_title)}</span>`;
		if (t.project)
			chips += `<span class="duty-proj-chip">📁 ${frappe.utils.escape_html(t.project)}</span>`;
		if (t.due_time) chips += `<span class="duty-time-chip">${t.due_time}</span>`;
		if (t.customer)
			chips += `<span class="duty-task-customer">${frappe.utils.escape_html(t.customer)}</span>`;
		if (t.assigned_by && t.assigned_by !== t.user) {
			const who = this.name_map[t.assigned_by] || t.assigned_by;
			chips += `<span class="duty-from-chip">${__("from")} ${frappe.utils.escape_html(who)}</span>`;
		}
		if (t.carry_count > 0)
			chips += `<span class="duty-carry-chip">${__("carried")} ×${t.carry_count}</span>`;
		return chips;
	}

	render_plan(me) {
		const $plan = this.body.find(".duty-plan").empty();
		if (!me) return;
		const todos = this.my_todos || [];
		const done = todos.filter((t) => t.status === "Done").length;
		const open = todos.length - done;

		const rows = todos
			.map(
				(t) => `
				<div class="duty-todo-row ${t.status === "Done" ? "duty-todo-done" : ""}" data-name="${t.name}">
					<input type="checkbox" class="duty-todo-check" ${t.status === "Done" ? "checked" : ""}>
					<span class="duty-todo-desc">${frappe.utils.escape_html(t.description)}</span>
					${this.todo_chips(t)}
					${
						t.status === "Open"
							? `<a class="duty-todo-edit" title="${__("Edit / set customer")}">✎</a><a class="duty-todo-share" title="${__("Invite a colleague")}">👤+</a><a class="duty-todo-carry" title="${__("Move to tomorrow")}">→</a>`
							: ""
					}
					<a class="duty-todo-remove" title="${__("Remove")}">&times;</a>
				</div>`
			)
			.join("");

		const upcoming = (this.my_upcoming || [])
			.map(
				(t) => `
				<div class="duty-todo-row" data-name="${t.name}">
					<span class="duty-upcoming-date">${frappe.datetime.str_to_user(t.date)}</span>
					<span class="duty-todo-desc">${frappe.utils.escape_html(t.description)}</span>
					${this.todo_chips(t)}
					<a class="duty-todo-remove" title="${__("Remove")}">&times;</a>
				</div>`
			)
			.join("");

		const plan_open = localStorage.getItem("duty_plan_open") !== "0";
		$plan.html(`
			<details class="duty-plan-card duty-plan-details" ${plan_open ? "open" : ""}>
				<summary class="duty-plan-head">
					<span>${__("My Plan for Today")}
						${todos.length ? `<span class="duty-plan-count">${done}/${todos.length} ${__("done")}</span>` : ""}
					</span>
				</summary>
				${
					this.overdue_count
						? `<div class="duty-overdue">
							${__("You have {0} unfinished item(s) from previous days.", [this.overdue_count])}
							<button class="btn btn-xs btn-default duty-bring-old">${__("Bring to today")}</button>
						   </div>`
						: ""
				}
				<div class="duty-plan-actions-row">
					${open ? `<a class="duty-carry-all">${__("Carry unfinished → tomorrow")}</a>` : ""}
					<button class="btn btn-xs btn-default duty-todo-more-btn">＋ ${__("More")}</button>
				</div>
				${rows || `<div class="text-muted duty-plan-empty">${__("Nothing planned yet. What do you want to get done today?")}</div>`}
				<div class="duty-plan-add">
					<input type="text" class="form-control duty-todo-input" placeholder="${__("Add a to-do and press Enter...")}">
					<button class="btn btn-default btn-sm duty-todo-add-btn">${__("Add")}</button>
					<button class="btn btn-default btn-sm duty-todo-existing-btn" title="${__("Add from my issues & tasks")}">📋</button>
				</div>
			</details>
			<details class="duty-sessions-details">
				<summary>${__("Upcoming")} (${(this.my_upcoming || []).length})</summary>
				${upcoming || `<div class="text-muted duty-history-empty">${__("Nothing scheduled ahead.")}</div>`}
			</details>
		`);
		$plan.find(".duty-plan-details").on("toggle", (e) => {
			localStorage.setItem("duty_plan_open", e.target.open ? "1" : "0");
		});

		const add = () => {
			const val = $plan.find(".duty-todo-input").val();
			if (val && val.trim()) this.action("add_todo", { description: val.trim() });
		};
		$plan.find(".duty-todo-add-btn").on("click", add);
		$plan.find(".duty-todo-input").on("keydown", (e) => {
			if (e.key === "Enter") add();
		});
		$plan.find(".duty-todo-more-btn").on("click", () => this.add_todo_dialog());
		$plan.find(".duty-todo-existing-btn").on("click", () => this.plan_existing_dialog());
		$plan.find(".duty-bring-old").on("click", () => this.action("bring_old_todos"));
		$plan.find(".duty-carry-all").on("click", () => {
			frappe.confirm(__("Move all unfinished items to tomorrow?"), () =>
				this.action("carry_all")
			);
		});
		$plan.find(".duty-todo-check").on("change", (e) => {
			const name = $(e.target).closest(".duty-todo-row").data("name");
			this.action("toggle_todo", { name: name, done: e.target.checked ? 1 : 0 });
		});
		$plan.find(".duty-todo-carry").on("click", (e) => {
			const name = $(e.target).closest(".duty-todo-row").data("name");
			this.action("carry_todo", { name: name });
		});
		$plan.find(".duty-todo-remove").on("click", (e) => {
			const name = $(e.target).closest(".duty-todo-row").data("name");
			frappe.confirm(__("Remove this to-do?"), () =>
				this.action("remove_todo", { name: name })
			);
		});
		$plan.find(".duty-todo-edit").on("click", (e) => {
			const name = $(e.target).closest(".duty-todo-row").data("name");
			const t = (this.my_todos || []).find((x) => x.name === name);
			if (t) this.edit_todo_dialog(t);
		});
		$plan.find(".duty-todo-share").on("click", (e) => {
			const name = $(e.target).closest(".duty-todo-row").data("name");
			this.share_todo_dialog(name);
		});
	}

	share_todo_dialog(name) {
		const d = new frappe.ui.Dialog({
			title: __("Invite colleagues to this to-do"),
			fields: [
				{
					fieldname: "users",
					fieldtype: "MultiSelectList",
					label: __("Colleagues"),
					reqd: 1,
					get_data: () =>
						this.team_members().map((x) => ({ value: x.user, description: x.full_name })),
				},
			],
			primary_action_label: __("Invite"),
			primary_action: (v) => {
				d.hide();
				this.action("share_todo", { name: name, users: JSON.stringify(v.users || []) });
			},
		});
		d.show();
	}

	edit_todo_dialog(t) {
		const d = new frappe.ui.Dialog({
			title: __("Edit To-do"),
			fields: [
				{ fieldname: "description", fieldtype: "Data", label: __("To-do"), default: t.description, reqd: 1 },
				{ fieldname: "customer", fieldtype: "Link", label: __("Customer"), options: "Customer", default: t.customer || "" },
				{ fieldname: "due_time", fieldtype: "Time", label: __("Time (optional)"), default: t.due_time || "" },
			],
			primary_action_label: __("Save"),
			primary_action: (v) => {
				d.hide();
				this.action("update_todo", {
					name: t.name,
					description: v.description,
					customer: v.customer || null,
					due_time: v.due_time || null,
				});
			},
		});
		d.show();
	}

	invite_task_dialog() {
		const d = new frappe.ui.Dialog({
			title: __("Invite colleagues to this task"),
			fields: [
				{
					fieldname: "users",
					fieldtype: "MultiSelectList",
					label: __("Colleagues"),
					reqd: 1,
					get_data: () =>
						this.team_members().map((x) => ({ value: x.user, description: x.full_name })),
				},
			],
			primary_action_label: __("Invite"),
			primary_action: (v) => {
				d.hide();
				this.action("invite_to_task", { users: JSON.stringify(v.users || []) });
				frappe.show_alert({ message: __("Invitation sent — it lands on their plan."), indicator: "green" }, 5);
			},
		});
		d.show();
	}

	task_customer_dialog(current) {
		const d = new frappe.ui.Dialog({
			title: __("Set customer for this task"),
			fields: [
				{
					fieldname: "customer",
					fieldtype: "Link",
					label: __("Customer (clear to remove)"),
					options: "Customer",
					default: current || "",
				},
			],
			primary_action_label: __("Save"),
			primary_action: (v) => {
				d.hide();
				this.action("set_task_customer", { customer: v.customer || null });
			},
		});
		d.show();
	}

	plan_existing_dialog() {
		const esc = frappe.utils.escape_html;
		frappe.call({
			method: "duty_board.api.plan_sources",
			callback: (r) => {
				const S = r.message || {};
				const issues = S.issues || [], tasks = S.tasks || [];
				if (!issues.length && !tasks.length) {
					frappe.show_alert({ message: __("No open issues or tasks assigned to you."), indicator: "orange" });
					return;
				}
				const opt = (kind, name, title, sub) => `
					<label class="duty-px-row"><input type="radio" name="duty-px" value="${kind}:${name}">
					<span class="duty-px-t">${esc(title)}</span><span class="duty-px-s">${esc(sub || "")}</span></label>`;
				const d = new frappe.ui.Dialog({
					title: __("Add existing work to my plan"),
					primary_action_label: __("Add to plan"),
					primary_action: () => {
						const v = $(d.body).find("input[name=duty-px]:checked").val();
						if (!v) return frappe.show_alert({ message: __("Pick one."), indicator: "orange" });
						const [kind, ...rest] = v.split(":");
						frappe.call({
							method: "duty_board.api.plan_existing",
							args: { kind: kind, source: rest.join(":"), date: $(d.body).find(".duty-px-date").val() || null },
							callback: (rr) => {
								d.hide();
								frappe.show_alert({ message: __("Added to your plan."), indicator: "green" });
								this.refresh(true);
							},
						});
					},
				});
				$(d.body).html(`
					<div class="duty-px-date-row"><label>${__("For day")}</label>
					<input type="date" class="form-control input-sm duty-px-date" value="${frappe.datetime.now_date()}" min="${frappe.datetime.now_date()}"></div>
					${issues.length ? `<h6>🐞 ${__("My open issues")}</h6>${issues.map((i) => opt("issue", i.name, i.title, i.customer)).join("")}` : ""}
					${tasks.length ? `<h6 style="margin-top:10px">📌 ${__("My project tasks")}</h6>${tasks.map((t) => opt("task", t.name, t.title, t.project_name)).join("")}` : ""}
				`);
				d.show();
			},
		});
	}

	add_todo_dialog() {
		const d = new frappe.ui.Dialog({
			title: __("Add To-do"),
			fields: [
				{
					fieldname: "description",
					fieldtype: "Data",
					label: __("To-do"),
					reqd: 1,
				},
				{
					fieldname: "for_users",
					fieldtype: "MultiSelectList",
					label: __("For (leave empty = just you)"),
					get_data: () =>
						this.team_members().map((x) => ({
							value: x.user,
							description: x.full_name,
						})),
					description: __("Pick one or more colleagues — each gets their own copy, marked as from you."),
				},
				{
					fieldname: "date",
					fieldtype: "Date",
					label: __("Date"),
					default: frappe.datetime.get_today(),
					reqd: 1,
				},
				{
					fieldname: "due_time",
					fieldtype: "Time",
					label: __("Time (optional — used for ordering the list)"),
				},
				{
					fieldname: "customer",
					fieldtype: "Link",
					label: __("Customer (optional)"),
					options: "Customer",
				},
			],
			primary_action_label: __("Add"),
			primary_action: (values) => {
				d.hide();
				this.action("add_todo", {
					description: values.description,
					for_users:
						values.for_users && values.for_users.length
							? JSON.stringify(values.for_users)
							: null,
					date: values.date,
					due_time: values.due_time || null,
					customer: values.customer || null,
				});
			},
		});
		d.show();
	}

	render_my_sessions(sessions, me) {
		const $s = this.body.find(".duty-my-sessions").empty();
		if (!me) return;
		sessions = sessions || [];
		const rows = sessions
			.map(
				(x) => `
				<div class="duty-session-row ${!x.end_time ? "duty-session-live" : ""}">
					<span class="duty-session-activity">${frappe.utils.escape_html(x.activity)}</span>
					${x.customer ? `<span class="duty-task-customer">${frappe.utils.escape_html(x.customer)}</span>` : ""}
					<span class="duty-session-time text-muted">
						${this.fmt_time(x.start_time)} – ${x.end_time ? this.fmt_time(x.end_time) : __("now")}
						· ${this.fmt_duration(x.duration)}
					</span>
					<a class="duty-session-notes" data-session="${x.name}" title="${__("Notes")}">📝${x.notes ? " " + frappe.utils.escape_html(x.notes) : ""}</a>
				</div>`
			)
			.join("");
		$s.html(`
			<details class="duty-sessions-details">
				<summary>${__("My tasks today")} (${sessions.length})</summary>
				${rows || `<div class="text-muted duty-history-empty">${__("No tasks yet today.")}</div>`}
			</details>
			<details class="duty-sessions-details">
				<summary>${__("Earlier days")}</summary>
				<div class="duty-history-link"><a>${__("Open work history ▸")}</a></div>
			</details>
		`);
		$s.find(".duty-session-notes").on("click", (e) => {
			e.preventDefault();
			e.stopPropagation();
			const id = $(e.currentTarget).data("session");
			const sess = sessions.find((s) => s.name === id);
			this.note_dialog(id, sess ? sess.activity : "", true);
		});
		$s.find(".duty-history-link a").on("click", () => this.task_history_dialog());
	}

	render_team(rows) {
		const $team = this.body.find(".duty-team").empty();
		if (!rows || !rows.length) {
			$team.html(`<div class="text-muted">${__("No staff found.")}</div>`);
			return;
		}
		const esc = frappe.utils.escape_html;
		this._team_f = this._team_f || localStorage.getItem("duty_team_f") || "all";
		const is_on = (r) => r.status === "On Duty";
		const no_plan = (r) => !r.todos_total;
		const no_task = (r) => is_on(r) && !r.task;
		const counts = {
			all: rows.length,
			on: rows.filter(is_on).length,
			off: rows.filter((r) => !is_on(r)).length,
			noplan: rows.filter(no_plan).length,
			notask: rows.filter(no_task).length,
		};
		const FDEF = [
			["all", __("All")], ["on", __("On duty")], ["off", __("Off duty")],
			["noplan", __("No plan")], ["notask", __("No task")],
		];
		const shown = rows.filter((r) =>
			this._team_f === "on" ? is_on(r)
			: this._team_f === "off" ? !is_on(r)
			: this._team_f === "noplan" ? no_plan(r)
			: this._team_f === "notask" ? no_task(r)
			: true);
		$team.html(`
			<div class="duty-tf">${FDEF.map(([k, l]) => `<a class="duty-tfp ${this._team_f === k ? "on" : ""}" data-f="${k}">${l} <b>${counts[k]}</b></a>`).join("")}</div>
			<div class="duty-teamtbl">
				${shown.map((r) => {
					const s = this.status_meta(r.status);
					const warn = no_task(r) || no_plan(r);
					return `
					<div class="duty-tr ${warn ? "duty-tr-warn" : ""}" data-user="${r.user}">
						<span class="duty-tr-who">${frappe.avatar(r.user, "avatar-small")}<b style="color:${this.user_color(r.user)}">${esc(r.full_name)}</b>
							${r.user !== frappe.session.user ? `<a class="duty-dm-btn" data-user="${r.user}" data-name="${esc(r.full_name)}" title="${__("Direct message")}">✉<b class="duty-dm-badge" ${(this.dm_unread || {})[r.user] ? "" : 'style="display:none"'}>${(this.dm_unread || {})[r.user] || ""}</b></a>` : ""}</span>
						<span class="duty-badge" style="color:${s.color};background:${s.bg}"><span class="duty-dot" style="background:${s.color}"></span>${__(r.status)}</span>
						<span class="duty-tr-task">${r.task
							? `${esc(r.task.activity)}${r.task.customer ? ` <span class="duty-task-customer">${esc(r.task.customer)}</span>` : ""} <span class="text-muted">${this.fmt_duration(r.task.seconds)}</span>`
							: r.status === "Away" && r.reason ? `<span class="text-muted">${esc(r.reason)}</span>`
							: r.status === "Done for the Day" && r.summary ? `<span class="text-muted">“${esc(r.summary)}”</span>`
							: `<span class="text-muted">—</span>`}</span>
						<span class="duty-tr-dur">${r.since ? this.fmt_duration(r.on_duty_seconds) : `<span class="text-muted">${__("not in")}</span>`}</span>
						<span class="duty-tr-plan ${no_plan(r) ? "duty-tr-plan-none" : ""}">${r.todos_total ? `${r.todos_done}/${r.todos_total}` : "—"}</span>
						<a class="duty-tr-more">›</a>
					</div>`;
				}).join("") || `<div class="text-muted" style="padding:10px 4px">${__("Nobody matches this filter.")}</div>`}
			</div>`);
		$team.find(".duty-tfp").on("click", (e) => {
			this._team_f = $(e.currentTarget).data("f");
			localStorage.setItem("duty_team_f", this._team_f);
			this.render_team(rows);
		});
		$team.find(".duty-tr").on("click", (e) => {
			if ($(e.target).closest(".duty-dm-btn").length) return;
			const r = rows.find((x) => x.user === $(e.currentTarget).data("user"));
			if (r) this.show_member(r);
		});
	}

	show_member(r) {
		const todo_rows = (r.todos || [])
			.map(
				(t) => `
				<div class="duty-todo-row ${t.status === "Done" ? "duty-todo-done" : ""}">
					<span class="duty-detail-tick">${t.status === "Done" ? "✅" : "⬜"}</span>
					<span class="duty-todo-desc">${frappe.utils.escape_html(t.description)}</span>
					${this.todo_chips(t)}
				</div>`
			)
			.join("");

		const session_rows = (r.sessions || [])
			.map(
				(x) => `
				<div class="duty-session-row ${!x.end_time ? "duty-session-live" : ""}">
					<span class="duty-session-activity">${frappe.utils.escape_html(x.activity)}</span>
					${x.customer ? `<span class="duty-task-customer">${frappe.utils.escape_html(x.customer)}</span>` : ""}
					<span class="duty-session-time text-muted">
						${this.fmt_time(x.start_time)} – ${x.end_time ? this.fmt_time(x.end_time) : __("now")}
						· ${this.fmt_duration(x.duration)}
					</span>
					<a class="duty-session-notes" data-session="${x.name}" title="${__("Notes")}">📝${x.notes ? " " + frappe.utils.escape_html(x.notes) : ""}</a>
				</div>`
			)
			.join("");

		const s = this.status_meta(r.status);
		const d = new frappe.ui.Dialog({
			title: __("{0} — Today", [r.full_name]),
			size: "large",
		});
		$(d.body).html(`
			<div class="duty-detail">
				<div class="duty-detail-status">
					<span class="duty-badge" style="color:${s.color};background:${s.bg}">
						<span class="duty-dot" style="background:${s.color}"></span>${__(r.status)}
					</span>
					${r.reason && r.status === "Away" ? `<span class="duty-reason">· ${frappe.utils.escape_html(r.reason)}</span>` : ""}
					<span class="text-muted">
						· ${__("On duty")}: ${this.fmt_duration(r.on_duty_seconds)}${
							r.breaks ? " · " + __("Breaks") + ": " + r.breaks : ""
						}
					</span>
				</div>
				<div class="duty-detail-title">${__("Plan")} ${r.todos_total ? `(${r.todos_done}/${r.todos_total})` : ""}</div>
				${todo_rows || `<div class="text-muted">${__("No plan recorded today.")}</div>`}
				<div class="duty-detail-title">${__("Tasks Worked On")}</div>
				${session_rows || `<div class="text-muted">${__("No tasks tracked today.")}</div>`}
				${
					r.summary
						? `<div class="duty-detail-title">${__("End of Day Summary")}</div>
						   <div class="duty-summary">“${frappe.utils.escape_html(r.summary)}”</div>`
						: ""
				}
			</div>
		`);
		$(d.body).find(".duty-session-notes").on("click", (e) => {
			e.preventDefault();
			const id = $(e.currentTarget).data("session");
			const sess = (r.sessions || []).find((s) => s.name === id);
			this.note_dialog(id, sess ? sess.activity : "", r.user === frappe.session.user);
		});
		d.show();
	}

	status_meta(status) {
		return (
			{
				"On Duty": { color: "var(--green-600, #2e7d32)", bg: "var(--green-100, #e8f5e9)" },
				Away: { color: "var(--orange-600, #ef6c00)", bg: "var(--orange-100, #fff3e0)" },
				"Done for the Day": { color: "var(--blue-600, #1565c0)", bg: "var(--blue-100, #e3f2fd)" },
				"On Leave": { color: "var(--purple-600, #6b21a8)", bg: "var(--bg-purple, #f3e8fd)" },
				"Off Duty": { color: "var(--gray-600, #757575)", bg: "var(--gray-100, #f5f5f5)" },
			}[status] || { color: "var(--gray-600)", bg: "var(--gray-100)" }
		);
	}

	fmt_stamp(dt) {
		if (!dt) return "";
		const p = frappe.datetime.str_to_user(dt).split(" ");
		return p[0] + (p[1] ? " " + p[1].slice(0, 5) : "");
	}

	smart_time(s) {
		if (!s) return "";
		const d = new Date(s.replace(" ", "T"));
		if (isNaN(d)) return s;
		const hm = s.slice(11, 16);
		const now = new Date();
		const day0 = (x) => { const y = new Date(x.getFullYear(), x.getMonth(), x.getDate()); return y; };
		const today = day0(now);
		const that = day0(d);
		if (that.getTime() === today.getTime()) return hm;
		const monday = new Date(today);
		monday.setDate(today.getDate() - ((today.getDay() + 6) % 7));
		if (that >= monday && that < today) return d.toLocaleDateString(undefined, { weekday: "long" }) + " " + hm;
		return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) + ", " + hm;
	}

	fmt_time(dt) {
		return frappe.datetime.str_to_user(dt).split(" ").slice(1).join(" ") || dt;
	}

	fmt_duration(seconds) {
		if (!seconds) return "0m";
		const h = Math.floor(seconds / 3600);
		const m = Math.round((seconds % 3600) / 60);
		return h ? `${h}h ${m}m` : `${m}m`;
	}

	// ---------------- Chat face ----------------

	_cr_host() {
		// render_client_room paints into whichever face is currently asking.
		if (this.face === "chat") return this.$chatface.find(".duty-ch-room");
		return this.$clients.find(".duty-cr-room");
	}

	ch_ping() {
		// Debounced: a burst of realtime events costs one rail refresh.
		if (this.face !== "chat") return;
		clearTimeout(this._ch_t);
		this._ch_t = setTimeout(() => this.refresh_chat(true), 700);
	}

	refresh_chat(silent) {
		frappe.call({
			method: "duty_board.chat.get_rail",
			freeze: false,
			error: (x) => this._poll_failed(x),
			callback: (r) => {
				this._ch_fail = 0;
				this._convos = r.message || [];
				this.render_chat_rail();
				if (!this._ch_open && !window.matchMedia("(max-width: 991px)").matches) {
					// Desktop only: two panes, the centre must show something —
					// Duty Room for staff (pinned), newest room for consultants.
					// On mobile the rail IS the destination; auto-opening here is
					// what bounced ‹ Chats straight back into the conversation.
					const first = (this._convos || [])[0];
					if (first) this.open_convo(first.kind, String(first.id));
				}
			},
		});
	}

	render_chat_rail() {
		const $list = this.$chatface.find(".duty-ch-list");
		const esc = frappe.utils.escape_html;
		const q = (this._ch_q || "").toLowerCase();
		const all = this._convos || [];
		const rows = all.filter(
			(c) =>
				!q ||
				(c.title || "").toLowerCase().indexOf(q) >= 0 ||
				(c.subtitle || "").toLowerCase().indexOf(q) >= 0
		);
		const total = all.reduce((n, c) => n + (c.unread || 0), 0);
		this.$chatface
			.find(".duty-ch-total")
			.text(total ? (total > 99 ? "99+" : total) : "")
			.toggle(!!total);
		if (!rows.length) {
			$list.html(
				`<div class="text-muted duty-plan-empty">${q ? __("No chats match.") : __("No conversations yet.")}</div>`
			);
			return;
		}
		const open = this._ch_open || {};
		$list.html(
			rows
				.map((c) => {
					const on = open.kind === c.kind && String(open.id) === String(c.id);
					const initial = (c.title || "?").trim().charAt(0).toUpperCase();
					const badge = c.unread
						? `<span class="duty-ch-badge ${c.unread_client ? "is-client" : ""}">${c.unread > 99 ? "99+" : c.unread}</span>`
						: "";
					const join = c.join_requests
						? `<span class="duty-ch-join" title="${__("Join requests waiting")}">\ud83d\ude4b ${c.join_requests}</span>`
						: "";
					const frozen = c.kind === "room" && c.status && c.status !== "Active";
					return `
					<a class="duty-ch-row ${on ? "on" : ""} ${c.unread ? "unread" : ""} ${frozen ? "frozen" : ""}"
					   data-kind="${esc(c.kind)}" data-id="${esc(String(c.id))}">
						<span class="duty-ch-av" style="background:${c.kind === "team" ? "#0f766e" : this.proj_color(String(c.id))}">${c.kind === "team" ? "\ud83d\udcac" : c.kind === "dm" ? "\u2709" : esc(initial)}</span>
						<span class="duty-ch-body">
							<span class="duty-ch-l1">
								<b class="duty-ch-title">${esc(c.title || "")}</b>
								${c.kind === "room" ? `<span class="duty-ch-unit">${esc(c.subtitle || "General")}</span>` : ""}
								<span class="duty-ch-when">${c.last_when ? esc(this.smart_time(c.last_when)) : ""}</span>
							</span>
							<span class="duty-ch-l2">
								<span class="duty-ch-prev">${esc(c.last || __("No messages yet"))}</span>
								${join}${badge}
							</span>
						</span>
					</a>`;
				})
				.join("")
		);
		$list.find(".duty-ch-row").on("click", (e) => {
			const $r = $(e.currentTarget);
			// .attr not .data — room ids and emails must not be coerced.
			this.open_convo($r.attr("data-kind"), $r.attr("data-id"));
		});
	}

	open_convo(kind, id) {
		if (!kind || !id) return;
		if (this._is_consultant && kind !== "room") return;
		this._ch_open = { kind: kind, id: id };
		// Optimistic: the pill dies the moment you open the conversation.
		// The server watermark (mark_*_seen) commits asynchronously, so a
		// reconciling refresh follows once it has had time to land.
		const cv = (this._convos || []).find((c) => c.kind === kind && String(c.id) === String(id));
		if (cv) { cv.unread = 0; cv.unread_client = 0; cv.unread_other = 0; }
		clearTimeout(this._ch_reconcile);
		this._ch_reconcile = setTimeout(() => { if (this.face === "chat") this.refresh_chat(true); }, 1500);
		const $c = this.$chatface;
		$c.find(".duty-ch-blank").hide();
		$c.find(".duty-ch-room, .duty-ch-team, .duty-ch-dm").hide();
		$c.find(".duty-ch-sidetoggle").toggle(kind === "room");
		if (kind === "team") this._ch_show_team();
		else if (kind === "room") this._ch_show_room(id);
		else if (kind === "dm") this._ch_show_dm(id);
		else return;
		this.render_chat_rail();
		if (window.matchMedia("(max-width: 991px)").matches) {
			// Full-screen conversation with a way back — WhatsApp shape.
			const esc = frappe.utils.escape_html;
			const conv = (this._convos || []).find(
				(c) => c.kind === kind && String(c.id) === String(id)
			);
			const title =
				(conv && conv.title) ||
				(kind === "team" ? __("Duty Room") : kind === "dm" ? this.name_map[id] || id : id);
			const $center = $c.find(".duty-ch-center");
			$center.find(".duty-ch-mhead").remove();
			$center.prepend(`
				<div class="duty-ch-mhead">
					<a class="duty-ch-mback">‹ ${__("Chats")}</a>
					<b>${esc(title)}</b>
					${conv && conv.subtitle && kind === "room" ? `<span class="duty-ch-munit">${esc(conv.subtitle)}</span>` : ""}
				</div>`);
			$center.find(".duty-ch-mback").on("click", () => {
				$c.removeClass("ch-convo-open");
				this._ch_open = null;
				this.refresh_chat(true);
			});
			$c.addClass("ch-convo-open");
		}
	}

	_ch_show_team() {
		const $host = this.$chatface.find(".duty-ch-team").show();
		// Move the live node — every handler, observer and draft comes along.
		if (this.$chat && this.$chat.parent()[0] !== $host[0]) this.$chat.appendTo($host);
		this.chat_open = true;
		this.apply_chat_state();
		this.clear_unread();
		this.scroll_chat();
	}

	_ch_return_team() {
		const $home = this.body.find(".duty-chat");
		if (this.$chat && $home.length && this.$chat.parent()[0] !== $home[0]) {
			this.$chat.appendTo($home);
			this.apply_chat_state();
		}
	}

	_ch_show_room(name) {
		this._ch_return_team();
		this.$chatface.find(".duty-ch-room").show();
		this.open_client_room(name);
	}

	_ch_show_dm(user) {
		this._ch_return_team();
		const $host = this.$chatface.find(".duty-ch-dm").show();
		this._ch_dm = this.build_dm_thread($host, user, this.name_map[user] || user);
	}

	new_dm_dialog() {
		const esc = frappe.utils.escape_html;
		const people = this.team_members();
		if (!people.length) {
			frappe.show_alert({ message: __("Colleague list is still loading — try again in a moment."), indicator: "orange" });
			return;
		}
		const d = new frappe.ui.Dialog({ title: __("New direct message") });
		$(d.body).html(`
			<input type="text" class="form-control duty-ndm-q" placeholder="${__("Type a name\u2026")}">
			<div class="duty-ndm-list"></div>
		`);
		const $q = $(d.body).find(".duty-ndm-q");
		const $list = $(d.body).find(".duty-ndm-list");
		const pick = (user) => {
			d.hide();
			this.open_convo("dm", user);
		};
		const paint = () => {
			const q = ($q.val() || "").toLowerCase();
			const rows = people
				.filter((p) => !q || (p.full_name || p.user).toLowerCase().indexOf(q) >= 0)
				.sort((a, b) => (a.full_name || a.user).localeCompare(b.full_name || b.user));
			$list.html(
				rows.length
					? rows
						.map(
							(p) => `
						<a class="duty-ndm-row" data-user="${esc(p.user)}">
							<span class="duty-ch-av" style="background:${this.user_color(p.user)}">${esc((p.full_name || p.user).trim().charAt(0).toUpperCase())}</span>
							<span>${esc(p.full_name || p.user)}</span>
						</a>`
						)
						.join("")
					: `<div class="text-muted duty-plan-empty">${__("Nobody matches.")}</div>`
			);
			$list.find(".duty-ndm-row").on("click", (e) => pick($(e.currentTarget).attr("data-user")));
		};
		$q.on("input", frappe.utils.debounce(paint, 120));
		$q.on("keydown", (e) => {
			if (e.key === "Enter") {
				const $first = $list.find(".duty-ndm-row").first();
				if ($first.length) pick($first.attr("data-user"));
			}
		});
		paint();
		d.show();
		setTimeout(() => $q.focus(), 150);
	}

	toggle_ch_side() {
		const hide = !this.$chatface.hasClass("ch-side-hidden");
		this.$chatface.toggleClass("ch-side-hidden", hide);
		localStorage.setItem("duty_ch_side", hide ? "0" : "1");
	}

	build_dm_thread($host, user, full_name) {
		// One implementation, two hosts: the ✉ dialog and the Chat face.
		const esc = frappe.utils.escape_html;
		const first = (full_name || user).split(" ")[0];
		$host.html(`
			<div class="duty-dm-list"><div class="text-muted">${__("Loading...")}</div></div>
			<div class="duty-dm-send">
				<textarea rows="1" class="form-control duty-dm-input" maxlength="1000"
					placeholder="${__("Message {0}... Enter to send, Shift+Enter for a new line", [esc(first)])}"></textarea>
				<button class="btn btn-primary btn-sm duty-dm-btn-send">${__("Send")}</button>
			</div>
		`);
		const $list = $host.find(".duty-dm-list");
		const $input = $host.find(".duty-dm-input");
		const att = this.wire_dm_attach($host.find(".duty-dm-send"), $input);
		let oldest = null;
		const load = (before) => {
			frappe.call({
				method: "duty_board.dm.get_dm_thread",
				args: { with_user: user, before: before },
				callback: (r) => {
					const data = r.message || {};
					this._dm_peer_delivered = data.peer_delivered || null;
					const msgs = data.messages || [];
					if (msgs.length) oldest = msgs[0].creation;
					if (!before) {
						$list.empty();
						if (data.has_more) {
							$list.append(`<div class="duty-load-earlier"><a>${__("Load earlier")}</a></div>`);
							$list.find(".duty-load-earlier a").on("click", () => load(oldest));
						}
						$list.append(msgs.map((m) => this.dm_row(m)).join(""));
						if (!msgs.length) {
							$list.append(`<div class="text-muted duty-plan-empty">${__("No messages yet — say hello.")}</div>`);
						}
						$list.scrollTop($list[0].scrollHeight);
					} else {
						const old_h = $list[0].scrollHeight;
						const $anchor = $list.find(".duty-load-earlier");
						$anchor.after(msgs.map((m) => this.dm_row(m)).join(""));
						if (!data.has_more) $anchor.hide();
						$list.scrollTop($list[0].scrollHeight - old_h);
					}
					this.mark_dm_seen(user);
				},
			});
		};
		const send = async () => {
			const text = ($input.val() || "").trim();
			if (!text && !att.has()) return;
			$input.val("");
			let up = null;
			try {
				up = await att.consume();
			} catch (err) {
				$input.val(text);
				frappe.show_alert(
					{
						message: __("Upload failed: {0}", [frappe.utils.escape_html(err.message || String(err))]),
						indicator: "red",
					},
					8
				);
				console.error("DM upload failed", err);
				return;
			}
			frappe.call({
				method: "duty_board.dm.send_dm",
				args: {
					to: user,
					message: text,
					attachment_url: up ? up.file_url : null,
					attachment_name: up ? up.file_name : null,
				},
				callback: (r) => {
					const m = r.message;
					if (m && !$list.find(`[data-name="${m.name}"]`).length) {
						$list.find(".duty-plan-empty").remove();
						$list.append(this.dm_row(m));
						$list.scrollTop($list[0].scrollHeight);
					}
				},
			});
		};
		$list.on("click", ".duty-dm-edit", (e) => {
			const $t = $(e.currentTarget);
			this.edit_prompt("dm", $t.data("name"), $t.data("text"), $t.data("att") == 1, () => load(null));
		});
		$host.find(".duty-dm-btn-send").on("click", send);
		$input.on("keydown", (e) => {
			if (e.key === "Enter" && !e.shiftKey) {
				e.preventDefault();
				send();
			}
		});
		load(null);
		this.set_dm_badge(user, 0);
		return { user: user, $list: $list, append: (m) => {
			if (!$list.find(`[data-name="${m.name}"]`).length) {
				$list.find(".duty-plan-empty").remove();
				$list.append(this.dm_row(m));
				$list.scrollTop($list[0].scrollHeight);
			}
		} };
	}

	inject_style() {
		if ($("#duty-board-style").length) $("#duty-board-style").remove();
		$(`<style id="duty-board-style">
			.duty-board { padding: var(--padding-md) 0; }
			.duty-me-card {
				display: flex; justify-content: space-between; align-items: center; gap: 16px;
				padding: 20px; border: 1px solid var(--border-color);
				border-radius: var(--border-radius-lg, 10px); background: var(--card-bg);
				flex-wrap: wrap;
			}
			.duty-me-status { font-size: var(--text-lg); }
			.duty-me-sub { margin-top: 4px; }
			.duty-main-btn { min-width: 160px; }
			.duty-task-card {
				display: flex; justify-content: space-between; align-items: center; gap: 16px;
				margin-top: 10px; padding: 14px 20px; border: 1px dashed var(--border-color);
				border-radius: var(--border-radius-lg, 10px); background: var(--card-bg);
				flex-wrap: wrap;
			}
			.duty-task-running { border-style: solid; border-color: var(--green-500, #4caf50); }
			.duty-task-label {
				font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.04em;
				color: var(--text-muted); font-weight: 600;
			}
			.duty-task-name { font-size: var(--text-base); font-weight: 600; margin: 2px 0; }
			.duty-task-customer {
				display: inline-block; margin-left: 6px; padding: 1px 8px; border-radius: 99px;
				background: var(--bg-purple, #f3e8fd); color: var(--purple-600, #6b21a8);
				font-size: var(--text-xs); font-weight: 600;
			}
			.duty-plan-tag {
				display: inline-block; padding: 1px 8px; border-radius: 99px;
				background: var(--blue-100, #e3f2fd); color: var(--blue-600, #1565c0);
				font-size: var(--text-xs); font-weight: 700;
			}
			.duty-task-actions { display: flex; gap: 8px; }
			.duty-plan-card {
				margin-top: 10px; padding: 14px 20px; border: 1px solid var(--border-color);
				border-radius: var(--border-radius-lg, 10px); background: var(--card-bg);
			}
			.duty-plan-head {
				font-weight: 600; margin-bottom: 8px; display: flex;
				justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px;
			}
			.duty-plan-actions { display: inline-flex; align-items: center; gap: 12px; font-weight: 400; }
			.duty-carry-all { cursor: pointer; font-size: var(--text-sm); color: var(--text-muted); }
			.duty-carry-all:hover { color: var(--text-color); }
			.duty-overdue {
				display: flex; justify-content: space-between; align-items: center; gap: 10px;
				margin-bottom: 10px; padding: 8px 12px; border-radius: 8px; flex-wrap: wrap;
				background: var(--orange-100, #fff3e0); color: var(--orange-700, #e65100);
				font-size: var(--text-sm);
			}
			.duty-time-chip {
				display: inline-block; margin-left: 6px; padding: 1px 8px; border-radius: 99px;
				background: var(--gray-100, #f5f5f5); color: var(--gray-700, #616161);
				font-size: var(--text-xs); font-weight: 600; font-variant-numeric: tabular-nums;
			}
			.duty-from-chip {
				display: inline-block; margin-left: 6px; padding: 1px 8px; border-radius: 99px;
				background: var(--blue-100, #e3f2fd); color: var(--blue-700, #1565c0);
				font-size: var(--text-xs); font-weight: 600;
			}
			.duty-carry-chip {
				display: inline-block; margin-left: 6px; padding: 1px 8px; border-radius: 99px;
				background: var(--orange-100, #fff3e0); color: var(--orange-700, #e65100);
				font-size: var(--text-xs); font-weight: 600;
			}
			.duty-upcoming-date {
				font-size: var(--text-xs); color: var(--text-muted); min-width: 82px;
				font-variant-numeric: tabular-nums;
			}
			.duty-plan-details > summary { cursor: pointer; list-style: none; }
			.duty-plan-details > summary::-webkit-details-marker { display: none; }
			.duty-plan-details > summary::after { content: " ▾"; color: var(--text-muted); font-size: var(--text-xs); }
			.duty-plan-details:not([open]) > summary::after { content: " ▸"; }
			.duty-plan-actions-row {
				display: flex; justify-content: flex-end; align-items: center; gap: 12px;
				margin: 6px 0 4px; font-weight: 400;
			}
			.duty-todo-edit, .duty-todo-share {
				cursor: pointer; color: var(--text-muted); padding: 0 4px;
				visibility: hidden; font-size: var(--text-sm);
			}
			.duty-todo-row:hover .duty-todo-edit,
			.duty-todo-row:hover .duty-todo-share { visibility: visible; }
			.duty-todo-carry {
				cursor: pointer; color: var(--text-muted); font-weight: 700;
				padding: 0 6px; visibility: hidden;
			}
			.duty-todo-row:hover .duty-todo-carry { visibility: visible; }
			.duty-plan-count { color: var(--text-muted); font-size: var(--text-sm); font-weight: 500; }
			.duty-plan-empty { padding: 4px 0 8px; }
			.duty-todo-row {
				display: flex; align-items: center; gap: 8px; padding: 6px 2px;
				border-bottom: 1px solid var(--border-color);
			}
			.duty-todo-row:last-of-type { border-bottom: none; }
			.duty-todo-check { margin: 0; cursor: pointer; }
			.duty-todo-desc { flex: 1; }
			.duty-todo-done .duty-todo-desc { text-decoration: line-through; color: var(--text-muted); }
			.duty-todo-remove {
				cursor: pointer; color: var(--text-muted); font-size: 16px;
				padding: 0 6px; visibility: hidden;
			}
			.duty-todo-row:hover .duty-todo-remove { visibility: visible; }
			.duty-plan-add { display: flex; gap: 8px; margin-top: 10px; }
			.duty-plan-add .duty-todo-input { flex: 1; }
			.duty-sessions-details { margin-top: 8px; font-size: var(--text-sm); }
			.duty-layout { display: flex; gap: 18px; align-items: flex-start; }
			.duty-main {
				flex: 1 1 0; min-width: 0;
				background: #fcfcfd; border: 1px solid var(--border-color);
				border-top: 4px solid #2563eb;
				border-radius: 14px; padding: 14px;
			}
			.duty-issues {
				background: #fbfbfa; border: 1px solid var(--border-color);
				border-top: 4px solid #d97706;
				border-radius: 14px; padding: 14px;
			}
			.duty-side {
				flex: 0 0 33%; max-width: 33%; position: sticky; top: 56px;
				background: #fafcfc; border: 1px solid var(--border-color);
				border-top: 4px solid #0F5C55;
				border-radius: 14px; padding: 12px;
			}
			.duty-chat-collapsed .duty-side { flex: 0 0 auto; max-width: none; }
			.duty-chatface { display: flex; gap: 0; height: calc(100vh - 150px); min-height: 420px; border: 1px solid var(--border-color, #e0e0e0); border-radius: 10px; overflow: hidden; background: var(--card-bg, #fff); }
			.duty-ch-rail { width: 360px; min-width: 360px; display: flex; flex-direction: column; border-right: 1px solid var(--border-color, #e0e0e0); background: var(--fg-color, #fafafa); }
			.duty-ch-railhead { display: flex; align-items: center; gap: 8px; padding: 12px 14px 8px; font-size: 15px; }
			.duty-ch-total { background: #ef4444; color: #fff; border-radius: 10px; padding: 0 7px; font-size: 11px; font-weight: 700; line-height: 18px; }
			.duty-ch-search { padding: 0 12px 10px; }
			.duty-ch-list { flex: 1; overflow-y: auto; }
			.duty-ch-row { display: flex; gap: 11px; padding: 12px 14px; border-bottom: 1px solid var(--border-color, #ececec); cursor: pointer; text-decoration: none; color: inherit; }
			.duty-ch-row:hover { background: var(--bg-light-gray, #f2f2f2); text-decoration: none; color: inherit; }
			.duty-ch-row.on { background: var(--bg-light-gray, #e8f2f1); box-shadow: inset 3px 0 0 #0f766e; }
			.duty-ch-row.frozen { opacity: .55; }
			.duty-ch-av { width: 40px; height: 40px; min-width: 40px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 15px; }
			.duty-ch-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
			.duty-ch-l1, .duty-ch-l2 { display: flex; align-items: center; gap: 6px; }
			.duty-ch-title { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 600; }
			.duty-ch-row.unread .duty-ch-title { font-weight: 800; }
			.duty-ch-when { font-size: 11px; color: var(--text-muted, #888); white-space: nowrap; }
			.duty-ch-prev { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; color: var(--text-muted, #777); }
			.duty-ch-row.unread .duty-ch-prev { color: var(--text-color, #333); }
			.duty-ch-sub { font-size: 11px; color: var(--text-muted, #999); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-ch-badge { background: #22c55e; color: #fff; border-radius: 11px; padding: 0 8px; font-size: 12px; font-weight: 700; line-height: 20px; min-width: 20px; text-align: center; }
			.duty-ch-badge.is-client { background: #ef4444; }
			.duty-ch-unit { background: var(--bg-light-gray, #eef2f1); color: #0f766e; border: 1px solid #d5e5e2; border-radius: 8px; padding: 0 6px; font-size: 10px; font-weight: 700; line-height: 16px; white-space: nowrap; flex-shrink: 0; }
			@media (min-width: 992px) {
				/* Chat lives in the Chat face now; My Day gets its width back. */
				.duty-layout > .duty-side { display: none !important; }
			}
			.duty-ch-join { background: #f59e0b; color: #fff; border-radius: 10px; padding: 0 6px; font-size: 10px; font-weight: 700; line-height: 17px; }
			.duty-ch-center { flex: 1; min-width: 0; position: relative; display: flex; flex-direction: column; }
			.duty-ch-center > .duty-ch-room, .duty-ch-center > .duty-ch-team, .duty-ch-center > .duty-ch-dm { flex: 1; min-height: 0; }
			.duty-ch-blank { margin: auto; color: var(--text-muted, #999); }
			.duty-ch-sidetoggle { position: absolute; top: 10px; right: 12px; z-index: 5; cursor: pointer; font-size: 15px; opacity: .65; }
			.duty-ch-sidetoggle:hover { opacity: 1; }
			.duty-chatface.ch-side-hidden .duty-cr-side { display: none !important; }
			.duty-ch-team { display: flex; flex-direction: column; }
			.duty-ch-team .duty-chat-card { flex: 1; min-height: 0; border: 0; border-radius: 0; box-shadow: none; }
			.duty-ch-team .duty-chat-collapse { display: none !important; }
			.duty-ch-dm { display: flex; flex-direction: column; padding: 12px; }
			.duty-ch-dm .duty-dm-list { flex: 1; min-height: 0; overflow-y: auto; }
			.duty-ch-room .duty-cr-back { display: none !important; }
			@media (min-width: 992px) {
				/* Desktop shows the task column; the 💬/📋 pills are mobile's. */
				.duty-ch-room .duty-cr-mtabs { display: none !important; }
			}
			@media (max-width: 991px) {
				.duty-ch-sidetoggle { display: none !important; }
			}
			.duty-ch-new { margin-left: auto; cursor: pointer; font-size: 15px; opacity: .7; text-decoration: none; }
			.duty-ch-new:hover { opacity: 1; text-decoration: none; }
			.duty-ndm-q { margin-bottom: 8px; }
			.duty-ndm-list { max-height: 320px; overflow-y: auto; }
			.duty-ndm-row { display: flex; align-items: center; gap: 10px; padding: 8px 10px; border-radius: 8px; cursor: pointer; color: inherit; text-decoration: none; }
			.duty-ndm-row:hover { background: var(--bg-light-gray, #f2f2f2); color: inherit; text-decoration: none; }
			.duty-ndm-row .duty-ch-av { width: 32px; height: 32px; min-width: 32px; font-size: 13px; }
			/* WhatsApp rhythm — Chat face only; mobile board tab and portal untouched. */
			.duty-chatface .duty-chat-list { padding: 16px 20px; }
			.duty-chatface .duty-chat-list .duty-msg { margin-bottom: 14px; line-height: 1.55; }
			.duty-chatface .duty-cr-msgs { padding: 16px 20px; }
			.duty-chatface .duty-cr-msgs .duty-cr-msg { margin-bottom: 14px; line-height: 1.55; }
			.duty-chatface .duty-dm-list { padding: 16px 20px; }
			.duty-chatface .duty-dm-list .duty-msg { margin-bottom: 14px; line-height: 1.55; }
			/* .duty-fluid.container out-specifies Bootstrap's .container breakpoints. */
			.duty-fluid.container { max-width: 100%; }
			.duty-daytabs { display: flex; gap: 8px; margin: 0 0 12px; }
			.duty-daytabs a { padding: 7px 18px; border-radius: 10px; font-weight: 600; cursor: pointer; border: 1px solid var(--border-color, #e0e0e0); background: var(--card-bg, #fff); color: var(--text-muted, #666); text-decoration: none; }
			.duty-daytabs a:hover { color: var(--text-color, #333); text-decoration: none; }
			.duty-daytabs a.on { background: #0F5C55; border-color: #0F5C55; color: #fff; }
			.duty-msg-edited { font-size: 10px; color: var(--text-muted, #9aa4a0); font-style: italic; margin-left: 4px; }
			.duty-msg-edit, .duty-cr-edit, .duty-dm-edit { cursor: pointer; opacity: .6; margin-left: 6px; }
			.duty-msg-edit:hover, .duty-cr-edit:hover, .duty-dm-edit:hover { opacity: 1; }
			.duty-paused-strip { display: flex; align-items: center; gap: 10px; margin: 0 0 12px; padding: 9px 14px; background: #FFF7E6; border: 1px solid #F5D08A; border-radius: 10px; }
			.duty-paused-ic { font-size: 16px; }
			.duty-paused-txt { flex: 1; min-width: 0; font-size: 13px; }
			.duty-paused-resume { cursor: pointer; font-weight: 700; color: #0F5C55; white-space: nowrap; }
			.duty-paused-hint { font-size: 12px; color: var(--text-muted, #999); white-space: nowrap; }
			.duty-paused-dismiss { cursor: pointer; opacity: .5; }
			.duty-paused-dismiss:hover { opacity: 1; }
			.duty-phases { padding: 12px 4px; max-width: 720px; }
			.duty-phases-empty { text-align: center; padding: 24px; }
			.duty-phase-seed { display: flex; gap: 10px; justify-content: center; align-items: center; flex-wrap: wrap; }
			.duty-phase-row { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border: 1px solid var(--border-color, #e6e6e6); border-radius: 10px; margin-bottom: 8px; background: #fff; }
			.duty-phase-active { border-color: #0F5C55; box-shadow: 0 0 0 1px #0F5C55 inset; }
			.duty-phase-done { opacity: .7; }
			.duty-phase-ix { width: 26px; height: 26px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; background: #EEF4F3; color: #0F5C55; flex: none; }
			.duty-phase-done .duty-phase-ix { background: #0E8A63; color: #fff; }
			.duty-phase-main { flex: 1; min-width: 0; }
			.duty-phase-title { font-weight: 700; }
			.duty-phase-meta { font-size: 12px; color: var(--text-muted, #888); }
			.duty-phase-wait { color: #B45309; font-size: 11px; font-weight: 700; }
			.duty-phase-acts { display: flex; gap: 8px; }
			.duty-phase-acts a { cursor: pointer; opacity: .65; text-decoration: none; }
			.duty-phase-acts a:hover { opacity: 1; }
			.duty-phase-add { margin-top: 10px; }
			.duty-phase-tasks { margin: 4px 0 2px 38px; display: flex; flex-direction: column; gap: 3px; }
			.duty-phase-tasks.empty { color: var(--text-muted, #9aa4a0); font-size: 12px; font-style: italic; }
			.duty-phase-task { display: flex; align-items: center; gap: 8px; font-size: 12.5px; }
			.duty-pt-dot { width: 7px; height: 7px; border-radius: 50%; background: #C4CFC9; flex: none; }
			.duty-pt-dot.done { background: #0E8A63; }
			.duty-pt-title { flex: 1; min-width: 0; }
			.duty-pt-st { color: var(--text-muted, #888); font-size: 11px; }
			.duty-pt-who { color: #5f6d68; font-size: 11px; }
			.duty-kb-ms { font-size: 10.5px; color: #0F5C55; margin-top: 2px; font-weight: 600; }
			.duty-kb-blk { font-size: 10.5px; color: #B45309; margin-top: 2px; font-weight: 700; }
			.duty-est-act { display: block; font-size: 11px; color: #65736F; margin-top: 2px; }
			.duty-est-act.over, .duty-est-over { color: #C2410C; font-weight: 700; }
			.duty-baseline-bar { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 8px 12px; border: 1px solid #E4EAE8; border-radius: 10px; margin-bottom: 12px; background: #F7FAF9; font-size: 13px; }
			.duty-baseline-bar.on { background: #F0F6F4; border-color: #D2E4E0; }
			.duty-baseline-set { cursor: pointer; }
			a.duty-baseline-set { font-size: 12px; text-decoration: underline; }
			.duty-phase-slip { font-weight: 700; }
			.duty-phase-slip.late { color: #C2410C; }
			.duty-phase-slip.early { color: #0E8A63; }
			.duty-phase-slip.onplan { color: #0E8A63; }
			.duty-paused-strip { display: block; }
			.duty-paused-head { display: flex; align-items: center; gap: 8px; margin-bottom: 4px; font-size: 13px; }
			.duty-paused-row { display: flex; align-items: center; gap: 10px; padding: 5px 0 5px 26px; border-top: 1px dashed #F0DFB6; }
			.duty-paused-row:first-of-type { border-top: 0; }
			.duty-paused-age { font-size: 11px; color: var(--text-muted, #999); margin-left: 6px; }
			.duty-pause-note { background: #FFF7E6; border: 1px solid #F5D08A; border-radius: 8px; padding: 8px 12px; margin-bottom: 10px; font-size: 12.5px; }
			@media (max-width: 1440px) {
				/* 15" laptops: rail + thread + tasks in one view, sidebar expanded or not. */
				.duty-ch-rail { width: 320px; min-width: 320px; }
				.duty-chatface .duty-cr-side { width: 320px; }
			}
			@media (max-width: 991px) {
				.duty-chatface { height: calc(100dvh - 120px); border: 0; border-radius: 0; }
				.duty-ch-rail { width: 100%; min-width: 0; border-right: 0; }
				.duty-ch-center { display: none; }
				.duty-chatface.ch-convo-open .duty-ch-rail { display: none; }
				.duty-chatface.ch-convo-open .duty-ch-center { display: flex; }
				.duty-ch-mhead { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-bottom: 1px solid var(--border-color, #e6e6e6); background: var(--fg-color, #fafafa); position: sticky; top: 0; z-index: 6; }
				.duty-ch-mhead b { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 15px; }
				.duty-ch-mback { font-weight: 700; color: #0F5C55; text-decoration: none; white-space: nowrap; cursor: pointer; }
				.duty-ch-mback:hover { text-decoration: none; color: #0F5C55; }
				.duty-ch-munit { background: var(--bg-light-gray, #eef2f1); color: #0f766e; border: 1px solid #d5e5e2; border-radius: 8px; padding: 0 6px; font-size: 10px; font-weight: 700; line-height: 16px; white-space: nowrap; }
				/* Team chat: full-height column. Kills the 260px side-panel cap
				   that survived from the board-face era (see 10802). */
				.duty-chatface .duty-ch-team,
				.duty-chatface .duty-ch-team .duty-chat,
				.duty-chatface .duty-ch-team .duty-chat-card { display: flex; flex-direction: column; flex: 1 1 auto; min-height: 0; }
				.duty-chatface .duty-ch-team .duty-chat-list { flex: 1 1 auto; min-height: 0; overflow-y: auto; max-height: none !important; }
				/* The card's own title duplicates the ‹ Chats header one line up;
				   🔍 search and enable-notifications keep the row, right-aligned. */
				.duty-chatface .duty-ch-team .duty-chat-head > span:first-child { display: none; }
				.duty-chatface .duty-ch-team .duty-chat-head { justify-content: flex-end; padding: 2px 4px; }
			}
			.duty-chat-rail {
				writing-mode: vertical-rl; cursor: pointer; user-select: none;
				border: 1px solid var(--border-color); border-radius: 10px;
				background: var(--card-bg); padding: 14px 8px; font-weight: 600;
				color: var(--text-muted); display: flex; align-items: center; gap: 8px;
			}
			.duty-chat-rail:hover { color: var(--text-color); border-color: var(--gray-400, #bdbdbd); }
			.duty-rail-badge {
				writing-mode: horizontal-tb; min-width: 20px; text-align: center;
				padding: 1px 6px; border-radius: 99px; background: var(--red-500, #ef4444);
				color: #fff; font-size: var(--text-xs); font-weight: 700;
			}
			.duty-chat-card {
				border: 1px solid var(--border-color);
				border-radius: var(--border-radius-lg, 10px); background: var(--card-bg);
				padding: 10px 16px; display: flex; flex-direction: column;
				height: calc(100vh - 140px); min-height: 320px;
			}
			.duty-chat-head {
				font-weight: 600; display: flex;
				justify-content: space-between; align-items: center; gap: 10px;
			}
			.duty-chat-collapse {
				cursor: pointer; font-size: 16px; font-weight: 700;
				color: var(--text-muted); padding: 0 4px; margin-left: 8px;
			}
			.duty-chat-collapse:hover { color: var(--text-color); }
			@media (max-width: 991px) {
				.duty-layout { flex-direction: column; }
				.duty-side { position: static; flex: 1 1 auto; max-width: 100%; width: 100%; }
				.duty-left { position: static; flex: 1 1 auto; max-width: 100%; width: 100%; order: 2; }
				.duty-issues-card { height: auto; }
				.duty-issues-list { max-height: calc(100vh - 250px); max-height: calc(100dvh - 250px); overflow-y: auto; }
				.duty-board[data-mtab="issues"] { padding-bottom: 0 !important; }
				.duty-issues-rail { writing-mode: horizontal-tb; justify-content: center; padding: 8px 14px; width: 100%; }
				.duty-chat-card { height: auto; }
				.duty-chat-list { max-height: 260px; }
				.duty-chat-rail { writing-mode: horizontal-tb; justify-content: center; padding: 8px 14px; width: 100%; }
			}
			@media (max-width: 767px) {
				body.duty-mobile .page-head { display: none; }
				body.duty-mobile.duty-immersive header.navbar { display: none; }
				body.duty-mobile.duty-immersive .main-section { padding-top: 0; }
				body.duty-mobile.duty-immersive .page-body { margin-top: 0; }
				body.duty-mobile { background: #F3F4F1; }
				body.duty-mobile .duty-board { padding-bottom: 88px; }
				body.duty-mobile .duty-projects, body.duty-mobile .duty-library,
				body.duty-mobile .duty-clients, body.duty-mobile .duty-sales,
				body.duty-mobile .duty-me, body.duty-mobile .duty-books { padding-bottom: 88px; }
				body.duty-mobile .duty-card, body.duty-mobile .duty-bk,
				body.duty-mobile .duty-chat-card { border-radius: 16px; border: none; box-shadow: 0 1px 2px rgba(16,24,40,.06), 0 1px 3px rgba(16,24,40,.05); }
				body.duty-mobile input.form-control, body.duty-mobile textarea.form-control,
				body.duty-mobile select.form-control { font-size: 16px; border-radius: 12px; }
				body.duty-mobile .btn { border-radius: 10px; }
				body.duty-mobile a[class*="-edit"], body.duty-mobile a[class*="-del"],
				body.duty-mobile a[class*="-fetch"], body.duty-mobile .duty-cr-caret { padding: 8px 6px; display: inline-block; }
				@media (hover: none) { .duty-cal-add { visibility: visible !important; } }
				.duty-sheet-wrap { position: fixed; inset: 0; z-index: 1055; }
				.duty-sheet-ovl { position: absolute; inset: 0; background: rgba(16,24,40,.4); opacity: 0; transition: opacity .18s; }
				.duty-sheet { position: absolute; left: 0; right: 0; bottom: 0; background: #fff; border-radius: 20px 20px 0 0; padding: 8px 16px calc(16px + env(safe-area-inset-bottom)); transform: translateY(100%); transition: transform .22s cubic-bezier(.32,.72,.32,1); box-shadow: 0 -8px 32px rgba(16,24,40,.16); }
				.duty-sheet-wrap.open .duty-sheet-ovl { opacity: 1; }
				.duty-sheet-wrap.open .duty-sheet { transform: none; }
				.duty-sheet-grip { width: 38px; height: 4px; border-radius: 99px; background: #E3E4E0; margin: 4px auto 10px; }
				.duty-sheet-title { font-size: 12px; font-weight: 800; letter-spacing: .07em; text-transform: uppercase; color: #6B7772; margin-bottom: 6px; }
				.duty-sheet-item { display: flex; align-items: center; gap: 14px; padding: 13px 6px; border-radius: 12px; font-size: 15px; color: #101828; text-decoration: none; cursor: pointer; }
				.duty-sheet-item:active { background: #F3F4F1; }
				.duty-sheet-item .i { font-size: 21px; width: 28px; text-align: center; }
				.duty-cr-mtabs { display: none; }
				body.duty-mobile .duty-cr-mtabs { display: flex; gap: 6px; margin: 2px 0 8px; background: #EFF0ED; border-radius: 12px; padding: 3px; }
				body.duty-mobile .duty-cr-mtabs a { flex: 1; text-align: center; padding: 8px 0; border-radius: 10px; font-size: 13.5px; font-weight: 600; color: #6B7772; text-decoration: none; cursor: pointer; }
				body.duty-mobile .duty-cr-mtabs a.on { background: #fff; color: #101828; box-shadow: 0 1px 2px rgba(16,24,40,.08); }
				body.duty-mobile .duty-cr-side { display: none; }
				body.duty-mobile .rt-tasks .duty-cr-side { display: block; width: 100%; border: none; padding: 0; }
				body.duty-mobile .rt-tasks .duty-cr-msgs, body.duty-mobile .rt-tasks .duty-cr-compose,
				body.duty-mobile .rt-tasks .duty-cr-typing, body.duty-mobile .rt-tasks .duty-cr-replychip,
				body.duty-mobile .rt-tasks .duty-cr-pending, body.duty-mobile .rt-tasks .duty-cr-emojis { display: none !important; }
				body.duty-mobile .duty-cr-head { overflow-x: auto; white-space: nowrap; -webkit-overflow-scrolling: touch; }
				body.duty-mobile .duty-cr-msgs { max-height: calc(100vh - 350px); }
				body.duty-mobile .duty-projects { display: block; }
				body.duty-mobile .duty-pj-side { width: 100%; border-right: none; max-height: none; padding: 0; }
				body.duty-mobile .duty-pj-main { display: none; padding-left: 0; }
				body.duty-mobile .duty-projects.pj-detail .duty-pj-side { display: none; }
				body.duty-mobile .duty-projects.pj-detail .duty-pj-main { display: block; }
				body.duty-mobile .duty-pj-item { padding: 12px 10px; }
				.duty-pj-back { display: none; }
				body.duty-mobile .duty-pj-back { display: inline-block; cursor: pointer; font-weight: 700; color: #0E5A4A; margin-right: 10px; text-decoration: none; font-size: 14px; }
				body.duty-mobile .duty-kanban { display: flex; flex-wrap: nowrap; overflow-x: auto; scroll-snap-type: x mandatory; gap: 12px; -webkit-overflow-scrolling: touch; padding-bottom: 8px; }
				body.duty-mobile .duty-kanban .duty-kb-col { flex: 0 0 86vw; scroll-snap-align: start; }
				body.duty-mobile .modal .modal-dialog { position: fixed; left: 0; right: 0; bottom: 0; top: auto; margin: 0; width: 100%; max-width: 100% !important; }
				body.duty-mobile .modal .modal-content { border-radius: 20px 20px 0 0; max-height: 92vh; overflow-y: auto; padding-bottom: env(safe-area-inset-bottom); }
				.duty-tabbar {
					position: fixed; left: 0; right: 0; bottom: 0; z-index: 100;
					display: flex; background: rgba(255,255,255,.88);
					backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
					border-top: 1px solid rgba(16,24,40,.07);
					padding: 8px 6px calc(8px + env(safe-area-inset-bottom));
				}
				.duty-tabbar a {
					flex: 1; text-align: center; font-size: 11px; color: var(--text-muted);
					text-decoration: none; display: flex; flex-direction: column;
					align-items: center; gap: 2px; position: relative;
				}
				.duty-tabbar a span { font-size: 20px; line-height: 1; filter: grayscale(1); opacity: 0.75; }
				.duty-tabbar a { padding: 4px 0 2px; border-radius: 12px; margin: 0 3px; }
				.duty-tabbar a.active { color: #0E5A4A; font-weight: 700; background: #E4EEEA; }
			.duty-tabbar-away { opacity: 0.92; box-shadow: 0 -2px 10px rgba(15, 92, 85, 0.25); }
			.duty-tabbar-away a.active { color: inherit; font-weight: 500; }
				.duty-tabbar a.active span { filter: none; opacity: 1; }
				.duty-tab-badge {
					position: absolute; top: -3px; right: 22%;
					background: var(--red-500, #ef4444); color: #fff; border-radius: 99px;
					min-width: 16px; padding: 0 4px; font-size: 10px; line-height: 16px; font-style: normal;
				}
				body.duty-mobile .duty-board[data-mtab="chat"] { padding: 0 !important; }
				body.duty-mobile .duty-board[data-mtab="chat"] > :not(:has(.duty-chat)):not(.duty-chat) { display: none !important; }
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-side > :not(.duty-chat) { display: none !important; }
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-side { padding: 0; width: 100%; }
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-urgent-banner,
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-metrics,
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-card:not(.duty-chat-card) { display: none !important; }
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-chat-card {
					display: flex; flex-direction: column;
					height: calc(100vh - 118px);
					height: calc(100dvh - 118px);
					margin: 0; background: #fff;
					border-radius: 0 !important; box-shadow: none !important; border: none !important;
				}
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-chat-head { padding: 7px 12px 5px; border-bottom: 1px solid #EEEFEC; font-size: 13.5px; }
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-chat-collapse { display: none; }
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-chat-list { flex: 1 1 auto; min-height: 0; overflow-y: auto; max-height: none !important; padding: 10px 12px; }
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-chat-send { padding: 6px 10px calc(6px + env(safe-area-inset-bottom)); border-top: 1px solid #EEEFEC; background: #fff; }
				body.duty-mobile .duty-chat-input { height: 42px; min-height: 42px; max-height: 120px; padding: 10px 14px; border-radius: 21px; resize: none; }
				body.duty-mobile .duty-chat-toolbar { margin-top: 4px !important; }
				body.duty-mobile .duty-chat-toolbar .btn, body.duty-mobile .duty-chat-toolbar a { font-size: 17px; padding: 3px 7px; }
				body.duty-mobile .duty-msg { margin: 3px 0; }
				body.duty-mobile .duty-msg-mine { padding: 5px 9px; }
				body.duty-mobile .duty-msg-time { font-size: 10px; }
				body.duty-mobile .duty-cr-msg { margin: 4px 0; padding: 7px 10px; }
				body.duty-mobile .duty-cr-compose textarea, body.duty-mobile .duty-cr-compose input[type="text"] { height: 42px; min-height: 42px; border-radius: 21px; padding: 10px 14px; }
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-msg { max-width: 82%; }
				body.duty-mobile .duty-board[data-mtab="chat"] .duty-msg-mine { margin-left: auto; }
				body.duty-mobile .duty-tabbar { z-index: 60; }
				.duty-board[data-mtab] .duty-left, .duty-board[data-mtab] .duty-side,
				.duty-board[data-mtab] .duty-plan, .duty-board[data-mtab] .duty-my-sessions,
				.duty-board[data-mtab] .duty-me, .duty-board[data-mtab] .duty-task,
				.duty-board[data-mtab] .duty-team-title, .duty-board[data-mtab] .duty-team,
				.duty-board[data-mtab] .duty-updated { display: none; }
				.duty-board[data-mtab="board"] .duty-me,
				.duty-board[data-mtab="board"] .duty-task,
				.duty-board[data-mtab="board"] .duty-team-title,
				.duty-board[data-mtab="board"] .duty-updated { display: block; }
				.duty-board[data-mtab="board"] .duty-team { display: grid; }
				.duty-board[data-mtab="plan"] .duty-plan,
				.duty-board[data-mtab="plan"] .duty-my-sessions { display: block; }
				.duty-board.duty-layout[data-mtab] { display: block; }
				.duty-board[data-mtab="issues"] .duty-left { display: block; }
				.duty-board[data-mtab="chat"] .duty-side { display: block; }
				.duty-board[data-mtab="issues"] .duty-left,
				.duty-board[data-mtab="chat"] .duty-side {
					position: static; width: 100%; max-width: 100%; flex: none;
				}
				.duty-board[data-mtab="issues"] .duty-issues-toolbar-row .duty-issue-scope,
				.duty-board[data-mtab="issues"] .duty-issue-filter,
				.duty-board[data-mtab="issues"] .duty-issue-user { width: 100%; }
				.duty-board[data-mtab="issues"] .duty-issues-rail { display: none !important; }
				.duty-board[data-mtab="chat"] .duty-chat-rail { display: none !important; }
				.duty-board[data-mtab="chat"] .duty-chat-card { height: calc(100vh - 175px); min-height: 0; }
				.duty-board[data-mtab="issues"] .duty-issues-card { height: calc(100vh - 175px); min-height: 0; }
				.duty-chat-collapse, .duty-issues-collapse { display: none; }
				.duty-chat-input, .duty-todo-input, .duty-search-input { font-size: 16px; }
				.duty-tabbar a, .duty-todo-row, .duty-issue-row, .duty-msg { -webkit-tap-highlight-color: rgba(15,92,85,0.1); }
				body.duty-mobile .duty-issue-title { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
			}
			.duty-chat-badge {
				display: inline-block; min-width: 20px; text-align: center; padding: 1px 7px;
				border-radius: 99px; background: var(--red-500, #ef4444); color: #fff;
				font-size: var(--text-xs); font-weight: 700; margin-left: 6px;
			}
			.duty-chat-tools a { font-size: var(--text-xs); color: var(--text-muted); cursor: pointer; font-weight: 400; }
			/* WhatsApp-shaped: a flex column so a message can align itself to a
			   side. The classes were always emitted — duty-msg-mine has existed
			   in both the Duty Room and DM renderers — but the list was a plain
			   block, so mine only ever picked up a background and every message
			   still ran full width. The client room got this right; these two
			   never did. */
			.duty-chat-list {
				flex: 1 1 auto; overflow-y: auto; margin: 10px 0;
				border-top: 1px solid var(--border-color); padding-top: 8px;
				display: flex; flex-direction: column; gap: 6px;
			}
			.duty-dm-list {
				display: flex; flex-direction: column; gap: 6px;
			}
			.duty-load-earlier { text-align: center; padding: 4px 0 8px; }
			.duty-load-earlier a { cursor: pointer; font-size: var(--text-xs); color: var(--text-muted); }
			.duty-load-earlier a:hover { color: var(--text-color); }
			.duty-chat-list > .duty-msg, .duty-dm-list > .duty-msg {
				position: relative; max-width: 78%; align-self: flex-start;
				background: var(--card-bg, #fff); border: 1px solid var(--border-color);
				border-radius: 12px 12px 12px 3px; padding: 6px 10px 5px;
				box-shadow: 0 1px 1px rgba(0,0,0,0.04);
			}
			.duty-chat-list > .duty-msg-mine, .duty-dm-list > .duty-msg-mine {
				align-self: flex-end; background: #d9fdd3; border-color: #c5f2bd;
				border-radius: 12px 12px 3px 12px;
			}
			[data-theme="dark"] .duty-chat-list > .duty-msg-mine,
			[data-theme="dark"] .duty-dm-list > .duty-msg-mine { background: #075e54; border-color: #0b7a6d; }
			/* sender name is redundant on your own bubble — the side says it */
			.duty-chat-list > .duty-msg-mine .duty-msg-who,
			.duty-dm-list > .duty-msg-mine .duty-msg-who { display: none; }
			.duty-msg { padding: 4px 2px; font-size: var(--text-sm); line-height: 1.5; }
			.duty-msg-who { font-weight: 700; color: var(--text-color); margin-right: 6px; display: block; font-size: var(--text-xs); margin-bottom: 1px; }
			.duty-msg-mine { background: #e7f4ec; border-radius: 10px; padding: 4px 8px; }
			/* time and ticks sit bottom-right inside the bubble, as in WhatsApp */
			.duty-chat-list > .duty-msg .duty-msg-time,
			.duty-dm-list > .duty-msg .duty-msg-time { float: right; margin: 3px 0 0 10px; font-size: 11px; opacity: .65; }
			.duty-chat-list > .duty-msg .duty-msg-quote,
			.duty-dm-list > .duty-msg .duty-msg-quote {
				border-left: 3px solid var(--green-600, #2e7d32); background: rgba(0,0,0,0.04);
				border-radius: 5px; padding: 3px 7px; margin-bottom: 4px;
				font-size: var(--text-xs); opacity: .85;
			}
			/* actions stay hidden until hover so the bubble is not a row of icons */
			.duty-chat-list > .duty-msg .duty-msg-edit,
			.duty-chat-list > .duty-msg .duty-msg-reply,
			.duty-chat-list > .duty-msg .duty-msg-react,
			.duty-chat-list > .duty-msg .duty-msg-issue,
			.duty-chat-list > .duty-msg .duty-msg-del { opacity: 0; transition: opacity .12s; margin-left: 5px; font-size: 12px; text-decoration: none; }
			.duty-chat-list > .duty-msg:hover .duty-msg-edit,
			.duty-chat-list > .duty-msg:hover .duty-msg-reply,
			.duty-chat-list > .duty-msg:hover .duty-msg-react,
			.duty-chat-list > .duty-msg:hover .duty-msg-issue,
			.duty-chat-list > .duty-msg:hover .duty-msg-del { opacity: .75; }
			@media (max-width: 767px) {
				.duty-chat-list > .duty-msg, .duty-dm-list > .duty-msg { max-width: 88%; }
				.duty-chat-list > .duty-msg .duty-msg-edit,
				.duty-chat-list > .duty-msg .duty-msg-reply,
				.duty-chat-list > .duty-msg .duty-msg-react,
				.duty-chat-list > .duty-msg .duty-msg-issue,
				.duty-chat-list > .duty-msg .duty-msg-del { opacity: .75; }
			}
			.duty-tc-emojibtn, .duty-tc-mic, .duty-cr-mic { cursor: pointer; font-size: 18px; align-self: center; padding: 0 4px; text-decoration: none; user-select: none; }
			@keyframes duty-pulse { 0% { opacity: 1; } 50% { opacity: .35; } 100% { opacity: 1; } }
			.duty-msg-mine .duty-msg-who { color: var(--green-600, #2e7d32); }
			.duty-msg-time { margin-left: 8px; font-size: var(--text-xs); color: var(--text-muted); }
			.duty-chat-send { display: flex; gap: 8px; align-items: flex-end; }
			.duty-chat-input { resize: none; overflow-y: auto; max-height: 120px; line-height: 1.45; }
			.duty-msg-text { white-space: pre-wrap; word-break: break-word; color: #000; font-size: 15px; }
			[data-theme="dark"] .duty-msg-text { color: var(--text-color); }
			.duty-chat-input-wrap { flex: 1; position: relative; }
			.duty-attach-btn { margin: 0; cursor: pointer; }
			.duty-mention-menu {
				position: absolute; bottom: 100%; left: 0; margin-bottom: 4px; z-index: 100;
				background: var(--card-bg, #fff); border: 1px solid var(--border-color);
				border-radius: 8px; box-shadow: var(--shadow-md, 0 4px 12px rgba(0,0,0,0.12));
				min-width: 220px; overflow: hidden;
			}
			.duty-mention-opt { padding: 7px 12px; cursor: pointer; font-size: var(--text-sm); }
			.duty-mention-opt.active, .duty-mention-opt:hover { background: var(--gray-100, #f5f5f5); }
			.duty-mention {
				color: var(--blue-600, #1565c0); font-weight: 700;
				background: var(--blue-100, #e3f2fd); border-radius: 4px; padding: 0 3px;
			}
			/* non-bubble children of the flex list — dividers, the load-earlier link
			   and any notice — must span the width rather than shrink to content */
			.duty-chat-list > .duty-load-earlier,
			.duty-chat-list > .duty-new-divider,
			.duty-chat-list > .duty-search-notice,
			.duty-chat-list > .text-muted,
			.duty-dm-list > .duty-load-earlier,
			.duty-dm-list > .text-muted,
			.duty-dm-list > .duty-plan-empty { align-self: stretch; width: 100%; }
			/* mention and unread tints must beat the bubble background */
			.duty-chat-list > .duty-msg-mentioned { background: var(--yellow-50, #fffbeb) !important; border-color: #fcd34d; }
			.duty-chat-list > .duty-msg-new { background: var(--blue-50, #eff6ff) !important; }
			.duty-chat-list > .duty-msg-mine.duty-msg-mentioned { background: #fef3c7 !important; }
			.duty-msg-mentioned { background: var(--yellow-50, #fffbeb); border-radius: 6px; }
			.duty-msg-new { background: var(--blue-50, #eff6ff); border-radius: 6px; }
			.duty-new-divider {
				display: flex; align-items: center; gap: 8px; margin: 8px 0;
				color: var(--red-500, #ef4444); font-size: var(--text-xs);
				font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;
			}
			.duty-new-divider::before, .duty-new-divider::after {
				content: ""; flex: 1; border-top: 1px solid var(--red-300, #fca5a5);
			}
			.duty-msg-quote {
				border-left: 3px solid var(--gray-400, #bdbdbd); color: var(--text-muted);
				font-size: var(--text-xs); padding: 2px 8px; margin: 2px 0 3px; font-style: italic;
			}
			.duty-search-bar { display: flex; gap: 6px; align-items: center; margin-top: 8px; }
			.duty-search-bar .duty-search-input { flex: 1; }
			.duty-search-close { cursor: pointer; font-size: 18px; font-weight: 700; color: var(--text-muted); padding: 0 6px; }
			.duty-search-notice {
				margin-top: 6px; padding: 4px 8px; border-radius: 6px;
				background: var(--gray-100, #f5f5f5); color: var(--text-muted); font-size: var(--text-xs);
			}
			.duty-msg-seen {
				margin-left: 8px; font-size: var(--text-xs);
				color: var(--blue-500, #3b82f6); font-weight: 600; cursor: default;
			}
			.duty-msg-react {
				cursor: pointer; margin-left: 6px; visibility: hidden; font-size: var(--text-sm);
				filter: grayscale(1); opacity: 0.7;
			}
			.duty-msg:hover .duty-msg-react { visibility: visible; }
			.duty-msg { position: relative; }
			.duty-react-picker {
				position: absolute; right: 8px; top: -34px; z-index: 100;
				background: var(--card-bg, #fff); border: 1px solid var(--border-color);
				border-radius: 99px; box-shadow: var(--shadow-md, 0 4px 12px rgba(0,0,0,0.12));
				padding: 4px 10px; display: flex; gap: 8px; font-size: 18px;
			}
			.duty-react-picker span { cursor: pointer; }
			.duty-react-picker span:hover { transform: scale(1.25); }
			.duty-msg-reactions { margin: 2px 0 2px 2px; display: flex; gap: 6px; flex-wrap: wrap; }
			.duty-react-chip {
				cursor: pointer; border: 1px solid var(--border-color); border-radius: 99px;
				padding: 0 8px; font-size: var(--text-xs); background: var(--gray-100, #f5f5f5);
			}
			.duty-react-chip.duty-react-mine {
				border-color: var(--blue-500, #3b82f6); background: var(--blue-100, #e3f2fd);
			}
			.duty-msg-reply {
				cursor: pointer; color: var(--text-muted); margin-left: 8px;
				visibility: hidden; font-size: var(--text-sm);
			}
			.duty-msg:hover .duty-msg-reply { visibility: visible; }
			.duty-msg-attach { margin: 4px 0 2px; }
			.duty-msg-attach img {
				max-width: 260px; max-height: 180px; border-radius: 8px;
				border: 1px solid var(--border-color); display: block;
			}
			.duty-msg-attach video {
				max-width: 320px; max-height: 220px; border-radius: 8px;
				border: 1px solid var(--border-color); display: block; background: #000;
			}
			.duty-reply-bar, .duty-attach-bar {
				font-size: var(--text-xs); color: var(--text-muted);
				padding: 4px 8px; margin-bottom: 6px; border-radius: 6px;
				background: var(--gray-100, #f5f5f5);
			}
			.duty-reply-bar a, .duty-attach-bar a { cursor: pointer; margin-left: 8px; font-weight: 700; }
			.duty-sessions-details summary { cursor: pointer; color: var(--text-muted); }
			.duty-session-row { padding: 6px 4px; border-bottom: 1px solid var(--border-color); }
			.duty-session-live .duty-session-activity { font-weight: 600; }
			.duty-session-notes {
				cursor: pointer; margin-left: 8px; color: var(--text-muted);
				font-size: var(--text-xs); text-decoration: none;
			}
			.duty-session-notes:hover { color: var(--text-color); }
			.duty-left { flex: 0 0 25%; max-width: 25%; position: sticky; top: 56px; }
			.duty-issues-collapsed .duty-left { flex: 0 0 auto; max-width: none; }
			.duty-issues-rail {
				writing-mode: vertical-rl; cursor: pointer; user-select: none;
				border: 1px solid var(--border-color); border-radius: 10px;
				background: var(--card-bg); padding: 14px 8px; font-weight: 600;
				color: var(--text-muted); display: flex; align-items: center; gap: 8px;
			}
			.duty-issues-rail:hover { color: var(--text-color); border-color: var(--gray-400, #bdbdbd); }
			.duty-issues-card {
				border: 1px solid var(--border-color);
				border-radius: var(--border-radius-lg, 10px); background: var(--card-bg);
				padding: 10px 16px; display: flex; flex-direction: column;
				height: calc(100vh - 140px); min-height: 320px;
			}
			.duty-iss-filters { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; }
			.duty-iss-filters select { flex: 1 1 45%; min-width: 130px; width: auto !important; }
			.duty-issues-toolbar { display: flex; flex-direction: column; gap: 6px; margin-top: 8px; }
			.duty-issue-scope { min-width: 108px; }
			.duty-issues-toolbar-row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
			.duty-issues-toolbar-row .duty-issue-scope { flex: 1; }
			.duty-ist-resolved { background: var(--green-100, #e8f5e9); color: var(--green-700, #2e7d32); }
			.duty-ist-closed { background: var(--gray-200, #eeeeee); color: var(--gray-700, #616161); }
			.duty-issues-list {
				flex: 1 1 auto; overflow-y: auto; margin-top: 8px;
				border-top: 1px solid var(--border-color); padding-top: 4px;
			}
			.duty-issues-collapse {
				cursor: pointer; font-size: 16px; font-weight: 700;
				color: var(--text-muted); padding: 0 4px;
			}
			.duty-issues-collapse:hover { color: var(--text-color); }
			.duty-issue-raised {
				font-size: var(--text-xs); color: var(--text-muted);
				font-variant-numeric: tabular-nums; margin-left: auto;
			}
			.duty-issue-row {
				display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
				padding: 10px 10px; cursor: pointer;
				background: #fff; border: 1px solid #dfe3e8; border-radius: 10px;
				margin-bottom: 10px; box-shadow: 0 1px 2px rgba(16, 24, 40, 0.05);
			}
			.duty-issue-row:hover { background: var(--gray-50, #fafafa); border-color: #c7ced6; }
			.duty-issue-mine { border-left: 3px solid var(--blue-400, #60a5fa); padding-left: 8px; }
			.duty-issue-title { font-weight: 600; flex: 1; min-width: 140px; }
			.duty-issue-who, .duty-issue-meta { font-size: var(--text-xs); color: var(--text-muted); }
			.duty-issue-status {
				font-size: var(--text-xs); font-weight: 700; padding: 1px 8px; border-radius: 99px;
				background: var(--blue-100, #e3f2fd); color: var(--blue-700, #1565c0);
			}
			.duty-issue-due { font-size: var(--text-xs); color: var(--text-muted); font-variant-numeric: tabular-nums; }
			.duty-health { font-size: 11px; }
			.duty-health-green { color: #16a34a; }
			.duty-health-amber { color: #d97706; }
			.duty-health-red { color: #dc2626; }
			.duty-oncall-chip { font-size: var(--text-xs); font-weight: 700; cursor: pointer; background: #ede9fe; color: #5b21b6; border-radius: 99px; padding: 2px 10px; white-space: nowrap; }
			.duty-kb-art { padding: 9px 4px; border-bottom: 1px dashed var(--border-color); }
			.duty-kb-sol { font-size: var(--text-sm); background: #f0fdfa; border-radius: 8px; padding: 7px 10px; margin-top: 5px; white-space: pre-wrap; }
			.duty-load-row { display: flex; gap: 12px; align-items: baseline; padding: 8px 4px; border-bottom: 1px dashed var(--border-color); flex-wrap: wrap; }
			.duty-load-n { font-weight: 700; font-size: var(--text-sm); }
			.duty-load-n.hot { color: #dc2626; }
			.duty-load-skills { display: flex; gap: 6px; flex-wrap: wrap; align-items: baseline; }
			.duty-skill-x { cursor: pointer; margin-left: 3px; }
			.duty-skill-add { cursor: pointer; font-size: var(--text-xs); font-weight: 700; }
			.duty-upd-row { padding: 7px 4px; border-bottom: 1px dashed var(--border-color); font-size: var(--text-sm); white-space: pre-wrap; }
			.duty-upd-meta { display: block; font-size: var(--text-xs); color: var(--text-muted); font-weight: 700; }
			.duty-upd-compose { display: flex; gap: 8px; margin-top: 8px; }
			.duty-upd-compose input { flex: 1; }
			.duty-sim-row { padding: 6px 4px; border-bottom: 1px dashed var(--border-color); font-size: var(--text-sm); display: flex; gap: 8px; flex-wrap: wrap; align-items: baseline; }
			.duty-sim-row .text-muted { font-size: var(--text-xs); width: 100%; }
			.duty-type-chip { font-size: var(--text-xs); background: #ede9fe; color: #5b21b6; border-radius: 99px; padding: 1px 8px; font-weight: 700; white-space: nowrap; }
			.duty-stars { color: #f59e0b; letter-spacing: 1px; }
			.duty-confirmed { color: #166534; font-weight: 700; font-size: var(--text-xs); }
			.duty-sla { font-size: var(--text-xs); background: #fef3c7; color: #92400e; border-radius: 99px; padding: 1px 8px; font-weight: 700; white-space: nowrap; }
			.duty-sla-over { background: #fee2e2; color: #b91c1c; }
			.duty-sla-met { background: #dcfce7; color: #166534; }
			.duty-issue-overdue { color: var(--red-600, #dc2626); font-weight: 700; }
			.duty-sev {
				font-size: var(--text-xs); font-weight: 700; padding: 1px 8px; border-radius: 99px;
				text-transform: uppercase; letter-spacing: 0.03em;
			}
			.duty-sev-low { background: var(--gray-100, #f5f5f5); color: var(--gray-700, #616161); }
			.duty-sev-medium { background: var(--blue-100, #e3f2fd); color: var(--blue-700, #1565c0); }
			.duty-sev-high { background: var(--orange-100, #fff3e0); color: var(--orange-700, #e65100); }
			.duty-sev-critical { background: var(--red-100, #fee2e2); color: var(--red-700, #b91c1c); }
			.duty-msg-issue {
				cursor: pointer; margin-left: 6px; visibility: hidden;
				font-size: var(--text-sm); opacity: 0.7;
			}
			.duty-msg:hover .duty-msg-issue { visibility: visible; }
			.duty-msg-del {
				cursor: pointer; visibility: hidden; font-size: var(--text-xs);
				margin-left: 4px; opacity: 0.6; text-decoration: none;
			}
			.duty-msg-del:hover { opacity: 1; }
			.duty-msg:hover .duty-msg-del { visibility: visible; }
			.duty-issue-detail-head { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; font-size: var(--text-base); }
			.duty-issue-meta { margin-top: 4px; }
			.duty-issue-desc { margin: 10px 0; white-space: pre-wrap; }
			.duty-issue-resolution {
				margin: 10px 0; padding: 8px 12px; border-radius: 8px;
				background: var(--green-100, #e8f5e9); font-size: var(--text-sm); white-space: pre-wrap;
			}
			.duty-issue-actions { display: flex; gap: 8px; margin-top: 14px; flex-wrap: wrap; align-items: center; }
			.duty-task-issuechip {
				cursor: pointer; font-size: var(--text-xs); font-weight: 700;
				border: 1px solid var(--orange-300, #fdba74); color: var(--orange-700, #e65100);
				background: var(--orange-100, #fff3e0); border-radius: 99px; padding: 3px 10px;
				align-self: center;
			}
			.duty-issue-actions .duty-issue-attach { margin: 0; }
			.duty-issue-files { display: flex; flex-wrap: wrap; gap: 8px; margin: 10px 0; }
			.duty-issue-files img {
				max-width: 180px; max-height: 130px; border-radius: 8px;
				border: 1px solid var(--border-color); display: block;
			}
			.duty-issue-filelink {
				border: 1px solid var(--border-color); border-radius: 8px;
				padding: 6px 10px; font-size: var(--text-sm); align-self: center;
			}
			.duty-attach-area { margin-top: 4px; }
			.duty-attach-hint { font-size: var(--text-xs); margin-top: 4px; }
			.duty-pending-files { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px; }
			.duty-file-chip {
				border: 1px solid var(--border-color); border-radius: 99px;
				padding: 2px 10px; font-size: var(--text-xs); background: var(--gray-100, #f5f5f5);
			}
			.duty-file-chip a { cursor: pointer; font-weight: 700; margin-left: 4px; }
			.duty-history-link { margin-top: 8px; font-size: var(--text-xs); }
			.duty-history-link a { cursor: pointer; color: var(--text-muted); }
			.duty-history-link a:hover { color: var(--text-color); }
			.duty-history-list { max-height: 60vh; overflow-y: auto; }
			.duty-history-day {
				font-weight: 700; margin: 12px 0 4px; color: var(--text-muted);
				font-size: var(--text-xs); text-transform: uppercase; letter-spacing: 0.04em;
			}
			.duty-proj-chip {
				font-size: var(--text-xs); border-radius: 99px; padding: 1px 8px;
				background: #ecfdf5; color: #0f766e; font-weight: 600;
			}
			.duty-projects { padding-bottom: 76px; }
			.duty-proj-head { display: flex; gap: 12px; align-items: flex-start; flex-wrap: wrap; margin-bottom: 12px; }
			.duty-pf { max-width: 1100px; }
			.duty-pf-head { display: flex; align-items: baseline; gap: 12px; margin-bottom: 14px; font-size: 16px; }
			.duty-pf-table { width: 100%; border-collapse: collapse; font-size: 13px; }
			.duty-pf-table th { text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .03em; color: #8a958f; padding: 6px 10px; border-bottom: 2px solid #E4EAE8; }
			.duty-pf-table td { padding: 10px; border-bottom: 1px solid #EEF2F1; vertical-align: middle; }
			.duty-pf-row { cursor: pointer; }
			.duty-pf-row:hover { background: #F4F7F6; }
			.duty-pf-dot { display: inline-block; width: 9px; height: 9px; border-radius: 50%; margin-right: 7px; }
			.duty-pf-cust { font-size: 11px; color: #8a958f; margin-left: 16px; }
			.duty-pf-bar { display: inline-block; width: 90px; height: 7px; border-radius: 4px; background: #EEF2F1; overflow: hidden; vertical-align: middle; }
			.duty-pf-bar span { display: block; height: 100%; }
			.duty-pf-pct { font-size: 11px; color: #65736F; margin-left: 6px; }
			.duty-pf-slip.late { color: #C2410C; font-weight: 700; }
			.duty-pf-slip.ok { color: #0E8A63; }
			.duty-pf-badge { font-size: 11px; font-weight: 700; padding: 3px 9px; border-radius: 20px; }
			.duty-pf-badge.risk { background: #FEF0E6; color: #C2410C; }
			.duty-pf-badge.ok { background: #E7F5EF; color: #0E8A63; }
			.duty-tl-chip { display: inline-block; font-size: 11px; background: #F0F4F3; border-radius: 20px; padding: 2px 9px; margin: 1px 0; color: #4b5a55; }
			.duty-tl-projects { max-width: 320px; }
			.duty-risk-mit { font-size: 11.5px; color: #65736F; margin-top: 2px; }
			.duty-risk-closed { opacity: .55; }
			.duty-risk-acts a { cursor: pointer; opacity: .65; margin-right: 4px; text-decoration: none; }
			.duty-risk-acts a:hover { opacity: 1; }
			.duty-pf-risks { font-size: 11px; color: #B45309; font-weight: 700; margin-top: 3px; }
			.duty-lv-card h4 { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
			.duty-lv-bal { font-size: 12.5px; font-weight: 600; color: #0E8A63; }
			.duty-lv-row { display: flex; gap: 10px; align-items: baseline; flex-wrap: wrap; padding: 6px 0; border-bottom: 1px dashed var(--border-color, #eee); font-size: 13px; }
			.duty-lv-row:last-child { border-bottom: none; }
			.duty-lv-st { font-weight: 700; font-size: 12px; }
			.duty-lv-approved { color: #0E8A63; }
			.duty-lv-pending { color: #B45309; }
			.duty-lv-declined, .duty-lv-cancelled { color: #9aa4a0; }
			.duty-lv-cancel { cursor: pointer; opacity: .6; margin-left: auto; }
			.duty-lv-cancel:hover { opacity: 1; }
			.duty-lv-ask { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-top: 10px; }
			.duty-lv-ask input[type="date"] { max-width: 150px; }
			.duty-lv-ask .duty-lv-note { max-width: 220px; }
			.duty-earn-m { border: 1px solid #D8E2DF; border-radius: 12px; margin-bottom: 14px; overflow: hidden; background: #fff; }
			.duty-earn-m summary { cursor: pointer; display: flex; gap: 10px; align-items: baseline; list-style: none; background: #EAF3F0; padding: 10px 14px; font-size: 15px; border-bottom: 1px solid #D8E2DF; }
			.duty-earn-m summary::-webkit-details-marker { display: none; }
			.duty-earn-grand { margin-left: auto; font-weight: 800; font-size: 16px; color: #0B6B4F; }
			.duty-earn-rows { padding: 8px 14px 4px; }
			.duty-earn-r { display: grid; grid-template-columns: 160px minmax(0,1fr) auto; gap: 12px; align-items: baseline; padding: 5px 0; font-size: 13px; }
			.duty-earn-lbl { font-weight: 700; }
			.duty-earn-r > b { text-align: right; }
			.duty-earn-total { border-top: 2px solid #123C35; margin-top: 4px; padding-top: 8px; font-size: 14px; }
			.duty-earn-total > b { color: #0B6B4F; font-size: 15px; }
			.duty-earn-cap { color: #B45309; font-weight: 700; font-size: 12px; font-style: normal; }
			.duty-earn-items { margin: 2px 14px 10px; padding-left: 8px; border-left: 3px solid #EAF3F0; display: flex; flex-direction: column; gap: 3px; }
			.duty-earn-it { display: grid; grid-template-columns: minmax(0,1fr) auto auto; gap: 10px; align-items: baseline; font-size: 12.5px; }
			.duty-earn-t { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
			.duty-earn-meta { color: #7A8783; font-size: 11.5px; white-space: nowrap; }
			.duty-earn-it > b { text-align: right; }
			@media (max-width: 640px) { .duty-earn-r { grid-template-columns: 1fr auto; } .duty-earn-r .duty-earn-calc { grid-column: 1 / -1; } }
			.duty-pay-tog { margin-left: 12px; font-size: 12px; font-weight: 400; }
			.duty-pay-tog a { cursor: pointer; padding: 3px 10px; border: 1px solid #D8E2DF; border-radius: 20px; margin-right: 4px; color: #4b5a55; text-decoration: none; }
			.duty-pay-tog a.on { background: #123C35; color: #fff; border-color: #123C35; font-weight: 700; }
			.duty-pay-tot td { border-top: 2px solid #123C35 !important; background: #F4F8F6; }
			.duty-earn-lock { font-size: 11px; font-weight: 700; color: #7A8783; background: #F0F4F3; border-radius: 20px; padding: 2px 8px; }
			.duty-pay-close { margin: 6px 0 2px; }
			.duty-lv-clash { width: 100%; font-size: 12px; color: #B45309; font-weight: 700; }
			.duty-lv-clash i { font-weight: 400; }
			.duty-msg-seen.tick-dlv { color: #9aa4a0; }
			.duty-msg-seen.tick-read { color: #3B82F6; font-weight: 700; }
			.duty-px-row { display: flex; gap: 8px; align-items: baseline; padding: 5px 2px; border-bottom: 1px dashed #eee; cursor: pointer; font-weight: 400; width: 100%; }
			.duty-px-t { font-size: 13px; }
			.duty-px-s { font-size: 11.5px; color: #8a958f; margin-left: auto; }
			.duty-px-date-row { display: flex; gap: 10px; align-items: center; margin-bottom: 10px; }
			.duty-px-date-row input { max-width: 170px; }
			.duty-rm-rep { font-size: 11px; font-weight: 700; color: #0F5C55; background: #E7F5EF; border-radius: 20px; padding: 2px 8px; }
			.duty-lv-ask .duty-rm-text { max-width: 240px; }
			.duty-lv-ask .duty-rm-date, .duty-lv-ask .duty-rm-time { max-width: 140px; }
			.duty-lv-ask .duty-rm-rep-sel { max-width: 110px; }
			.duty-ex-top { display: flex; align-items: baseline; margin-bottom: 4px; }
			.duty-ex-clock { margin-left: auto; font-weight: 800; font-size: 18px; color: #0F5C55; }
			.duty-ex-bar { height: 6px; border-radius: 4px; background: #EEF2F1; overflow: hidden; margin-bottom: 12px; }
			.duty-ex-bar span { display: block; height: 100%; background: #0E8A63; transition: width .25s linear; }
			.duty-ex-bar span.low { background: #C2410C; }
			.duty-ex-q { font-weight: 700; font-size: 15px; margin-bottom: 10px; }
			.duty-ex-opt { display: flex; gap: 10px; align-items: baseline; padding: 8px 10px; border: 1px solid #E4EAE8; border-radius: 10px; margin-bottom: 6px; cursor: pointer; font-weight: 400; }
			.duty-ex-opt:hover { background: #F4F7F6; }
			.duty-fx-flag td { background: #FEF6F0; }
			.duty-ld-files { margin-top: 6px; }
			.duty-ld-files-h { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .03em; color: #8a958f; display: block; margin-bottom: 4px; }
			.duty-tf-list { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 6px; }
			.duty-tf-chip { display: inline-flex; gap: 6px; align-items: center; font-size: 12px; background: #F0F4F3; border: 1px solid #E4EAE8; border-radius: 20px; padding: 3px 10px; cursor: pointer; max-width: 240px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
			.duty-tf-chip:hover { background: #E7F0ED; }
			.duty-tf-del { opacity: .55; margin-left: 2px; text-decoration: none; }
			.duty-tf-del:hover { opacity: 1; }
			.duty-kb-files { font-size: 10.5px; color: #65736F; font-weight: 700; }
			/* --- contracted layouts: keep content together on wide screens --- */
			@media (min-width: 992px) {
				body:not(.duty-mobile) .duty-board { max-width: 1120px; margin-left: auto; margin-right: auto; }
				body:not(.duty-mobile) .duty-issues { max-width: 1160px; margin-left: auto; margin-right: auto; }
				body:not(.duty-mobile) .duty-sales { max-width: 1560px; margin-left: auto; margin-right: auto; }
				body:not(.duty-mobile) .duty-chat { max-width: 1000px; margin-right: auto; }
				body:not(.duty-mobile) .duty-projects { max-width: 1500px; margin-left: auto; margin-right: auto; }
				body:not(.duty-mobile) .duty-pj-main { max-width: 1220px; }
			}
			.duty-step-none { color: #B45309; font-weight: 700; font-size: 11px; }
			.duty-step { font-size: 11px; font-weight: 700; color: #0F5C55; }
			.duty-ld-step, .duty-ld-meets { margin-bottom: 12px; font-size: 13px; }
			.duty-ld-step-cur { display: flex; gap: 8px; align-items: baseline; flex-wrap: wrap; }
			.duty-ld-step-cur.over b { color: #C2410C; }
			.duty-ld-meet { padding: 3px 0; }
			.duty-meet-log { color: #B45309; font-weight: 700; cursor: pointer; }
			.duty-ld-meets .duty-meet-new { margin-top: 6px; }
			.duty-slot-grid { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
			.duty-slot-grid button { min-width: 64px; }
			.duty-tr-group { display: flex; align-items: baseline; gap: 10px; margin: 14px 0 4px; padding-bottom: 4px; border-bottom: 2px solid #E4EAE8; }
			.duty-tr-group b { font-size: 13px; text-transform: uppercase; letter-spacing: .04em; color: #0F5C55; }
			.duty-tr-group span { font-size: 11.5px; font-weight: 700; color: #8a958f; }
			.duty-tr-group span.duty-tr-done { color: #0E8A63; }
			.duty-tr-row { padding-left: 10px; }
			.duty-projects { display: flex; gap: 0; align-items: stretch; min-height: calc(100vh - 120px); }
			.duty-pj-side { width: 250px; flex: none; border-right: 1px solid #e5e7eb; padding: 8px 8px 8px 0; overflow-y: auto; max-height: calc(100vh - 110px); }
			.duty-pj-sidehead { display: flex; gap: 6px; margin-bottom: 8px; }
			.duty-pj-main { flex: 1; min-width: 0; padding-left: 14px; }
			.duty-pj-title { font-size: 15px; padding: 2px 0 10px; }
			.duty-pj-cust { font-size: 11px; font-weight: 800; letter-spacing: .06em; text-transform: uppercase; color: #6B7772; padding: 7px 4px 4px; cursor: pointer; user-select: none; }
			.duty-pj-count { color: #b3b8b5; font-weight: 600; }
			.duty-pj-item { display: block; padding: 6px 8px; border-radius: 8px; margin: 2px 0; cursor: pointer; text-decoration: none; color: inherit; }
			.duty-pj-item:hover { background: #f5f4f0; text-decoration: none; color: inherit; }
			.duty-pj-item.active { background: #eef2f0; }
			.duty-pj-item .t { display: block; font-weight: 600; font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-pj-item .s { display: block; font-size: 11px; color: #8a938f; }
			.duty-pj-views { display: inline-flex; gap: 2px; margin-left: 14px; background: #f0efe9; border-radius: 8px; padding: 2px; }
			.duty-pj-v { font-size: 12px; padding: 3px 10px; border-radius: 6px; cursor: pointer; color: #6B7772; text-decoration: none; }
			.duty-pj-v.on { background: #fff; color: #182420; font-weight: 600; box-shadow: 0 1px 2px rgba(0,0,0,.08); }
			.duty-cal-head { display: flex; gap: 10px; align-items: center; margin: 8px 0; }
			.duty-cal-nav, .duty-cal-today { cursor: pointer; padding: 2px 8px; border-radius: 6px; background: #f0efe9; text-decoration: none; color: #182420; font-size: 12.5px; }
			.duty-cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); border: 1px solid #e5e7eb; border-radius: 10px; overflow: hidden; }
			.duty-cal-dow { font-size: 10.5px; font-weight: 800; letter-spacing: .05em; text-transform: uppercase; color: #1a1a1a; padding: 6px 8px; background: #faf9f6; border-bottom: 1px solid #e5e7eb; }
			.duty-cal-cell { min-height: 92px; border-right: 1px solid #f0eee8; border-bottom: 1px solid #f0eee8; padding: 4px 5px; }
			.duty-cal-cell .d { font-size: 11.5px; color: #000; font-weight: 700; display: flex; justify-content: space-between; align-items: center; }
			.duty-cal-add { visibility: hidden; cursor: pointer; color: #0E5A4A; font-weight: 700; text-decoration: none; padding: 0 3px; }
			.duty-cal-cell:hover .duty-cal-add { visibility: visible; }
			.duty-cal-cell:not(.duty-cal-pad) { cursor: pointer; }
			.duty-cal-cell.today { background: #f2f7f4; }
			.duty-cal-cell.today .d { color: #0E5A4A; font-weight: 800; }
			.duty-cal-cell.over { background: #e4eeea; }
			.duty-cal-pad { background: #fbfaf7; }
			.duty-cal-task { font-size: 11.5px; color: #000; font-weight: 500; background: #fff; border: 1px solid #eceae4; border-radius: 6px; padding: 2px 5px; margin-top: 3px; cursor: pointer; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-cal-task.done { text-decoration: line-through; color: #96A09B; }
			.duty-proj-tabs { display: block; }
			.duty-proj-tab {
				border: 1px solid var(--border-color); border-radius: 10px; padding: 8px 14px;
				background: var(--card-bg); cursor: pointer; text-decoration: none;
				display: flex; flex-direction: column; gap: 2px; min-width: 140px;
			}
			.duty-proj-tab.active { border-color: #0F5C55; box-shadow: 0 0 0 1px #0F5C55 inset; }
			.duty-proj-name { font-weight: 700; color: var(--text-color); }
			.duty-proj-stats { font-size: var(--text-xs); color: var(--text-muted); }
			.duty-proj-over { color: var(--red-600, #dc2626); font-weight: 700; }
			.duty-proj-bar {
				display: block; height: 5px; border-radius: 99px;
				background: var(--gray-200, #e5e7eb); overflow: hidden; margin-top: 4px;
			}
			.duty-proj-bar span { display: block; height: 100%; border-radius: 99px; }
			.duty-proj-target { font-size: var(--text-xs); color: var(--text-muted); font-weight: 600; }
			.duty-kb-working { font-weight: 600; }
			.duty-kb-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
			.duty-kb-bar a { cursor: pointer; font-size: var(--text-xs); color: var(--text-muted); }
			.duty-kanban { display: flex; gap: 12px; align-items: flex-start; overflow-x: auto; padding-bottom: 8px; }
			.duty-kb-col {
				flex: 1 1 0; min-width: 230px; background: var(--gray-50, #fafafa);
				border: 1px solid var(--border-color); border-radius: 10px; padding: 10px;
			}
			.duty-kb-col-head { font-weight: 700; margin-bottom: 8px; display: flex; justify-content: space-between; }
			.duty-kb-col[data-col="To Do"] { border-top: 3px solid #64748b; }
			.duty-kb-col[data-col="To Do"] .duty-kb-col-head { color: #475569; }
			.duty-kb-col[data-col="In Progress"] { border-top: 3px solid #d97706; }
			.duty-kb-col[data-col="In Progress"] .duty-kb-col-head { color: #b45309; }
			.duty-kb-col[data-col="Completed"] { border-top: 3px solid #16a34a; }
			.duty-kb-col[data-col="Completed"] .duty-kb-col-head { color: #15803d; }
			.duty-kb-col[data-col="Suspended"] { border-top: 3px solid #7c3aed; }
			.duty-kb-col[data-col="Suspended"] .duty-kb-col-head { color: #6d28d9; }
			.duty-clients { padding-bottom: 76px; display: flex; gap: 14px; align-items: flex-start; }
			.duty-cr-list {
				flex: 0 0 340px; display: flex; flex-direction: column; gap: 8px;
				background: var(--bg-light-gray, #f4f6f8); border: 1px solid var(--border-color);
				border-radius: 12px; padding: 12px; align-self: flex-start;
				max-height: calc(100vh - 185px); overflow-y: auto;
			}
			.duty-cr-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
			.duty-cr-item {
				border: 1px solid var(--border-color); border-radius: 10px; padding: 10px 12px;
				background: var(--card-bg); cursor: pointer; text-decoration: none;
				display: flex; flex-direction: column; gap: 2px;
			}
			.duty-cr-item.active { border-color: #0F5C55; box-shadow: 0 0 0 1px #0F5C55 inset; }
			.duty-cr-frozen { opacity: 0.6; }
			.duty-cr-status { font-size: var(--text-xs); font-weight: 700; color: #0369a1; }
			.duty-cr-last { font-size: var(--text-xs); color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-cr-members { font-size: var(--text-xs); color: var(--text-muted); }
			.duty-cr-room {
				flex: 1; border: 1px solid var(--border-color); border-radius: 12px;
				background: var(--card-bg); padding: 0 14px 14px; min-width: 0;
				display: flex; flex-direction: column; height: calc(100vh - 185px);
			}
			.duty-cr-ribbon {
				margin: 0 -14px 10px; padding: 7px 14px; border-radius: 12px 12px 0 0;
				background: #fef3c7; color: #92400e; font-size: var(--text-xs); font-weight: 700;
			}
			.duty-cr-head { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; margin-bottom: 8px; }
			.duty-cr-taskchips { font-size: var(--text-xs); color: var(--text-muted); font-weight: 600; }
			.duty-cr-tools { margin-left: auto; display: flex; gap: 12px; }
			.duty-cr-tools a { cursor: pointer; font-size: var(--text-xs); font-weight: 600; }
			.duty-cr-main { display: flex; gap: 0; flex: 1 1 auto; min-height: 0; }
			.duty-cr-chatcol { padding-right: 14px; }
			.duty-cr-chatcol { flex: 1 1 auto; min-width: 0; display: flex; flex-direction: column; min-height: 0; }
			.duty-cr-side {
				width: clamp(360px, 32%, 520px); flex: none;
				border-left: 3px solid var(--border-color);
				background: var(--bg-light-gray, #f8fafc);
				border-radius: 0 12px 12px 0;
				padding: 10px 12px; display: flex; flex-direction: column; min-height: 0;
			}
			.duty-cr-side .duty-cr-tasksbar { border-bottom: 2px solid var(--border-color); padding-bottom: 6px; margin-bottom: 8px; }
			.duty-cr-side.folded { width: 46px; padding-left: 6px; }
			.duty-cr-side.folded .duty-cr-sidebody { display: none; }
			.duty-cr-sidebody { overflow-y: auto; min-height: 0; flex: 1 1 auto; }
			.duty-cr-tasks { display: flex; flex-direction: column; gap: 4px; margin-bottom: 10px; border-bottom: 1px solid var(--border-color); padding-bottom: 8px; flex: none; }
			.duty-sessions-details { margin-top: 8px; width: 100%; }
			.duty-sessions-details > summary { cursor: pointer; font-weight: 600; }
			.duty-cr-back { display: none; }
			@media (max-width: 767px) {
				/* two screens: the list OR the room, never the stack */
				.duty-clients.cr-room-open .duty-cr-list { display: none; }
				.duty-clients:not(.cr-room-open) .duty-cr-room { display: none !important; }
				.duty-cr-back {
					display: inline-block; font-weight: 700; font-size: var(--text-md);
					color: var(--text-color); padding: 4px 10px 4px 0; white-space: nowrap;
				}
				/* conversation first; work folds beneath */
				.duty-cr-main { flex-direction: column; }
				.duty-cr-side {
					width: 100%; border-left: none; border-top: 3px solid var(--border-color);
					border-radius: 0; padding: 10px 4px 0; order: 1; margin-top: 10px;
				}
				.duty-cr-side.folded { width: 100%; }
				.duty-cr-sidebody { max-height: 38vh; }
				/* calm header: name + essentials, tools scroll, counts retire */
				.duty-cr-head {
					position: sticky; top: 0; z-index: 6; background: var(--bg-color, #fff);
					padding: 8px 0 6px; margin-bottom: 4px; flex-wrap: nowrap;
					overflow-x: auto; -webkit-overflow-scrolling: touch; scrollbar-width: none;
				}
				.duty-cr-head::-webkit-scrollbar { display: none; }
				.duty-cr-head > b { white-space: nowrap; }
				.duty-cr-taskchips, .duty-cr-lastseen { display: none; }
				.duty-cr-ribbon {
					font-size: 11px; white-space: nowrap; overflow: hidden;
					text-overflow: ellipsis; padding: 4px 10px;
				}
				/* room list rows: thumb-sized */
				.duty-cr-item { padding: 12px 12px; }
				/* composer: message field full-width on top, controls beneath */
				.duty-cr-compose { flex-wrap: wrap; gap: 8px 12px; }
				.duty-cr-compose textarea.duty-cr-input { flex: 1 1 100%; width: 100%; order: -1; }
				.duty-cr-compose button.duty-cr-send { margin-left: auto; }
			}
			.duty-cr-task {
				display: flex; gap: 10px; align-items: center; padding: 5px 8px;
				border-radius: 8px; cursor: pointer; text-decoration: none;
			}
			.duty-cr-task:hover { background: var(--gray-100, #f5f5f5); }
			.duty-crt-pill { font-size: 10px; font-weight: 700; border-radius: 99px; padding: 2px 9px; flex: none; }
			.duty-crt-queued { background: #f1f5f9; color: #475569; }
			.duty-crt-inprogress { background: #fef3c7; color: #b45309; }
			.duty-crt-done { background: #dcfce7; color: #15803d; }
			.duty-crt-suspended { background: #ede9fe; color: #6d28d9; }
			.duty-crt-title { flex: 1; color: var(--text-color); font-size: var(--text-sm); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-crt-who { font-size: var(--text-xs); color: var(--text-muted); flex: none; }
			.duty-cr-openissues { cursor: pointer; font-size: var(--text-xs); font-weight: 700; margin-top: 2px; }
			.duty-cr-tasksbar { display: flex; gap: 10px; align-items: center; margin-bottom: 6px; }
			.duty-cr-taskstoggle { cursor: pointer; text-decoration: none; color: var(--text-color); }
			.duty-cr-tfilter { width: auto; margin-left: auto; }
			.duty-crt-stamps { flex-basis: 100%; font-size: 10px; color: var(--text-muted); }
			.duty-cr-task { flex-wrap: wrap; }
			.duty-cr-att img { max-width: 220px; max-height: 160px; border-radius: 10px; display: block; margin-top: 6px; border: 1px solid var(--border-color); }
			.duty-cr-attach { cursor: pointer; align-self: center; margin: 0; font-size: 16px; }
			.duty-cr-pending { margin-bottom: 4px; }
			.duty-issue-vis { cursor: pointer; font-weight: 600; }
			.duty-cr-msgs { display: flex; flex-direction: column; gap: 8px; flex: 1 1 auto; min-height: 120px; overflow-y: auto; padding: 4px 0 8px; }
			.duty-cr-msg {
				border-radius: 10px; padding: 7px 11px; width: fit-content; min-width: 140px;
				max-width: 88%; position: relative; font-size: 15px;
				overflow-wrap: break-word; word-break: normal;
			}
			.duty-cr-msg .duty-msg-who { white-space: nowrap; }
			.duty-cr-reply {
				position: absolute; right: 6px; top: 4px; cursor: pointer; font-size: var(--text-xs);
				visibility: hidden; opacity: 0.6; text-decoration: none;
			}
			.duty-cr-msg:hover .duty-cr-reply { visibility: visible; }
			.duty-cr-quote {
				display: block; background: rgba(15, 92, 85, 0.08); border-left: 3px solid #0F5C55;
				border-radius: 6px; padding: 3px 8px; font-size: var(--text-xs); margin: 2px 0 4px;
				cursor: pointer; color: var(--text-color); text-decoration: none;
			}
			.duty-msg-flash { outline: 2px solid #0F5C55; border-radius: 10px; }
			.duty-msg-quote-link { cursor: pointer; }
			.duty-cr-emojis {
				flex-wrap: wrap; gap: 2px; border: 1px solid var(--border-color); border-radius: 10px;
				padding: 5px; margin-bottom: 5px; background: var(--card-bg);
			}
			.duty-cr-emojis a { font-size: 19px; padding: 2px 5px; cursor: pointer; border-radius: 6px; text-decoration: none; }
			.duty-cr-emojis a:hover { background: var(--gray-100, #f5f5f5); }
			.duty-cr-emojibtn { cursor: pointer; align-self: center; font-size: 18px; text-decoration: none; }
			.duty-cr-staff { background: #ecfdf5; align-self: flex-end; }
			.duty-cr-mine { background: #cdeedd; align-self: flex-end; border: 1px solid #b5e3cd; }
			.duty-cr-unread-sys { background: #eceae4 !important; color: #6B7772 !important; }
			@media (max-width: 767px) {
				.duty-library { padding: 10px 12px 90px; }
				.duty-lb-head { gap: 10px; }
				.duty-lb-search { flex-basis: 100%; }
				.duty-rd-toc { width: 100% !important; position: static !important; max-height: 200px !important; border-right: none !important; border-bottom: 1px solid #E8E5DD; padding-bottom: 8px; }
				.duty-pj-side { width: 190px; }
			}

			.duty-cr-client { background: var(--gray-100, #f3f4f6); align-self: flex-start; }
			.duty-cr-internal { background: #fef9c3; border: 1px dashed #d97706; align-self: flex-end; }
			.duty-cr-msg .duty-msg-who { display: block; font-size: var(--text-xs); font-weight: 700; }
			.duty-cr-mktask { position: absolute; right: -26px; top: 6px; cursor: pointer; text-decoration: none; opacity: 0.5; }
			.duty-cr-msg:hover .duty-cr-mktask { opacity: 1; }
			.duty-cr-compose { display: flex; gap: 8px; align-items: flex-end; }
			.duty-cr-compose textarea { flex: 1; resize: none; font-size: 16px; }
			.duty-me-overlay {
				position: fixed; inset: 0; z-index: 1200; background: var(--bg-color, #fff);
				overflow-y: auto; padding: 0 16px 60px;
			}
			.duty-me-ovbar {
				position: sticky; top: 0; background: inherit; z-index: 2;
				display: flex; justify-content: space-between; align-items: center;
				padding: 14px 4px 10px; font-size: var(--text-lg);
			}
			.duty-me-ovclose { cursor: pointer; font-size: 22px; color: var(--text-muted); padding: 4px 10px; }
			.duty-me-ovbody { max-width: 1100px; margin: 0 auto; }
			.duty-me { padding: 8px 4px 40px; max-width: 1100px; margin: 0 auto; }
			.duty-me-head h2 { margin: 4px 0 2px; }
			.duty-me .duty-mtiles { margin: 14px 0 18px; }
			.duty-me-charts { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; margin-bottom: 20px; }
			.duty-me-chart { background: #fff; border: 1px solid var(--border-color); border-radius: 12px; padding: 10px 12px 4px; }
			.duty-me-chart h4 { margin: 2px 0 0; font-size: var(--text-sm); color: var(--text-muted); }
			.duty-me-reqs { background: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 12px; margin-bottom: 20px; }
			.duty-me-reqs h4 { margin: 0 0 8px; }
			.duty-req-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; padding: 7px 4px; border-bottom: 1px dashed #fde68a; font-size: var(--text-sm); }
			.duty-req-btns { margin-left: auto; display: flex; gap: 6px; }
			.duty-me-cal { background: #fff; border: 1px solid var(--border-color); border-radius: 12px; padding: 12px; margin-bottom: 20px; }
			.duty-me-calhead { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
			.duty-me-calhead h4 { margin: 0; }
			.duty-cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; }
			.duty-cal-dow { text-align: center; font-size: var(--text-xs); color: var(--text-muted); font-weight: 700; padding: 2px 0; }
			.duty-cal-cell { min-height: 64px; border: 1px solid var(--border-color); border-radius: 8px; padding: 3px 4px; position: relative; }
			.duty-cal-cell.empty { border: none; }
			.duty-cal-cell.today { border-color: #0F5C55; box-shadow: inset 0 0 0 1px #0F5C55; }
			.duty-cal-cell .dnum { font-size: var(--text-xs); color: var(--text-muted); font-weight: 700; }
			.cbadge { display: inline-block; font-size: 10px; font-weight: 700; border-radius: 6px; padding: 0 5px; margin: 1px 2px 0 0; color: #fff; }
			.cbadge.cmeet, .cdot.cmeet { background: #7c3aed; }
			.cbadge.ctodo, .cdot.ctodo { background: #0F5C55; }
			.duty-day-todo input { margin-right: 6px; vertical-align: -1px; }
			.duty-todo-done { text-decoration: line-through; color: var(--text-muted); }
			.cbadge.cdue, .cdot.cdue { background: #dc2626; }
			.duty-cal-cell:not(.empty) { cursor: pointer; }
			.duty-cal-cell:not(.empty):hover { background: var(--gray-50, #fafafa); }
			.duty-day-row { padding: 8px 4px; border-bottom: 1px dashed var(--border-color); font-size: var(--text-sm); }
			.duty-day-task { cursor: pointer; }
			.duty-day-task:hover { background: var(--gray-50, #fafafa); }
			.duty-day-pending { color: #b45309; font-size: var(--text-xs); font-weight: 700; margin-left: 6px; }
			.duty-day-actions { display: flex; gap: 10px; margin-top: 12px; }
			.cbadge.cres, .cdot.cres { background: #16a34a; }
			.cbadge.chrs, .cdot.chrs { background: #2563eb; }
			.duty-cal-legend { display: flex; gap: 16px; margin-top: 8px; font-size: var(--text-xs); color: var(--text-muted); }
			.cdot { display: inline-block; width: 10px; height: 10px; border-radius: 3px; vertical-align: -1px; }
			.duty-me-open { background: #fff; border: 1px solid var(--border-color); border-radius: 12px; padding: 12px; }
			.duty-me-open h4 { margin: 0 0 8px; }
			.duty-me-row {
				display: grid; grid-template-columns: 74px minmax(0, 1fr) auto 96px;
				align-items: center; gap: 10px; padding: 9px 6px;
				border-bottom: 1px dashed var(--border-color); cursor: pointer;
			}
			.duty-me-row:hover { background: var(--gray-50, #fafafa); }
			.duty-me-title { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
			.duty-me-cust {
				font-size: var(--text-xs); background: #ede9fe; color: #5b21b6;
				border-radius: 99px; padding: 2px 10px; font-weight: 700; white-space: nowrap;
				max-width: 180px; overflow: hidden; text-overflow: ellipsis;
			}
			.duty-me-due { font-size: var(--text-xs); font-weight: 700; color: var(--text-muted); text-align: right; }
			.duty-me-due.duetoday { color: #b45309; }
			.duty-me-due.overdue { color: #dc2626; }
			.duty-me-clock { display: flex; align-items: center; gap: 8px; font-size: var(--text-sm); }
			.duty-me-dot.on { color: #16a34a; }
			.duty-me-dot.off { color: #9ca3af; }
			.duty-me-head { display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 10px; }
			.duty-day-move { margin-left: auto; cursor: pointer; color: var(--text-muted); padding: 0 4px; }
			.duty-day-move:hover { color: var(--text-color); }
			@media (max-width: 767px) {
				.duty-me-row { grid-template-columns: 64px minmax(0, 1fr) 84px; }
				.duty-me-cust { display: none; }
			}
			@media (max-width: 767px) { .duty-cal-cell { min-height: 46px; } }
			.duty-mtiles { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 10px; }
			.duty-mtile { background: #f0fdfa; border-radius: 12px; padding: 14px 10px; text-align: center; }
			.duty-mtile b { display: block; font-size: 22px; color: #0F5C55; }
			.duty-mtile span { font-size: 11px; color: var(--text-muted); }
						.duty-cr-int { font-size: var(--text-xs); font-weight: 700; align-self: center; white-space: nowrap; }
			.duty-cr-composing-internal textarea { background: #FDF6E3; border-color: #B27409; }
			.duty-cr-composing-internal { background: #FBF0DC; border-radius: 10px; }
			.duty-md { display: inline-flex; border: 1.5px solid #E2E8E5; border-radius: 99px; overflow: hidden; flex: none; align-self: center; }
			.duty-md a { padding: 4px 11px; font-size: 11.5px; font-weight: 700; cursor: pointer; color: #65736F; white-space: nowrap; }
			.duty-md a.on { background: #123C35; color: #fff; }
			.duty-md .duty-md-i.on { background: #B27409; }
			.duty-cr-intbanner { background: #B27409; color: #fff; font-size: 12px; font-weight: 700; padding: 5px 12px; border-radius: 8px 8px 0 0; }
			.duty-cr-send.duty-send-internal { background: #B27409 !important; border-color: #B27409 !important; }
			.duty-strip { position: fixed; bottom: 14px; left: 50%; transform: translateX(-50%); z-index: 300;
				display: flex; align-items: center; gap: 9px; background: #123C35; color: #fff;
				border-radius: 99px; padding: 8px 16px; font-size: 12.5px; box-shadow: 0 6px 22px rgba(12,34,30,.35); }
			.duty-strip .ds-dot { width: 9px; height: 9px; border-radius: 50%; background: #8A9994; flex: none; }
			.duty-strip .ds-dot.on { background: #2FD08C; box-shadow: 0 0 0 3px rgba(47,208,140,.25); }
			.duty-strip .ds-lab { color: rgba(255,255,255,.65); }
			.duty-strip .ds-task { max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-strip .ds-cust { color: #7FD6BC; font-weight: 600; }
			.duty-strip .ds-time { font-weight: 800; font-variant-numeric: tabular-nums; }
			.duty-strip .ds-idle { color: rgba(255,255,255,.6); }
			.duty-strip .ds-btn { background: rgba(255,255,255,.14); border-radius: 99px; padding: 4px 12px; font-weight: 700; cursor: pointer; color: #fff; transition: background .15s; }
			.duty-strip .ds-btn:hover { background: rgba(255,255,255,.26); color: #fff; }
			.duty-strip .ds-stop { background: rgba(201,70,70,.85); }
			.duty-strip .ds-stop:hover { background: #C94646; }
			.duty-ivrow { display: flex; gap: 5px; padding: 7px 8px 3px; flex-wrap: wrap; }
			.duty-iv { font-size: 11.5px; font-weight: 700; color: #65736F; background: #F0F4F2; border-radius: 99px; padding: 4px 11px; cursor: pointer; transition: all .14s; }
			.duty-iv b { font-weight: 800; }
			.duty-iv:hover { background: #E2E8E5; color: #17211F; }
			.duty-iv.on { background: #123C35; color: #fff; }
			.duty-rail { position: fixed; left: 0; top: var(--navbar-height, 60px); bottom: 0; width: 172px; z-index: 90;
				background: #123C35; display: flex; flex-direction: column; padding: 10px 8px; gap: 2px; overflow-y: auto; }
			.duty-rl { display: flex; align-items: center; gap: 10px; color: rgba(255,255,255,.72); font-size: 13px; font-weight: 600;
				border-radius: 9px; padding: 8px 10px; cursor: pointer; white-space: nowrap; transition: background .14s, color .14s; }
			.duty-rl:hover { color: #fff; background: rgba(255,255,255,.08); text-decoration: none; }
			.duty-rl.on { background: #fff; color: #123C35; font-weight: 700; }
			.duty-rl svg { flex: none; }
			.duty-rl-min { margin-top: auto; color: rgba(255,255,255,.45); }
			body.duty-rail-min .duty-rail { width: 52px; padding: 10px 6px; align-items: center; }
			body.duty-rail-min .duty-rl span { display: none; }
			body.duty-rail-min .duty-rl-min svg { transform: rotate(180deg); }
			body.duty-has-rail .layout-main-section-wrapper, body.duty-has-rail .page-head { margin-left: 172px; }
			body.duty-rail-min.duty-has-rail .layout-main-section-wrapper, body.duty-rail-min.duty-has-rail .page-head { margin-left: 52px; }
			body.duty-mobile .duty-rail { display: none !important; }
			body.duty-mobile.duty-has-rail .layout-main-section-wrapper, body.duty-mobile.duty-has-rail .page-head { margin-left: 0; }
			.duty-cr-search { padding: 6px 2px 8px; }
			.duty-cr-sech { font-size: 10.5px; font-weight: 800; letter-spacing: .07em; text-transform: uppercase; color: #8A9994; margin: 12px 2px 5px; }
			.duty-cr-secrow { display: flex; flex-direction: column; gap: 2px; padding: 7px 9px; border-radius: 10px; cursor: pointer; border: 1px solid transparent; }
			.duty-cr-secrow:hover { background: #F0F4F2; text-decoration: none; }
			.duty-cr-secmain { display: flex; align-items: center; gap: 7px; font-size: 13px; color: #17211F; }
			.duty-cr-secunit { font-size: 11px; color: #65736F; background: #F0F4F2; border-radius: 99px; padding: 1px 8px; }
			.duty-cr-secprev { font-size: 12px; color: #65736F; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100%; }
			.duty-cr-sectime { font-size: 10.5px; color: #8A9994; }
			.duty-kb-colslim { flex: 0 0 40px !important; min-width: 40px !important; cursor: pointer; display: flex; align-items: flex-start; justify-content: center;
				background: #F0F4F2; border-radius: 10px; padding-top: 12px; }
			.duty-kb-colslim span { writing-mode: vertical-rl; font-size: 11.5px; font-weight: 700; color: #8A9994; letter-spacing: .04em; }
			.duty-kb-colslim:hover { background: #E2E8E5; }
			.duty-kanban .duty-kb-col { max-width: 340px; }
			.duty-kb-compact .duty-kb-card { padding: 5px 8px !important; font-size: 12px !important; }
			.duty-kb-compact .duty-kb-col-head { font-size: 12px; }
			.duty-kb-dense { cursor: pointer; font-size: 11.5px; color: #65736F; margin-left: 8px; }
			.duty-kb-dense:hover { color: #17211F; }
			.duty-sg-slots { display: flex; gap: 6px; flex-wrap: wrap; margin: 4px 0; }
			.duty-sg-slot { border: 1.5px solid #E2E8E5; border-radius: 99px; padding: 5px 13px; font-size: 12.5px; font-weight: 700; cursor: pointer; color: #17211F; }
			.duty-sg-slot:hover { border-color: #087A67; text-decoration: none; }
			.duty-sg-slot.on { background: #123C35; border-color: #123C35; color: #fff; }
			.duty-cr-msuggest { cursor: pointer; margin: 0 4px; color: #087A67; font-weight: 700; }
			.duty-mtile-act { cursor: pointer; transition: transform .14s, box-shadow .14s; }
			.duty-mtile-act:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(12,34,30,.12); }
			.tm-tabs { display: flex; gap: 4px; margin-bottom: 10px; }
			.tm-tabs a { font-size: 12.5px; font-weight: 700; color: #65736F; background: #F0F4F2; border-radius: 99px; padding: 5px 14px; cursor: pointer; }
			.tm-tabs a.on { background: #123C35; color: #fff; }
			.tm-wrap { overflow-x: auto; max-height: 62vh; }
			.tm { border-collapse: collapse; font-size: 12px; }
			.tm th, .tm td { border: 1px solid #E2E8E5; padding: 5px 9px; text-align: center; white-space: nowrap; }
			.tm thead th { background: #F3F6F4; font-size: 11px; font-weight: 700; color: #51605C; max-width: 130px; overflow: hidden; text-overflow: ellipsis; position: sticky; top: 0; }
			.tm tbody th { text-align: left; font-weight: 700; background: #FAFBFA; position: sticky; left: 0; }
			.tm-c.tm-done { background: #DFF2EC; color: #0B6B4F; font-weight: 800; }
			.tm-c.tm-prog { background: #FAEEDC; color: #8F5C07; font-weight: 700; }
			.tm-c.tm-fail { background: #FAE4E1; color: #C94646; font-weight: 700; }
			.tm-c.tm-zero { color: #8A9994; }
			.tm-c.tm-none { color: #D4DCD8; }
			.tm-legend { font-size: 11.5px; color: #65736F; margin-top: 8px; }
			.tm-legend span { font-weight: 800; }
			.tm-legend .tm-done { color: #0B6B4F; } .tm-legend .tm-prog { color: #8F5C07; } .tm-legend .tm-fail { color: #C94646; }
			.duty-ldrawer { position: fixed; top: var(--navbar-height, 60px); right: 0; bottom: 0; width: 460px; max-width: 96vw; z-index: 150;
				background: #fff; border-left: 1px solid #E2E8E5; box-shadow: -8px 0 28px rgba(12,34,30,.14); display: flex; flex-direction: column; }
			.duty-ld-head { padding: 13px 16px 9px; border-bottom: 1px solid #EEF2F0; position: relative; }
			.duty-ld-x { position: absolute; top: 10px; right: 12px; cursor: pointer; color: #8A9994; font-size: 14px; padding: 4px 8px; }
			.duty-ld-co { font-size: 16.5px; display: block; padding-right: 30px; }
			.duty-ld-chips { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-top: 7px; font-size: 12px; }
			.duty-ld-stage { border: 1.5px solid #E2E8E5; border-radius: 99px; padding: 3px 10px; font-size: 12px; font-weight: 700; background: #F3F6F4; }
			.duty-ld-val { font-weight: 800; color: #0B6B4F; }
			.duty-ld-own { font-weight: 700; }
			.duty-ld-close-d { color: #65736F; }
			.duty-ld-tabs { display: flex; gap: 4px; padding: 8px 14px 0; border-bottom: 1px solid #EEF2F0; }
			.duty-ld-tabs a { font-size: 12.5px; font-weight: 700; color: #65736F; padding: 7px 12px; cursor: pointer; border-bottom: 2.5px solid transparent; }
			.duty-ld-tabs a.on { color: #123C35; border-bottom-color: #123C35; }
			.duty-ld-body { flex: 1; overflow-y: auto; padding: 12px 16px; }
			.duty-ld-form { display: grid; grid-template-columns: 1fr 1fr; gap: 9px 12px; margin-bottom: 12px; }
			.duty-ld-f { display: flex; flex-direction: column; gap: 3px; font-size: 12px; margin: 0; }
			.duty-ld-f span { font-weight: 700; color: #51605C; font-size: 11px; }
			.duty-ld-f input, .duty-ld-f select, .duty-ld-f textarea { border: 1px solid #E2E8E5; border-radius: 8px; padding: 6px 9px; font-size: 13px; font-family: inherit; }
			.duty-ld-wide { grid-column: 1 / -1; }
			.duty-ld-bar { display: flex; gap: 6px; padding: 10px 14px; border-top: 1px solid #EEF2F0; background: #FAFBFA; flex-wrap: wrap; }
			.duty-ldb { font-size: 12px; font-weight: 700; border: 1.5px solid #E2E8E5; border-radius: 99px; padding: 6px 12px; cursor: pointer; color: #17211F; background: #fff; }
			.duty-ldb:hover { border-color: #087A67; text-decoration: none; }
			.duty-ldb-won { background: #123C35; border-color: #123C35; color: #fff; }
			.duty-ldb-lost { color: #C94646; }
			body.duty-mobile .duty-ldrawer { top: 0; width: 100vw; max-width: 100vw; }
			#page-duty-board .container { max-width: none; }
			.duty-issues-face { padding: 14px 30px 90px; max-width: none; margin: 0; }
			.duty-issues-face .duty-issues-card { border: 1px solid #E2E8E5; border-radius: 14px; background: #fff; box-shadow: 0 1px 2px rgba(12,34,30,.05); padding: 4px 8px 10px; }
			.duty-issues-face .duty-issues-collapse { display: none !important; }
			.duty-issues-face .duty-ih, .duty-issues-face .duty-issue-row {
				display: grid; grid-template-columns: minmax(105px, 140px) 76px 86px minmax(200px, 1.8fr) minmax(100px, 135px) 100px minmax(118px, 150px) minmax(118px, 150px) 120px;
				gap: 9px; align-items: center; }
			.duty-crpill { display: inline-flex; align-items: center; gap: 4px; font-size: 10.5px; font-weight: 800; color: #51605C; background: #F0F4F2; border-radius: 99px; padding: 3px 9px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
			.duty-crpill-go { color: #0B6B4F; background: #E4F3EC; box-shadow: 0 0 0 1.5px #0E8A63 inset; }
			.duty-issue-type { font-size: 11.5px; font-weight: 600; color: #51605C; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-ih { padding: 6px 12px 2px; font-size: 10.5px; font-weight: 800; letter-spacing: .06em; text-transform: uppercase; color: #8A9994; }
			.duty-issues-face .duty-issue-row { padding: 8px 12px; }
			.duty-issues-face .duty-issue-title, .duty-issues-face .duty-issue-who, .duty-issues-face .duty-task-customer {
				overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; }
			.duty-issues-face .duty-issue-due { white-space: nowrap; display: flex; align-items: center; gap: 6px; }
			.duty-issues-face .duty-issue-raised { font-size: 11px; color: #8A9994; text-align: right; white-space: nowrap; }
			.duty-issues-face .duty-sev { text-align: center; }
			.duty-issue-status.duty-ist-open { background: #EDF2EF; color: #51605C; }
			.duty-ic-empty { color: #C4CFC9; font-style: normal; }
			body.duty-mobile .duty-issues-face .duty-issue-row { display: flex; flex-wrap: wrap; }
			body.duty-mobile .duty-ih { display: none; }
			.duty-idrawer { position: fixed; top: var(--navbar-height, 60px); right: 0; bottom: 0; width: 640px; max-width: 96vw; z-index: 140;
				background: #fff; border-left: 1px solid #E2E8E5; box-shadow: -8px 0 28px rgba(12,34,30,.14); display: flex; flex-direction: column; }
			.duty-id-head { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border-bottom: 1px solid #EEF2F0; }
			.duty-id-title { font-size: 14px; letter-spacing: .01em; }
			.duty-id-x { cursor: pointer; color: #8A9994; font-size: 15px; padding: 4px 8px; }
			.duty-id-body { flex: 1; overflow-y: auto; padding: 14px 18px 24px; }
			body.duty-idrawer-open .duty-issues-face { max-width: none; margin: 0 660px 0 26px; }
			body.duty-idrawer-open .duty-issues-face .duty-ih,
			body.duty-idrawer-open .duty-issues-face .duty-issue-row {
				grid-template-columns: minmax(100px, 130px) 74px minmax(160px, 1.8fr) 102px minmax(115px, 145px); }
			body.duty-idrawer-open .duty-issues-face .duty-issue-who,
			body.duty-idrawer-open .duty-issues-face .duty-issue-type,
			body.duty-idrawer-open .duty-issues-face .duty-issue-crcol,
			body.duty-idrawer-open .duty-issues-face .duty-issue-raised,
			body.duty-idrawer-open .duty-issues-face .duty-ih span:nth-child(3),
			body.duty-idrawer-open .duty-issues-face .duty-ih span:nth-child(5),
			body.duty-idrawer-open .duty-issues-face .duty-ih span:nth-child(7),
			body.duty-idrawer-open .duty-issues-face .duty-ih span:nth-child(9) { display: none; }
			body.duty-mobile .duty-idrawer { top: 0; width: 100vw; max-width: 100vw; }
			body.duty-mobile.duty-idrawer-open .duty-issues-face { margin: 0; }
			.duty-id-ctl { display: flex; gap: 14px; flex-wrap: wrap; align-items: center; margin: 9px 0; padding: 9px 12px; background: #F6F8F7; border-radius: 11px; }
			.duty-id-ctl label { display: flex; align-items: center; gap: 7px; margin: 0; font-size: 11.5px; font-weight: 700; color: #51605C; }
			.duty-idc-sev, .duty-idc-due { border: 1px solid #E2E8E5; border-radius: 8px; padding: 4px 8px; font-size: 12.5px; font-family: inherit; background: #fff; }
			.duty-idc-who { font-weight: 600; font-size: 12.5px; }
			.duty-idc-assign { font-size: 11.5px; font-weight: 700; color: #087A67; cursor: pointer; }
			.duty-id-tools { display: flex; gap: 7px; flex-wrap: wrap; margin: 10px 0 6px; }
			.duty-cons-hold { display: flex; align-items: center; justify-content: center; min-height: 70vh; padding: 20px; }
			.duty-cons-card { max-width: 480px; background: #fff; border: 1px solid #E2E8E5; border-radius: 18px; padding: 34px 36px; text-align: center; box-shadow: 0 8px 30px rgba(12,34,30,.10); }
			.duty-cons-badge { display: inline-block; font-size: 10px; font-weight: 800; letter-spacing: .14em; color: #fff; background: #123C35; border-radius: 99px; padding: 4px 12px; margin-bottom: 14px; }
			.duty-cons-card h2 { font-size: 22px; margin: 0 0 10px; }
			.duty-cons-card p { font-size: 14px; color: #51605C; line-height: 1.55; margin: 0 0 10px; }
			.duty-cons-sub { font-size: 12.5px !important; color: #8A9994 !important; }
			body.duty-consultant .duty-chat-rail { display: none !important; }
			body.duty-consultant .duty-ch-new { display: none !important; }
			body.duty-consultant .duty-cr-side .duty-cr-milestones, body.duty-consultant .duty-cr-side .duty-cr-chreqs,
			body.duty-consultant .duty-cr-side .duty-cr-meetings, body.duty-consultant .duty-cr-side .duty-cr-shelf { display: none !important; }
			body.duty-consultant .duty-cr-new { display: none !important; }
			body.duty-consultant .duty-md-i { display: none !important; }
			body.duty-consultant .duty-kb-open, body.duty-consultant .duty-team-load,
			body.duty-consultant .duty-oncall-chip, body.duty-consultant .duty-iv[data-iv="unassigned"] { display: none !important; }
			body.duty-consultant .duty-issue-rca, body.duty-consultant .duty-issue-kb,
			body.duty-consultant .duty-issue-vis,
			body.duty-consultant .duty-issue-ack { display: none !important; }
			.duty-cons-chip { font-size: 9px; font-weight: 800; letter-spacing: .1em; color: #fff; background: #123C35; border-radius: 99px; padding: 2px 8px; vertical-align: 1px; }
			.duty-proj-cons { font-size: var(--text-xs); font-weight: 700; color: #087A67; cursor: pointer; margin-right: 10px; }
			.duty-proj-staffb { font-size: var(--text-xs); font-weight: 700; color: #0F5C55; cursor: pointer; margin-right: 10px; }
			.duty-td-form .duty-ld-form { margin-bottom: 4px; }
			.duty-td-chk { display: flex; align-items: center; gap: 7px; font-size: 12.5px; margin: 0; grid-column: 1 / -1; font-weight: 600; color: #17211F; }
			.duty-td-bar { justify-content: flex-start; }
			.duty-td-del { color: #C94646; }
			body.duty-consultant .duty-td-del { display: none !important; }
			body.duty-consultant .duty-lib-add, body.duty-consultant .duty-lib-upload,
			body.duty-consultant .duty-bk-edit, body.duty-consultant .duty-bk-del,
			body.duty-consultant .duty-lib-convert { display: none !important; }
			body.duty-consultant .page-actions [data-label*="Document"],
			body.duty-consultant .page-actions .menu-btn-group { display: none !important; }
			body.duty-consultant .duty-cr-memadmin, body.duty-consultant .duty-cr-memrm,
			body.duty-consultant .duty-cr-approve, body.duty-consultant .duty-cr-rejectq,
			body.duty-consultant .duty-cr-addmem, body.duty-consultant .duty-cr-joinlink,
			body.duty-consultant .duty-cr-bookable, body.duty-consultant .duty-cr-membersbtn ~ .duty-attach-hint { display: none !important; }
			body.duty-consultant .modal .duty-lead-section, body.duty-consultant .modal .duty-attach-hint { display: none; }
			body.duty-consultant .modal .duty-cr-memlist { display: block !important; }
			.duty-idc-chip { display: inline-flex; align-items: center; gap: 3px; font-weight: 700; background: #F0F4F2; border-radius: 99px; padding: 2px 7px; margin-right: 4px; font-size: 11.5px; }
			.duty-idc-rm { color: #8A9994; cursor: pointer; font-size: 10px; padding: 0 2px; }
			.duty-idc-rm:hover { color: #C94646; }
			.duty-cons-stats { display: flex; gap: 10px; margin-bottom: 12px; flex-wrap: wrap; }
			.duty-cs-tile { background: #fff; border: 1px solid #E2E8E5; border-radius: 12px; padding: 10px 18px; display: flex; flex-direction: column; }
			.duty-cs-tile b { font-size: 20px; }
			.duty-cs-tile span { font-size: 11px; color: #65736F; font-weight: 700; }
			.duty-cs-warn { border-left: 3px solid #B27409; background: #FFFDF8; }
			.duty-crtag { cursor: help; }
			.duty-crtag-go { filter: drop-shadow(0 0 3px rgba(14,138,99,.8)); }
			.duty-id-crline { background: #F6F8F7; border-radius: 10px; padding: 8px 11px; display: flex; align-items: center; gap: 7px; flex-wrap: wrap; }
			.duty-id-crline.duty-cr-go { background: #EDF7F2; border-left: 3px solid #0E8A63; }
			.duty-cr-chiptxt { font-weight: 700; color: #51605C; font-size: 12px; }
			.duty-cr-go .duty-cr-chiptxt { color: #0B6B4F; }
			.duty-checklist { margin-top: 16px; border-radius: 14px; padding: 14px 16px; border: 2px solid #E2E8E5; background: #FAFCFB; }
			.duty-checklist.duty-cl-open { border-color: #B27409; background: #FFFBF2; box-shadow: 0 2px 14px rgba(178,116,9,.14); }
			.duty-checklist.duty-cl-complete { border-color: #0E8A63; background: #F1FAF6; box-shadow: 0 2px 14px rgba(14,138,99,.14); }
			.duty-cl-head { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
			.duty-cl-head b { font-size: 15px; color: #123C35; }
			.duty-cl-count { font-weight: 800; font-size: 14px; color: #B27409; background: #FFF; border-radius: 99px; padding: 2px 12px; border: 1.5px solid #B27409; }
			.duty-cl-complete .duty-cl-count { color: #0B6B4F; border-color: #0E8A63; }
			.duty-cl-optional { font-size: 11.5px; color: #8A9994; font-style: italic; }
			.duty-cl-bar { height: 7px; border-radius: 99px; background: #EDE4D3; overflow: hidden; margin-bottom: 10px; }
			.duty-cl-bar i { display: block; height: 100%; background: linear-gradient(90deg, #B27409, #0E8A63); border-radius: 99px; transition: width .25s; }
			.duty-cl-complete .duty-cl-bar { background: #D7EDE3; }
			.duty-cl-item { display: flex; align-items: center; gap: 9px; padding: 7px 9px; border-radius: 9px; margin: 0 0 3px; cursor: pointer; font-size: 13px; font-weight: 600; color: #17211F; }
			.duty-cl-item:hover { background: rgba(18, 60, 53, .05); }
			.duty-cl-item input { width: 17px; height: 17px; accent-color: #0E8A63; cursor: pointer; flex: 0 0 auto; }
			.duty-cl-item span { flex: 1; }
			.duty-cl-done span { text-decoration: line-through; color: #8A9994; font-weight: 500; }
			.duty-cl-by { font-size: 10.5px; color: #0B6B4F; font-style: normal; background: #E4F3EC; border-radius: 99px; padding: 1px 8px; }
			.duty-cl-rm { color: #C6CFCB; font-size: 11px; padding: 0 3px; }
			.duty-cl-rm:hover { color: #C94646; }
			.duty-cl-warn { font-size: 12px; font-weight: 800; color: #8F5C07; background: #FDF0D7; border-radius: 8px; padding: 7px 11px; margin-top: 8px; }
			.duty-cl-clear { font-size: 12px; font-weight: 800; color: #0B6B4F; background: #DBF0E6; border-radius: 8px; padding: 7px 11px; margin-top: 8px; }
			.duty-cl-addrow { margin-top: 9px; }
			.duty-wk-chip { margin-left: 6px; font-size: 10px; font-weight: 800; color: #8F5C07; background: #FFF6E0; border-radius: 99px; padding: 1px 7px; }
			.duty-wk-full { color: #0B6B4F; background: #E4F3EC; }
			.duty-cl-who, .duty-cl-due { font-size: 10.5px; font-weight: 700; color: #A9B5B1; text-decoration: none !important; margin-left: 6px; white-space: nowrap; }
			.duty-cl-who.duty-cl-set { color: #0B6B4F; }
			.duty-cl-due.duty-cl-set { color: #51605C; }
			.duty-cl-late .duty-cl-due { color: #C94646 !important; }
			.duty-cl-late { background: #FFF7F5; border-radius: 8px; }
			.duty-enab-promote { float: right; font-size: 11.5px; font-weight: 800; color: #0B6B4F; background: #E4F3EC; border-radius: 99px; padding: 4px 13px; cursor: pointer; text-decoration: none !important; margin-bottom: 6px; }
			.duty-enab-promote:hover { background: #123C35; color: #E7F0EC; }
			.duty-enab-tpl { float: right; font-size: 11.5px; font-weight: 800; color: #8F5C07; background: #FFF6E0; border-radius: 99px; padding: 4px 13px; cursor: pointer; text-decoration: none !important; margin: 0 8px 6px 0; }
			.duty-enab-tpl:hover { background: #B27409; color: #fff; }
			.duty-issue-merge { float: right; font-size: 11.5px; font-weight: 800; color: #51605C; background: #EDF2EF; border-radius: 99px; padding: 4px 13px; cursor: pointer; text-decoration: none !important; margin: 0 8px 6px 0; }
			.duty-issue-merge:hover { background: #123C35; color: #E7F0EC; }
			.duty-erp-bar { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; background: #F4FAF6; border: 1px dashed #B9D6C6; border-radius: 12px; padding: 8px 12px; margin: 6px 0 10px; }
			.duty-erp-bar a { font-size: 11.5px; font-weight: 800; color: #123C35; background: #E4F3EC; border-radius: 99px; padding: 4px 13px; cursor: pointer; text-decoration: none !important; }
			.duty-erp-bar a:hover { background: #123C35; color: #E7F0EC; }
			.duty-erp-done { font-size: 11px; font-weight: 800; color: #0B6B4F; }
			.duty-erp-bar a.duty-erp-open { background: #fff; border: 1px solid #B9D6C6; color: #0B6B4F; }
			.duty-erp-bar a.duty-erp-open:hover { background: #0B6B4F; color: #fff; }
			.duty-ld-docs { border: 1px solid #E2E8E5; border-radius: 12px; padding: 8px 12px; margin: 0 0 10px; }
			.duty-ld-docs b { display: block; font-size: 10.5px; text-transform: uppercase; letter-spacing: .4px; color: #65736F; margin-bottom: 4px; }
			.duty-ld-docs a { display: flex; justify-content: space-between; gap: 10px; font-size: 12.5px; font-weight: 700; color: #123C35; padding: 4px 2px; text-decoration: none !important; border-bottom: 1px dashed #EDF2EF; }
			.duty-ld-docs a:hover { color: #0B6B4F; }
			.duty-ld-docs a i { font-style: normal; font-size: 10.5px; color: #8A9994; }
			.duty-issue-details { background: #FBFDFC; border: 1.5px solid #CFE3D8; border-left: 5px solid #0E8A63; border-radius: 12px; padding: 12px 16px; margin: 10px 0 14px; box-shadow: 0 2px 8px rgba(18,60,53,.06); }
			.duty-issue-details > b { display: flex; align-items: baseline; gap: 8px; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: .5px; color: #0B6B4F; margin-bottom: 6px; }
			.duty-issue-details > b i { font-style: normal; font-weight: 700; text-transform: none; letter-spacing: 0; color: #8A9994; }
			.duty-idet-body { font-size: 13.5px; line-height: 1.62; color: #17211F; white-space: normal; max-height: 300px; overflow-y: auto; }
			.duty-idet-empty { color: #8A9994; font-size: 12px; font-weight: 700; border-left-color: #D5DEDA; }
			.duty-cl-input { width: 100%; border: 1.5px dashed #B9C6C1; border-radius: 9px; padding: 7px 11px; font-size: 12.5px; background: #FFF; }
			.duty-cl-input:focus { border-color: #0E8A63; outline: none; border-style: solid; }
			.duty-kudo { font-size: 11px; font-weight: 800; color: #8A9994; cursor: pointer; margin-left: 6px; border-radius: 99px; padding: 1px 7px; background: #F0F4F2; }
			.duty-kudo:hover { color: #0B6B4F; background: #E4F3EC; text-decoration: none; }
			.duty-kudo-mine { color: #0B6B4F; background: #E4F3EC; cursor: default; }
			.duty-kudo-ro { cursor: default; }
			.duty-gamify { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 16px; }
			.duty-gm-card { background: #fff; border: 1px solid #E2E8E5; border-radius: 14px; padding: 12px 16px; }
			.duty-gm-streak { display: flex; align-items: center; gap: 12px; border-left: 4px solid #E2620E; background: #FFFAF5; }
			.duty-gm-flame { font-size: 30px; }
			.duty-gm-nums b { font-size: 26px; color: #17211F; }
			.duty-gm-nums span { display: block; font-size: 10.5px; font-weight: 800; color: #A2542C; text-transform: uppercase; }
			.duty-gm-nums i { font-size: 10.5px; color: #8A9994; font-style: normal; }
			.duty-gm-today { display: flex; flex-direction: column; gap: 3px; margin-left: 6px; }
			.duty-gm-chk { font-size: 11px; font-weight: 700; color: #A9B5B1; }
			.duty-gm-on { color: #0B6B4F; }
			.duty-gm-week b, .duty-gm-badges b { font-size: 11px; text-transform: uppercase; color: #65736F; letter-spacing: .4px; }
			.duty-gm-wrow { font-size: 12px; color: #51605C; margin-top: 3px; }
			.duty-gm-wrow span { font-weight: 800; color: #17211F; }
			.duty-gm-badges { max-width: 380px; }
			.duty-gm-brow { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 6px; }
			.duty-gm-badge { font-size: 19px; cursor: help; }
			.duty-gm-locked { filter: grayscale(1); opacity: .32; }
			.duty-pulse { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; background: #123C35; color: #E7F0EC; border-radius: 12px; padding: 9px 16px; margin: 0 0 12px; width: 100%; box-sizing: border-box; }
			.duty-pulse-hit { background: linear-gradient(90deg, #123C35, #0E8A63); }
			.duty-pl-label { font-weight: 800; font-size: 12px; }
			.duty-pl-bar { flex: 1 1 160px; height: 8px; border-radius: 99px; background: rgba(255,255,255,.18); overflow: hidden; min-width: 120px; }
			.duty-pl-bar i { display: block; height: 100%; background: #FFC53D; border-radius: 99px; transition: width .3s; }
			.duty-pulse-hit .duty-pl-bar i { background: #7BE3B0; }
			.duty-pl-num, .duty-pl-breach, .duty-pl-app { font-size: 11.5px; font-weight: 700; }
			.duty-pl-bad { color: #FFB3A6; }
			.duty-library { padding: 14px 30px 90px; }
			.duty-lb-head { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 10px; }
			.duty-lb-head h3 { margin: 0; color: #123C35; font-weight: 800; }
			.duty-lb-search { flex: 0 1 320px; border: 1.5px solid #E2E8E5; border-radius: 99px; padding: 7px 16px; font-size: 12.5px; background: #fff; }
			.duty-lb-search:focus { border-color: #0E8A63; outline: none; }
			.duty-lb-admin { margin-left: auto; display: flex; gap: 8px; align-items: center; }
			.duty-lb-admin .duty-bk-file { width: 200px; font-size: 11px; }
			.duty-lb-chips { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 6px; }
			.duty-lb-chip { font-size: 11.5px; font-weight: 800; color: #51605C; background: #EDF2EF; border-radius: 99px; padding: 4px 13px; cursor: pointer; }
			.duty-lb-chip i { font-style: normal; opacity: .6; font-weight: 700; }
			.duty-lb-chip.on, .duty-lb-chip:hover { background: #123C35; color: #E7F0EC; text-decoration: none; }
			.duty-lb-cat { display: flex; align-items: baseline; gap: 8px; margin: 20px 0 10px; }
			.duty-lb-cat b { font-size: 14px; color: #123C35; letter-spacing: .02em; }
			.duty-lb-cat span { font-size: 11px; font-weight: 800; color: #8A9994; }
			.duty-lb-shelf { display: flex; gap: 16px; overflow-x: auto; padding: 4px 2px 14px; scroll-snap-type: x proximity; }
			.duty-lb-shelf::-webkit-scrollbar { height: 8px; }
			.duty-lb-shelf::-webkit-scrollbar-thumb { background: #D5DEDA; border-radius: 99px; }
			.duty-lb-tile { flex: 0 0 148px; width: 148px; min-width: 148px; max-width: 148px; scroll-snap-align: start; display: flex; flex-direction: column; gap: 3px; text-decoration: none !important; }
			.duty-lb-mini { flex-basis: 118px; width: 118px; min-width: 118px; max-width: 118px; }
			.duty-lb-coverwrap { position: relative; }
			.duty-lb-cover { display: block; width: 148px; height: 222px; border-radius: 10px; background-size: cover; background-position: center; box-shadow: 0 3px 10px rgba(18, 60, 53, .16); transition: transform .14s, box-shadow .14s; }
			.duty-lb-mini .duty-lb-cover { width: 118px; height: 177px; }
			.duty-lb-tile:hover .duty-lb-cover { transform: translateY(-4px) scale(1.02); box-shadow: 0 12px 26px rgba(18, 60, 53, .26); }
			.duty-lb-fallback { display: flex; align-items: flex-end; padding: 12px 11px; }
			.duty-lb-fallback i { font-style: normal; color: #fff; font-weight: 800; font-size: 13.5px; line-height: 1.25; text-shadow: 0 1px 5px rgba(0,0,0,.35); display: -webkit-box; -webkit-line-clamp: 5; -webkit-box-orient: vertical; overflow: hidden; }
			.duty-lb-ring { position: absolute; right: 7px; bottom: 7px; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 7px rgba(0,0,0,.3); }
			.duty-lb-ring i { font-style: normal; background: #123C35; color: #fff; border-radius: 50%; width: 27px; height: 27px; display: flex; align-items: center; justify-content: center; font-size: 8.5px; font-weight: 800; }
			.duty-lb-done { background: #0E8A63; color: #fff; font-weight: 800; font-size: 15px; }
			.duty-lb-newtag { position: absolute; top: 7px; left: 7px; background: #FFC53D; color: #4A3A00; font-size: 9.5px; font-weight: 800; text-transform: uppercase; letter-spacing: .05em; border-radius: 99px; padding: 2px 8px; box-shadow: 0 1px 4px rgba(0,0,0,.2); }
			.duty-lb-menu { position: absolute; top: 5px; right: 7px; color: #fff; font-weight: 800; font-size: 16px; text-shadow: 0 1px 4px rgba(0,0,0,.6); cursor: pointer; padding: 0 5px; opacity: 0; transition: opacity .12s; }
			.duty-lb-tile:hover .duty-lb-menu { opacity: 1; }
			.duty-lb-title { font-size: 12.5px; font-weight: 700; color: #17211F; line-height: 1.25; margin-top: 5px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
			.duty-lb-meta { font-size: 10.5px; color: #65736F; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
			.duty-lb-meta2 { font-size: 10px; color: #8A9994; }
			.duty-lb-meta2 b { color: #B27409; font-weight: 800; }
			.duty-lb-empty { padding: 50px 0; text-align: center; color: #65736F; font-weight: 700; }
			.duty-lb-pop { position: fixed; z-index: 100000; background: #fff; border: 1px solid #E2E8E5; border-radius: 12px; box-shadow: 0 10px 30px rgba(18,60,53,.18); padding: 6px; width: 170px; display: flex; flex-direction: column; }
			.duty-lb-pop a { padding: 8px 11px; border-radius: 8px; font-size: 12.5px; font-weight: 700; color: #17211F; text-decoration: none !important; }
			.duty-lb-pop a:hover { background: #EDF2EF; }
			.duty-lb-pop .duty-bk-del { color: #C94646; }
			.duty-rd-prog { position: sticky; top: 0; z-index: 20; height: 22px; display: flex; align-items: center; background: transparent; margin-bottom: 6px; }
			.duty-rd-prog i { display: block; height: 4px; background: linear-gradient(90deg, #B27409, #0E8A63); border-radius: 99px; flex: none; transition: width .3s; min-width: 0; }
			.duty-rd-prog { gap: 10px; }
			.duty-rd-prog span { font-size: 10.5px; font-weight: 800; color: #8A9994; white-space: nowrap; }
			.duty-rd-thm, .duty-rd-zenbtn, .duty-rd-listen { padding: 3px 9px; border-radius: 6px; cursor: pointer; text-decoration: none !important; color: #6B7772; }
			.duty-rd-thm:hover, .duty-rd-zenbtn:hover, .duty-rd-listen:hover { background: #fff; color: #182420; }
			.duty-rd-listen.on { background: #123C35 !important; color: #FFC53D !important; }
			.duty-th-sepia { background: #F6EEDC; border-radius: 14px; }
			.duty-th-sepia .duty-rd-body, .duty-th-sepia .duty-rd-toc a { color: #463924 !important; }
			.duty-th-night { background: #0F1B17; border-radius: 14px; }
			.duty-th-night .duty-rd-body { color: #C6D4CD !important; }
			.duty-th-night .duty-rd-head b, .duty-th-night .duty-rd-toc a { color: #C6D4CD !important; }
			.duty-th-night .duty-rd-toc, .duty-th-night .duty-rd-nav { border-color: #23342E !important; }
			.duty-th-night .duty-rd-opts { background: #1A2822 !important; }
			.duty-th-night .duty-rd-prog span { color: #6E837B; }
			.duty-th-night .btn-default { background: #1A2822; color: #C6D4CD; border-color: #2A3D36; }
			.duty-rd-speaking { background: rgba(255, 197, 61, .28); border-radius: 6px; box-decoration-break: clone; transition: background .25s; }
			.duty-th-night .duty-rd-speaking { background: rgba(255, 197, 61, .18); }
			.duty-rd-audio { position: fixed; bottom: 22px; left: 50%; transform: translateX(-50%); z-index: 10000;
				display: flex; align-items: center; gap: 8px; background: #123C35; color: #E7F0EC; border-radius: 99px;
				padding: 8px 14px; box-shadow: 0 10px 30px rgba(10, 26, 22, .4); }
			.duty-rd-audio a { color: #E7F0EC; font-size: 17px; cursor: pointer; text-decoration: none !important; padding: 0 4px; }
			.duty-rd-audio a:hover { color: #FFC53D; }
			.duty-rd-audio select { background: #1A2822; color: #E7F0EC; border: 1px solid #2A3D36; border-radius: 8px; font-size: 11.5px; padding: 3px 6px; max-width: 150px; }
			.duty-rd-zenmode .duty-rd-head, .duty-rd-zenmode .duty-rd-toc, .duty-rd-zenmode .duty-rd-nav,
			.duty-rd-zenmode .duty-rd-revpanel, .duty-rd-zenmode .duty-lb-chips { display: none !important; }
			.duty-rd-zenmode .duty-rd-body { max-width: 66ch !important; margin: 0 auto; }
			.duty-rd-zenx { position: fixed; top: 16px; right: 20px; z-index: 10001; font-size: 17px; font-weight: 800;
				color: #8A9994; cursor: pointer; background: rgba(255,255,255,.85); border-radius: 50%; width: 34px; height: 34px;
				display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 10px rgba(0,0,0,.15); text-decoration: none !important; }
			.duty-th-night .duty-rd-zenx { background: #1A2822; color: #C6D4CD; }
			mark.duty-hl { background: rgba(255, 197, 61, .32); border-radius: 4px; padding: 0 1px; cursor: pointer; box-decoration-break: clone; color: inherit; }
			mark.duty-hl-shared { background: rgba(255, 197, 61, .5); border-bottom: 2px solid #B27409; }
			mark.duty-hl:not(.duty-hl-mine) { background: rgba(14, 138, 99, .18); }
			mark.duty-hl-shared:not(.duty-hl-mine) { background: rgba(14, 138, 99, .3); border-bottom-color: #0E8A63; }
			.duty-th-night mark.duty-hl { background: rgba(255, 197, 61, .22); }
			.duty-hl-para { border-left: 3px solid rgba(255, 197, 61, .8); padding-left: 10px; }
			.duty-hl-flash { animation: duty-hl-pulse 2.4s ease; border-radius: 6px; }
			@keyframes duty-hl-pulse { 0%, 60% { background: rgba(255, 197, 61, .4); } 100% { background: transparent; } }
			.duty-rd-selbar { position: fixed; z-index: 100001; display: flex; gap: 2px; background: #123C35; border-radius: 10px; padding: 5px; box-shadow: 0 8px 24px rgba(10,26,22,.4); }
			.duty-rd-selbar a { color: #E7F0EC; font-size: 12px; font-weight: 700; padding: 5px 10px; border-radius: 7px; cursor: pointer; text-decoration: none !important; white-space: nowrap; }
			.duty-rd-selbar a:hover { background: #0E8A63; }
			.duty-hl-pop { width: 250px; }
			.duty-hl-who { font-size: 11px; font-weight: 800; color: #65736F; padding: 5px 9px 3px; }
			.duty-hl-note { font-size: 12px; padding: 4px 9px; color: #2A3531; }
			.duty-hl-rm { color: #C94646 !important; }
			.duty-rd-hlpanel, .duty-rd-findpanel { border: 1px solid #E8E5DD; border-radius: 12px; padding: 8px; margin-bottom: 10px; max-height: 320px; overflow-y: auto; background: #fff; }
			.duty-hl-row { display: block; padding: 8px 10px; border-radius: 9px; cursor: pointer; text-decoration: none !important; }
			.duty-hl-row:hover { background: #F2F6F4; }
			.duty-hl-row i { display: block; font-style: normal; font-size: 10.5px; font-weight: 800; color: #0B6B4F; }
			.duty-hl-row span { display: block; font-size: 12.5px; color: #2A3531; line-height: 1.45; }
			.duty-hl-row b { display: block; font-size: 11.5px; color: #8F5C07; margin-top: 2px; font-weight: 600; }
			.duty-rd-marks, .duty-rd-find { padding: 3px 9px; border-radius: 6px; cursor: pointer; text-decoration: none !important; color: #6B7772; }
			.duty-rd-marks:hover, .duty-rd-find:hover { background: #fff; color: #182420; }
			.duty-rd-zenmode .duty-rd-hlpanel, .duty-rd-zenmode .duty-rd-findpanel { display: none !important; }
			.duty-rd-aa, .duty-rd-bmk { padding: 3px 9px; border-radius: 6px; cursor: pointer; text-decoration: none !important; color: #6B7772; font-weight: 700; }
			.duty-rd-aa:hover, .duty-rd-bmk:hover { background: #fff; color: #182420; }
			.duty-rd-aapanel { position: absolute; top: 44px; right: 0; z-index: 10002; width: 300px; background: #fff; border: 1px solid #E2E8E5; border-radius: 14px; box-shadow: 0 14px 40px rgba(18,60,53,.2); padding: 12px 14px; }
			.duty-rd-head { position: relative; }
			.duty-aa-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin: 7px 0; font-size: 12px; font-weight: 700; color: #51605C; }
			.duty-aa-row input[type=range] { width: 150px; accent-color: #0E8A63; }
			.duty-aa-segs { display: flex; gap: 4px; align-items: center; }
			.duty-aa-seg, .duty-aa-fs { font-size: 11.5px; font-weight: 800; color: #51605C; background: #EDF2EF; border-radius: 8px; padding: 4px 10px; cursor: pointer; text-decoration: none !important; }
			.duty-aa-seg.on { background: #123C35; color: #E7F0EC; }
			.duty-aa-fsv { min-width: 22px; text-align: center; }
			.duty-rd-aapanel details summary { font-size: 11.5px; font-weight: 800; color: #0B6B4F; cursor: pointer; margin: 6px 0 2px; }
			.duty-rd-scrub { flex: 1; height: 5px; accent-color: #0E8A63; cursor: pointer; margin: 0; }
			.duty-rd-wb { position: relative; background: linear-gradient(135deg, #FFFAF0, #F4FAF6); border: 1px solid #EAD9A8; border-radius: 14px; padding: 12px 40px 12px 16px; margin-bottom: 12px; }
			.duty-rd-wb b { display: block; color: #123C35; font-size: 13.5px; }
			.duty-rd-wb span { font-size: 12.5px; color: #51605C; }
			.duty-rd-wb i { display: block; font-style: normal; font-size: 10.5px; font-weight: 800; text-transform: uppercase; color: #8F5C07; margin-top: 8px; }
			.duty-rd-wb q { display: block; font-size: 12px; color: #4A3E22; margin-top: 3px; quotes: none; }
			.duty-wb-x { position: absolute; top: 8px; right: 12px; cursor: pointer; color: #8A9994; font-weight: 800; text-decoration: none !important; }
			.duty-rd-undo { position: fixed; bottom: 80px; left: 50%; transform: translateX(-50%); z-index: 100002; background: #17211F; color: #E7F0EC; border-radius: 99px; padding: 9px 18px; font-size: 12.5px; font-weight: 700; box-shadow: 0 8px 26px rgba(0,0,0,.35); }
			.duty-rd-undo a { color: #FFC53D; cursor: pointer; font-weight: 800; text-decoration: none !important; margin-left: 4px; }
			.duty-au-skip { font-size: 14px !important; }
			.duty-au-sleep { background: #1A2822; color: #E7F0EC; border: 1px solid #2A3D36; border-radius: 8px; font-size: 11px; padding: 3px 5px; }
			.duty-hl-sect { font-size: 10.5px; font-weight: 800; text-transform: uppercase; letter-spacing: .05em; color: #65736F; padding: 8px 10px 2px; display: flex; justify-content: space-between; }
			.duty-hl-md { font-style: normal; color: #0B6B4F; cursor: pointer; text-transform: none; letter-spacing: 0; }
			.duty-hl-qc, .duty-bm-rm { float: right; font-style: normal; cursor: pointer; color: #8A9994; padding: 0 4px; }
			.duty-hl-qc:hover { color: #B27409; }
			.duty-bm-rm:hover { color: #C94646; }
			.duty-gm-memory { max-width: 300px; border-left: 4px solid #B27409; background: #FFFDF6; }
			.duty-gm-memory b { font-size: 11px; text-transform: uppercase; color: #8F5C07; letter-spacing: .4px; }
			.duty-gm-memory q { display: block; font-size: 12px; color: #4A3E22; margin-top: 5px; line-height: 1.45; quotes: none; }
			.duty-gm-memory i { display: block; font-style: normal; font-size: 10.5px; font-weight: 800; color: #8A9994; margin-top: 4px; }
			.duty-radar { margin-bottom: 16px; }
			.duty-radar-head { display: flex; align-items: baseline; gap: 10px; margin-bottom: 8px; }
			.duty-radar-head b { color: #123C35; font-size: 14px; }
			.duty-radar-head span { font-size: 11px; color: #8A9994; font-weight: 700; }
			.duty-radar-add { margin-left: auto; font-size: 12px; font-weight: 800; color: #0B6B4F; cursor: pointer; text-decoration: none !important; }
			.duty-radar-shelf { display: flex; gap: 12px; overflow-x: auto; padding-bottom: 8px; }
			.duty-radar-card { flex: 0 0 250px; display: flex; flex-direction: column; gap: 4px; background: #fff; border: 1px solid #E2E8E5; border-radius: 12px; padding: 10px 13px; text-decoration: none !important; transition: transform .12s, box-shadow .12s; border-top: 3px solid #A9B5B1; }
			.duty-radar-card:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(18,60,53,.12); }
			.duty-heat-hot { border-top-color: #E2620E; }
			.duty-heat-warm { border-top-color: #FFC53D; }
			.duty-heat-cool { border-top-color: #7BA8C9; }
			.duty-radar-top { font-size: 13px; color: #17211F; }
			.duty-radar-top b { font-weight: 800; }
			.duty-radar-top i { font-style: normal; font-size: 10px; font-weight: 800; color: #65736F; background: #EDF2EF; border-radius: 99px; padding: 1px 8px; margin-left: 6px; text-transform: uppercase; }
			.duty-radar-angle { font-size: 11.5px; color: #51605C; line-height: 1.4; }
			.duty-radar-trig { font-size: 11px; font-weight: 700; color: #8F5C07; }
			.duty-radar-worth { font-size: 11.5px; font-weight: 800; color: #0B6B4F; }
			.duty-radar-empty { padding: 18px; color: #8A9994; font-weight: 700; font-size: 12.5px; }
			.duty-radar-log { margin: 8px 0; font-size: 12px; color: #2A3531; }
			.duty-radar-log b { display: block; font-size: 10.5px; text-transform: uppercase; color: #65736F; margin-bottom: 4px; }
			.duty-radar-log div { padding: 3px 0; border-bottom: 1px dashed #EDF2EF; }
			.duty-radar-drop { display: inline-block; margin: 6px 0 2px; color: #C94646; font-size: 12px; font-weight: 700; cursor: pointer; text-decoration: none !important; }
			.duty-radar-visit { display: block; font-size: 12px; margin-bottom: 8px; color: #0B6B4F; word-break: break-all; }
			.duty-radar-daily { background: linear-gradient(135deg, #F4FAF6, #FFFDF6); border: 1px solid #DCE8E0; border-left: 4px solid #123C35; border-radius: 14px; padding: 12px 16px; margin-bottom: 16px; max-width: 560px; }
			.duty-radar-daily b { display: block; font-size: 11px; text-transform: uppercase; letter-spacing: .4px; color: #65736F; }
			.duty-rdd-co { display: block; font-size: 15px; font-weight: 800; color: #17211F; margin-top: 3px; }
			.duty-radar-daily q { display: block; font-size: 12.5px; color: #51605C; margin-top: 4px; quotes: none; line-height: 1.45; }
			.duty-radar-daily i { display: block; font-style: normal; font-size: 11.5px; font-weight: 700; color: #8F5C07; margin-top: 4px; }
			.duty-myrooms { display: flex; flex-direction: column; gap: 8px; margin-bottom: 16px; }
			.duty-mr-sect { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
			.duty-mr-sect > b { font-size: 11px; text-transform: uppercase; letter-spacing: .4px; color: #65736F; white-space: nowrap; }
			.duty-mr-sect > span { display: flex; gap: 6px; flex-wrap: wrap; }
			.duty-mr-chip { font-size: 11.5px; font-weight: 800; color: #123C35; background: #E4F3EC; border-radius: 99px; padding: 4px 13px; cursor: pointer; text-decoration: none !important; }
			.duty-mr-chip:hover { background: #123C35; color: #E7F0EC; }
			.duty-cr-accessbtn { cursor: pointer; padding: 0 6px; text-decoration: none !important; }
			.duty-th-night .duty-rd-aapanel { background: #14231E; border-color: #23342E; }
			.duty-th-night .duty-aa-row { color: #9FB3AB; }
			.duty-th-night .duty-aa-seg, .duty-th-night .duty-aa-fs { background: #1A2822; color: #C6D4CD; }
			.duty-th-night .duty-aa-seg.on { background: #0E8A63; }
			.duty-th-night .duty-rd-wb { background: #14231E; border-color: #2A3D36; }
			.duty-th-night .duty-rd-wb b { color: #C6D4CD; }
			.duty-rd-turn { position: absolute; top: 0; bottom: 0; width: 46%; z-index: 8; pointer-events: none; overflow: hidden; border-radius: 8px; }
			.duty-turn-fwd { right: 0; background: linear-gradient(270deg, rgba(0,0,0,.14), rgba(255,255,255,.55) 24%, transparent 55%); transform-origin: left center; animation: duty-turn-f .52s cubic-bezier(.3,.5,.3,1) forwards; }
			.duty-turn-bck { left: 0; background: linear-gradient(90deg, rgba(0,0,0,.14), rgba(255,255,255,.55) 24%, transparent 55%); transform-origin: right center; animation: duty-turn-b .52s cubic-bezier(.3,.5,.3,1) forwards; }
			@keyframes duty-turn-f { 0% { transform: perspective(1200px) rotateY(0deg); opacity: .95; } 100% { transform: perspective(1200px) rotateY(-72deg); opacity: 0; } }
			@keyframes duty-turn-b { 0% { transform: perspective(1200px) rotateY(0deg); opacity: .95; } 100% { transform: perspective(1200px) rotateY(72deg); opacity: 0; } }
			.duty-th-night .duty-turn-fwd { background: linear-gradient(270deg, rgba(0,0,0,.45), rgba(198,212,205,.16) 24%, transparent 55%); }
			.duty-th-night .duty-turn-bck { background: linear-gradient(90deg, rgba(0,0,0,.45), rgba(198,212,205,.16) 24%, transparent 55%); }
			.duty-news { padding: 14px 26px 90px; max-width: 1280px; margin: 0 auto; }
			.duty-nw-head { display: flex; align-items: center; gap: 18px; flex-wrap: wrap; margin-bottom: 14px; }
			.duty-nw-head h3 { margin: 0; color: #123C35; font-weight: 800; }
			.duty-nw-chips { display: flex; gap: 6px; flex-wrap: wrap; }
			.duty-nw-chip { font-size: 11.5px; font-weight: 800; color: #51605C; background: #EDF2EF; border-radius: 99px; padding: 4px 13px; cursor: pointer; }
			.duty-nw-chip.on, .duty-nw-chip:hover { background: #123C35; color: #E7F0EC; text-decoration: none; }
			.duty-nw-refresh { margin-left: auto; font-size: 19px; font-weight: 800; color: #51605C; cursor: pointer; padding: 0 8px; }
			.duty-nw-refresh:hover { color: #0B6B4F; text-decoration: none; }
			.duty-confetti { position: fixed; inset: 0; pointer-events: none; z-index: 99999; overflow: hidden; }
			.duty-confetti i { position: absolute; top: -14px; display: block; opacity: .95;
				animation-name: duty-confetti-fall; animation-timing-function: cubic-bezier(.25,.45,.45,.95); animation-fill-mode: forwards; }
			@keyframes duty-confetti-fall {
				0% { transform: translate3d(0, -10px, 0) rotate(0deg); opacity: 1; }
				70% { opacity: 1; }
				100% { transform: translate3d(var(--sway, 30px), 104vh, 0) rotate(var(--spin, 360deg)); opacity: .55; }
			}
			.duty-nw-hero { display: block; position: relative; height: 300px; border-radius: 18px; background-size: cover; background-position: center; background-color: #123C35; overflow: hidden; margin-bottom: 16px; }
			.duty-nw-hgrad { position: absolute; inset: 0; background: linear-gradient(180deg, transparent 30%, rgba(10, 26, 22, .88)); }
			.duty-nw-htxt { position: absolute; left: 22px; right: 22px; bottom: 18px; color: #fff; }
			.duty-nw-htxt i { font-style: normal; font-size: 11.5px; font-weight: 800; opacity: .85; text-transform: uppercase; letter-spacing: .5px; }
			.duty-nw-htxt b { display: block; font-size: 24px; line-height: 1.25; margin-top: 4px; text-shadow: 0 1px 8px rgba(0,0,0,.4); }
			.duty-nw-hero:hover .duty-nw-htxt b { text-decoration: underline; }
			.duty-nw-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 14px; }
			.duty-nw-card { display: flex; flex-direction: column; background: #fff; border: 1px solid #E2E8E5; border-radius: 14px; overflow: hidden; text-decoration: none !important; transition: transform .12s, box-shadow .12s; }
			.duty-nw-card:hover { transform: translateY(-2px); box-shadow: 0 8px 22px rgba(18, 60, 53, .12); }
			.duty-nw-img { height: 136px; background-size: cover; background-position: center; background-color: #EDF2EF; }
			.duty-nw-noimg { display: flex; align-items: center; justify-content: center; font-size: 44px; font-weight: 800; color: #fff; background: linear-gradient(135deg, #123C35, #0E8A63); }
			.duty-nw-body { display: flex; flex-direction: column; gap: 4px; padding: 10px 13px 12px; }
			.duty-nw-src { font-size: 10.5px; font-weight: 800; color: #65736F; text-transform: uppercase; letter-spacing: .4px; }
			.duty-nw-cat { font-style: normal; color: #0B6B4F; }
			.duty-nw-title { font-size: 13.5px; font-weight: 700; color: #17211F; line-height: 1.3; }
			.duty-nw-when { font-size: 10.5px; color: #8A9994; }
			.duty-nw-new { color: #B27409; }
			.duty-nw-load { padding: 60px 0; text-align: center; color: #65736F; font-weight: 700; }
			.duty-ndrawer { width: 560px; }
			.duty-nd-hero { height: 230px; border-radius: 14px; background-size: cover; background-position: center; background-color: #EDF2EF; margin-bottom: 14px; }
			.duty-nd-title { color: #123C35; font-weight: 800; margin: 0 0 4px; line-height: 1.3; }
			.duty-nd-meta { font-size: 11px; font-weight: 800; color: #65736F; text-transform: uppercase; letter-spacing: .4px; margin-bottom: 12px; }
			.duty-nd-p { font-size: 13.5px; line-height: 1.65; color: #2A3531; }
			.duty-nd-extra { height: 180px; border-radius: 12px; background-size: cover; background-position: center; margin: 10px 0; }
			.duty-nd-src { margin-top: 14px; }
			body.duty-consultant .duty-proj-new, body.duty-consultant .duty-proj-cons, body.duty-consultant .duty-proj-staffb,
			body.duty-consultant .duty-proj-archive { display: none !important; }
			body.duty-mobile .duty-issues-face { padding: 8px 10px 90px; }
			.duty-team { display: block !important; }
			.duty-tf { display: flex; gap: 5px; flex-wrap: wrap; margin-bottom: 9px; }
			.duty-tr .duty-dm-btn { border: 1px solid #E2E8E5; border-radius: 99px; padding: 1px 9px; font-size: 11px; color: #087A67; flex: none; text-decoration: none; }
			.duty-tr .duty-dm-btn:hover { border-color: #087A67; background: #F0F7F4; }
			.duty-tfp { font-size: 11.5px; font-weight: 700; color: #65736F; background: #F0F4F2; border-radius: 99px; padding: 4px 11px; cursor: pointer; }
			.duty-tfp b { font-weight: 800; }
			.duty-tfp.on { background: #123C35; color: #fff; }
			.duty-tfp:hover:not(.on) { background: #E2E8E5; }
			.duty-teamtbl { display: flex; flex-direction: column; gap: 4px; }
			.duty-tr { display: grid; grid-template-columns: minmax(150px, 1.1fr) auto minmax(160px, 1.6fr) 74px 52px 20px;
				gap: 10px; align-items: center; background: #fff; border: 1px solid #EEF2F0; border-radius: 10px;
				padding: 7px 11px; font-size: 12.5px; cursor: pointer; transition: box-shadow .14s; }
			.duty-tr:hover { box-shadow: 0 2px 8px rgba(12,34,30,.08); }
			.duty-tr-warn { border-left: 3px solid #B27409; background: #FFFDF8; }
			.duty-tr-who { display: flex; align-items: center; gap: 7px; min-width: 0; }
			.duty-tr-who b { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-tr-task { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-tr-dur { text-align: right; font-variant-numeric: tabular-nums; font-weight: 600; }
			.duty-tr-plan { text-align: center; font-weight: 700; }
			.duty-tr-plan-none { color: #B27409; }
			.duty-tr-more { color: #8A9994; font-weight: 800; text-align: right; }
			body.duty-mobile .duty-tr { grid-template-columns: 1fr auto; grid-auto-rows: auto; }
			body.duty-mobile .duty-tr-task { grid-column: 1 / -1; }
			body.duty-mobile .duty-tr-dur, body.duty-mobile .duty-tr-plan { text-align: left; }
			.duty-cr-mem { padding: 6px 0; border-bottom: 1px dashed var(--border-color); display: flex; gap: 8px; align-items: center; }
			.duty-cr-mem a { margin-left: auto; cursor: pointer; font-size: var(--text-xs); }
			.duty-cr-addmem { display: flex; gap: 6px; margin-top: 10px; }
			.duty-cr-joinlink { display: flex; gap: 6px; }
			.duty-cr-approve { color: var(--green-600, #16a34a); font-weight: 700; cursor: pointer; margin-left: auto; }
			.duty-cr-rejectq { color: var(--red-600, #dc2626); font-weight: 700; cursor: pointer; }
			.duty-acad-row { display: flex; gap: 10px; align-items: baseline; padding: 6px 4px; border-bottom: 1px dashed var(--border-color); font-size: var(--text-sm); flex-wrap: wrap; }
			.duty-acad-done { color: #166534; font-weight: 700; font-size: var(--text-xs); }
			.duty-cr-msline { display: flex; flex-direction: column; gap: 4px; font-size: var(--text-sm); margin-bottom: 8px; }
			.duty-cr-msbar { height: 7px; background: var(--bg-light-gray, #f1f5f9); border-radius: 99px; overflow: hidden; }
			.duty-cr-msbar i { display: block; height: 100%; background: #0F5C55; border-radius: 99px; }
			.duty-cr-mswait { color: #b45309; }
			.duty-cr-msmanage { float: right; cursor: pointer; font-size: var(--text-xs); font-weight: 700; }
			.duty-cr-msrow { padding: 8px 4px; border-bottom: 1px dashed var(--border-color); display: flex; gap: 10px; align-items: baseline; flex-wrap: wrap; }
			.duty-cr-msrow.locked { background: #f0fdf4; border-radius: 8px; }
			.duty-cr-mssig { font-size: var(--text-xs); color: #166534; }
			.duty-cr-msacts a { margin-right: 8px; cursor: pointer; font-weight: 700; }
			.duty-cr-msask { color: #b45309; }
			.duty-cr-msask.glow { background: #fef3c7; border-radius: 8px; padding: 2px 8px; }
			.duty-cr-msev { font-size: var(--text-xs); background: var(--bg-light-gray, #f1f5f9); border-radius: 99px; padding: 2px 9px; }
			.duty-cr-msev.ready { background: #dcfce7; color: #166534; font-weight: 700; }
			.duty-cr-msdesc { width: 100%; font-size: var(--text-xs); }
			.duty-cr-meeting {
				display: flex; gap: 8px; align-items: center; font-size: var(--text-sm);
				padding: 4px 0; border-bottom: 1px dashed var(--border-color); flex-wrap: wrap;
			}
			.duty-cr-meeting a { cursor: pointer; font-weight: 700; }
			.duty-cr-mconfirm, .duty-cr-mheld { color: var(--green-600, #16a34a); }
			.duty-cr-mmissed { color: var(--red-600, #dc2626); }
			.duty-cr-mdecline { color: var(--red-600, #dc2626); }
			.duty-cr-cust {
				font-size: var(--text-xs); font-weight: 800; color: var(--text-muted);
				text-transform: uppercase; letter-spacing: 0.04em; margin: 10px 2px 2px;
				cursor: pointer; user-select: none;
			}
			.duty-cr-cust:hover { color: var(--text-color); }
			.duty-cr-caret { display: inline-block; width: 12px; color: var(--text-muted); }
			.duty-renew { font-size: var(--text-xs); border-radius: 99px; padding: 2px 9px; font-weight: 700; white-space: nowrap; }
			.duty-renew-calm { background: #f0fdfa; color: #0f766e; }
			.duty-renew-warn { background: #fef3c7; color: #92400e; }
			.duty-renew-over { background: #fee2e2; color: #b91c1c; }
			.duty-renew-frozen { background: #b91c1c; color: #fff; }
			.duty-cr-unitchip {
				font-size: var(--text-xs); background: var(--bg-light-gray, #f1f5f9);
				border-radius: 99px; padding: 2px 9px; font-weight: 700;
			}
			.duty-cr-joinpill {
				background: #fef3c7; color: #92400e; border-radius: 99px;
				padding: 0 8px; font-size: 10px; font-weight: 700; white-space: nowrap;
			}
			.duty-cr-unread {
				background: var(--red-500, #ef4444); color: #fff; border-radius: 99px;
				padding: 0 7px; font-size: 10px; font-weight: 700;
			}
			.duty-chat-typing, .duty-cr-typing {
				font-size: var(--text-xs); color: var(--text-muted); font-style: italic;
				padding: 2px 4px; min-height: 16px;
			}
			.duty-cr-owner { font-size: var(--text-xs); font-weight: 700; cursor: pointer; color: #b45309; }
			.duty-cr-rename, .duty-cr-delete { cursor: pointer; font-size: var(--text-sm); opacity: 0.55; }
			.duty-cr-rename:hover, .duty-cr-delete:hover { opacity: 1; }
			.duty-cr-lastseen { font-size: var(--text-xs); color: var(--text-muted); }
			.duty-issue-ack { cursor: pointer; font-weight: 700; }
			.duty-cr-reqbadge {
				background: var(--red-500, #ef4444); color: #fff; border-radius: 99px;
				padding: 0 6px; font-size: 10px; font-style: normal;
			}
			@media (max-width: 767px) {
				.duty-clients { flex-direction: column; }
				.duty-cr-list { flex: 1 1 auto; width: 100%; }
				.duty-cr-room { width: 100%; height: auto; }
				.duty-cr-msgs { max-height: 46vh; flex: none; }
			}
			.duty-lead-chip {
				font-size: var(--text-xs); border-radius: 99px; padding: 1px 8px;
				background: #fef3c7; color: #92400e; font-weight: 600;
			}
			.duty-sales { padding-bottom: 76px; }
			.duty-sales-head { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 12px; }
			.duty-sales-total { font-size: var(--text-lg); }
			.duty-sales-actions { display: flex; gap: 14px; align-items: center; }
			.duty-sales-arch { cursor: pointer; font-weight: 600; font-size: var(--text-sm); }
			.duty-kb-sum { font-size: var(--text-xs); color: var(--text-muted); font-weight: 600; }
			.duty-sales-kanban .duty-kb-col[data-col="New"] { border-top: 3px solid #64748b; }
			.duty-sales-kanban .duty-kb-col[data-col="New"] .duty-kb-col-head { color: #475569; }
			.duty-sales-kanban .duty-kb-col[data-col="Contacted"] { border-top: 3px solid #0284c7; }
			.duty-sales-kanban .duty-kb-col[data-col="Contacted"] .duty-kb-col-head { color: #0369a1; }
			.duty-sales-kanban .duty-kb-col[data-col="Proposal"] { border-top: 3px solid #d97706; }
			.duty-sales-kanban .duty-kb-col[data-col="Proposal"] .duty-kb-col-head { color: #b45309; }
			.duty-sales-kanban .duty-kb-col[data-col="Negotiation"] { border-top: 3px solid #dc2626; }
			.duty-sales-kanban .duty-kb-col[data-col="Negotiation"] .duty-kb-col-head { color: #b91c1c; }
			.duty-sales-kanban .duty-kb-col[data-col="Awaiting Payment"] { border-top: 3px solid #7c3aed; }
			.duty-sales-kanban .duty-kb-col[data-col="Awaiting Payment"] .duty-kb-col-head { color: #6d28d9; }
			.duty-lead-card:hover { box-shadow: 0 3px 10px rgba(0,0,0,0.08); transform: translateY(-1px); transition: all 0.12s; }
			.duty-lead-company { font-weight: 700; color: var(--text-color); }
			.duty-lead-value { color: #0F5C55; font-weight: 700; }
			.duty-lead-contact { font-size: var(--text-xs); color: var(--text-muted); }
			.duty-lead-badges { display: flex; gap: 8px; font-size: var(--text-xs); }
			.duty-lead-over { color: var(--red-600, #dc2626); font-weight: 700; }
			.duty-stale { color: #b45309; font-weight: 700; }
			.duty-stale-red { color: var(--red-600, #dc2626); }
			.duty-lead-links { margin-bottom: 10px; font-weight: 600; }
			.duty-lead-section { font-weight: 700; margin: 14px 0 6px; border-top: 1px solid var(--border-color); padding-top: 10px; }
			.duty-lead-task { display: flex; gap: 8px; align-items: center; padding: 4px 0; cursor: pointer; font-weight: normal; }
			.duty-lead-task span:first-of-type { flex: 1; color: var(--text-color); }
			.duty-lead-task-done span:first-of-type { text-decoration: line-through; color: var(--text-muted); }
			.duty-lead-addtask { display: flex; gap: 6px; margin-top: 8px; }
			.duty-lead-addtask .duty-lt-desc { flex: 2; font-size: 16px; }
			.duty-lead-addtask .duty-lt-date, .duty-lead-addtask .duty-lt-time, .duty-lead-addtask .duty-lt-who { flex: 1; min-width: 90px; }
			.duty-lead-addtask { flex-wrap: wrap; }
			.duty-lead-note { padding: 6px 0; border-bottom: 1px dashed var(--border-color); }
			.duty-note-mention { color: #0F5C55; }
			.duty-mention-host { position: relative; }
			.duty-mention-dd {
				position: absolute; bottom: 100%; left: 0; margin-bottom: 4px;
				background: var(--card-bg, #fff); border: 1px solid var(--border-color);
				border-radius: 8px; box-shadow: 0 4px 14px rgba(0,0,0,0.12);
				display: flex; flex-direction: column; min-width: 220px; z-index: 1060;
				overflow: hidden;
			}
			.duty-mention-opt { padding: 7px 14px; cursor: pointer; font-weight: 600; text-decoration: none; }
			.duty-mention-opt:hover { background: var(--gray-100, #f5f5f5); }
			.duty-lead-addnote { margin-top: 8px; }
			.duty-lead-addnote input { font-size: 16px; }
			.duty-lead-close { display: flex; gap: 10px; margin-top: 16px; justify-content: flex-end; }
			.duty-lead-closedrow { display: flex; gap: 12px; align-items: center; padding: 8px 0; border-bottom: 1px solid var(--border-color); flex-wrap: wrap; }
			.duty-lead-closedrow b { flex: 1; }
			.duty-lead-reopen { cursor: pointer; font-size: var(--text-xs); }
			.duty-proj-cust { font-size: var(--text-xs); color: var(--text-color); font-weight: 600; }
			.duty-proj-cust-inline { font-size: var(--text-sm); color: var(--text-muted); font-weight: 600; }
			.duty-kb-count { color: var(--text-muted); font-weight: 600; }
			.duty-kb-add { margin-bottom: 8px; font-size: 16px; }
			.duty-kb-cards { min-height: 40px; display: flex; flex-direction: column; gap: 8px; }
			.duty-kb-over { outline: 2px dashed #0F5C55; outline-offset: -4px; }
			.duty-kb-card {
				background: var(--card-bg, #fff); border: 1px solid var(--border-color);
				border-radius: 8px; padding: 8px 10px; cursor: grab;
			}
			.duty-kb-card:active { cursor: grabbing; }
			.duty-kb-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
			.duty-kb-due { font-size: var(--text-xs); color: var(--text-muted); }
			.duty-kb-title { font-weight: 600; color: var(--text-color); }
			.duty-kb-meta { font-size: var(--text-xs); margin-top: 4px; }
			@media (max-width: 767px) {
				.duty-kb-col { min-width: 240px; flex: 0 0 240px; }
			}
			.duty-name-row { display: flex; align-items: center; gap: 8px; min-width: 0; }
			.duty-name-row .duty-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
			.duty-dm-btn {
				cursor: pointer; text-decoration: none; font-size: var(--text-sm);
				opacity: 0.5; position: relative; padding: 0 3px; flex: none;
			}
			.duty-dm-btn:hover { opacity: 1; }
			.duty-dm-badge {
				position: absolute; top: -8px; right: -10px;
				background: var(--red-500, #ef4444); color: #fff; border-radius: 99px;
				min-width: 16px; text-align: center; padding: 0 4px;
				font-size: 10px; line-height: 16px; font-style: normal;
			}
			.duty-dm-list {
				max-height: 46vh; min-height: 220px; overflow-y: auto;
				margin-bottom: 10px; border-bottom: 1px solid var(--border-color); padding-bottom: 6px;
			}
			.duty-dm-send { display: flex; gap: 8px; align-items: flex-end; }
			.duty-dm-send textarea { flex: 1; resize: none; font-size: 16px; }
			.duty-note-list { max-height: 300px; overflow-y: auto; }
			.duty-note-item { padding: 7px 0; border-bottom: 1px solid var(--border-color); }
			.duty-note-meta { font-size: var(--text-xs); display: flex; gap: 10px; font-weight: 600; }
			.duty-note-text { white-space: pre-wrap; word-break: break-word; margin-top: 2px; font-size: var(--text-sm); }
			.duty-note-add { display: flex; gap: 8px; margin-top: 12px; align-items: flex-end; }
			.duty-note-add textarea { flex: 1; resize: none; }
			.duty-session-time { margin-left: 8px; }
			.duty-team-title {
				margin: 24px 0 10px; font-weight: 600; color: var(--text-muted);
				text-transform: uppercase; letter-spacing: 0.04em; font-size: var(--text-sm);
			}
			.duty-team {
				display: grid; gap: 12px;
				grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
			}
			.duty-card {
				border: 1px solid var(--border-color); border-radius: var(--border-radius-lg, 10px);
				padding: 14px; background: var(--card-bg);
			}
			.duty-card-click { cursor: pointer; transition: box-shadow 0.15s ease, border-color 0.15s ease; }
			.duty-card-click:hover { border-color: var(--gray-400, #bdbdbd); box-shadow: var(--shadow-sm, 0 1px 4px rgba(0,0,0,0.08)); }
			.duty-card-more { margin-top: 6px; font-size: var(--text-xs); color: var(--text-muted); }
			.duty-detail-status { margin-bottom: 6px; }
			.duty-detail-title {
				margin: 14px 0 6px; font-weight: 600; font-size: var(--text-sm);
				text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-muted);
			}
			.duty-detail-tick { width: 22px; }
			.duty-card.collapsed .duty-card-body { display: none; }
			.duty-card-caret { color: var(--text-muted); font-size: var(--text-sm); width: 14px; flex: none; align-self: center; }
			.duty-card-head { cursor: pointer; }
			.duty-card.collapsed { padding-bottom: 10px; }
			.duty-card-head { display: flex; align-items: center; gap: 10px; }
			.duty-name { font-weight: 600; }
			.duty-badge {
				display: inline-flex; align-items: center; gap: 5px; margin-top: 3px;
				font-size: var(--text-xs); font-weight: 600; padding: 2px 8px; border-radius: 99px;
			}
			.duty-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
			.duty-card-body { margin-top: 10px; font-size: var(--text-sm); line-height: 1.6; }
			.duty-card-task { color: var(--text-color); font-weight: 500; }
			.duty-reason { font-style: italic; }
			.duty-summary { font-style: italic; color: var(--text-color); margin: 2px 0; }
			.duty-updated { margin-top: 16px; font-size: var(--text-xs); }
			.duty-daynum-table { width: 100%; border-collapse: collapse; margin-bottom: 12px; }
			.duty-daynum-table td { padding: 7px 4px; border-bottom: 1px solid var(--border-color); }
			.duty-daynum-head td { color: var(--text-muted); font-size: var(--text-sm); border-bottom: none; padding-bottom: 2px; }
			.duty-daynum-short td b { color: var(--red-600, #dc2626); }
			.duty-daynum-ok td b { color: var(--green-600, #2e7d32); }
			.duty-daynum-remark {
				margin-top: 8px; padding: 8px 12px; border-radius: 8px; font-size: var(--text-sm);
			}
			.duty-daynum-warn { background: var(--orange-100, #fff3e0); color: var(--orange-700, #e65100); }
			.duty-daynum-good { background: var(--green-100, #e8f5e9); color: var(--green-700, #2e7d32); }
		</style>`).appendTo("head");
	}
}
